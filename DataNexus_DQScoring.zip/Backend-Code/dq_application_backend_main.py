# dq_application_backend_main.py
# Entrypoint for the Data Quality application backend.
from __future__ import annotations

import json
import os
import sys
import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import httpx
from dotenv import load_dotenv

# PySpark imports
from pyspark.sql import SparkSession, DataFrame, Row
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, LongType, BooleanType,
    TimestampType
)
from pyspark.sql.window import Window

# 1️⃣ Load environment variables if any
load_dotenv()

# 2️⃣ Add project root to sys.path so that `dq_utils`, `dq_ingestion`, etc. can resolve
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 3️⃣ Application imports
from dq_utils.config_manager import ConfigManager
from dq_utils.input_manager import load_input_dataframe, create_input_widgets
from dq_utils.audit import AuditLogger
from dq_utils.notification_service import NotificationService

from dq_ingestion.autoloader_configs import AutoLoaderManager
from dq_ingestion.connector_clients import ConnectorClients
from dq_ingestion.custom_ingestors import CustomIngestors

from dq_engine.profiler import DataProfiler
from dq_engine.llm_interaction import GroqLLMInteraction
from dq_engine.rule_manager import DQRuleManager
from dq_engine.rule_translator import DQRuleTranslator
from dq_engine.metrics_calculator import DQMetricsCalculator

from dq_rag.vector_search_interface import DatabricksVectorSearchInterface
from dq_rag.embedding_generators import EmbeddingGenerator
from dq_rag.weaviate_fallback_client import WeaviateClientRAG

from dq_reporting.pdf_generator import PDFReportGenerator
from dq_orchestration.workflow_triggers import DatabricksWorkflowManager

# 4️⃣ Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(name)s - %(module)s - %(message)s"
)
logger = logging.getLogger(__name__)


async def main_dq_pipeline_async(
    spark_session: SparkSession,
    dbutils_instance,
    job_config_dict: Dict[str, Any]
) -> None:
    """
    Main async entrypoint to run the full Data Quality pipeline.
    """
    # — Initialization —
    config_mgr = ConfigManager(dbutils_instance=dbutils_instance)
    audit_logger = AuditLogger(spark_session, job_config_dict.get("audit_log_table_fqn"))
    notification_svc = NotificationService(config_mgr)
    run_user = job_config_dict.get("run_as_user", "dq_pipeline_service")

    # Log pipeline start
    audit_logger.log_event(
        user_id=run_user,
        action="DQ_PIPELINE_STARTED",
        details={"config": job_config_dict}
    )

    # 1️⃣ Data ingestion
    source_type = job_config_dict.get("source_type", "delta_table").lower()
    data_df: Optional[DataFrame] = None
    try:
        if source_type == "delta_table":
            table_fqn = job_config_dict["input_table_fqn"]
            data_df = spark_session.table(table_fqn)
        # (Extend here to handle CSV, Kafka, JDBC, etc.)
    except Exception as e:
        audit_logger.log_event(run_user, "DQ_PIPELINE_FAILED", {"reason": str(e)})
        raise

    total_records = data_df.count() if data_df else 0

    # 2️⃣ Profiling & LLM rule suggestion
    if job_config_dict.get("run_llm_rule_suggestion", False) and total_records > 0:
        profiler = DataProfiler(spark_session)
        profile = profiler.profile_dataframe(data_df, job_config_dict.get("input_table_fqn"))
        groq = GroqLLMInteraction(config_mgr)
        suggested = await groq.suggest_dq_rules(
            profile,
            num_suggestions=int(job_config_dict.get("num_llm_rule_suggestions", 5))
        )
        if suggested:
            mgr = DQRuleManager(spark_session, job_config_dict.get("dq_rules_table_fqn"))
            mgr.save_rules(suggested, mode="append")
            audit_logger.log_event(run_user, "LLM_RULES_SUGGESTED", {"count": len(suggested)})

    # 3️⃣ Load active rules
    rule_mgr = DQRuleManager(spark_session, job_config_dict.get("dq_rules_table_fqn"))
    active_rules_df = rule_mgr.load_active_rules()

    # 4️⃣ Execute rules & collect failures
    translator = DQRuleTranslator(spark_session)
    failing_dfs = []
    if total_records > 0:
        for row in active_rules_df.collect():
            df_fail = translator.translate_rule_to_spark_df_operation(data_df, row.asDict())
            if df_fail and not df_fail.rdd.isEmpty():
                failing_dfs.append(df_fail)

    all_failures_df: Optional[DataFrame] = None
    if failing_dfs:
        from functools import reduce
        all_failures_df = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), failing_dfs)
        all_failures_df.write.format("delta").mode("overwrite") \
            .saveAsTable(job_config_dict.get("dq_all_failures_table_fqn"))

    # 5️⃣ Calculate metrics
    metrics_calc = DQMetricsCalculator(spark_session)
    scores = metrics_calc.calculate_rule_and_dimension_scores(
        total_records_in_table=total_records,
        all_failing_records_df=all_failures_df,
        rules_config_df=active_rules_df
    )
    audit_logger.log_event(run_user, "DQ_SCORES_CALCULATED", {"scores": scores})

    # 6️⃣ Send alerts if below threshold
    threshold = float(job_config_dict.get("alert_threshold", 75))
    if scores.get("overall_dq_score", 100) < threshold:
        notification_svc.send_email(
            subject=f"DQ Alert: Score {scores['overall_dq_score']}% below {threshold}%",
            body_html=f"<p>Overall DQ score {scores['overall_dq_score']}% is below threshold {threshold}%.</p>"
        )
        audit_logger.log_event(run_user, "DQ_ALERT_TRIGGERED", {"score": scores["overall_dq_score"]})

    # 7️⃣ Generate & store PDF report
    report_gen = PDFReportGenerator(dbutils_instance, template_dir=job_config_dict.get("report_template_dir"))
    report_data = {
        "report_title": f"DQ Report: {job_config_dict.get('input_table_fqn')}",
        "overall_score": scores["overall_dq_score"],
        "dimensions": scores["dimensions"],
        "rules_summary": scores["rules"],
        "generation_date": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    }
    local_pdf = f"/dbfs/tmp/dq_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    if report_gen.generate_pdf_report(report_data, job_config_dict.get("report_html_template_name"), local_pdf):
        target_path = job_config_dict.get("output_report_uc_path_prefix").rstrip("/") + \
                      f"/dq_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        report_gen.store_pdf_to_uc_volume_or_dbfs(local_pdf, target_path)
        audit_logger.log_event(run_user, "DQ_REPORT_GENERATED_STORED", {"path": target_path})


if __name__ == "__main__":
    # — Initialize Spark session —
    spark = SparkSession.builder.appName("DQApplicationJob").getOrCreate()

    # — Obtain dbutils (for widgets & secrets) —
    dbutils = globals().get("dbutils", None)

    # — Initialize ConfigManager (loads .env, widgets, secrets) —
    config_mgr = ConfigManager(dbutils_instance=dbutils)

    # — Load input DataFrame via input_manager —
    input_df = load_input_dataframe(spark, dbutils, config_mgr)
    total_records = input_df.count() if input_df is not None else 0
    logger.info(f"Loaded input source with {total_records} records.")

    # — Gather job configuration parameters —
    EXPECTED_PARAMS = {
        "input_table_fqn": None,
        "dq_rules_table_fqn": None,
        "dq_all_failures_table_fqn": "/tmp/dq_failures",
        "audit_log_table_fqn": "governance_catalog.audit_db.application_events_log",
        "source_type": "delta_table",
        "run_llm_rule_suggestion": "false",
        "num_llm_rule_suggestions": "5",
        "report_template_dir": "templates",
        "report_html_template_name": "dq_report.html",
        "output_report_uc_path_prefix": "/tmp/dq_reports",
        "alert_threshold": "75"
    }
    job_config: Dict[str, Any] = {}
    for key, default in EXPECTED_PARAMS.items():
        job_config[key] = config_mgr.get_config(key, default=default)

    # — Validate mandatory params —
    if not job_config["input_table_fqn"]:
        raise ValueError("Missing required parameter 'input_table_fqn'.")
    if not job_config["dq_rules_table_fqn"]:
        raise ValueError("Missing required parameter 'dq_rules_table_fqn'.")

    # — Ensure input table exists if using delta_table source —
    if job_config["source_type"] == "delta_table" and not spark.catalog.tableExists(job_config["input_table_fqn"]):
        raise ValueError(f"Input table '{job_config['input_table_fqn']}' not found.")

    # — Convert boolean flags & numeric types —
    job_config["run_llm_rule_suggestion"] = str(job_config["run_llm_rule_suggestion"]).lower() == "true"
    try:
        job_config["num_llm_rule_suggestions"] = int(job_config.get("num_llm_rule_suggestions", 5))
    except ValueError:
        job_config["num_llm_rule_suggestions"] = 5

    # — Run the async DQ pipeline —
    import nest_asyncio
    nest_asyncio.apply()
    asyncio.run(
        main_dq_pipeline_async(
            spark_session=spark,
            dbutils_instance=dbutils,
            job_config_dict={**job_config, "total_records": total_records}
        )
    )

    # — Stop Spark session —
    spark.stop()
