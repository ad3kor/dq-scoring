# Databricks notebook source
# MAGIC %pip install -r /Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/requirements.txt

# COMMAND ----------

import streamlit as st
import pandas as pd
import time
import re # Added for regex in Accuracy
import json # Added for params in Accuracy (Range Check)

# --- Page Configuration ---
st.set_page_config(
    page_title="DQ App - Phase 1",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- Helper Functions & Mock Data ---
def mock_dq_processing(data_source_name, rules, data_sample):
    """Simulates a DQ processing engine (like a Spark job)."""
    st.info(f"🚀 Starting DQ processing for '{data_source_name}'...")
    log_messages = [
        f"[INFO] Connecting to data source: {data_source_name}",
        f"[INFO] Applying {len(rules)} DQ rules...",
    ]

    results = {"overall_dq_score": 0, "dimension_scores": {}, "rule_results": []}
    num_rules = len(rules)
    if num_rules == 0:
        log_messages.append("[WARNING] No DQ rules defined. Skipping processing.")
        st.warning("No DQ rules defined to process.")
        results["overall_dq_score"] = None # Or some other indicator for no rules
        return results, log_messages

    passed_rules_count = 0

    if data_sample is not None and not data_sample.empty:
        log_messages.append(f"[INFO] Analyzing {len(data_sample)} sample records.")
        for i, rule in enumerate(rules):
            progress = (i + 1) / num_rules
            log_messages.append(f"[PROGRESS] Processing rule {i+1}/{num_rules}: '{rule['name']}' on column '{rule['column']}' ({rule['dimension']}/{rule['type']})")
            time.sleep(0.5) # Simulate processing time

            rule_passed = True # Assume rule passes by default
            log_detail = "Default pass"

            if rule['column'] not in data_sample.columns:
                log_messages.append(f"  [WARNING] Column '{rule['column']}' not found in data sample for rule '{rule['name']}'. Skipping specific check.")
                rule_passed = False # Or treat as a failure, or skip scoring for this rule
                log_detail = f"Column '{rule['column']}' not found."
            else:
                # --- Completeness Check ---
                if rule['dimension'] == "Completeness" and rule['type'] == "Completeness":
                    null_count = data_sample[rule['column']].isnull().sum()
                    if null_count == 0:
                        rule_passed = True
                        log_detail = f"All records are non-null in '{rule['column']}'."
                    else:
                        rule_passed = False
                        log_detail = f"Found {null_count} nulls in '{rule['column']}'."
                    log_messages.append(f"  [DETAIL] Completeness check on '{rule['column']}': {log_detail}")

                # --- Uniqueness Check ---
                elif rule['dimension'] == "Uniqueness" and rule['type'] == "Uniqueness":
                    duplicate_count = data_sample[rule['column']].duplicated().sum()
                    if duplicate_count == 0:
                        rule_passed = True
                        log_detail = f"All records are unique in '{rule['column']}'."
                    else:
                        rule_passed = False
                        log_detail = f"Found {duplicate_count} duplicates in '{rule['column']}'."
                    log_messages.append(f"  [DETAIL] Uniqueness check on '{rule['column']}': {log_detail}")

                # --- Accuracy Checks ---
                elif rule['dimension'] == "Accuracy":
                    if rule['type'] == "Format (Regex)":
                        # Mock: Check if email column contains '@'
                        # A real implementation would use rule['params'] for the regex pattern
                        if 'email' in rule['column'].lower(): # Simple check for email-like column
                            valid_formats = data_sample[rule['column']].astype(str).str.contains('@', na=False)
                            num_valid = valid_formats.sum()
                            num_total_non_na = data_sample[rule['column']].notna().sum()
                            if num_total_non_na > 0:
                                rule_passed = (num_valid == num_total_non_na)
                                log_detail = f"{num_valid}/{num_total_non_na} non-null records in '{rule['column']}' contain '@'."
                            else:
                                rule_passed = True # No non-null data to check
                                log_detail = f"No non-null data in '{rule['column']}' to check format."
                        else: # Fallback for other columns
                            rule_passed = (i % 2 == 0) # Random pass/fail for non-email columns
                            log_detail = f"Mock format check: {'Passed' if rule_passed else 'Failed'}."
                        log_messages.append(f"  [DETAIL] Accuracy (Format) on '{rule['column']}': {log_detail}")

                    elif rule['type'] == "Range Check":
                        # Mock: Check if quantity > 0
                        # A real implementation would parse min/max from rule['params']
                        if 'quantity' in rule['column'].lower() or 'age' in rule['column'].lower(): # Simple check for quantity-like column
                            try:
                                numeric_column = pd.to_numeric(data_sample[rule['column']], errors='coerce')
                                valid_range = numeric_column[numeric_column.notna()] > 0
                                num_valid = valid_range.sum()
                                num_total_numeric_non_na = numeric_column.notna().sum()
                                if num_total_numeric_non_na > 0:
                                    rule_passed = (num_valid == num_total_numeric_non_na)
                                    log_detail = f"{num_valid}/{num_total_numeric_non_na} numeric non-null records in '{rule['column']}' are > 0."
                                else:
                                    rule_passed = True # No numeric non-null data
                                    log_detail = f"No numeric non-null data in '{rule['column']}' for range check."
                            except Exception as e:
                                rule_passed = False
                                log_detail = f"Error during range check on '{rule['column']}': {e}"
                        else: # Fallback for other columns
                            rule_passed = (i % 2 != 0) # Random pass/fail
                            log_detail = f"Mock range check: {'Passed' if rule_passed else 'Failed'}."
                        log_messages.append(f"  [DETAIL] Accuracy (Range) on '{rule['column']}': {log_detail}")
                    else: # Fallback for other accuracy types
                        rule_passed = (i % 2 == 0)
                        log_detail = f"Generic accuracy check: {'Passed' if rule_passed else 'Failed'}."
                        log_messages.append(f"  [DETAIL] Accuracy (Other) on '{rule['column']}': {log_detail}")


                # --- Consistency Check ---
                elif rule['dimension'] == "Consistency":
                    # Mock: If 'email' (rule['column']) is present, 'signup_date' (related_column) must be present.
                    # This is a highly specific mock for the "ProductionDB_Customers_Table" data.
                    # A real system would parse rule['params'] for related columns and conditions.
                    related_column = 'signup_date' # Example related column
                    if rule['column'] == 'email' and related_column in data_sample.columns:
                        consistent_count = 0
                        relevant_rows = 0
                        for _, row_data in data_sample.iterrows():
                            if pd.notna(row_data[rule['column']]): # If primary column is not null
                                relevant_rows +=1
                                if pd.notna(row_data[related_column]): # Check if related column is also not null
                                    consistent_count += 1
                        if relevant_rows > 0:
                            rule_passed = (consistent_count == relevant_rows) # All relevant rows must be consistent
                            log_detail = f"{consistent_count}/{relevant_rows} records consistent between '{rule['column']}' and '{related_column}'."
                        else:
                            rule_passed = True # No relevant data to check for inconsistency
                            log_detail = f"No relevant data to check consistency between '{rule['column']}' and '{related_column}'."
                    else: # Fallback for other consistency rules or different datasets
                        rule_passed = (i % 3 == 0) # Different random pattern
                        log_detail = f"Mock consistency check: {'Passed' if rule_passed else 'Failed'}."
                    log_messages.append(f"  [DETAIL] Consistency check on '{rule['column']}': {log_detail}")
                else: # Fallback for unhandled dimension/type combinations
                    rule_passed = (i % 2 == 0) # Original random pass/fail
                    log_detail = f"Generic mock rule execution: {'Passed' if rule_passed else 'Failed'}."
                    log_messages.append(f"  [DETAIL] Generic check for '{rule['column']}': {log_detail}")


            results["rule_results"].append({
                "name": rule['name'],
                "dimension": rule['dimension'],
                "type": rule['type'],
                "column": rule['column'],
                "status": "PASS" if rule_passed else "FAIL",
                "details": log_detail
            })
            if rule_passed:
                passed_rules_count +=1
    else:
        log_messages.append("[WARNING] No data sample provided or data sample is empty. Mocking rule outcomes.")
        for i, rule in enumerate(rules): # Simplified mocking if no data
            rule_passed = (i % 2 == 0)
            results["rule_results"].append({
                "name": rule['name'],
                "dimension": rule['dimension'],
                "type": rule['type'],
                "column": rule['column'],
                "status": "PASS" if rule_passed else "FAIL",
                "details": f"Mocked due to no data sample"
            })
            if rule_passed:
                passed_rules_count +=1

    results["overall_dq_score"] = (passed_rules_count / num_rules) * 100 if num_rules > 0 else 0

    dimensions = ["Accuracy", "Completeness", "Consistency", "Uniqueness"]
    for dim in dimensions:
        dim_rules = [r for r in results["rule_results"] if r["dimension"] == dim]
        if dim_rules:
            passed_dim_rules = sum(1 for r in dim_rules if r["status"] == "PASS")
            results["dimension_scores"][dim] = (passed_dim_rules / len(dim_rules)) * 100
        else:
            results["dimension_scores"][dim] = None

    log_messages.append(f"[INFO] DQ Processing completed. Overall Score: {results['overall_dq_score']:.2f}%")
    st.success(f"✅ DQ Processing completed for '{data_source_name}'!")
    return results, log_messages

# --- Initialize Session State ---
if 'dq_rules_phase1' not in st.session_state:
    st.session_state.dq_rules_phase1 = []
if 'logs_phase1' not in st.session_state:
    st.session_state.logs_phase1 = ["[INFO] Application started. Ready for DQ configuration."]
if 'dq_results_phase1' not in st.session_state:
    st.session_state.dq_results_phase1 = None
if 'uploaded_file_data_phase1' not in st.session_state:
    st.session_state.uploaded_file_data_phase1 = None
if 'uploaded_file_name_phase1' not in st.session_state: # To store the name of the uploaded file
    st.session_state.uploaded_file_name_phase1 = None


# --- Sidebar for Configuration ---
with st.sidebar:
    st.header("⚙️ Phase 1 Configuration")
    st.markdown("""
    **Core Infrastructure & Foundational DQ Engine**

    This phase focuses on:
    1.  Establishing core environment concepts.
    2.  Developing initial ingestion pipelines (mocked).
    3.  Implementing the DQ processing engine with manual rules.
    """)

    st.subheader("🌍 Environment Setup (Conceptual)")
    st.info("""
    -   **Databricks Workspaces**: Dev, Stg, Prod (Conceptual)
    -   **Unity Catalog**: Central governance (Conceptual)
    -   **Secret Management**: Secure credentials (Conceptual)
    """)

    st.subheader("📊 Data Source Selection")
    data_source_options = ["Upload CSV/Parquet", "Mock Database A (Customers)", "Mock Cloud Storage (Orders)"]
    selected_data_source_type = st.selectbox("Select Data Source Type", data_source_options, key="ph1_dst_select")

    current_data_source_name = "N/A"
    if selected_data_source_type == "Upload CSV/Parquet":
        uploaded_file = st.file_uploader("Upload your data file (CSV or Parquet)", type=["csv", "parquet"], key="ph1_uploader")
        if uploaded_file:
            st.session_state.uploaded_file_name_phase1 = uploaded_file.name
            current_data_source_name = uploaded_file.name
            try:
                if uploaded_file.name.endswith('.csv'):
                    st.session_state.uploaded_file_data_phase1 = pd.read_csv(uploaded_file)
                elif uploaded_file.name.endswith('.parquet'):
                    st.session_state.uploaded_file_data_phase1 = pd.read_parquet(uploaded_file)
                st.success(f"Uploaded '{uploaded_file.name}' successfully!")
            except Exception as e:
                st.error(f"Error reading file: {e}")
                st.session_state.uploaded_file_data_phase1 = None
                st.session_state.uploaded_file_name_phase1 = None
        elif st.session_state.uploaded_file_name_phase1: # If a file was previously uploaded
            current_data_source_name = st.session_state.uploaded_file_name_phase1
            # Data is already in st.session_state.uploaded_file_data_phase1
        else:
            current_data_source_name = "No file uploaded"
            st.session_state.uploaded_file_data_phase1 = None


    elif selected_data_source_type == "Mock Database A (Customers)":
        current_data_source_name = "ProductionDB_Customers_Table"
        st.session_state.uploaded_file_data_phase1 = pd.DataFrame({
            'customer_id': [1, 2, 3, 4, 2, 6],
            'email': ['a@test.com', 'b@test.com', None, 'd_test.com', 'b@test.com', 'f@test.com'], # Added an invalid email
            'age': [25, 30, -5, 40, 30, 28], # Added a negative age
            'signup_date': ['2023-01-01', '2023-01-15', '2023-02-01', '2023-02-10', '2023-01-15', None] # Added a None for consistency check
        })
        st.caption(f"Using mock data for {current_data_source_name}")
    else: # Mock Cloud Storage (Orders)
        current_data_source_name = "S3_Orders_Bucket_DailyFeed"
        st.session_state.uploaded_file_data_phase1 = pd.DataFrame({
            'order_id': [101, 102, 103, 103, 105, 106],
            'product_id': ['P10', 'P11', 'P12', 'P12', 'P13', 'P14'],
            'quantity': [1, None, 2, 2, 3, 0], # Added a zero quantity
            'order_date': ['2023-03-01', '2023-03-01', '2023-03-02', '2023-03-02', '2023-03-03', '2023-03-04']
        })
        st.caption(f"Using mock data for {current_data_source_name}")

    st.markdown("---")
    st.subheader("📜 Manual DQ Rule Definition")
    # Ensure rule types are comprehensive enough for dimensions
    rule_type_options = ["Completeness", "Uniqueness", "Format (Regex)", "Range Check", "Cross-Column Consistency"]

    with st.form("dq_rule_form_phase1", clear_on_submit=True):
        rule_name = st.text_input("Rule Name (e.g., 'Email Format Check')")
        rule_dimension = st.selectbox("DQ Dimension", ["Accuracy", "Completeness", "Consistency", "Uniqueness"])
        rule_column = st.text_input("Target Column Name (e.g., 'email')")
        # Filter rule types based on dimension for better UX, or keep all and let logic handle
        rule_type = st.selectbox("Rule Type", rule_type_options)
        rule_params = st.text_area("Rule Parameters (e.g., regex for Format, JSON for Range {'min':0,'max':100}, JSON for Consistency {'related_column':'col_b'})")

        submitted = st.form_submit_button("Add DQ Rule")
        if submitted and rule_name and rule_dimension and rule_column and rule_type:
            st.session_state.dq_rules_phase1.append({
                "name": rule_name,
                "dimension": rule_dimension,
                "column": rule_column,
                "type": rule_type,
                "params": rule_params
            })
            st.success(f"Rule '{rule_name}' added!")
            st.session_state.logs_phase1.append(f"[CONFIG] DQ Rule '{rule_name}' ({rule_dimension}/{rule_type}) added for column '{rule_column}'.")
        elif submitted:
            st.error("Please fill in all rule fields.")


# --- Main Page Layout ---
st.title("📊 Data Quality Application - Phase 1")
st.markdown("Foundational DQ Engine with Manual Rule Definition")

# Display Data Sample if available
if st.session_state.uploaded_file_data_phase1 is not None:
    with st.expander("View Data Sample (First 10 rows)", expanded=False):
        st.dataframe(st.session_state.uploaded_file_data_phase1.head(10))

col1, col2 = st.columns(2)

with col1:
    st.subheader("📋 Defined DQ Rules")
    if not st.session_state.dq_rules_phase1:
        st.info("No DQ rules defined yet. Add rules using the sidebar form.")
    else:
        rules_to_remove = []
        for i, rule in enumerate(st.session_state.dq_rules_phase1):
            with st.expander(f"{rule['name']} ({rule['dimension']}/{rule['type']} on '{rule['column']}')"):
                st.json(rule)
                if st.button(f"Remove Rule '{rule['name']}'", key=f"remove_rule_{i}_phase1"):
                    rules_to_remove.append(i) # Mark for removal

        if rules_to_remove:
            for index in sorted(rules_to_remove, reverse=True): # Remove from end to avoid index shifts
                removed_rule = st.session_state.dq_rules_phase1.pop(index)
                st.session_state.logs_phase1.append(f"[CONFIG] DQ Rule '{removed_rule['name']}' removed.")
            st.rerun()


with col2:
    st.subheader("🚀 Trigger DQ Assessment")
    st.markdown(f"**Target Data Source:** `{current_data_source_name}`")

    if not st.session_state.dq_rules_phase1:
        st.warning("Add at least one DQ rule to run an assessment.")
    elif st.session_state.uploaded_file_data_phase1 is None and "Mock" not in selected_data_source_type :
        st.warning(f"Please upload a data file for '{current_data_source_name}' or select a mock data source.")
    else:
        if st.button("▶️ Run DQ Assessment", type="primary", use_container_width=True):
            st.session_state.logs_phase1.append(f"[ACTION] DQ Assessment triggered for '{current_data_source_name}'.")
            with st.spinner(f"Running DQ assessment on '{current_data_source_name}'... This is a simulation."):
                results, new_logs = mock_dq_processing(current_data_source_name, st.session_state.dq_rules_phase1, st.session_state.uploaded_file_data_phase1)
                st.session_state.dq_results_phase1 = results
                st.session_state.logs_phase1.extend(new_logs)


# --- Display DQ Results ---
if st.session_state.dq_results_phase1:
    st.subheader("📈 DQ Assessment Results")
    results = st.session_state.dq_results_phase1

    if results["overall_dq_score"] is not None:
        st.metric("Overall DQ Score", f"{results['overall_dq_score']:.2f}%")

        st.markdown("**Dimension Scores:**")
        # Ensure all dimensions are present in the scores dictionary for consistent display
        all_dims = ["Accuracy", "Completeness", "Consistency", "Uniqueness"]
        display_scores = {dim: results['dimension_scores'].get(dim) for dim in all_dims}

        dim_cols = st.columns(len(all_dims))
        for idx, (dim, score) in enumerate(display_scores.items()):
            with dim_cols[idx]:
                st.metric(dim, f"{score:.2f}%" if score is not None else "N/A")

        st.markdown("**Rule Details:**")
        if results['rule_results']:
            results_df = pd.DataFrame(results['rule_results'])
            st.dataframe(results_df[['name', 'dimension', 'type', 'column', 'status', 'details']])
        else:
            st.info("No rules were processed to show details.")
    else:
        st.info("DQ Assessment was run, but no rules were defined or applicable to produce a score.")


# --- Logging Area ---
st.subheader("📝 Application Logs")
log_container = st.container(height=300)
with log_container:
    for log_entry in reversed(st.session_state.logs_phase1): # Show newest logs first
        if "[INFO]" in log_entry:
            st.text(log_entry)
        elif "[WARNING]" in log_entry:
            st.warning(log_entry)
        elif "[ERROR]" in log_entry:
            st.error(log_entry)
        elif "[CONFIG]" in log_entry:
            st.caption(log_entry)
        elif "[ACTION]" in log_entry:
            st.caption(f"➡️ {log_entry}")
        elif "[PROGRESS]" in log_entry:
            st.caption(f"⏳ {log_entry}")
        else:
            st.text(log_entry)

st.caption("End of Phase 1 Application.")


# COMMAND ----------

!streamlit run /databricks/python_shell/scripts/db_ipykernel_launcher.py

# COMMAND ----------

# src/dq_app/__init__.py
# This file can remain empty. It marks the 'dq_app' directory as a Python package.
# At the top of src/dq_app/app.py (and relevant files in pages/)
import sys
import os

# This navigates from src/dq_app/app.py up one level to src/
# ensuring that dq_core (which is in src/dq_core) can be found.
project_src_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
if project_src_path not in sys.path:
    sys.path.append(project_src_path)

# Now your imports should work:
# import streamlit as st
# from dq_core.utils.logging_config import setup_logging
# ...
# src/dq_app/app.py
# Main Streamlit application file
import streamlit as st
from dq_core.utils.logging_config import setup_logging # Assuming utils are in PYTHONPATH

# Setup logger for the Streamlit app
logger = setup_logging(log_level="INFO") # Configure as needed

def main():
    """
    Main function to run the Streamlit application.
    """
    st.set_page_config(
        page_title="Petabyte DQ Application",
        page_icon="📊",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    logger.info("Streamlit application started.")

    st.sidebar.title("DQ Application Navigator")
    # Navigation will be handled by Streamlit's multi-page app feature
    # by placing .py files in a 'pages' directory.

    st.title("Petabyte-Scale Data Quality Application 📊")
    st.markdown("""
    Welcome to the Production-Grade Data Quality (DQ) application.
    Use the sidebar to navigate to different sections of the application.
    """)

    st.header("Overview")
    st.markdown("""
    This application provides a comprehensive suite of tools for managing and ensuring
    data quality at petabyte scale. Key features include:
    - Interactive data source selection and configuration.
    - LLM-powered and manual Data Quality (DQ) rule definition and management.
    - Execution of DQ assessments on massive datasets.
    - Generation of detailed PDF DQ reports.
    - Advanced issue investigation using a Retrieval Augmented Generation (RAG) pipeline.

    **Current Phase: Phase 2 - Chatbot UI (Alpha) and Basic Reporting**
    """)

    # Placeholder for future dashboard elements
    st.subheader("DQ Metrics Summary (Placeholder)")
    col1, col2, col3 = st.columns(3)
    col1.metric("Overall DQ Score", "N/A", delta_color="off")
    col2.metric("Sources Monitored", "0", delta_color="off")
    col3.metric("Active DQ Rules", "0", delta_color="off")

if __name__ == "__main__":
    main()

# src/dq_app/pages/01_Data_Source_Selection.py
# Streamlit page for Data Source Selection
import streamlit as st
from dq_core.utils.logging_config import setup_logging

logger = setup_logging(log_level="INFO")

st.set_page_config(page_title="Data Source Selection", layout="wide")

st.title("🔎 Data Source Selection and Configuration")
st.markdown("""
Here you can select and configure the data sources for Data Quality assessment.
This section will allow you to connect to various data platforms and specify
datasets for analysis.
""")

# --- Data Source Type Selection ---
st.header("1. Select Data Source Type")
source_types = [
    "Select a type...",
    "Delta Lake Table",
    "AWS S3 (Parquet, JSON, CSV, Excel)",
    "Relational Database (e.g., PostgreSQL, MySQL)", # Placeholder, specific connectors needed
    "NoSQL Database (e.g., Cassandra, MongoDB)",   # Placeholder, specific connectors needed
    "Web API",
    "File Upload (CSV, Excel)"
]
selected_source_type = st.selectbox("Choose the type of your data source:", source_types, key="data_source_type_selector")
logger.info(f"User selected data source type: {selected_source_type}")

# --- Configuration Area (Dynamic based on selection) ---
st.header("2. Configure Data Source")

if selected_source_type == "Delta Lake Table":
    st.subheader("Delta Lake Configuration")
    delta_table_name = st.text_input("Delta Table Name (e.g., catalog.schema.table):", key="delta_table_name")
    # Add more Delta Lake specific options if needed (e.g., version, timestamp)
    if delta_table_name:
        st.write(f"Configured Delta Table: `{delta_table_name}`")

elif selected_source_type == "AWS S3 (Parquet, JSON, CSV, Excel)":
    st.subheader("AWS S3 Configuration")
    s3_path = st.text_input("S3 Path (e.g., s3://bucket-name/path/to/data/):", key="s3_path")
    s3_file_format = st.selectbox("File Format:", ["Parquet", "JSON", "CSV", "Excel"], key="s3_file_format")
    
    if s3_file_format == "CSV":
        csv_header = st.checkbox("Does the CSV file have a header?", True, key="csv_header")
        csv_delimiter = st.text_input("CSV Delimiter:", ",", max_chars=1, key="csv_delimiter")
    elif s3_file_format == "Excel":
        excel_sheet_name = st.text_input("Sheet Name (optional, defaults to first sheet):", key="excel_sheet_name")
        excel_header_row = st.number_input("Header Row (0-indexed):", value=0, min_value=0, key="excel_header_row")

    if s3_path:
        st.write(f"Configured S3 Path: `{s3_path}` with format `{s3_file_format}`")

elif selected_source_type == "File Upload (CSV, Excel)":
    st.subheader("File Upload Configuration")
    uploaded_file = st.file_uploader("Upload your file (CSV or Excel):", type=["csv", "xlsx", "xls"], key="file_uploader")
    if uploaded_file is not None:
        st.write(f"File uploaded: `{uploaded_file.name}` (Size: {uploaded_file.size} bytes)")
        # In a real scenario, this file would be saved to a staging area (e.g., DBFS, S3 volume)
        # and then processed by Auto Loader or Spark.

# --- Placeholder for other source types ---
elif selected_source_type not in ["Select a type...", "Delta Lake Table", "AWS S3 (Parquet, JSON, CSV, Excel)", "File Upload (CSV, Excel)"]:
    st.warning(f"Configuration for '{selected_source_type}' is not yet implemented in this Alpha version.")

# --- Action Button ---
st.header("3. Proceed with Configuration")
if st.button("Save and Proceed to Rule Definition", key="save_source_config_button", type="primary", \
             disabled=(selected_source_type == "Select a type...")):
    # Placeholder for action:
    # 1. Validate configuration
    # 2. Store configuration (e.g., in session state, or pass to backend)
    # 3. Navigate to the next step (DQ Rule Definition page - to be created)
    logger.info(f"User clicked 'Save and Proceed' for source type: {selected_source_type}")
    st.success("Data source configuration saved (Placeholder). Ready to define DQ rules.")
    # Example of storing in session state:
    # st.session_state['current_data_source_config'] = {
    #     "type": selected_source_type,
    #     "details": { ... collected details ... }
    # }
    # st.switch_page("pages/02_DQ_Rule_Definition.py") # If using st.switch_page (Streamlit 1.30+)

# --- Display current session state for debugging (optional) ---
if st.checkbox("Show Session State (Debug)", key="show_session_state_datasource"):
    st.write(st.session_state)

/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/__init__.py
# src/dq_core/reporting/__init__.py
# This file can remain empty. It marks the 'reporting' directory as a Python package.


# src/dq_core/reporting/pdf_report_generator.py
import logging
from typing import Dict, List, Any
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.axes import XCategoryAxis, YValueAxis
from reportlab.graphics.charts.textlabels import Label

# Setup logger for the reporting module
logger = logging.getLogger("dq_application.reporting")


class PDFReportGenerator:
    """
    Generates PDF Data Quality reports, structured like 'actual_output.pdf'.
    This is a placeholder for Phase 2. Actual implementation will use libraries like ReportLab.
    """

    def __init__(self, report_data: Dict[str, Any]):
        """
        Initializes the report generator with data.

        Args:
            report_data (Dict[str, Any]): A dictionary containing all necessary data
                                          for the DQ report. Expected keys based on 'actual_output.pdf':
                                          - 'report_title' (str, e.g., "Data Quality Scoring Report")
                                          - 'data_source_name' (str, used for context if not in title)
                                          - 'report_date' (str)
                                          - 'dimensions' (List[Dict]), where each dict has:
                                            - 'name' (str, e.g., "Accuracy")
                                            - 'weight_percentage' (float, e.g., 40 for 40%)
                                            - 'score_0_10' (float)
                                            - 'observations' (str)
                                          - 'weighted_score_data' (Dict), with:
                                            - 'total_weight_percentage' (float, e.g., 100)
                                            - 'overall_score_0_10' (float, e.g., 6.75)
                                            - 'summary_observations' (str)
                                          - 'chart_image_path' (str, optional): Path to a pre-generated chart image.
                                            Alternatively, chart data to be generated by ReportLab.
        """
        self.report_data = report_data
        self.file_path = None
        # self.styles = getSampleStyleSheet() # For ReportLab
        logger.info("PDFReportGenerator initialized with new data structure.")

    def generate_report(self, output_file_path: str) -> bool:
        """
        Generates the PDF report and saves it to the specified path.
        The placeholder output now mimics the structure of 'actual_output.pdf'.

        Args:
            output_file_path (str): The full path where the PDF report will be saved.

        Returns:
            bool: True if report generation was successful, False otherwise.
        """
        self.file_path = output_file_path
        logger.info(f"Attempting to generate PDF report (actual_output.pdf structure) at: {self.file_path}")

        try:
            # --- Placeholder for ReportLab implementation ---
            doc = SimpleDocTemplate(output_file_path, pagesize=letter)
            story = []
            styles = getSampleStyleSheet()

            # 1. Report Title
            story.append(Paragraph(self.report_data.get('report_title', "Data Quality Scoring Report"), styles['h1']))
            story.append(Spacer(1, 0.2*inch))
            story.append(Paragraph(f"Data Source: {self.report_data.get('data_source_name', 'N/A')}", styles['h3']))
            story.append(Paragraph(f"Report Date: {self.report_data.get('report_date', 'N/A')}", styles['Normal']))
            story.append(Spacer(1, 0.3*inch))

            # 2. Score Visualization (Bar Chart)
            # This would involve using reportlab.graphics.charts.barcharts.VerticalBarChart
            # and reportlab.graphics.shapes.Drawing.
            # Or, if an image is pre-generated:
            if self.report_data.get('chart_image_path'):
                story.append(Image(self.report_data['chart_image_path'], width=6*inch, height=3*inch)) # Adjust size
            story.append(Paragraph("Data Quality Scores per Dimension (Chart Placeholder)", styles['h2']))
            story.append(Spacer(1, 0.2*inch))


            # 3. Data Quality Scores per Dimension (Table)
            story.append(Paragraph("Data Quality Scores per Dimension:", styles['h2']))
            table_data = [["Dimension", "Weight (%)", "Score (0-10)", "Observations"]]
            for dim in self.report_data.get('dimensions', []):
                table_data.append([
                    dim.get('name', 'N/A'),
                    f"{dim.get('weight_percentage', 0):.0f}", # Assuming weight is 0-100
                    f"{dim.get('score_0_10', 0.0):.1f}",
                    Paragraph(dim.get('observations', ''), styles['Normal']) # Allow observations to wrap
                ])
            
            # Weighted Score Row
            weighted_data = self.report_data.get('weighted_score_data', {})
            table_data.append([
                "Weighted Score",
                f"{weighted_data.get('total_weight_percentage', 100):.0f}%",
                f"{weighted_data.get('overall_score_0_10', 0.0):.2f}", # Display with 2 decimal places
                Paragraph(weighted_data.get('summary_observations', ''), styles['Normal'])
            ])
            
            dq_table = Table(table_data, colWidths=[1.5*inch, 1*inch, 1*inch, 3*inch]) # Adjust colWidths
            dq_table.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.grey),
                ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
                ('ALIGN', (0,0), (-1,-1), 'CENTER'),
                ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
                ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
                ('BOTTOMPADDING', (0,0), (-1,0), 12),
                ('BACKGROUND', (0,1), (-1,-1), colors.beige),
                ('GRID', (0,0), (-1,-1), 1, colors.black),
                ('ALIGN', (3,1), (3,-1), 'LEFT'), # Align observations to the left
            ]))
            story.append(dq_table)
            story.append(Spacer(1, 0.3*inch))

            # Build the PDF
            doc.build(story)
            
            # Simulate file creation for now, reflecting the new structure
            with open(output_file_path, 'w') as f:
                f.write(f"{self.report_data.get('report_title', 'Data Quality Scoring Report')}\n")
                f.write(f"Data Source: {self.report_data.get('data_source_name', 'N/A')}\n")
                f.write(f"Report Date: {self.report_data.get('report_date', 'N/A')}\n\n")

                f.write("Data Quality Scores per Dimension (Chart Placeholder)\n")
                # Placeholder for chart data or image reference
                f.write("====================================================\n\n")

                f.write("Data Quality Scores per Dimension:\n")
                f.write("----------------------------------------------------------------------------------------------------------\n")
                f.write(f"{'Dimension':<20} | {'Weight (%)':<12} | {'Score (0-10)':<14} | {'Observations':<50}\n")
                f.write("----------------------------------------------------------------------------------------------------------\n")
                for dim in self.report_data.get('dimensions', []):
                    obs = dim.get('observations', '')
                    # Simple wrap for placeholder
                    obs_lines = [obs[i:i+48] for i in range(0, len(obs), 48)]
                    f.write(f"{dim.get('name', 'N/A'):<20} | {dim.get('weight_percentage', 0):<12.0f} | {dim.get('score_0_10', 0.0):<14.1f} | {obs_lines[0] if obs_lines else '':<50}\n")
                    for line in obs_lines[1:]:
                         f.write(f"{'':<20} | {'':<12} | {'':<14} | {line:<50}\n")
                
                weighted_data = self.report_data.get('weighted_score_data', {})
                summary_obs = weighted_data.get('summary_observations', '')
                summary_obs_lines = [summary_obs[i:i+48] for i in range(0, len(summary_obs), 48)]

                f.write("----------------------------------------------------------------------------------------------------------\n")
                f.write(f"{'Weighted Score':<20} | {weighted_data.get('total_weight_percentage', 100):<12.0f}% | {weighted_data.get('overall_score_0_10', 0.0):<14.2f} | {summary_obs_lines[0] if summary_obs_lines else '':<50}\n")
                for line in summary_obs_lines[1:]:
                    f.write(f"{'':<20} | {'':<12} | {'':<14} | {line:<50}\n")
                f.write("----------------------------------------------------------------------------------------------------------\n")


            logger.info(f"PDF report (placeholder with actual_output.pdf structure) generated successfully: {self.file_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to generate PDF report: {e}", exc_info=True)
            return False

# Example Usage (Illustrative - would be called by a backend job)
if __name__ == "__main__":
    # Ensure logger is set up if running standalone
    main_logger = setup_logging(log_level="DEBUG")
    
    sample_report_data_actual_output_style = {
        "report_title": "Data Quality Scoring Report",
        "data_source_name": "Electrical Grid Measurements",
        "report_date": "2024-05-28",
        "dimensions": [
            {"name": "Accuracy", "weight_percentage": 40, "score_0_10": 8.2, "observations": "Most records have valid electrical measurements, but one record has an improbably high voltage and negative current, indicating some accuracy issues."},
            {"name": "Completeness", "weight_percentage": 25, "score_0_10": 4.5, "observations": "Multiple required fields are missing across all records, and one record has an invalid cumulative_energy_wh_import value."},
            {"name": "Consistency", "weight_percentage": 25, "score_0_10": 6.0, "observations": "Multiple consistency issues identified, including missing phase-specific power factors, negative cumulative energy, and invalid event duration."},
            {"name": "Uniqueness", "weight_percentage": 10, "score_0_10": 8.5, "observations": "Most identifiers are unique, but sessionld has duplicates."}
        ],
        "weighted_score_data": {
            "total_weight_percentage": 100, # Sum of dimension weights
            "overall_score_0_10": 6.75, # Example: (8.2*0.4 + 4.5*0.25 + 6.0*0.25 + 8.5*0.10) -> This calculation is illustrative
            "summary_observations": "The data quality is compromised primarily by significant completeness and consistency issues, despite relatively high accuracy and uniqueness scores. While most electrical measurements are valid, the presence of missing required fields, invalid values, and consistency errors undermines the overall reliability and trustworthiness of the data. Addressing these issues is critical to improving data quality."
        }
        # "chart_image_path": "path/to/your/chart.png" # Optional: if chart is pre-generated
    }
    
    reporter = PDFReportGenerator(sample_report_data_actual_output_style)
    success = reporter.generate_report("dq_report_actual_output_style_sample.pdf")
    if success:
        main_logger.info("Sample PDF report (actual_output.pdf style) generated.")
    else:
        main_logger.error("Sample PDF report (actual_output.pdf style) generation failed.")



# COMMAND ----------

# MAGIC %pip install streamlit
# MAGIC %pip install pyspark
# MAGIC %pip install reportlab
# MAGIC %pip install delta-spark
# MAGIC %pip install dq-core
# MAGIC

# COMMAND ----------

