# Databricks notebook source


# COMMAND ----------

# Phase 1: Foundational DQ Engine (Pandas-based) & Basic Rule Execution

import pandas as pd
import logging
import re
from datetime import datetime

# --- Configuration ---
LOG_FORMAT = '%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)
logger = logging.getLogger(__name__)

# --- Sample Data ---
def get_sample_data():
    """Returns a sample Pandas DataFrame for DQ checks."""
    data = {
        'order_id': [1, 2, 3, 4, 5, 6, 7, 8],
        'customer_id': ['CUST001', 'CUST002', 'CUST003', 'CUST001', None, 'CUST004', 'CUST005', 'CUST002'],
        'order_date': ['2023-01-15', '2023-01-16', '2023-02-10', '2023-02-11', '2023-03-05', 'invalid_date', '2023-03-06', '2023-01-16'],
        'product_price': [100.00, 150.50, 0.00, 75.25, 200.00, 50.00, -10.00, 150.50],
        'email': ['test1@example.com', 'test2@example.com', 'test3@example.com', 'test1@example.com', 'nodata', 'test4@example.com', 'test5@example.com', 'test2@example.com'],
        'order_status': ['shipped', 'pending', 'shipped', 'delivered', 'shipped', 'cancelled', 'shipped', 'pending'],
        'shipping_date': ['2023-01-17', None, '2023-02-12', '2023-02-13', '2023-03-07', None, '2023-03-08', None]
    }
    return pd.DataFrame(data)

# --- DQ Rule Definitions & Execution ---

# Category: Accuracy
def check_accuracy(df, column_rules):
    """
    Checks data accuracy based on defined rules.
    Args:
        df (pd.DataFrame): The DataFrame to check.
        column_rules (dict): A dictionary where keys are column names and
                             values are dictionaries of accuracy rules.
                             Example: {'product_price': {'min_value': 0, 'max_value': 10000},
                                       'order_date': {'date_format': '%Y-%m-%d'}}
    Returns:
        dict: A dictionary with accuracy results (passed, failed, total, issues).
    """
    logger.info("Starting Accuracy checks.")
    results = {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues': []}

    for col, rules in column_rules.items():
        if col not in df.columns:
            logger.warning(f"Accuracy check: Column '{col}' not found in DataFrame.")
            continue

        for index, value in df[col].items():
            results['total_checks'] += 1
            is_valid = True
            error_detail = ""

            if 'min_value' in rules and (pd.isna(value) or value < rules['min_value']):
                is_valid = False
                error_detail = f"Value '{value}' is less than min_value {rules['min_value']}"
            if 'max_value' in rules and (pd.isna(value) or value > rules['max_value']):
                is_valid = False
                error_detail = f"Value '{value}' is greater than max_value {rules['max_value']}"
            if 'date_format' in rules:
                try:
                    if pd.notna(value): # Only attempt to parse if not NaN/NaT
                        datetime.strptime(str(value), rules['date_format'])
                except ValueError:
                    is_valid = False
                    error_detail = f"Value '{value}' does not match date_format {rules['date_format']}"
            if 'regex_pattern' in rules:
                if pd.notna(value) and not re.match(rules['regex_pattern'], str(value)):
                    is_valid = False
                    error_detail = f"Value '{value}' does not match regex pattern '{rules['regex_pattern']}'"


            if is_valid:
                results['passed'] += 1
            else:
                results['failed'] += 1
                results['issues'].append({
                    'row_index': index,
                    'column': col,
                    'value': value,
                    'rule_violated': 'Accuracy',
                    'detail': error_detail
                })
    logger.info(f"Accuracy checks completed. Passed: {results['passed']}, Failed: {results['failed']}")
    return results

# Category: Completeness
def check_completeness(df, required_columns):
    """
    Checks if required columns have non-null values.
    Args:
        df (pd.DataFrame): The DataFrame to check.
        required_columns (list): A list of column names that should not be null.
    Returns:
        dict: A dictionary with completeness results.
    """
    logger.info("Starting Completeness checks.")
    results = {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues': []}

    for col in required_columns:
        if col not in df.columns:
            logger.warning(f"Completeness check: Column '{col}' not found in DataFrame.")
            # All potential checks for this column fail if it's missing
            results['failed'] += len(df)
            results['total_checks'] += len(df)
            for index in df.index:
                 results['issues'].append({
                    'row_index': index,
                    'column': col,
                    'value': 'COLUMN_MISSING',
                    'rule_violated': 'Completeness',
                    'detail': f"Required column '{col}' is missing from DataFrame."
                })
            continue

        for index, value in df[col].items():
            results['total_checks'] += 1
            if pd.notna(value) and str(value).strip() != "": # Also check for empty strings
                results['passed'] += 1
            else:
                results['failed'] += 1
                results['issues'].append({
                    'row_index': index,
                    'column': col,
                    'value': value,
                    'rule_violated': 'Completeness',
                    'detail': f"Value is null or empty in required column '{col}'."
                })
    logger.info(f"Completeness checks completed. Passed: {results['passed']}, Failed: {results['failed']}")
    return results

# Category: Consistency
def check_consistency(df, consistency_rules):
    """
    Checks data consistency based on defined rules.
    Example rule: if 'order_status' is 'shipped', then 'shipping_date' must not be null.
    Args:
        df (pd.DataFrame): The DataFrame to check.
        consistency_rules (list of dicts): Each dict defines a rule.
            Example: [{'condition_col': 'order_status', 'condition_val': 'shipped',
                       'dependent_col': 'shipping_date', 'check': 'not_null'}]
    Returns:
        dict: A dictionary with consistency results.
    """
    logger.info("Starting Consistency checks.")
    results = {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues': []}

    for index, row in df.iterrows():
        for rule in consistency_rules:
            results['total_checks'] += 1
            condition_col = rule['condition_col']
            condition_val = rule['condition_val']
            dependent_col = rule['dependent_col']
            check_type = rule['check']

            if condition_col not in df.columns or dependent_col not in df.columns:
                logger.warning(f"Consistency check: Column '{condition_col}' or '{dependent_col}' not found.")
                results['failed'] +=1 # Count as a failure for this check
                results['issues'].append({
                    'row_index': index,
                    'column': f"{condition_col}, {dependent_col}",
                    'value': 'COLUMN_MISSING',
                    'rule_violated': 'Consistency',
                    'detail': f"Rule '{rule}' involves missing column(s)."
                })
                continue


            if row[condition_col] == condition_val:
                if check_type == 'not_null':
                    if pd.notna(row[dependent_col]) and str(row[dependent_col]).strip() != "":
                        results['passed'] += 1
                    else:
                        results['failed'] += 1
                        results['issues'].append({
                            'row_index': index,
                            'column': dependent_col,
                            'value': row[dependent_col],
                            'rule_violated': 'Consistency',
                            'detail': f"If '{condition_col}' is '{condition_val}', '{dependent_col}' should not be null. Rule: {rule}"
                        })
                # Add more check_types here (e.g., 'equals_value', 'greater_than_col')
            else:
                # Condition not met, so this specific rule passes by default for this row
                results['passed'] += 1

    logger.info(f"Consistency checks completed. Passed: {results['passed']}, Failed: {results['failed']}")
    return results

# Category: Uniqueness
def check_uniqueness(df, unique_columns):
    """
    Checks if values in specified columns are unique.
    Args:
        df (pd.DataFrame): The DataFrame to check.
        unique_columns (list): A list of column names that should have unique values.
    Returns:
        dict: A dictionary with uniqueness results.
    """
    logger.info("Starting Uniqueness checks.")
    results = {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues': []} # total_checks is per column

    for col in unique_columns:
        if col not in df.columns:
            logger.warning(f"Uniqueness check: Column '{col}' not found in DataFrame.")
            # Consider all rows as failing for this non-existent unique column check
            results['failed'] += len(df)
            results['total_checks'] += len(df)
            for index in df.index:
                results['issues'].append({
                    'row_index': index, # Or None if it's a column-level issue
                    'column': col,
                    'value': 'COLUMN_MISSING',
                    'rule_violated': 'Uniqueness',
                    'detail': f"Unique column '{col}' is missing."
                })
            continue

        results['total_checks'] += len(df) # Each row is checked for uniqueness within the column
        duplicates = df[df.duplicated(subset=[col], keep=False)] # keep=False marks all duplicates

        if duplicates.empty:
            results['passed'] += len(df) # All rows in this column passed the uniqueness check
        else:
            # Passed count is total minus number of duplicated entries for this column
            results['passed'] += (len(df) - len(duplicates[col].unique()) * (duplicates.groupby(col).size().max() -1) - (len(duplicates) - duplicates[col].nunique() * duplicates.groupby(col).size().max() ) )
            # A more precise way to count failures: each duplicated value occurrence beyond the first is a failure.
            # Or, simpler: number of rows involved in a duplication.
            failed_count_for_col = len(duplicates)
            results['failed'] += failed_count_for_col

            for index, row in duplicates.iterrows():
                results['issues'].append({
                    'row_index': index,
                    'column': col,
                    'value': row[col],
                    'rule_violated': 'Uniqueness',
                    'detail': f"Value '{row[col]}' in column '{col}' is not unique."
                })
    logger.info(f"Uniqueness checks completed. Passed: {results['passed']}, Failed: {results['failed']}")
    return results

# --- Main DQ Orchestration ---
def run_dq_pipeline(df, rules_config):
    """
    Runs the full DQ pipeline.
    Args:
        df (pd.DataFrame): The DataFrame to process.
        rules_config (dict): Configuration for all DQ checks.
            Example: {
                'accuracy': {'product_price': {'min_value': 0.01, 'max_value': 10000},
                             'order_date': {'date_format': '%Y-%m-%d'},
                             'email': {'regex_pattern': r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'}},
                'completeness': ['customer_id', 'order_date', 'product_price'],
                'consistency': [{'condition_col': 'order_status', 'condition_val': 'shipped',
                                 'dependent_col': 'shipping_date', 'check': 'not_null'}],
                'uniqueness': ['order_id']
            }
    Returns:
        dict: A dictionary containing results from all DQ checks.
    """
    logger.info("Starting Data Quality Pipeline.")
    all_dq_results = {}
    overall_summary = {
        'total_passed': 0,
        'total_failed': 0,
        'total_checks_performed': 0,
        'all_issues': []
    }

    if 'accuracy' in rules_config and rules_config['accuracy']:
        accuracy_results = check_accuracy(df, rules_config['accuracy'])
        all_dq_results['accuracy'] = accuracy_results
        overall_summary['total_passed'] += accuracy_results['passed']
        overall_summary['total_failed'] += accuracy_results['failed']
        overall_summary['total_checks_performed'] += accuracy_results['total_checks']
        overall_summary['all_issues'].extend(accuracy_results['issues'])

    if 'completeness' in rules_config and rules_config['completeness']:
        completeness_results = check_completeness(df, rules_config['completeness'])
        all_dq_results['completeness'] = completeness_results
        overall_summary['total_passed'] += completeness_results['passed']
        overall_summary['total_failed'] += completeness_results['failed']
        overall_summary['total_checks_performed'] += completeness_results['total_checks']
        overall_summary['all_issues'].extend(completeness_results['issues'])

    if 'consistency' in rules_config and rules_config['consistency']:
        consistency_results = check_consistency(df, rules_config['consistency'])
        all_dq_results['consistency'] = consistency_results
        overall_summary['total_passed'] += consistency_results['passed']
        overall_summary['total_failed'] += consistency_results['failed']
        overall_summary['total_checks_performed'] += consistency_results['total_checks']
        overall_summary['all_issues'].extend(consistency_results['issues'])

    if 'uniqueness' in rules_config and rules_config['uniqueness']:
        uniqueness_results = check_uniqueness(df, rules_config['uniqueness'])
        all_dq_results['uniqueness'] = uniqueness_results
        # Uniqueness checks are a bit different; passed/failed is per column's data
        # For overall summary, let's use its direct passed/failed
        overall_summary['total_passed'] += uniqueness_results['passed']
        overall_summary['total_failed'] += uniqueness_results['failed']
        overall_summary['total_checks_performed'] += uniqueness_results['total_checks']
        overall_summary['all_issues'].extend(uniqueness_results['issues'])

    all_dq_results['overall_summary'] = overall_summary
    logger.info("Data Quality Pipeline finished.")
    logger.info(f"Overall DQ Summary: Passed={overall_summary['total_passed']}, Failed={overall_summary['total_failed']}, Total Checks={overall_summary['total_checks_performed']}")

    if overall_summary['total_checks_performed'] > 0:
        overall_dq_score = (overall_summary['total_passed'] / overall_summary['total_checks_performed']) * 100
        logger.info(f"Overall DQ Score: {overall_dq_score:.2f}%")
        all_dq_results['overall_summary']['dq_score_percentage'] = round(overall_dq_score, 2)
    else:
        logger.info("No DQ checks performed.")
        all_dq_results['overall_summary']['dq_score_percentage'] = None


    return all_dq_results

# --- Example Usage ---
if __name__ == "__main__":
    logger.info("--- Starting Phase 1 DQ Application (Pandas) ---")
    sample_df = get_sample_data()
    logger.info(f"Sample DataFrame loaded with {len(sample_df)} rows.")
    logger.debug(f"Sample DataFrame head:\n{sample_df.head().to_string()}")

    # Define DQ rules configuration
    # As per dq_report.pdf, dimensions are Accuracy, Completeness, Consistency, Uniqueness
    dq_rules = {
        'accuracy': {
            'product_price': {'min_value': 0.0, 'max_value': 10000.00}, # Rule 1: Price range
            'order_date': {'date_format': '%Y-%m-%d'},                  # Rule 2: Date format
            'email': {'regex_pattern': r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'} # Rule 3: Email format
        },
        'completeness': [
            'customer_id',                                              # Rule 4: Customer ID not null
            'order_date',                                               # Rule 5: Order Date not null
            'product_price'                                             # Rule 6: Product Price not null
        ],
        'consistency': [
            {                                                           # Rule 7: Shipping date if shipped
                'condition_col': 'order_status',
                'condition_val': 'shipped',
                'dependent_col': 'shipping_date',
                'check': 'not_null'
            }
        ],
        'uniqueness': [
            'order_id'                                                  # Rule 8: Order ID is unique
        ]
    }

    dq_results = run_dq_pipeline(sample_df, dq_rules)

    logger.info("\n--- Detailed DQ Results ---")
    for category, result in dq_results.items():
        if category != 'overall_summary' and category != 'all_issues':
            logger.info(f"\nCategory: {category.upper()}")
            logger.info(f"  Passed: {result['passed']}")
            logger.info(f"  Failed: {result['failed']}")
            logger.info(f"  Total Checks: {result['total_checks']}")
            if result['total_checks'] > 0:
                 score = (result['passed'] / result['total_checks']) * 100
                 logger.info(f"  Score: {score:.2f}%")

            # Log first 5 issues for brevity
            if result['issues']:
                logger.info("  Sample Issues (up to 5):")
                for issue in result['issues'][:5]:
                    logger.info(f"    - Row: {issue['row_index']}, Col: {issue['column']}, Val: '{issue['value']}', Detail: {issue['detail']}")
            else:
                logger.info("  No issues found in this category.")

    logger.info("\n--- Overall DQ Summary ---")
    summary = dq_results['overall_summary']
    logger.info(f"  Total Passed Checks: {summary['total_passed']}")
    logger.info(f"  Total Failed Checks: {summary['total_failed']}")
    logger.info(f"  Total Checks Performed: {summary['total_checks_performed']}")
    logger.info(f"  Overall DQ Score: {summary.get('dq_score_percentage', 'N/A')}%")

    if summary['all_issues']:
        logger.info(f"\nTotal issues found across all categories: {len(summary['all_issues'])}")
        # Example of accessing all issues:
        # for issue in summary['all_issues']:
        #     print(issue)
    else:
        logger.info("No issues found across all categories.")

    logger.info("--- Phase 1 DQ Application (Pandas) Finished ---")


# COMMAND ----------

# Phase 3: Data Ingestion Framework (Simulated with Runtime Choice & Detailed Connector Structures) + DQ Engine

import logging
import re
from datetime import datetime
import os # For file path operations

# PySpark imports
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, when, lit, count, isnull, monotonically_increasing_id, expr, regexp_extract, countDistinct, from_json
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType, LongType

# For Web API simulation
import requests
import pandas as pd # Can be used to help create Spark DF from simple API responses

# --- Configuration ---
LOG_FORMAT = '%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)
logger = logging.getLogger(__name__)

# --- Spark Session Initialization ---
def get_spark_session(app_name="PySparkDQAppWithIngestion"):
    """
    Initializes and returns a Spark session.
    For database connectors, you might need to add JARs for drivers, e.g.:
    .config("spark.jars.packages", "org.mongodb.spark:mongo-spark-connector_2.12:3.0.1,com.datastax.spark:spark-cassandra-connector_2.12:3.0.0,org.postgresql:postgresql:42.2.18")
    Adjust versions as needed. For Excel: "com.crealytics.spark.excel_2.12:0.13.7" (or latest compatible version for your Spark version)
    """
    builder = SparkSession.builder.appName(app_name) \
        .config("spark.sql.legacy.timeParserPolicy", "LEGACY")

    # Add package for Excel reading. Ensure you have internet access for Spark to download it,
    # or provide the JAR locally via spark.jars option.
    # Adjust the version (e.g., 0.13.7 or a more recent one like 0.17.1 or latest) 
    # to be compatible with your Spark version (e.g., Spark 3.x might need a newer connector version).
    # Check the spark-excel GitHub page for compatibility.
    # Example for Spark 3.2.x / Scala 2.12 might be: "com.crealytics:spark-excel_2.12:3.2.1_0.17.1"
    # For older Spark versions, "com.crealytics.spark.excel_2.12:0.13.7" might work.
    # We'll use a common one, but this is the most likely point of adjustment.
    builder = builder.config("spark.jars.packages", 
                             "com.crealytics.spark.excel_2.12:0.13.7" 
                             # You can add other packages here, separated by commas, e.g.:
                             # + ",org.mongodb.spark:mongo-spark-connector_2.12:3.0.1" 
                             # + ",com.datastax.spark:spark-cassandra-connector_2.12:3.0.0"
                            )
                             # For JDBC, provide driver JARs via --jars command line option or spark.jars config if not using packages.

    spark = builder.getOrCreate()
    spark.sparkContext.setLogLevel("WARN") 
    logger.info(f"Spark session '{app_name}' created with spark-excel package.")
    return spark

# --- Data Ingestion Functions ---

def ingest_csv_spark(spark: SparkSession, file_path: str, header: bool = True, infer_schema: bool = True, custom_schema: StructType = None) -> DataFrame:
    logger.info(f"Attempting to ingest CSV from: {file_path} (Simulating Auto Loader for cloud paths like s3a://bucket/path/)")
    if not os.path.exists(file_path) and not file_path.startswith(("s3a://", "gs://", "abfss://")): # Basic check for local
        logger.error(f"CSV file not found at local path: {file_path}")
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"File not found: {file_path}"))
    try:
        # For actual Auto Loader on Databricks:
        # reader = spark.readStream.format("cloudFiles").option("cloudFiles.format", "csv") \
        # .option("cloudFiles.schemaLocation", "path/to/schema/checkpoint") \
        # .option("header", str(header).lower())
        # if custom_schema: reader = reader.schema(custom_schema)
        # else: reader = reader.option("cloudFiles.inferColumnTypes", str(infer_schema).lower())
        # return reader.load(file_path) # This would be a streaming DF

        # Batch simulation:
        reader = spark.read.format("csv").option("header", header)
        if custom_schema:
            reader = reader.schema(custom_schema)
        else:
            reader = reader.option("inferSchema", infer_schema)
        
        df = reader.load(file_path)
        logger.info(f"Successfully ingested CSV from '{file_path}'. Rows: {df.count()}")
        df = df.withColumn("row_id_ingest", monotonically_increasing_id())
        return df
    except Exception as e:
        logger.error(f"Error ingesting CSV from '{file_path}': {e}", exc_info=True)
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True)])).withColumn("error", lit(str(e)))


def ingest_parquet_spark(spark: SparkSession, dir_path: str, custom_schema: StructType = None) -> DataFrame:
    logger.info(f"Attempting to ingest Parquet from directory: {dir_path} (Simulating Auto Loader for cloud paths)")
    if not os.path.exists(dir_path) and not dir_path.startswith(("s3a://", "gs://", "abfss://")):
        logger.error(f"Parquet directory not found or is not a directory: {dir_path}")
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"Directory not found: {dir_path}"))
    try:
        # Actual Auto Loader:
        # reader = spark.readStream.format("cloudFiles").option("cloudFiles.format", "parquet") \
        # .option("cloudFiles.schemaLocation", "path/to/parquet_schema/checkpoint")
        # if custom_schema: reader = reader.schema(custom_schema) # Can override if needed
        # return reader.load(dir_path)

        # Batch simulation:
        reader = spark.read.format("parquet")
        if custom_schema: 
            reader = reader.schema(custom_schema)
        
        df = reader.load(dir_path)
        logger.info(f"Successfully ingested Parquet from '{dir_path}'. Rows: {df.count()}")
        df = df.withColumn("row_id_ingest", monotonically_increasing_id())
        return df
    except Exception as e:
        logger.error(f"Error ingesting Parquet from '{dir_path}': {e}", exc_info=True)
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True)])).withColumn("error", lit(str(e)))

def ingest_json_spark(spark: SparkSession, file_path: str, multi_line: bool = False, custom_schema: StructType = None) -> DataFrame:
    logger.info(f"Attempting to ingest JSON from: {file_path} (Simulating Auto Loader for cloud paths)")
    if not os.path.exists(file_path) and not file_path.startswith(("s3a://", "gs://", "abfss://")):
        logger.error(f"JSON file not found at path: {file_path}")
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"File not found: {file_path}"))
    try:
        # Actual Auto Loader:
        # reader = spark.readStream.format("cloudFiles").option("cloudFiles.format", "json") \
        # .option("cloudFiles.schemaLocation", "path/to/json_schema/checkpoint") \
        # .option("multiLine", str(multi_line).lower())
        # if custom_schema: reader = reader.schema(custom_schema)
        # else: reader = reader.option("cloudFiles.inferColumnTypes", "true") # Or provide schema hints
        # return reader.load(file_path)

        # Batch simulation:
        reader = spark.read.format("json").option("multiLine", multi_line)
        if custom_schema:
            reader = reader.schema(custom_schema)
        else:
            logger.info("Inferring schema for JSON. For large/complex JSON, provide schema or use schemaHints with AutoLoader.")
            
        df = reader.load(file_path)
        logger.info(f"Successfully ingested JSON from '{file_path}'. Rows: {df.count()}")
        df = df.withColumn("row_id_ingest", monotonically_increasing_id())
        return df
    except Exception as e:
        logger.error(f"Error ingesting JSON from '{file_path}': {e}", exc_info=True)
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True)])).withColumn("error", lit(str(e)))

def ingest_excel_spark(spark: SparkSession, file_path: str, sheet_name: str = None, header: bool = True, infer_schema: bool = True, custom_schema: StructType = None) -> DataFrame:
    logger.info(f"Attempting to ingest Excel from: {file_path}")
    if not os.path.exists(file_path): # Excel usually local or DBFS, not directly via s3a:// with this connector
        logger.error(f"Excel file not found at path: {file_path}")
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"File not found: {file_path}"))
    try:
        reader = spark.read.format("com.crealytics.spark.excel") \
            .option("header", str(header).lower()) \
            .option("inferSchema", str(infer_schema).lower()) \
            .option("treatEmptyValuesAsNulls", "true") 

        if sheet_name:
            reader = reader.option("dataAddress", f"'{sheet_name}'!A1") 
        df_loaded = reader.load(file_path)

        if custom_schema:
            logger.info("Applying custom schema to Excel data (selecting and casting).")
            select_exprs = []
            for field in custom_schema.fields:
                if field.name in df_loaded.columns:
                    select_exprs.append(col(field.name).cast(field.dataType).alias(field.name))
                else:
                    logger.warning(f"Column '{field.name}' from custom schema not found in Excel. It will be missing.")
            df = df_loaded.select(*select_exprs) if select_exprs else spark.createDataFrame([], custom_schema)
        else:
            df = df_loaded
        
        logger.info(f"Successfully ingested Excel from '{file_path}'. Rows: {df.count()}. Consider converting to Delta/Parquet.")
        df = df.withColumn("row_id_ingest", monotonically_increasing_id())
        return df
    except Exception as e:
        if "Class Not Found" in str(e) and "com.crealytics.spark.excel" in str(e):
            msg = "Error ingesting Excel: spark-excel JAR not found or not configured in Spark session. Add 'com.crealytics.spark.excel_2.12:YOUR_VERSION' to Spark packages. Check get_spark_session function."
            logger.error(msg, exc_info=False) # Set exc_info to False to avoid redundant traceback if Spark already printed it
            return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(msg))
        else:
            logger.error(f"Error ingesting Excel from '{file_path}': {e}", exc_info=True)
            return spark.createDataFrame([], StructType([StructField("error", StringType(), True)])).withColumn("error", lit(str(e)))

def ingest_delta_lake_table(spark: SparkSession, table_path_or_name: str) -> DataFrame:
    logger.info(f"Attempting to ingest from Delta Lake table/path: {table_path_or_name}")
    try:
        # If it's a path (e.g., "s3a://bucket/delta_table_path" or "/mnt/local/delta_table")
        if "/" in table_path_or_name or table_path_or_name.startswith(("s3a:", "gs:", "abfss:", "dbfs:")):
            df = spark.read.format("delta").load(table_path_or_name)
        else: # Assume it's a table name registered in the metastore (e.g., "my_database.my_delta_table")
            df = spark.read.table(table_path_or_name)
        
        logger.info(f"Successfully ingested from Delta Lake '{table_path_or_name}'. Rows: {df.count()}")
        df = df.withColumn("row_id_ingest", monotonically_increasing_id())
        return df
    except Exception as e:
        logger.error(f"Error ingesting from Delta Lake '{table_path_or_name}': {e}", exc_info=True)
        msg = f"Failed to read Delta table/path: {table_path_or_name}. Ensure it exists and Spark has access."
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(msg))

def ingest_jdbc_database(spark: SparkSession, jdbc_url: str, table_name: str, driver: str, user: str, password_secret_details: dict) -> DataFrame:
    logger.info(f"Attempting to ingest from JDBC table: {table_name} via URL: {jdbc_url.split('@')[-1] if '@' in jdbc_url else jdbc_url}")
    # In a real scenario, password would be fetched from Databricks secrets or a secure vault.
    # Example: password_secret_details = {"scope": "db_scope", "key": "db_password"}
    # In Databricks notebook: password = dbutils.secrets.get(scope=password_secret_details["scope"], key=password_secret_details["key"])
    # For local execution, you'd need to provide it or use environment variables.
    password = password_secret_details.get("password_value", "YOUR_ACTUAL_PASSWORD_HERE") # Placeholder
    if password == "YOUR_ACTUAL_PASSWORD_HERE":
        logger.warning("Using placeholder password for JDBC. Replace with secure secret retrieval in production.")

    try:
        df = spark.read.format("jdbc") \
            .option("url", jdbc_url) \
            .option("dbtable", table_name) \
            .option("driver", driver) \
            .option("user", user) \
            .option("password", password) \
            .load()
        logger.info(f"Successfully ingested from JDBC table '{table_name}'. Rows: {df.count()}")
        df = df.withColumn("row_id_ingest", monotonically_increasing_id())
        return df
    except Exception as e:
        logger.error(f"Error ingesting from JDBC table '{table_name}': {e}", exc_info=True)
        msg = f"JDBC connection failed for {table_name}. Check URL, driver ({driver}), credentials, and network access. Ensure driver JAR is in classpath or Spark packages."
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(msg))

def ingest_cassandra_table(spark: SparkSession, keyspace: str, table: str, host: str, port: str = "9042") -> DataFrame:
    logger.info(f"Attempting to ingest from Cassandra: {keyspace}.{table} on {host}:{port}")
    # Requires spark-cassandra-connector JAR. Add to Spark packages in get_spark_session:
    # "com.datastax.spark:spark-cassandra-connector_2.12:YOUR_CONNECTOR_VERSION"
    try:
        df = spark.read.format("org.apache.spark.sql.cassandra") \
            .option("spark.cassandra.connection.host", host) \
            .option("spark.cassandra.connection.port", port) \
            .option("keyspace", keyspace) \
            .option("table", table) \
            .load()
        logger.info(f"Successfully ingested from Cassandra '{keyspace}.{table}'. Rows: {df.count()}")
        df = df.withColumn("row_id_ingest", monotonically_increasing_id())
        return df
    except Exception as e:
        logger.error(f"Error ingesting from Cassandra '{keyspace}.{table}': {e}", exc_info=True)
        msg = f"Cassandra connection failed for {keyspace}.{table}. Check host, port, credentials, and ensure spark-cassandra-connector JAR is configured in Spark session."
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(msg))

def ingest_mongodb_collection(spark: SparkSession, connection_uri: str, database: str, collection: str) -> DataFrame:
    logger.info(f"Attempting to ingest from MongoDB: {database}.{collection}")
    # Requires mongo-spark-connector JAR. Add to Spark packages in get_spark_session:
    # "org.mongodb.spark:mongo-spark-connector_2.12:YOUR_CONNECTOR_VERSION"
    try:
        df = spark.read.format("mongo") \
            .option("uri", connection_uri) \
            .option("database", database) \
            .option("collection", collection) \
            .load()
        logger.info(f"Successfully ingested from MongoDB '{database}.{collection}'. Rows: {df.count()}")
        df = df.withColumn("row_id_ingest", monotonically_increasing_id())
        return df
    except Exception as e:
        logger.error(f"Error ingesting from MongoDB '{database}.{collection}': {e}", exc_info=True)
        msg = f"MongoDB connection failed for {database}.{collection}. Check URI, credentials, and ensure mongo-spark-connector JAR is configured in Spark session."
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(msg))

def ingest_kafka_topic_batch(spark: SparkSession, kafka_bootstrap_servers: str, topic: str, starting_offsets: str = "earliest") -> DataFrame:
    logger.info(f"Attempting to ingest a batch from Kafka topic: {topic}")
    # Requires spark-sql-kafka-0-10 JAR, usually included with Spark distributions, but confirm.
    try:
        df = spark.read.format("kafka") \
            .option("kafka.bootstrap.servers", kafka_bootstrap_servers) \
            .option("subscribe", topic) \
            .option("startingOffsets", starting_offsets) \
            .option("endingOffsets", "latest")  # Read up to the latest available for a batch
            .load()
        
        logger.info(f"Successfully read a batch from Kafka topic '{topic}'. Rows: {df.count()}. Value column is likely binary.")
        df = df.withColumn("row_id_ingest", monotonically_increasing_id()) 
        return df
    except Exception as e:
        logger.error(f"Error ingesting batch from Kafka topic '{topic}': {e}", exc_info=True)
        msg = f"Kafka batch read failed for topic {topic}. Check bootstrap servers, topic name, and Spark's Kafka connector setup (spark-sql-kafka-0-10)."
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(msg))

def ingest_web_api_spark(spark: SparkSession, api_url: str, params: dict = None, headers: dict = None) -> DataFrame:
    logger.info(f"Attempting to ingest from Web API: {api_url}")
    try:
        response = requests.get(api_url, params=params, headers=headers, timeout=10)
        response.raise_for_status() 
        api_data = response.json() 

        if not api_data:
            logger.warning(f"Web API '{api_url}' returned no data.")
            return spark.createDataFrame([], StructType([StructField("nodata_marker", StringType(), True), StructField("row_id_ingest", LongType(), True)]))
        
        if isinstance(api_data, dict) and len(api_data) > 0: 
            api_data = [api_data]
        elif not isinstance(api_data, list):
            logger.error(f"API data from '{api_url}' is not a list of records or a single record dict.")
            return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit("API data format error"))

        if not api_data: 
             logger.warning(f"Web API '{api_url}' resulted in empty list after processing.")
             return spark.createDataFrame([], StructType([StructField("nodata_marker", StringType(), True), StructField("row_id_ingest", LongType(), True)]))
        try:
            # Using pandas for robust conversion from list of dicts, then to Spark
            pandas_df = pd.DataFrame(api_data)
            df = spark.createDataFrame(pandas_df)
        except Exception as conversion_e: # More specific error handling for conversion
            logger.error(f"Error converting API data (list of dicts) to Spark DataFrame: {conversion_e}", exc_info=True)
            return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"API data conversion error: {conversion_e}"))


        logger.info(f"Successfully ingested and converted data from Web API '{api_url}'. Rows: {df.count()}")
        df = df.withColumn("row_id_ingest", monotonically_increasing_id())
        return df
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching data from Web API '{api_url}': {e}", exc_info=True)
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"API request error: {e}"))
    except Exception as e: # Catch-all for other unexpected errors during processing
        logger.error(f"Error processing data from Web API '{api_url}': {e}", exc_info=True)
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"API processing error: {e}"))

# --- DQ ENGINE (FROM PREVIOUS PHASE - ensure it's robust for varied inputs) ---

# Category: Accuracy
def check_accuracy_spark(df: DataFrame, column_rules: dict, spark: SparkSession):
    logger.info("Starting Accuracy checks (Spark).")
    original_count = df.count()
    if original_count == 0:
        logger.info("Accuracy check: Input DataFrame is empty.")
        return {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues_sample': []}

    issues_sample_list = []
    df_validated = df 
    temp_validation_cols = []
    applied_rules_count = 0

    for col_name, rules in column_rules.items():
        if col_name not in df_validated.columns:
            logger.warning(f"Accuracy check: Rule for column '{col_name}' skipped as column not found in DataFrame.")
            continue
        base_col_obj = col(col_name)
        
        if 'min_value' in rules:
            applied_rules_count +=1
            rule_col_name = f"acc_{col_name}_min_val_ok"
            temp_validation_cols.append(rule_col_name)
            # Ensure column is numeric type for comparison or handle potential cast error
            condition = base_col_obj.isNotNull() & (base_col_obj.cast(DoubleType()) >= rules['min_value'])
            df_validated = df_validated.withColumn(rule_col_name, condition)
        
        if 'max_value' in rules:
            applied_rules_count +=1
            rule_col_name = f"acc_{col_name}_max_val_ok"
            temp_validation_cols.append(rule_col_name)
            condition = base_col_obj.isNotNull() & (base_col_obj.cast(DoubleType()) <= rules['max_value'])
            df_validated = df_validated.withColumn(rule_col_name, condition)

        if 'date_format' in rules:
            applied_rules_count +=1
            rule_col_name = f"acc_{col_name}_date_fmt_ok"
            cast_col_name = f"acc_{col_name}_casted_date" 
            temp_validation_cols.append(rule_col_name)
            temp_validation_cols.append(cast_col_name) 
            
            df_validated = df_validated.withColumn(cast_col_name, expr(f"to_timestamp(CAST(COALESCE(`{col_name}`, '') AS STRING), '{rules['date_format']}')"))
            condition = base_col_obj.isNull() | \
                        ((expr(f"CAST(COALESCE(`{col_name}`, '') AS STRING) != ''")) & col(cast_col_name).isNotNull()) | \
                        (expr(f"CAST(COALESCE(`{col_name}`, '') AS STRING) == ''")) 
            df_validated = df_validated.withColumn(rule_col_name, condition)
            
        if 'regex_pattern' in rules:
            applied_rules_count +=1
            rule_col_name = f"acc_{col_name}_regex_ok"
            temp_validation_cols.append(rule_col_name)
            condition = base_col_obj.isNull() | (expr(f"CAST(COALESCE(`{col_name}`, '') AS STRING)") == "") | base_col_obj.rlike(rules['regex_pattern'])
            df_validated = df_validated.withColumn(rule_col_name, condition)
            
    if not temp_validation_cols or applied_rules_count == 0 : 
        logger.info("No accuracy rules applied or applicable columns found.")
        return {'passed': original_count, 'failed': 0, 'total_checks': original_count, 'issues_sample': []}

    overall_accuracy_condition = lit(True)
    actual_validation_rule_cols = [c for c in temp_validation_cols if c.endswith("_ok")] 
    if not actual_validation_rule_cols: 
        return {'passed': original_count, 'failed': 0, 'total_checks': original_count, 'issues_sample': []}

    for rule_c in actual_validation_rule_cols:
        overall_accuracy_condition = overall_accuracy_condition & col(rule_c)
    
    df_validated = df_validated.withColumn("is_accurate_row_overall", overall_accuracy_condition)
    failed_df = df_validated.filter(col("is_accurate_row_overall") == False)
    failed_count_rows = failed_df.count()
    passed_count_rows = original_count - failed_count_rows

    if failed_count_rows > 0:
        sample_failed_collected = failed_df.limit(10).collect()
        for row_spark in sample_failed_collected:
            row_dict = row_spark.asDict()
            for val_col_name in actual_validation_rule_cols: 
                if val_col_name in row_dict and not row_dict[val_col_name]:
                    parts = val_col_name.split('_') 
                    original_col_name = parts[1] 
                    rule_type_detail = "_".join(parts[2:-1]) 
                    rule_description = f"{rule_type_detail.replace('_', ' ')} rule failed"
                    if rule_type_detail == "min_val" and original_col_name in column_rules and 'min_value' in column_rules[original_col_name]: rule_description = f"Min value rule failed (expected >= {column_rules[original_col_name]['min_value']})"
                    elif rule_type_detail == "max_val" and original_col_name in column_rules and 'max_value' in column_rules[original_col_name]: rule_description = f"Max value rule failed (expected <= {column_rules[original_col_name]['max_value']})"
                    elif rule_type_detail == "date_fmt" and original_col_name in column_rules and 'date_format' in column_rules[original_col_name]: rule_description = f"Date format rule failed (expected {column_rules[original_col_name]['date_format']})"
                    elif rule_type_detail == "regex" and original_col_name in column_rules and 'regex_pattern' in column_rules[original_col_name]: rule_description = f"Regex rule failed (pattern: {column_rules[original_col_name]['regex_pattern']})"
                                        
                    issues_sample_list.append({
                        'row_id': row_dict.get('row_id_ingest', 'N/A'), 
                        'column': original_col_name, 
                        'value': str(row_dict.get(original_col_name)),
                        'rule_violated': 'Accuracy', 
                        'detail': rule_description
                    })
                    if len(issues_sample_list) >= 10: break 
            if len(issues_sample_list) >= 10: break 
    logger.info(f"Accuracy checks (Spark) completed. Passed (rows): {passed_count_rows}, Failed (rows): {failed_count_rows}")
    return {'passed': passed_count_rows, 'failed': failed_count_rows, 'total_checks': original_count, 'issues_sample': issues_sample_list[:10]}

# Completeness
def check_completeness_spark(df: DataFrame, required_columns: list, spark: SparkSession):
    logger.info("Starting Completeness checks (Spark).")
    original_count = df.count()
    if original_count == 0: return {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues_sample': []}
    total_individual_checks = 0 
    passed_individual_checks = 0
    issues_sample_list = []
    for col_name in required_columns:
        total_individual_checks += original_count
        if col_name not in df.columns:
            logger.warning(f"Completeness check: Column '{col_name}' not found.")
            sample_row_ids = [r.row_id_ingest for r in df.select("row_id_ingest").limit(3).collect()] if "row_id_ingest" in df.columns else ["N/A"]*min(3, original_count)
            for r_id in sample_row_ids:
                 issues_sample_list.append({'row_id': r_id, 'column': col_name, 'value': 'COLUMN_MISSING', 'rule_violated': 'Completeness', 'detail': f"Required column '{col_name}' is missing."})
            continue 
        condition = col(col_name).isNotNull() & (expr(f"trim(CAST(COALESCE(`{col_name}`, '') AS STRING))") != "")
        current_passed = df.filter(condition).count()
        passed_individual_checks += current_passed
        if current_passed < original_count: 
            current_failed_df = df.filter(~condition)
            sample_failed_rows = current_failed_df.select("row_id_ingest", col_name).limit(3).collect()
            for row in sample_failed_rows:
                issues_sample_list.append({'row_id': row['row_id_ingest'], 'column': col_name, 'value': str(row[col_name]), 'rule_violated': 'Completeness', 'detail': f"Value is null or empty in '{col_name}'."})
                if len(issues_sample_list) >= 10: break
        if len(issues_sample_list) >= 10: break
    failed_individual_checks = total_individual_checks - passed_individual_checks
    logger.info(f"Completeness: Passed Indiv Checks: {passed_individual_checks}, Failed Indiv Checks: {failed_individual_checks}, Total Indiv Checks: {total_individual_checks}")
    return {'passed': passed_individual_checks, 'failed': failed_individual_checks, 'total_checks': total_individual_checks, 'issues_sample': issues_sample_list[:10]}

# Consistency
def check_consistency_spark(df: DataFrame, consistency_rules: list, spark: SparkSession):
    logger.info("Starting Consistency checks (Spark).")
    original_count = df.count()
    if original_count == 0: return {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues_sample': []}
    df_with_checks = df
    temp_cols = []
    issues_sample_list = []
    applied_rules_count = 0
    for rule_idx, rule in enumerate(consistency_rules):
        rule_ok_col = f"cons_rule_{rule_idx}_ok"
        temp_cols.append(rule_ok_col)
        cond_col_name, cond_val, dep_col_name, check_type = rule['condition_col'], rule['condition_val'], rule['dependent_col'], rule['check']
        if cond_col_name not in df.columns or dep_col_name not in df.columns:
            logger.warning(f"Consistency Rule {rule_idx}: Column '{cond_col_name}' or '{dep_col_name}' not found.")
            df_with_checks = df_with_checks.withColumn(rule_ok_col, lit(False)) 
            applied_rules_count +=1 
            sample_row_ids = [r.row_id_ingest for r in df.select("row_id_ingest").limit(2).collect()] if "row_id_ingest" in df.columns else ["N/A"]*min(2, original_count)
            for r_id in sample_row_ids:
                issues_sample_list.append({'row_id': r_id, 'column': f"{cond_col_name}, {dep_col_name}", 'value': 'COLUMN_MISSING','rule_violated': 'Consistency', 'detail': f"Rule {rule} involves missing column(s)." })
            continue
        applied_rules_count +=1
        if check_type == 'not_null':
            dep_populated = col(dep_col_name).isNotNull() & (expr(f"trim(CAST(COALESCE(`{dep_col_name}`, '') AS STRING))") != "")
            rule_logic = (col(cond_col_name) != cond_val) | dep_populated
            df_with_checks = df_with_checks.withColumn(rule_ok_col, rule_logic)
        else:
            logger.warning(f"Unsupported consistency check_type: {check_type} for rule {rule_idx}. Assuming pass.")
            df_with_checks = df_with_checks.withColumn(rule_ok_col, lit(True)) 
        
        rule_failed_df_snapshot = df_with_checks.filter(col(rule_ok_col) == False)
        if rule_failed_df_snapshot.count() > 0 and len(issues_sample_list) < 10:
            sample_failed_this_rule = rule_failed_df_snapshot.select("row_id_ingest", cond_col_name, dep_col_name).limit(2).collect()
            for row_spark_consistency in sample_failed_this_rule:
                 issues_sample_list.append({
                    'row_id': row_spark_consistency['row_id_ingest'], 
                    'column': f"Cond: {cond_col_name} ({row_spark_consistency[cond_col_name]}), Dep: {dep_col_name} ({row_spark_consistency[dep_col_name]})",
                    'value': f"Condition met but dependent check failed",
                    'rule_violated': 'Consistency', 
                    'detail': f"Rule: If '{cond_col_name}' is '{cond_val}', '{dep_col_name}' should be {check_type}. Rule: {rule}"
                })
                 if len(issues_sample_list) >= 10: break
        if len(issues_sample_list) >= 10: break

    if not temp_cols or applied_rules_count == 0:
        return {'passed': original_count, 'failed': 0, 'total_checks': original_count, 'issues_sample': []}
    overall_ok_cond = lit(True)
    for c_col_name_consistency in temp_cols: overall_ok_cond = overall_ok_cond & col(c_col_name_consistency)
    df_with_checks = df_with_checks.withColumn("is_consistent_row_overall", overall_ok_cond)
    failed_rows = df_with_checks.filter(col("is_consistent_row_overall") == False).count()
    passed_rows = original_count - failed_rows
    logger.info(f"Consistency: Passed (rows): {passed_rows}, Failed (rows): {failed_rows}")
    return {'passed': passed_rows, 'failed': failed_rows, 'total_checks': original_count, 'issues_sample': issues_sample_list[:10]}

# Uniqueness
def check_uniqueness_spark(df: DataFrame, unique_columns: list, spark: SparkSession):
    logger.info("Starting Uniqueness checks (Spark).")
    original_count = df.count()
    if original_count == 0: return {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues_sample': []}
    total_row_checks = 0 
    passed_row_checks = 0
    issues_sample_list = []
    for col_name in unique_columns:
        total_row_checks += original_count
        if col_name not in df.columns:
            logger.warning(f"Uniqueness check: Column '{col_name}' not found.")
            sample_row_ids = [r.row_id_ingest for r in df.select("row_id_ingest").limit(3).collect()] if "row_id_ingest" in df.columns else ["N/A"]*min(3, original_count)
            for r_id in sample_row_ids:
                issues_sample_list.append({'row_id': r_id, 'column': col_name, 'value': 'COLUMN_MISSING','rule_violated': 'Uniqueness', 'detail': f"Unique column '{col_name}' is missing."})
            continue
        non_null_df = df.filter(col(col_name).isNotNull())
        # Count of distinct non-null values. If this is less than total non-nulls, there are duplicates.
        distinct_count = non_null_df.select(col_name).distinct().count()
        non_null_count = non_null_df.count()

        if distinct_count == non_null_count: # All non-nulls are unique
            passed_row_checks += original_count # All rows pass (nulls don't fail uniqueness here)
        else:
            # Find specific duplicate values among non-nulls
            duplicates_values_df = non_null_df.groupBy(col_name).agg(count("*").alias("cnt")).filter(col("cnt") > 1)
            # Get all rows that contain these duplicate values
            failing_rows_df = non_null_df.join(duplicates_values_df.select(col_name), on=col_name, how="inner")
            num_failing_rows_with_duplicates = failing_rows_df.count()
            
            passed_row_checks += (original_count - num_failing_rows_with_duplicates)

            if len(issues_sample_list) < 10:
                sample_failed_rows = failing_rows_df.select("row_id_ingest", col_name).limit(3).collect()
                for row_uniqueness in sample_failed_rows:
                     issues_sample_list.append({
                        'row_id': row_uniqueness['row_id_ingest'], 'column': col_name, 'value': str(row_uniqueness[col_name]),
                        'rule_violated': 'Uniqueness', 
                        'detail': f"Value '{row_uniqueness[col_name]}' in column '{col_name}' is not unique among non-nulls."
                    })
                     if len(issues_sample_list) >= 10: break
        if len(issues_sample_list) >= 10: break
                
    failed_row_checks = total_row_checks - passed_row_checks
    logger.info(f"Uniqueness: Passed Row Checks: {passed_row_checks}, Failed: {failed_row_checks}, Total: {total_row_checks}")
    return {'passed': passed_row_checks, 'failed': failed_row_checks, 'total_checks': total_row_checks, 'issues_sample': issues_sample_list[:10]}

# Main DQ Pipeline Runner
def run_dq_pipeline_spark(df: DataFrame, rules_config: dict, spark: SparkSession):
    logger.info("Starting Data Quality Pipeline (Spark).")
    if df is None: # df.count() will fail if df is None
        logger.error("DQ Pipeline: Input DataFrame is None. Aborting DQ checks.")
        return {"error": "Input DataFrame is None.", "overall_summary": {'dq_score_percentage': 0}}
    
    # Check for error columns from ingestion first
    if "error" in df.columns and df.filter(col("error").isNotNull()).count() > 0:
        first_error_row = df.filter(col("error").isNotNull()).select("error", "message").first()
        error_msg = first_error_row["message"] if first_error_row["message"] else first_error_row["error"] # Prefer message if available
        logger.error(f"DQ Pipeline: Input DataFrame contains ingestion errors: '{error_msg}'. Aborting.")
        return {"error": f"Ingestion errors: {error_msg}", "overall_summary": {'dq_score_percentage': 0}}
    
    if df.count() == 0: # Now safe to call count()
        logger.warning("DQ Pipeline: Input DataFrame is empty (0 rows). No DQ checks will be run.")
        # Return a structure indicating no checks ran but not an error
        return {"info": "Input DataFrame is empty (0 rows).", 
                "overall_summary": {'total_passed': 0, 'total_failed': 0, 'total_checks_performed': 0, 
                                    'all_issues_sample': [], 'dq_score_percentage': None}} # Score is None for empty DF

    if "conceptual_message" in df.columns:
        message = df.select("conceptual_message").first()["conceptual_message"]
        logger.info(f"DQ Pipeline: Input is conceptual: '{message}'. No DQ checks run.")
        return {"info": message, "overall_summary": {'dq_score_percentage': None}}

    all_dq_results = {}
    overall_summary = {'total_passed': 0, 'total_failed': 0, 'total_checks_performed': 0, 'all_issues_sample': []}
    original_df_count_for_score = df.count() # Store count before any potential filtering in checks (though checks aim to be non-destructive)

    if "row_id_ingest" not in df.columns:
        logger.warning("Input DataFrame for DQ pipeline missing 'row_id_ingest'. Adding one.")
        df = df.withColumn("row_id_ingest", monotonically_increasing_id())

    # Accuracy
    if 'accuracy' in rules_config and rules_config['accuracy']:
        res = check_accuracy_spark(df, rules_config['accuracy'], spark)
        all_dq_results['accuracy'] = res
        overall_summary['total_passed'] += res.get('passed',0); overall_summary['total_failed'] += res.get('failed',0); overall_summary['total_checks_performed'] += res.get('total_checks',0); overall_summary['all_issues_sample'].extend(res.get('issues_sample',[]))
    # Completeness
    if 'completeness' in rules_config and rules_config['completeness']:
        res = check_completeness_spark(df, rules_config['completeness'], spark)
        all_dq_results['completeness'] = res
        overall_summary['total_passed'] += res.get('passed',0); overall_summary['total_failed'] += res.get('failed',0); overall_summary['total_checks_performed'] += res.get('total_checks',0); overall_summary['all_issues_sample'].extend(res.get('issues_sample',[]))
    # Consistency
    if 'consistency' in rules_config and rules_config['consistency']:
        res = check_consistency_spark(df, rules_config['consistency'], spark)
        all_dq_results['consistency'] = res
        overall_summary['total_passed'] += res.get('passed',0); overall_summary['total_failed'] += res.get('failed',0); overall_summary['total_checks_performed'] += res.get('total_checks',0); overall_summary['all_issues_sample'].extend(res.get('issues_sample',[]))
    # Uniqueness
    if 'uniqueness' in rules_config and rules_config['uniqueness']:
        res = check_uniqueness_spark(df, rules_config['uniqueness'], spark)
        all_dq_results['uniqueness'] = res
        overall_summary['total_passed'] += res.get('passed',0); overall_summary['total_failed'] += res.get('failed',0); overall_summary['total_checks_performed'] += res.get('total_checks',0); overall_summary['all_issues_sample'].extend(res.get('issues_sample',[]))

    all_dq_results['overall_summary'] = overall_summary
    if overall_summary['total_checks_performed'] > 0:
        score = (overall_summary['total_passed'] / overall_summary['total_checks_performed']) * 100
        all_dq_results['overall_summary']['dq_score_percentage'] = round(score, 2)
    else:
        # If no checks were performed but DF had rows, it implies all rules passed by default (or no rules were applicable)
        all_dq_results['overall_summary']['dq_score_percentage'] = 100.0 if original_df_count_for_score > 0 else None
    
    if overall_summary['all_issues_sample']:
        try:
            # Deduplicate samples: Convert list of dicts to list of tuples of sorted items, then to set, then back
            seen_issues = set()
            deduplicated_issues = []
            for issue_dict in overall_summary['all_issues_sample']:
                # Create a frozenset of items for hashability, including a subset of keys for uniqueness
                # This basic deduplication might not be perfect if 'value' is very long or complex
                issue_tuple = tuple(sorted((k, str(v)[:50]) for k, v in issue_dict.items() if k in ['row_id', 'column', 'rule_violated', 'detail']))
                if issue_tuple not in seen_issues:
                    seen_issues.add(issue_tuple)
                    deduplicated_issues.append(issue_dict)
            all_dq_results['overall_summary']['all_issues_sample'] = deduplicated_issues[:20]
        except Exception as e_dedup: # Fallback if complex types in dict cause issues
            logger.warning(f"Could not perform complex deduplication of issues: {e_dedup}. Using simple slice.")
            all_dq_results['overall_summary']['all_issues_sample'] = overall_summary['all_issues_sample'][:20]
    else:
        all_dq_results['overall_summary']['all_issues_sample'] = []
        
    logger.info(f"DQ Pipeline Finished. Overall Score: {all_dq_results['overall_summary'].get('dq_score_percentage', 'N/A')}%")
    return all_dq_results


# --- Main Execution Block ---
def display_menu_and_get_choice():
    print("\n--- Data Source Ingestion Menu (ETL Extract Simulation) ---")
    print("1. CSV File (Local/Cloud Path)")
    print("2. Parquet Directory (Local/Cloud Path)")
    print("3. JSON File (Local/Cloud Path)")
    print("4. Excel File (Local Path - Requires spark-excel JAR)")
    print("5. Delta Lake Table/Path (Local/Cloud Path or Metastore Name)")
    print("6. Relational Database (JDBC - Requires Driver & DB)")
    print("7. Cassandra Table (Requires Connector & DB)")
    print("8. MongoDB Collection (Requires Connector & DB)")
    print("9. Kafka Topic (Batch Read - Requires Kafka & Connector)")
    print("10. Web API (Public Test API)")
    print("0. Exit")
    while True:
        try:
            choice = int(input("Enter your choice (0-10): "))
            if 0 <= choice <= 10:
                return choice
            else:
                print("Invalid choice. Please enter a number between 0 and 10.")
        except ValueError:
            print("Invalid input. Please enter a number.")

if __name__ == "__main__":
    spark = get_spark_session()

    SAMPLE_DATA_DIR = "sample_data_files_etl"
    os.makedirs(SAMPLE_DATA_DIR, exist_ok=True)
    sample_csv_path = os.path.join(SAMPLE_DATA_DIR, "sample_data.csv")
    sample_parquet_dir = os.path.join(SAMPLE_DATA_DIR, "sample_data.parquet_dir")
    sample_json_path = os.path.join(SAMPLE_DATA_DIR, "sample_data.json")
    sample_excel_path = os.path.join(SAMPLE_DATA_DIR, "sample_data.xlsx")
    sample_delta_path = os.path.join(SAMPLE_DATA_DIR, "sample_delta_table")

    if not os.path.exists(sample_csv_path):
        with open(sample_csv_path, "w") as f: 
            f.write("order_id,customer_id,order_date_str,product_price,email,order_status,shipping_date_str\n101,CUST1001,2024-05-01,10.99,alpha@example.com,shipped,2024-05-03\n102,CUST1002,2024-05-01,5.50,beta@example.com,pending,\n103,CUST1003,invalid-date,20.00,gamma@example.com,shipped,2024-05-04")
        logger.info(f"Created sample CSV: {sample_csv_path}")

    if not os.path.exists(sample_parquet_dir):
        try:
            df_temp = spark.read.csv(sample_csv_path, header=True, inferSchema=True)
            if df_temp.count() > 0: df_temp.write.format("parquet").mode("overwrite").save(sample_parquet_dir)
            logger.info(f"Created sample Parquet: {sample_parquet_dir}")
        except Exception as e: logger.error(f"Failed to create sample Parquet: {e}")

    if not os.path.exists(sample_json_path):
         with open(sample_json_path, "w") as f:
            f.write('{"order_id": 201, "customer_id": "CUST2001", "order_date_str": "2024-05-10", "product_price": 100.50, "email": "json1@example.com", "order_status": "pending", "shipping_date_str": null}\n')
            f.write('{"order_id": 202, "customer_id": "CUST2002", "order_date_str": "2024-05-11", "product_price": 75.20, "email": "json2@example.com", "order_status": "shipped", "shipping_date_str": "2024-05-12"}')
         logger.info(f"Created sample JSON: {sample_json_path}")
    
    if not os.path.exists(sample_excel_path):
        try: # Create a valid Excel file pandas can read, then Spark with connector
            excel_sample_data = {'order_id': [701, 702], 'customer_id': ['EXCL01', 'EXCL02'], 'order_date_str': ['2024-07-01', '2024-07-02'], 
                                 'product_price': [1.99, 2.99], 'email': ['excel@test.com', 'sheet@test.com'], 
                                 'order_status': ['pending', 'shipped'], 'shipping_date_str': [None, '2024-07-03']}
            pd.DataFrame(excel_sample_data).to_excel(sample_excel_path,index=False, sheet_name="Sheet1")
            logger.info(f"Created sample Excel: {sample_excel_path}")
        except Exception as e: logger.error(f"Failed to create sample Excel: {e}. 'openpyxl' needed for pandas.to_excel?")

    if not os.path.exists(sample_delta_path): 
        try:
            df_temp = spark.read.csv(sample_csv_path, header=True, inferSchema=True)
            if df_temp.count() > 0: df_temp.write.format("delta").mode("overwrite").save(sample_delta_path)
            logger.info(f"Created sample Delta table at: {sample_delta_path}")
        except Exception as e: logger.error(f"Failed to create sample Delta table: {e}")


    expected_schema_for_dq = StructType([ 
        StructField("order_id", IntegerType(), True), StructField("customer_id", StringType(), True),
        StructField("order_date_str", StringType(), True), StructField("product_price", DoubleType(), True),
        StructField("email", StringType(), True), StructField("order_status", StringType(), True),
        StructField("shipping_date_str", StringType(), True)
    ])
    
    dq_rules = { 
        'accuracy': {'product_price': {'min_value': 0.01}, 'order_date_str': {'date_format': 'yyyy-MM-dd'}, 'email':{'regex_pattern': r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'}},
        'completeness': ['customer_id', 'product_price'],
        'consistency': [{'condition_col': 'order_status', 'condition_val': 'shipped', 'dependent_col': 'shipping_date_str', 'check': 'not_null'}],
        'uniqueness': ['order_id']
    }

    ingested_df_main = None
    while True:
        choice = display_menu_and_get_choice()
        ingested_df_main = None 

        if choice == 1: 
            path = input(f"Enter CSV file path (default: {sample_csv_path}): ") or sample_csv_path
            ingested_df_main = ingest_csv_spark(spark, path, custom_schema=expected_schema_for_dq)
        elif choice == 2: 
            path = input(f"Enter Parquet directory path (default: {sample_parquet_dir}): ") or sample_parquet_dir
            ingested_df_main = ingest_parquet_spark(spark, path, custom_schema=expected_schema_for_dq)
        elif choice == 3: 
            path = input(f"Enter JSON file path (default: {sample_json_path}): ") or sample_json_path
            multiline = input("Multi-line JSON? (y/n, default n): ").lower() == 'y'
            ingested_df_main = ingest_json_spark(spark, path, multi_line=multiline, custom_schema=expected_schema_for_dq)
        elif choice == 4: 
            path = input(f"Enter Excel file path (default: {sample_excel_path}): ") or sample_excel_path
            sheet = input("Sheet name (optional, e.g., Sheet1): ") or None
            logger.info("Ensure spark-excel JAR is configured in Spark session for Excel ingestion (see get_spark_session).")
            ingested_df_main = ingest_excel_spark(spark, path, sheet_name=sheet, custom_schema=expected_schema_for_dq)
        elif choice == 5: 
            path_name = input(f"Enter Delta table path or name (default: {sample_delta_path}): ") or sample_delta_path
            ingested_df_main = ingest_delta_lake_table(spark, path_name)
        elif choice == 6: 
            logger.warning("JDBC: Provide actual DB details. This is a structural placeholder.")
            db_url = input("Enter JDBC URL (e.g., jdbc:postgresql://host:port/db): ") or "jdbc:postgresql://localhost:5432/mydatabase"
            tbl = input("Enter table name (e.g., schema.tablename): ") or "public.orders"
            drv = input("Enter JDBC driver class (e.g., org.postgresql.Driver): ") or "org.postgresql.Driver"
            usr = input("Enter DB username: ") or "user"
            pwd_val = input("Enter DB password (WARNING: typed in console, use secrets in prod): ") or "password"
            ingested_df_main = ingest_jdbc_database(spark, db_url, tbl, drv, usr, {"password_value": pwd_val})
        elif choice == 7: 
            logger.warning("Cassandra: Provide actual DB details. Requires connector JAR. This is a structural placeholder.")
            ks = input("Enter Cassandra keyspace: ") or "mykeyspace"
            tbl = input("Enter Cassandra table: ") or "orders"
            hst = input("Enter Cassandra host: ") or "localhost"
            ingested_df_main = ingest_cassandra_table(spark, ks, tbl, hst)
        elif choice == 8: 
            logger.warning("MongoDB: Provide actual DB details. Requires connector JAR. This is a structural placeholder.")
            uri = input("Enter MongoDB connection URI (e.g., mongodb://user:pass@host:port/db): ") or "mongodb://localhost:27017/testdb"
            db = input("Enter MongoDB database: ") or "testdb"
            coll = input("Enter MongoDB collection: ") or "orders"
            ingested_df_main = ingest_mongodb_collection(spark, uri, db, coll)
        elif choice == 9: 
            logger.warning("Kafka: Provide actual Kafka details. This is a structural placeholder for batch read.")
            servers = input("Enter Kafka bootstrap servers (e.g., localhost:9092): ") or "localhost:9092"
            tpc = input("Enter Kafka topic: ") or "orders_topic"
            ingested_df_main = ingest_kafka_topic_batch(spark, servers, tpc)
            if ingested_df_main and "value" in ingested_df_main.columns and ingested_df_main.count() > 0: 
                logger.info("Kafka 'value' column is typically binary. Attempting to cast to string and parse as JSON for DQ.")
                try:
                    # This assumes value is a JSON string. Adapt as needed.
                    # Create a temporary view to query the schema of the JSON string
                    ingested_df_main.select(col("value").cast("string").alias("json_str")).createOrReplaceTempView("kafka_json_temp_view")
                    # Infer schema from a sample of the JSON strings
                    # Note: This might be slow or fail if JSON structures are very different or malformed.
                    # A more robust approach would be to have a predefined schema for Kafka messages.
                    sample_json_rdd = spark.sql("SELECT json_str FROM kafka_json_temp_view LIMIT 10").rdd.map(lambda r: r.json_str)
                    if not sample_json_rdd.isEmpty():
                        json_schema_from_kafka_value = spark.read.json(sample_json_rdd).schema
                        logger.info(f"Inferred Kafka JSON value schema: {json_schema_from_kafka_value}")
                        ingested_df_main = ingested_df_main.withColumn("parsed_value", from_json(col("value").cast("string"), json_schema_from_kafka_value)).select("parsed_value.*", "row_id_ingest")
                    else:
                        logger.warning("Kafka topic had messages, but could not sample JSON to infer schema for parsing.")
                        ingested_df_main = spark.createDataFrame([], expected_schema_for_dq).withColumn("error", lit("Kafka value schema inference failed"))

                except Exception as e_kafka_parse:
                    logger.error(f"Could not parse Kafka JSON value for DQ: {e_kafka_parse}")
                    ingested_df_main = spark.createDataFrame([], expected_schema_for_dq).withColumn("error", lit(f"Kafka value parsing failed: {e_kafka_parse}"))

        elif choice == 10: 
            url = input("Enter Web API URL (default: https://jsonplaceholder.typicode.com/users/1): ") or "https://jsonplaceholder.typicode.com/users/1" 
            ingested_df_main = ingest_web_api_spark(spark, url)
            if ingested_df_main and ingested_df_main.count() > 0 and "error" not in ingested_df_main.columns:
                logger.warning("API schema is dynamic. DQ rules might not apply correctly without schema mapping.")
                ingested_df_main.printSchema()
        elif choice == 0:
            logger.info("Exiting.")
            break
        else:
            logger.warning("Invalid choice.")
            continue

        if ingested_df_main is not None:
            logger.info("Sample of ingested data (up to 5 rows):")
            ingested_df_main.show(5, truncate=False)
            
            aligned_df_for_dq = ingested_df_main # Start with the ingested DF
            # Attempt to align schema only if it's not an error/conceptual DF and has rows
            if ingested_df_main.count() > 0 and \
               "error" not in ingested_df_main.columns and \
               "conceptual_message" not in ingested_df_main.columns and \
               not all(field.name in ingested_df_main.columns for field in expected_schema_for_dq.fields):
                
                logger.warning(f"Schema mismatch! Ingested DF columns: {ingested_df_main.columns}. Expected by DQ: {[f.name for f in expected_schema_for_dq.fields]}. Attempting to align.")
                select_exprs_for_dq = []
                existing_cols = ingested_df_main.columns
                
                for field in expected_schema_for_dq.fields:
                    if field.name in existing_cols:
                        select_exprs_for_dq.append(col(field.name).cast(field.dataType).alias(field.name)) # Cast to expected type
                    else:
                        select_exprs_for_dq.append(lit(None).cast(field.dataType).alias(field.name))
                
                if "row_id_ingest" in existing_cols: 
                    if "row_id_ingest" not in [f.name for f in expected_schema_for_dq.fields]: # Avoid duplicate if already expected
                         select_exprs_for_dq.append(col("row_id_ingest"))
                
                aligned_df_for_dq = ingested_df_main.select(*select_exprs_for_dq)
                logger.info("Schema after alignment attempt for DQ:")
                aligned_df_for_dq.printSchema()

            dq_results_main = run_dq_pipeline_spark(aligned_df_for_dq, dq_rules, spark)
            
            logger.info("\n--- Detailed DQ Results (Spark) ---")
            for category, result in dq_results_main.items():
                if category not in ['overall_summary', 'all_issues_sample', 'error', 'info']:
                    logger.info(f"\nCategory: {category.upper()}")
                    logger.info(f"  Passed: {result.get('passed', 'N/A')}")
                    logger.info(f"  Failed: {result.get('failed', 'N/A')}")
                    logger.info(f"  Total Checks: {result.get('total_checks', 'N/A')}")
                    if isinstance(result.get('total_checks'), (int, float)) and result.get('total_checks', 0) > 0 and \
                       isinstance(result.get('passed'), (int, float)):
                        score = (result['passed'] / result['total_checks']) * 100
                        logger.info(f"  Score: {score:.2f}%")
                    
                    if result.get('issues_sample'):
                        logger.info(f"  Sample Issues for {category} (up to 5):")
                        for issue in result['issues_sample'][:5]:
                            logger.info(f"    - RowID: {issue.get('row_id', issue.get('row_id_ingest', 'N/A'))}, Col: {issue.get('column','N/A')}, Val: '{str(issue.get('value', 'N/A'))[:50]}', Detail: {issue.get('detail', 'N/A')}")
            
            summary_res = dq_results_main.get('overall_summary', {})
            if summary_res:
                logger.info("\n--- Overall DQ Summary (Spark) ---")
                logger.info(f"  Total Passed: {summary_res.get('total_passed', 'N/A')}, Failed: {summary_res.get('total_failed', 'N/A')}, Checks: {summary_res.get('total_checks_performed', 'N/A')}, Score: {summary_res.get('dq_score_percentage', 'N/A')}%")
                if summary_res.get('all_issues_sample'):
                    logger.info(f"  Overall Sample Issues (first 10):")
                    for issue in summary_res['all_issues_sample'][:10]:
                         logger.info(f"    - RowID: {issue.get('row_id_ingest', 'N/A')}, Col: {issue.get('column','N/A')}, Val: '{str(issue.get('value', 'N/A'))[:50]}', Rule: {issue.get('rule_violated', 'N/A')}, Detail: {issue.get('detail', 'N/A')}")

            elif dq_results_main.get("error"): logger.error(f"DQ Pipeline Error: {dq_results_main.get('error')}")
            elif dq_results_main.get("info"): logger.info(f"DQ Pipeline Info: {dq_results_main.get('info')}")
        else:
            logger.error("Ingestion resulted in no DataFrame or an error DataFrame. Cannot run DQ pipeline.")
        
        if input("\nProcess another source? (yes/no, default: yes): ").lower() == 'no':
            break
    spark.stop()


# COMMAND ----------

