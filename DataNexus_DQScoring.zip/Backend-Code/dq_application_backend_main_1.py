# Databricks notebook source
# MAGIC %pip install python-dotenv langchain-groq langchain langchain-community langchain-core weaviate-client pyspark langchain-weaviate asyncio playwright Jinja2 ray databricks-vectorsearch requests delta-spark httpx sentence-transformers
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %pip install tiktoken databricks-sdk

# COMMAND ----------

# ① Clean out any partial installs (optional but tidy)
%pip uninstall -y weaviate          # gets rid of the 0.1.2 stub
%pip uninstall -y weaviate-client   # in case an old v3 is still around
%pip uninstall -y protobuf google-api-core proto-plus

# modern client + modern protobuf + Google stack that accepts protobuf 5.x
%pip install --upgrade \
"weaviate-client>=4.14.0" \
"protobuf>=5.29,<6" \
"google-api-core>=2.24.2" \
"googleapis-common-protos>=1.63.0" \
"proto-plus>=1.25.0"



# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# dq_application_backend_main.py
# This script consolidates the Python backend code for the Data Quality application.
# It is designed as a comprehensive implementation of the architectural blueprint
# detailed in "Production-Grade Data Quality Application on Databricks: A Petabyte-Scale
# Architectural Blueprint" (document ID: 21851cf4-32af-481f-9b65-1f629e527cdf).
# The code is organized into classes mirroring the modular structure proposed in the blueprint,
# though presented here as a single file for the Canvas environment. In a typical project,
# these classes would be in separate files/modules as per blueprint Section VIII.A.
#
# Key features implemented include:
# - Configuration management prioritizing Databricks utilities and .env fallbacks.
# - Data ingestion framework components (AutoLoader, connectors, custom ingestors).
# - A Data Quality Engine with profiling, Groq LLM-based rule suggestion, rule management,
#   translation, and metrics calculation.
# - A RAG pipeline backend with Databricks Vector Search, Hugging Face embedding generation (via Ray),
#   and a Weaviate fallback client.
# - PDF report generation using Jinja2 and Playwright.
# - Orchestration utilities for Databricks Jobs.
# - Shared utilities for auditing, secret management, Spark operations, and notifications.

# --- requirements.txt (Illustrative) ---
# pyspark
# delta-spark
# databricks-sdk
# requests
# httpx # For async HTTP requests
# groq # Official Groq SDK (if available and preferred, else use httpx)
# databricks-vectorsearch
# sentence-transformers # For Hugging Face embeddings
# ray # For Ray-based embedding fallback
# weaviate-client # For Weaviate fallback
# Jinja2
# playwright # For PDF generation from HTML
# pandas # Often used with PySpark
# python-dotenv # For loading .env files (primarily for local dev/fallback)
# asyncio
# tiktoken # For token counting with LLMs
# openpyxl # For pandas to read .xlsx files if used in CustomIngestors or main pipeline
# nest_asyncio # To handle nested asyncio event loops in environments like Databricks notebooks/jobs

# --- Imports (Organized by typical module usage) ---
import json
import os
import sys
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Union
import asyncio # For asynchronous operations
import httpx # For making async API calls to Groq
import logging # For more structured logging

# PySpark imports
from pyspark.sql import SparkSession, DataFrame, Row
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, MapType, DoubleType, LongType, BooleanType, TimestampType, ArrayType, IntegerType
from pyspark.sql.window import Window

# Setup basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(name)s - %(module)s - %(message)s')
logger = logging.getLogger(__name__) # Root logger for the application


# === src/dq_utils/config_manager.py ===
from dotenv import load_dotenv

class ConfigManager:
    """
    Manages configuration loading, prioritizing Databricks utils (widgets, secrets)
    and falling back to environment variables or a .env file.
    Reflects blueprint's emphasis on secure and flexible configuration (Section VI.A, VII.B).
    """
    def __init__(self, dbutils_instance=None, dotenv_path: Optional[str] = None):
        self.dbutils = dbutils_instance
        if dotenv_path and os.path.exists(dotenv_path):
            load_dotenv(dotenv_path)
            logger.info(f"Loaded configurations from specified .env file: {dotenv_path}")
        elif os.path.exists(".env"): # Auto-load .env from current dir if present
            load_dotenv()
            logger.info("Loaded configurations from .env file in current directory.")
        else:
            logger.info("No .env file specified or found at default location. Relying on Databricks configs or environment variables.")


    def get_config(self, key: str, default: Optional[Any] = None, is_secret: bool = False, secret_scope: Optional[str] = None) -> Optional[Any]:
        """
        Retrieves a configuration value.
        Priority:
        1. Databricks widget (if dbutils and not secret)
        2. Databricks secret (if dbutils and is_secret and secret_scope)
        3. Environment variable
        4. Default value
        """
        value = None
        # 1. Try Databricks widget (for non-secrets passed as job params)
        if self.dbutils and not is_secret and hasattr(self.dbutils, "widgets"):
            try:
                # dbutils.widgets.get() throws an exception if the key doesn't exist.
                value = self.dbutils.widgets.get(key)
                # Ensure value is not an empty string if that should be treated as "not found" for widgets
                # However, an empty string can be a valid widget value.
                if value is not None: # Check for None, empty string is a valid value from widget
                    logger.debug(f"Retrieved '{key}' from dbutils.widgets.")
                    return value
            except Exception: # pylint: disable=broad-except
                logger.debug(f"Key '{key}' not found in dbutils.widgets.")

        # 2. Try Databricks secret
        if self.dbutils and is_secret and hasattr(self.dbutils, "secrets") and secret_scope:
            try:
                value = self.dbutils.secrets.get(scope=secret_scope, key=key)
                if value: # Databricks secrets.get returns the value or throws if not found/no permission
                    logger.info(f"Retrieved secret '{key}' from scope '{secret_scope}'.")
                    return value
            except Exception: # pylint: disable=broad-except
                logger.warning(f"Failed to retrieve secret '{key}' from scope '{secret_scope}'. Trying environment variable.")
        
        # 3. Try environment variable
        env_value = os.getenv(key)
        if env_value is not None: # Check for None explicitly, as empty string can be a valid env var
            logger.debug(f"Retrieved '{key}' from environment variables.")
            return env_value

        # 4. Return default
        if default is not None:
            logger.debug(f"Key '{key}' not found in any source, using default value for '{key}'.")
            return default
        
        logger.debug(f"Configuration key '{key}' not found and no default provided.")
        return None


# === src/dq_utils/secrets_manager.py ===
class SecretsManager:
    """
    Utility class for securely retrieving secrets, using ConfigManager.
    Aligns with blueprint Section VII.B on secure credential handling.
    """
    def __init__(self, config_manager_instance: ConfigManager, default_secret_scope: str = "dq_app_secrets"):
        self.config_mgr = config_manager_instance
        self.default_secret_scope = default_secret_scope # Default scope if none provided

    def get_secret(self, key: str, scope: Optional[str] = None) -> Optional[str]:
        """
        Retrieves a secret value using the configured ConfigManager.
        """
        secret_scope_to_use = scope if scope else self.default_secret_scope
        # Ensure a scope is actually provided if is_secret=True is to be effective with dbutils.secrets
        if not secret_scope_to_use:
            logger.warning(f"Attempting to get secret '{key}' but no secret scope was effectively provided (neither specific nor default).")
            # ConfigManager might still find it via environment variable if is_secret is not strictly tied to dbutils.secrets
        return self.config_mgr.get_config(key, is_secret=True, secret_scope=secret_scope_to_use)


# === src/dq_utils/audit.py ===
class AuditLogger:
    """
    Handles application-level audit logging to a Delta table.
    Implements blueprint Section VII.D.
    """
    def __init__(self, spark_session: SparkSession, audit_table_fqn: str = "governance_catalog.audit_db.application_events_log"):
        self.spark = spark_session
        self.audit_table_fqn = audit_table_fqn
        self._ensure_audit_table_exists()

    def _ensure_audit_table_exists(self):
        if not self.spark:
            logger.error("SparkSession not available for AuditLogger.")
            return
        try:
            if not self.spark.catalog.tableExists(self.audit_table_fqn):
                logger.info(f"Audit table {self.audit_table_fqn} does not exist. Creating...")
                schema = StructType([
                    StructField("event_timestamp_utc", TimestampType(), False),
                    StructField("user_id", StringType(), True),
                    StructField("action", StringType(), True),
                    StructField("details_json", StringType(), True) # Storing complex details as JSON string
                ])
                self.spark.createDataFrame([], schema).write.format("delta").saveAsTable(self.audit_table_fqn)
                logger.info(f"Audit table {self.audit_table_fqn} created successfully.")
        except Exception as e:
             logger.error(f"Failed to create or check audit table {self.audit_table_fqn}. Error: {e}", exc_info=True)

    def log_event(self, user_identifier: str, action_taken: str, event_details: Dict[str, Any]):
        if not self.spark:
            logger.error("SparkSession is not available. Cannot log audit event.")
            return
        try:
            timestamp_utc = datetime.now(timezone.utc)
            audit_record = {
                "event_timestamp_utc": timestamp_utc,
                "user_id": str(user_identifier), # Ensure string
                "action": str(action_taken),     # Ensure string
                "details_json": json.dumps(event_details, default=str) # default=str for non-serializable items like datetime
            }
            audit_df = self.spark.createDataFrame([Row(**audit_record)]) # Create DF from a list of Rows
            audit_df.write.format("delta").mode("append").saveAsTable(self.audit_table_fqn)
            logger.info(f"Audit event logged to {self.audit_table_fqn}: Action='{action_taken}', User='{user_identifier}'")
        except Exception as e:
            logger.error(f"Failed to log audit event to {self.audit_table_fqn}. Error: {e}", exc_info=True)


# === src/dq_utils/spark_utils.py ===
class SparkUtils:
    """
    Common PySpark helper functions. Aligns with blueprint Section VI.B.
    """
    def __init__(self, spark_session: SparkSession):
        self.spark = spark_session

    def optimize_delta_table(self, table_fqn: str, zorder_cols: Optional[List[str]] = None):
        if not self.spark:
            logger.error("SparkSession is not available for SparkUtils.")
            return
        try:
            logger.info(f"Optimizing Delta table: {table_fqn}")
            optimize_query = f"OPTIMIZE {table_fqn}"
            if zorder_cols and isinstance(zorder_cols, list) and len(zorder_cols) > 0:
                optimize_query += f" ZORDER BY ({', '.join(zorder_cols)})"
            self.spark.sql(optimize_query)
            logger.info(f"Successfully optimized {table_fqn}.")
        except Exception as e:
            logger.error(f"Failed to optimize table {table_fqn}. Error: {e}", exc_info=True)

    def set_liquid_clustering(self, table_fqn: str, cluster_by_cols: List[str]):
        if not self.spark:
            logger.error("SparkSession is not available for SparkUtils.")
            return
        if not cluster_by_cols or not isinstance(cluster_by_cols, list) or len(cluster_by_cols) == 0:
            logger.error("cluster_by_cols must be a non-empty list of column names.")
            return
        try:
            logger.info(f"Setting Liquid Clustering for {table_fqn} by columns: {cluster_by_cols}")
            alter_query = f"ALTER TABLE {table_fqn} CLUSTER BY ({', '.join(cluster_by_cols)})"
            self.spark.sql(alter_query)
            self.spark.sql(f"OPTIMIZE {table_fqn}") # OPTIMIZE is needed to apply clustering to existing data
            logger.info(f"Liquid Clustering set and table optimized for {table_fqn}.")
        except Exception as e:
            logger.error(f"Failed to set Liquid Clustering for {table_fqn}. Error: {e}", exc_info=True)

    def get_table_row_count(self, table_fqn: str) -> Optional[int]:
        if not self.spark:
            logger.error("SparkSession is not available for SparkUtils.")
            return None
        try:
            count = self.spark.table(table_fqn).count()
            logger.debug(f"Row count for {table_fqn}: {count}")
            return count
        except Exception as e:
            logger.error(f"Could not get row count for {table_fqn}. Error: {e}", exc_info=True)
            return None

# === src/dq_utils/notification_service.py ===
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

class NotificationService:
    """
    Handles sending notifications, e.g., email alerts.
    Uses configurations from ConfigManager (blueprint Section VII.B).
    """
    def __init__(self, config_manager_instance: ConfigManager):
        self.config_mgr = config_manager_instance
        self.smtp_server = self.config_mgr.get_config("SMTP_SERVER")
        smtp_port_str = self.config_mgr.get_config("SMTP_PORT", default="587")
        try:
            self.smtp_port = int(smtp_port_str)
        except ValueError:
            logger.error(f"Invalid SMTP_PORT: '{smtp_port_str}'. Using default 587.")
            self.smtp_port = 587
        self.sender_email = self.config_mgr.get_config("SENDER_EMAIL")
        self.sender_password = self.config_mgr.get_config("SENDER_PASSWORD", is_secret=True, secret_scope="smtp_credentials")
        self.default_recipient_email = self.config_mgr.get_config("RECIPIENT_EMAIL")

    def send_email(self, subject: str, body_html: str, recipient_email: Optional[str] = None, attachments: Optional[List[str]] = None):
        if not all([self.smtp_server, self.smtp_port, self.sender_email, self.sender_password]):
            logger.error("SMTP configuration is incomplete. Cannot send email.")
            if not self.sender_password and "gmail.com" in (self.sender_email or ""):
                 logger.warning("For Gmail, ensure an App Password is used and configured as SENDER_PASSWORD in secrets (scope: smtp_credentials).")
            return False

        to_email = recipient_email if recipient_email else self.default_recipient_email
        if not to_email:
            logger.error("Recipient email not specified and no default is set. Cannot send email.")
            return False

        msg = MIMEMultipart()
        msg['From'] = self.sender_email
        msg['To'] = to_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body_html, 'html'))

        if attachments:
            for file_path in attachments:
                if not os.path.exists(file_path):
                    logger.warning(f"Attachment file not found: {file_path}. Skipping.")
                    continue
                try:
                    with open(file_path, "rb") as attachment_file:
                        part = MIMEBase('application', 'octet-stream')
                        part.set_payload(attachment_file.read())
                    encoders.encode_base64(part)
                    part.add_header('Content-Disposition', f"attachment; filename= {os.path.basename(file_path)}")
                    msg.attach(part)
                    logger.debug(f"Attached file: {file_path}")
                except Exception as e:
                    logger.error(f"Failed to attach file {file_path}: {e}", exc_info=True)
        try:
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.sendmail(self.sender_email, to_email, msg.as_string())
            logger.info(f"Email sent successfully to {to_email} with subject: '{subject}'")
            return True
        except smtplib.SMTPAuthenticationError as auth_err:
            logger.error(f"SMTP Authentication Error sending email to {to_email}: {auth_err}", exc_info=True)
            if "gmail.com" in (self.sender_email or "") and "Application-specific password required" in str(auth_err):
                logger.error("Gmail requires an App Password for SMTP. Please generate one from your Google Account settings and update the SENDER_PASSWORD secret.")
            return False
        except Exception as e:
            logger.error(f"Failed to send email to {to_email} with subject '{subject}'. Error: {e}", exc_info=True)
            return False


# === src/dq_ingestion/autoloader_configs.py ===
class AutoLoaderManager:
    """
    Manages Auto Loader stream configurations for various file types (JSON, CSV, Parquet, Excel).
    Reflects blueprint Section II.A and Table 1 for scalable file ingestion from cloud storage.
    """
    def __init__(self, spark_session: SparkSession, dbutils_instance):
        self.spark = spark_session
        self.dbutils = dbutils_instance # May be used for path resolution or advanced S3 notification setup

    def _get_base_autoloader_reader(self, schema_location: str, 
                                   bad_records_path: Optional[str] = None,
                                   extra_options: Optional[Dict[str, str]] = None) -> Optional[SparkSession.readStream]:
        """Helper to get a base Auto Loader stream reader with common options."""
        if not self.spark:
            logger.error("SparkSession is not available for AutoLoaderManager.")
            return None
        
        reader = self.spark.readStream.format("cloudFiles") \
            .option("cloudFiles.schemaLocation", schema_location) \
            .option("cloudFiles.schemaEvolutionMode", "addNewColumns") # A common, robust default

        if bad_records_path:
            reader = reader.option("badRecordsPath", bad_records_path)
            logger.info(f"Auto Loader configured to route bad records to: {bad_records_path}")
        
        # Apply any additional user-provided options
        if extra_options:
            for k, v in extra_options.items():
                reader = reader.option(k, v)
        return reader

    def get_autoloader_stream(self,
                              input_path: str, # Cloud storage path (e.g., S3, ADLS Gen2, GCS)
                              file_format: str, # "json", "csv", "parquet", "excel"
                              schema_location: str, # Path for schema tracking and evolution
                              bad_records_path: Optional[str] = None, # Path for malformed records
                              extra_options: Optional[Dict[str, str]] = None) -> Optional[DataFrame]:
        """
        Configures and returns an Auto Loader stream for various file formats from cloud storage.
        This method is designed for continuous or triggered incremental ingestion.
        """
        base_reader = self._get_base_autoloader_reader(schema_location, bad_records_path, extra_options)
        if not base_reader:
            return None

        # Initialize specific options dictionary, potentially overriding some from extra_options if needed
        specific_options = {}
        effective_options_log = {**(extra_options if extra_options else {}), "cloudFiles.schemaLocation": schema_location, "cloudFiles.schemaEvolutionMode": "addNewColumns"}
        if bad_records_path: effective_options_log["badRecordsPath"] = bad_records_path


        file_format_lower = file_format.lower()
        specific_options["cloudFiles.format"] = file_format_lower # Set the primary format

        if file_format_lower == "json":
            specific_options.setdefault("multiLine", "true") # Common for JSON files
            # Consider schemaHints for complex JSON: .option("cloudFiles.schemaHints", "columnName dataType, ...")
        elif file_format_lower == "csv":
            specific_options.setdefault("header", "true")
            specific_options.setdefault("inferSchema", "false") # Recommended for production
            logger.warning("For CSV Auto Loader, providing 'cloudFiles.schemaHints' or an explicit schema via DataFrame operations post-load is highly recommended for production to ensure reliability and performance.")
        elif file_format_lower == "parquet":
            pass # Parquet is self-describing, fewer specific options typically needed for format itself
        elif file_format_lower == "excel":
            # Auto Loader's direct Excel support might depend on Databricks Runtime version or require
            # the 'binaryFile' format with subsequent parsing.
            # For true Auto Loader with Excel, often files are pre-converted or specific DBR features are used.
            # This setup assumes `cloudFiles.format="excel"` is supported or will be handled by underlying mechanisms.
            specific_options.setdefault("header", "true")
            # May need options like "dataAddress", "treatEmptyValuesAsNulls", etc.
            logger.warning("Direct Auto Loader for Excel ('cloudFiles.format', 'excel') has limitations and specific DBR requirements. Ensure compatibility or consider pre-conversion to Parquet/CSV for robust, scalable ingestion.")
        else:
            logger.error(f"Unsupported file_format '{file_format}' for Auto Loader in this manager.")
            return None

        try:
            final_reader = base_reader
            for k, v_spec in specific_options.items(): # Apply format-specific options
                final_reader = final_reader.option(k, v_spec)
                effective_options_log[k] = v_spec # For logging
            
            logger.info(f"Configured Auto Loader stream for {file_format.upper()} from {input_path} with effective options: {effective_options_log}")
            return final_reader.load(input_path)
        except Exception as e:
            logger.error(f"Failed to configure Auto Loader for {file_format.upper()} from path {input_path}. Error: {e}", exc_info=True)
            return None

    def start_autoloader_to_delta(self,
                                 stream_df: DataFrame,
                                 target_table_fqn: str,
                                 checkpoint_location: str,
                                 output_mode: str = "append", # "append" or "complete" (for aggregations)
                                 trigger_type: str = "processingTime", # "once", "availableNow" for batch-like behavior
                                 trigger_interval: str = "1 minute"): # For "processingTime"
        """
        Starts writing a configured Auto Loader stream (or any streaming DataFrame) to a Delta table.
        """
        if not stream_df:
            logger.error("Input stream DataFrame is None. Cannot start Auto Loader stream to Delta.")
            return None
        if not stream_df.isStreaming:
            logger.error("Input DataFrame is not a streaming DataFrame. Use standard batch write for non-streaming DFs.")
            return None
        
        writer = stream_df.writeStream \
            .format("delta") \
            .outputMode(output_mode) \
            .option("checkpointLocation", checkpoint_location) \
            .option("mergeSchema", "true") # Allow schema evolution in the target Delta table

        if trigger_type.lower() == "processingtime":
            writer = writer.trigger(processingTime=trigger_interval)
        elif trigger_type.lower() == "once":
            writer = writer.trigger(once=True)
        elif trigger_type.lower() == "availablenow": # DBR 10.1+
            writer = writer.trigger(availableNow=True)
        else: 
            logger.warning(f"Unknown trigger type '{trigger_type}'. Stream will use default trigger behavior of .toTable() (typically continuous if not specified).")
        
        try:
            # .toTable() starts the stream and manages it. It's simpler for Delta targets.
            # For more control, .start(path_to_delta_table) can be used.
            streaming_query = writer.toTable(target_table_fqn)
            logger.info(f"Auto Loader stream writing to Delta table {target_table_fqn} configured and started/starting. Query Name: {streaming_query.name if streaming_query else 'N/A'}, ID: {streaming_query.id if streaming_query else 'N/A'}")
            return streaming_query # Returns a StreamingQuery object
        except Exception as e:
            logger.error(f"Failed to start Auto Loader stream to Delta table {target_table_fqn}. Error: {e}", exc_info=True)
            return None


# === src/dq_ingestion/connector_clients.py ===
class ConnectorClients:
    """
    Clients for reading from various data sources like Cassandra, MongoDB, Kafka, JDBC.
    Uses ConfigManager for secrets (Blueprint Section II.B and Table 1).
    These methods typically return batch DataFrames. For streaming from these sources (e.g. Kafka),
    the readStream API would be used, often configured similarly.
    """
    def __init__(self, spark_session: SparkSession, config_manager_instance: ConfigManager):
        self.spark = spark_session
        self.config_mgr = config_manager_instance

    def read_from_cassandra(self, host: str, keyspace: str, table: str,
                            username_secret_key: Optional[str] = "CASSANDRA_USER", 
                            password_secret_key: Optional[str] = "CASSANDRA_PASS",
                            secret_scope: Optional[str] = "cassandra_credentials") -> Optional[DataFrame]:
        """Reads data from Cassandra. Production considerations: predicate pushdown, column selection."""
        if not self.spark: logger.error("SparkSession not available for ConnectorClients."); return None
        options = {"spark.cassandra.connection.host": host, "keyspace": keyspace, "table": table}
        if username_secret_key and password_secret_key and secret_scope:
            username = self.config_mgr.get_config(username_secret_key, is_secret=True, secret_scope=secret_scope)
            password = self.config_mgr.get_config(password_secret_key, is_secret=True, secret_scope=secret_scope)
            if username and password:
                options["spark.cassandra.auth.username"] = username
                options["spark.cassandra.auth.password"] = password
            else: logger.warning(f"Cassandra secrets ('{username_secret_key}', '{password_secret_key}') not found in scope '{secret_scope}'.")
        try:
            # For production, add .option("pushdown", "true") if supported and use .select() and .filter() before .load()
            df = self.spark.read.format("org.apache.spark.sql.cassandra").options(**options).load()
            logger.info(f"Successfully read from Cassandra: {keyspace}.{table} on {host}")
            return df
        except Exception as e: logger.error(f"Error reading from Cassandra {keyspace}.{table}: {e}", exc_info=True); return None

    def read_from_mongodb(self, database: str, collection: str,
                          connection_uri_secret_key: str = "MONGO_CONNECTION_URI", 
                          secret_scope: str = "mongo_credentials") -> Optional[DataFrame]:
        """Reads data from MongoDB. Production considerations: aggregation pipeline pushdown."""
        if not self.spark: logger.error("SparkSession not available for ConnectorClients."); return None
        connection_uri = self.config_mgr.get_config(connection_uri_secret_key, is_secret=True, secret_scope=secret_scope)
        if not connection_uri:
            logger.error(f"MongoDB URI secret '{connection_uri_secret_key}' not found in scope '{secret_scope}'."); return None
        try:
            # For production, consider using .option("pipeline", "[{'$match': ...}, {'$project': ...}]") for pushdown
            df = self.spark.read.format("mongodb") \
                .option("spark.mongodb.input.uri", connection_uri) \
                .option("database", database).option("collection", collection).load()
            logger.info(f"Successfully read from MongoDB: {database}.{collection}")
            return df
        except Exception as e: logger.error(f"Error reading from MongoDB {database}.{collection}: {e}", exc_info=True); return None

    def read_from_kafka(self, 
                        topic: str, 
                        kafka_bootstrap_servers_key: str = "KAFKA_BOOTSTRAP_SERVERS",
                        starting_offsets: str = "earliest", # "earliest", "latest", specific JSON, or "batch" for this method
                        kafka_options: Optional[Dict[str, str]] = None, # For auth, SSL etc.
                        secret_scope: Optional[str] = "kafka_credentials",
                        is_streaming: bool = False) -> Optional[DataFrame]:
        """
        Reads data from a Kafka topic.
        If is_streaming is True, returns a streaming DataFrame.
        If is_streaming is False (or starting_offsets="batch"), attempts a batch read.
        Note: True batch read from Kafka might require specific offset management if not just taking earliest/latest available.
        """
        if not self.spark: logger.error("SparkSession not available for ConnectorClients."); return None
        
        bootstrap_servers = self.config_mgr.get_config(kafka_bootstrap_servers_key, secret_scope=secret_scope)
        if not bootstrap_servers:
            logger.error(f"Kafka bootstrap servers key '{kafka_bootstrap_servers_key}' not found in config/secrets (scope: {secret_scope})."); return None

        reader = self.spark.readStream if is_streaming else self.spark.read
        
        options = {
            "kafka.bootstrap.servers": bootstrap_servers,
            "subscribe": topic,
        }
        if is_streaming:
             options["startingOffsets"] = starting_offsets
        # For batch, startingOffsets/endingOffsets can be used if reading a specific range.
        # If starting_offsets="batch", it implies reading available data as a batch, often for testing or small lookups.
        # True batch processing of large Kafka topics usually involves other patterns or tools.

        # Example for SASL_SSL (common for production Kafka) - fetch from secrets:
        # jaas_config = self.config_mgr.get_config("KAFKA_SASL_JAAS_CONFIG", is_secret=True, secret_scope=secret_scope)
        # if jaas_config:
        #     options["kafka.security.protocol"] = "SASL_SSL"
        #     options["kafka.sasl.mechanism"] = "PLAIN" # Or SCRAM-SHA-256, SCRAM-SHA-512
        #     options["kafka.sasl.jaas.config"] = jaas_config
        #     # May also need: options["kafka.ssl.truststore.location"], options["kafka.ssl.truststore.password"]
        
        if kafka_options: options.update(kafka_options)

        try:
            df = reader.format("kafka").options(**options).load()
            mode = "streaming" if is_streaming else "batch"
            logger.info(f"Successfully configured Kafka reader for topic '{topic}' ({mode}). Servers: '{bootstrap_servers}'.")
            return df # Raw Kafka DataFrame (key, value, topic, partition, offset, etc.)
        except Exception as e:
            logger.error(f"Error configuring Kafka reader for topic '{topic}': {e}", exc_info=True)
            return None

    def read_from_jdbc(self, table_or_query: str, # Non-default arguments first
                       jdbc_url_key: str = "JDBC_URL", 
                       user_secret_key: Optional[str] = "JDBC_USER",
                       password_secret_key: Optional[str] = "JDBC_PASSWORD",
                       driver: Optional[str] = None, 
                       jdbc_options: Optional[Dict[str, str]] = None,
                       secret_scope: Optional[str] = "jdbc_credentials") -> Optional[DataFrame]:
        """Reads data from a relational database via JDBC. Production: use partitioning options for large tables."""
        if not self.spark: logger.error("SparkSession not available for ConnectorClients."); return None

        jdbc_url = self.config_mgr.get_config(jdbc_url_key, secret_scope=secret_scope) 
        if not jdbc_url:
            logger.error(f"JDBC URL key '{jdbc_url_key}' not found in config/secrets (scope: {secret_scope})."); return None

        options = {"url": jdbc_url}
        # Differentiate between reading a full table and executing a query
        if "SELECT " in table_or_query.strip().upper().split('\n')[0]: # Basic check if it's a query
            options["query"] = table_or_query
            logger.info(f"JDBC source configured with query: {table_or_query[:100]}...")
        else:
            options["dbtable"] = table_or_query # Assumed to be a table name
            logger.info(f"JDBC source configured with table: {table_or_query}")
            # For large tables, partitioning is crucial for performance:
            # options["partitionColumn"] = "id_column_numeric_or_date"
            # options["lowerBound"] = "1"
            # options["upperBound"] = "1000000"
            # options["numPartitions"] = "20"
            # options["fetchsize"] = "10000" # Driver-specific fetch size
            if jdbc_options and ("partitionColumn" in jdbc_options or "numPartitions" in jdbc_options):
                logger.info(f"JDBC read for table '{table_or_query}' includes partitioning options.")
            else:
                logger.warning(f"Reading full JDBC table '{table_or_query}' without partitioning options. This can be slow for large tables.")


        if user_secret_key and password_secret_key: # Both must be provided if auth is by user/pass
            user = self.config_mgr.get_config(user_secret_key, is_secret=True, secret_scope=secret_scope)
            password = self.config_mgr.get_config(password_secret_key, is_secret=True, secret_scope=secret_scope)
            if user is not None and password is not None: # Allow empty user/pass if that's valid for DB
                options["user"] = user
                options["password"] = password
            else: logger.warning(f"JDBC user/password secrets ('{user_secret_key}', '{password_secret_key}') not fully found in scope '{secret_scope}'. Connection might fail or use other auth.")
        
        if driver: options["driver"] = driver
        if jdbc_options: options.update(jdbc_options)

        try:
            df = self.spark.read.format("jdbc").options(**options).load()
            logger.info(f"Successfully read from JDBC source: {table_or_query} at {jdbc_url.split('@')[-1] if '@' in jdbc_url else jdbc_url}") # Avoid logging full URL if it contains creds
            return df
        except Exception as e:
            logger.error(f"Error reading from JDBC source '{table_or_query}': {e}", exc_info=True)
            return None


# === src/dq_ingestion/custom_ingestors.py ===
import requests 
import pandas as pd 

class CustomIngestors:
    """
    Custom ingestion scripts for Web APIs and processing local/DBFS file uploads.
    (Blueprint Section II.C and Table 1 for File Uploads)
    """
    def __init__(self, spark_session: SparkSession, config_manager_instance: ConfigManager, dbutils_instance):
        self.spark = spark_session
        self.config_mgr = config_manager_instance
        self.dbutils = dbutils_instance 

    def fetch_api_data_and_stage(self, api_url: str, output_path: str, 
                                 api_key_name: Optional[str] = None,  
                                 api_key_scope: Optional[str] = "api_credentials", 
                                 is_spark_env: bool = True):
        headers = {}
        if api_key_name and api_key_scope:
            api_key = self.config_mgr.get_config(api_key_name, is_secret=True, secret_scope=api_key_scope)
            if api_key: headers["Authorization"] = f"Bearer {api_key}"
            else: logger.warning(f"API key '{api_key_name}' not found in scope '{api_key_scope}'.")
        try:
            logger.info(f"Fetching API data from {api_url}")
            response = requests.get(api_url, headers=headers, timeout=30)
            response.raise_for_status()
            data = response.json()
            if not data: logger.warning(f"No data received from API: {api_url}"); return
            if is_spark_env and self.spark:
                if isinstance(data, list) and len(data) > 0: df = self.spark.createDataFrame(data)
                elif isinstance(data, dict): df = self.spark.createDataFrame([data])
                else:
                    logger.error(f"API data from {api_url} not list/dict. Cannot create DataFrame.")
                    if self.dbutils and hasattr(self.dbutils, "fs"):
                        target_file_path = os.path.join(output_path, "raw_api_data.json")
                        self.dbutils.fs.put(target_file_path, json.dumps(data, indent=2), overwrite=True)
                        logger.info(f"Raw JSON API data saved to {target_file_path} using dbutils.")
                    return
                df.write.mode("overwrite").parquet(output_path)
                logger.info(f"API data from {api_url} staged as Parquet to: {output_path}")
            else:
                if not os.path.exists(output_path): os.makedirs(output_path, exist_ok=True)
                file_path = os.path.join(output_path, "api_data.json") 
                with open(file_path, "w", encoding='utf-8') as f: json.dump(data, f, indent=2)
                logger.info(f"API data (non-Spark) saved to: {file_path}")
        except requests.exceptions.RequestException as e: logger.error(f"Error fetching API data from {api_url}: {e}", exc_info=True)
        except Exception as e: logger.error(f"Error processing/staging API data from {api_url}: {e}", exc_info=True)

    def process_uploaded_file(self, file_path_on_dbfs_or_volume: str, file_format: str, 
                                read_options: Optional[Dict[str, str]] = None) -> Optional[DataFrame]:
        """
        Processes a single file uploaded to DBFS or a UC Volume (e.g. from UI upload).
        This is for batch processing. For continuous streams of files, Auto Loader is preferred.
        """
        if not self.spark: logger.error("SparkSession not available for process_uploaded_file."); return None
        
        logger.info(f"Processing uploaded file: '{file_path_on_dbfs_or_volume}', format: '{file_format}'")
        reader = self.spark.read
        effective_options = read_options.copy() if read_options else {} # Use a copy to modify

        try:
            file_format_lower = file_format.lower()
            if file_format_lower == "csv":
                reader = reader.format("csv")
                effective_options.setdefault("header", "true")
                # For single file uploads, inferSchema might be acceptable for user convenience,
                # but for production pipelines, explicit schema or hints are better.
                effective_options.setdefault("inferSchema", "true") 
                if effective_options.get("inferSchema") == "true":
                    logger.warning(f"Inferring schema for CSV: {file_path_on_dbfs_or_volume}. Consider providing schema for robustness.")
            elif file_format_lower == "json":
                reader = reader.format("json")
                effective_options.setdefault("multiLine", "true")
            elif file_format_lower == "excel":
                logger.info(f"Reading Excel file '{file_path_on_dbfs_or_volume}' using pandas (requires openpyxl).")
                # Pandas needs a local file system path. DBFS paths are accessed via /dbfs/ FUSE mount.
                # UC Volume paths are also available via /Volumes/...
                local_fs_path = file_path_on_dbfs_or_volume
                if not (local_fs_path.startswith("/dbfs/") or local_fs_path.startswith("/Volumes/")):
                    # Assuming if it's not a volume path, it's a relative DBFS path
                    local_fs_path = f"/dbfs{local_fs_path}" if local_fs_path.startswith("/") else f"/dbfs/{local_fs_path}"
                
                if not os.path.exists(local_fs_path):
                     raise FileNotFoundError(f"Excel file not found at resolved path: {local_fs_path} (original: {file_path_on_dbfs_or_volume})")
                
                # Pass pandas read_excel options if provided in effective_options (e.g., sheet_name)
                pandas_read_excel_opts = {k:v for k,v in effective_options.items() if k in pd.read_excel.__code__.co_varnames}
                if '.xlsx' in local_fs_path.lower() and 'engine' not in pandas_read_excel_opts:
                    pandas_read_excel_opts['engine'] = 'openpyxl'
                
                pandas_df = pd.read_excel(local_fs_path, **pandas_read_excel_opts)
                df = self.spark.createDataFrame(pandas_df)
                logger.info(f"Successfully read Excel file '{file_path_on_dbfs_or_volume}' via pandas and converted to Spark DF.")
                return df 
            elif file_format_lower == "parquet":
                reader = reader.format("parquet")
            else:
                logger.error(f"Unsupported file format '{file_format}' for process_uploaded_file.")
                return None

            for k, v in effective_options.items(): # Apply all collected options
                reader = reader.option(k,v)
            
            df = reader.load(file_path_on_dbfs_or_volume) # Spark can read dbfs:/ and /Volumes/ paths directly
            logger.info(f"Successfully read uploaded file '{file_path_on_dbfs_or_volume}' (format: {file_format}).")
            return df
        except FileNotFoundError as fnf_e: 
            logger.error(f"File not found error during processing of '{file_path_on_dbfs_or_volume}': {fnf_e}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"Error processing uploaded file '{file_path_on_dbfs_or_volume}' (format: {file_format}): {e}", exc_info=True)
            return None


# === src/dq_engine/profiler.py ===
class DataProfiler:
    """
    Profiles data to generate statistics for LLM input or general analysis.
    (Blueprint Section III.A)
    """
    def __init__(self, spark_session: SparkSession):
        self.spark = spark_session

    def profile_dataframe(self, df: DataFrame, table_name_for_report: str) -> Dict[str, Any]:
        if not self.spark or not df:
            logger.error("SparkSession or DataFrame not available for DataProfiler.")
            return {"error": "SparkSession or DataFrame not available."}
        
        profile_summary = {"table_name": table_name_for_report, "column_profiles": []}
        try:
            total_rows = df.count()
            if total_rows == 0:
                logger.info(f"DataFrame for profiling '{table_name_for_report}' is empty.")
                profile_summary["total_rows"] = 0
                for col_name_schema in df.schema: 
                     profile_summary["column_profiles"].append({
                        "column_name": col_name_schema.name,
                        "data_type": str(col_name_schema.dataType),
                        "stats": "No data to profile"
                    })
                return profile_summary
            
            logger.info(f"Profiling DataFrame '{table_name_for_report}' with {total_rows} rows.")
            profile_summary["total_rows"] = total_rows

            for col_schema_field in df.schema: 
                col_name = col_schema_field.name
                col_obj = F.col(col_name)
                col_type_str = str(col_schema_field.dataType)
                col_profile = {"column_name": col_name, "data_type": col_type_str}

                distinct_count_val = df.select(F.approx_count_distinct(col_obj)).first()[0]
                null_count_val = df.where(col_obj.isNull() | F.isnan(col_obj)).count() 
                null_percentage = (null_count_val / total_rows) * 100 if total_rows > 0 else 0
                
                col_profile["distinct_count"] = distinct_count_val
                col_profile["null_count"] = null_count_val
                col_profile["null_percentage"] = round(null_percentage, 2)

                if isinstance(col_schema_field.dataType, (IntegerType, LongType, DoubleType)): 
                    numeric_stats_df = df.select(
                        F.min(col_obj).alias("min"), F.max(col_obj).alias("max"),
                        F.mean(col_obj).alias("mean"), F.stddev(col_obj).alias("stddev"),
                        F.expr(f"percentile_approx({col_name}, 0.25)").alias("p25"),
                        F.expr(f"percentile_approx({col_name}, 0.50)").alias("p50_median"),
                        F.expr(f"percentile_approx({col_name}, 0.75)").alias("p75")
                    ).first()
                    if numeric_stats_df:
                        col_profile["numeric_stats"] = {k: (round(v, 2) if v is not None else None) for k, v in numeric_stats_df.asDict().items()}
                
                elif isinstance(col_schema_field.dataType, StringType):
                    df_lengths = df.withColumn(f"{col_name}_len", F.length(col_obj))
                    string_stats_df = df_lengths.select(
                        F.min(f"{col_name}_len").alias("min_length"),
                        F.max(f"{col_name}_len").alias("max_length"),
                        F.avg(f"{col_name}_len").alias("avg_length")
                    ).first()
                    if string_stats_df:
                        col_profile["string_stats"] = {k: (round(v, 2) if v is not None else None) for k, v in string_stats_df.asDict().items()}

                elif isinstance(col_schema_field.dataType, (TimestampType, DateType)):
                    date_stats_df = df.select(
                        F.min(col_obj).alias("min_date"),
                        F.max(col_obj).alias("max_date")
                    ).first()
                    if date_stats_df:
                        col_profile["date_stats"] = {
                            "min_date": str(date_stats_df.min_date) if date_stats_df.min_date else None,
                            "max_date": str(date_stats_df.max_date) if date_stats_df.max_date else None
                        }
                
                profile_summary["column_profiles"].append(col_profile)
            
            return profile_summary
        except Exception as e:
            logger.error(f"Error during profiling of '{table_name_for_report}'. Error: {e}", exc_info=True)
            return {"error": str(e), "table_name": table_name_for_report}


# === src/dq_engine/llm_interaction.py ===
import tiktoken 

class GroqLLMInteraction:
    """
    Handles interaction with Groq LLMs for tasks like DQ rule suggestion.
    (Blueprint Section III.B)
    """
    DEFAULT_GROQ_MODEL = "llama3-8b-8192" 
    MAX_TOKENS_DEFAULT = 8192 

    def __init__(self, config_manager_instance: ConfigManager,
                 llm_model_name: Optional[str] = None,
                 max_prompt_tokens: Optional[int] = None): 
        self.config_mgr = config_manager_instance
        self.api_key = self.config_mgr.get_config("GROQ_API_KEY", is_secret=True, secret_scope="groq_credentials")
        self.api_url = self.config_mgr.get_config("GROQ_API_URL", default='https://api.groq.com/openai/v1/chat/completions')
        self.model_name = llm_model_name if llm_model_name else self.DEFAULT_GROQ_MODEL
        self.model_max_total_tokens = self._get_max_tokens_for_model(self.model_name)
        self.max_prompt_tokens = max_prompt_tokens if max_prompt_tokens is not None else int(self.model_max_total_tokens * 0.75) 

        try:
            self.tokenizer = tiktoken.encoding_for_model("gpt-3.5-turbo") 
        except Exception:
            logger.warning("Tiktoken gpt-3.5-turbo tokenizer not found, falling back to cl100k_base. Token counts might be approximate.")
            self.tokenizer = tiktoken.get_encoding("cl100k_base")

    def _get_max_tokens_for_model(self, model_name: str) -> int:
        parts = model_name.split('-')
        for part in reversed(parts):
            if part.isdigit(): return int(part)
        logger.warning(f"Could not determine max tokens from model name '{model_name}'. Using default {self.MAX_TOKENS_DEFAULT}.")
        return self.MAX_TOKENS_DEFAULT

    def _count_tokens(self, text: str) -> int:
        return len(self.tokenizer.encode(text))

    def _truncate_prompt(self, prompt: str) -> str:
        tokens = self.tokenizer.encode(prompt)
        if len(tokens) > self.max_prompt_tokens:
            logger.warning(f"Prompt is too long ({len(tokens)} tokens). Truncating to {self.max_prompt_tokens} tokens.")
            truncated_tokens = tokens[:self.max_prompt_tokens]
            return self.tokenizer.decode(truncated_tokens)
        return prompt

    async def _call_groq_api(self, prompt: str, is_json_response: bool = False, json_schema_obj: Optional[Dict] = None) -> Optional[Union[Dict, str]]:
        if not self.api_key:
            logger.error("Groq API key not configured. Cannot call Groq API.")
            return None
        
        current_prompt_content = prompt
        if is_json_response and json_schema_obj:
            schema_instruction = (
                f"\nPlease provide your response as a JSON object adhering to the following schema:"
                f"\n```json\n{json.dumps(json_schema_obj, indent=2)}\n```"
                f"\nEnsure the output is ONLY the JSON object, with no surrounding text or explanations."
            )
            current_prompt_content += schema_instruction
        
        truncated_prompt = self._truncate_prompt(current_prompt_content)
        messages = [{"role": "user", "content": truncated_prompt}]
        payload = {"model": self.model_name, "messages": messages}
        if is_json_response: payload["response_format"] = {"type": "json_object"}

        headers = {'Authorization': f'Bearer {self.api_key}', 'Content-Type': 'application/json'}
        timeout_seconds = float(self.config_mgr.get_config("HF_TIMEOUT", default=60.0)) 

        async with httpx.AsyncClient(timeout=timeout_seconds) as client:
            try:
                logger.debug(f"Calling Groq API. Model: {self.model_name}, Prompt (first 100 chars): {truncated_prompt[:100]}...")
                response = await client.post(self.api_url, headers=headers, json=payload)
                response.raise_for_status()
                result = response.json()

                if result.get("choices") and result["choices"][0].get("message") and result["choices"][0]["message"].get("content"):
                    content = result["choices"][0]["message"]["content"]
                    if is_json_response:
                        try:
                            if content.strip().startswith("```json"): content = content.strip()[7:-3].strip()
                            elif content.strip().startswith("```"): content = content.strip()[3:-3].strip()
                            return json.loads(content)
                        except json.JSONDecodeError as e:
                            logger.error(f"Failed to parse LLM JSON response: {e}. Raw content: {content}", exc_info=True)
                            return {"error": "Failed to parse JSON response", "raw_content": content}
                    else: return content
                else:
                    logger.error(f"Unexpected Groq API response structure: {result}")
                    return None
            except httpx.HTTPStatusError as e:
                logger.error(f"Groq API request failed with status {e.response.status_code}: {e.response.text}", exc_info=True)
                return None
            except httpx.RequestError as e: logger.error(f"Groq API request failed (network/timeout): {e}", exc_info=True); return None
            except Exception as e: logger.error(f"An unexpected error occurred during Groq API call: {e}", exc_info=True); return None

    async def suggest_dq_rules(self, data_profile: Dict[str, Any], num_suggestions: int = 5) -> Optional[List[Dict[str, Any]]]:
        if 'error' in data_profile:
            logger.error(f"Cannot suggest rules due to profiling error: {data_profile['error']}")
            return None
        
        profile_summary_for_prompt = f"Table: {data_profile.get('table_name', 'N/A')}, Rows: {data_profile.get('total_rows', 'N/A')}\n"
        profile_summary_for_prompt += "Column Profiles (Name, Type, Distincts, Nulls%):\n"
        for col_prof in data_profile.get("column_profiles", []):
            profile_summary_for_prompt += (
                f"- {col_prof.get('column_name')} ({col_prof.get('data_type')}): "
                f"D:{col_prof.get('distinct_count')}, N:{col_prof.get('null_percentage')}%\n"
            )
            if "numeric_stats" in col_prof and col_prof["numeric_stats"]:
                profile_summary_for_prompt += f"  Num Stats (min/max/mean): {col_prof['numeric_stats'].get('min')}/{col_prof['numeric_stats'].get('max')}/{col_prof['numeric_stats'].get('mean')}\n"

        prompt = f"""
        Given this data profile summary:
        {profile_summary_for_prompt}
        Suggest {num_suggestions} data quality rules for this table.
        Focus on Accuracy, Completeness, Uniqueness, Consistency, Validity.
        For each rule, provide: rule_name, rule_type, column_name, description, parameters (as a JSON object), and suggested_spark_sql_condition.
        Return ONLY a JSON array of rule objects.
        Example of a single rule object:
        {{
            "rule_name": "Valid Age Range", "rule_type": "range_check", "column_name": "age",
            "description": "Age should be between 0 and 120.",
            "parameters": {{"min_value": 0, "max_value": 120}},
            "suggested_spark_sql_condition": "age < 0 OR age > 120"
        }}
        Ensure the output is a valid JSON array.
        """
        rule_schema = { 
            "type": "OBJECT", "properties": {
                "rule_name": {"type": "STRING"}, "rule_type": {"type": "STRING"},
                "column_name": {"type": "STRING"}, "description": {"type": "STRING"},
                "parameters": {"type": "OBJECT"}, "suggested_spark_sql_condition": {"type": "STRING"}
            }, "required": ["rule_name", "rule_type", "column_name", "description", "parameters", "suggested_spark_sql_condition"]
        }
        response_schema_for_prompt = {"type": "ARRAY", "items": rule_schema}
        
        llm_response = await self._call_groq_api(prompt, is_json_response=True, json_schema_obj=response_schema_for_prompt)
        
        if isinstance(llm_response, list): return llm_response
        elif isinstance(llm_response, dict) and "error" in llm_response:
            logger.error(f"LLM returned an error or unparseable JSON for rule suggestion: {llm_response}")
        else: logger.error(f"LLM did not return a valid JSON list for rule suggestion. Response: {llm_response}")
        return None


# === src/dq_engine/rule_manager.py ===
class DQRuleManager:
    """
    Manages storage and retrieval of DQ rule configurations in a Delta table.
    (Blueprint Section III.C)
    """
    def __init__(self, spark_session: SparkSession, rules_table_fqn: str = "my_catalog.my_schema.dq_rules"):
        self.spark = spark_session
        self.rules_table_fqn = rules_table_fqn
        self._ensure_rules_table_exists()

    def _get_rule_schema(self) -> StructType: 
        return StructType([
            StructField("rule_id", StringType(), False), StructField("rule_name", StringType(), True),
            StructField("rule_type", StringType(), True), StructField("column_name", StringType(), True),
            StructField("description", StringType(), True), StructField("parameters_json", StringType(), True),
            StructField("spark_sql_condition", StringType(), True), StructField("is_active", BooleanType(), True),
            StructField("severity", StringType(), True), StructField("dimension", StringType(), True),
            StructField("weight", DoubleType(), True), StructField("created_at", TimestampType(), True),
            StructField("updated_at", TimestampType(), True), StructField("version", LongType(), True),
            StructField("tags_json", StringType(), True)
        ])

    def _ensure_rules_table_exists(self): 
        if not self.spark: logger.error("SparkSession not available for DQRuleManager."); return
        try:
            if not self.spark.catalog.tableExists(self.rules_table_fqn):
                logger.info(f"Rules table {self.rules_table_fqn} does not exist. Creating...")
                self.spark.createDataFrame([], self._get_rule_schema()) \
                    .write.format("delta").saveAsTable(self.rules_table_fqn)
                logger.info(f"Rules table {self.rules_table_fqn} created.")
        except Exception as e:
            logger.error(f"Failed to create or check rules table {self.rules_table_fqn}. Error: {e}", exc_info=True)
    
    def save_rules(self, rules_config_list: List[Dict[str, Any]], mode: str = "append"): 
        if not self.spark: logger.error("SparkSession not available. Cannot save rules."); return
        if not rules_config_list: logger.warning("No rules to save."); return
        
        processed_rules = []
        for rule_dict_orig in rules_config_list:
            rule_dict = rule_dict_orig.copy() 
            if "rule_id" not in rule_dict or not rule_dict["rule_id"]: 
                rule_dict["rule_id"] = f"rule_{datetime.now(timezone.utc).timestamp()}_{hash(json.dumps(rule_dict, sort_keys=True))}"
            
            rule_dict["parameters_json"] = json.dumps(rule_dict.pop("parameters", {}))
            rule_dict["tags_json"] = json.dumps(rule_dict.pop("tags", []))
            
            current_ts = datetime.now(timezone.utc)
            rule_dict.setdefault("is_active", True); rule_dict.setdefault("severity", "MEDIUM")
            rule_dict.setdefault("dimension", "N/A"); rule_dict.setdefault("weight", 1.0)
            rule_dict.setdefault("created_at", current_ts); rule_dict.setdefault("updated_at", current_ts)
            rule_dict.setdefault("version", 1) 
            
            schema_field_names = {f.name for f in self._get_rule_schema().fields}
            final_rule_dict = {k: v for k, v in rule_dict.items() if k in schema_field_names}
            for field_name in schema_field_names:
                final_rule_dict.setdefault(field_name, None)

            processed_rules.append(Row(**final_rule_dict))
            
        if not processed_rules: logger.warning("No valid rules to process after transformation."); return
        
        try:
            rules_df = self.spark.createDataFrame(processed_rules, schema=self._get_rule_schema())
            rules_df.write.format("delta").mode(mode).option("mergeSchema", "true").saveAsTable(self.rules_table_fqn)
            logger.info(f"Successfully saved {len(processed_rules)} rules to {self.rules_table_fqn} in mode '{mode}'.")
        except Exception as e:
            logger.error(f"Error saving rules to {self.rules_table_fqn}. Error: {e}", exc_info=True)

    def load_active_rules(self, dimension_filter: Optional[str] = None) -> Optional[DataFrame]: 
        if not self.spark: logger.error("SparkSession not available. Cannot load rules."); return None
        if not self.spark.catalog.tableExists(self.rules_table_fqn):
            logger.error(f"Rules table {self.rules_table_fqn} does not exist.")
            return self.spark.createDataFrame([], self._get_rule_schema()) 
        try:
            rules_df = self.spark.read.format("delta").table(self.rules_table_fqn)
            active_rules_df = rules_df.filter(F.col("is_active") == True)
            if dimension_filter:
                active_rules_df = active_rules_df.filter(F.col("dimension") == dimension_filter)
            count = active_rules_df.count()
            logger.info(f"Loaded {count} active rules (filter: {dimension_filter}).")
            return active_rules_df
        except Exception as e:
            logger.error(f"Error loading rules from {self.rules_table_fqn}. Error: {e}", exc_info=True)
            return self.spark.createDataFrame([], self._get_rule_schema()) 


# === src/dq_engine/rule_translator.py ===
class DQRuleTranslator:
    """
    Translates structured rule definitions into executable PySpark/Spark SQL.
    (Blueprint Section III.D)
    """
    def __init__(self, spark_session: SparkSession):
        self.spark = spark_session

    def translate_rule_to_spark_df_operation(self, df_to_validate: DataFrame, rule_config: Dict[str, Any]) -> Optional[DataFrame]:
        if not self.spark or not df_to_validate:
            logger.error("SparkSession or DataFrame not available for DQRuleTranslator.")
            return None
        
        rule_type = rule_config.get("rule_type")
        column_name = rule_config.get("column_name") 
        params_json_str = rule_config.get("parameters_json")
        try:
            parameters = json.loads(params_json_str) if params_json_str else rule_config.get("parameters", {})
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON in parameters_json for rule '{rule_config.get('rule_name')}'. Using empty params.")
            parameters = {}
            
        sql_condition = rule_config.get("spark_sql_condition")
        failing_records_df = None
        rule_name_for_log = rule_config.get('rule_name', 'N/A')
        rule_id_for_log = rule_config.get('rule_id', 'N/A')

        try:
            if sql_condition:
                logger.debug(f"Applying custom SQL condition for rule '{rule_name_for_log}' (ID: {rule_id_for_log}): {sql_condition}")
                failing_records_df = df_to_validate.where(sql_condition)
            elif rule_type == "completeness":
                if not column_name: raise ValueError(f"Column name required for completeness rule '{rule_name_for_log}'.")
                failing_records_df = df_to_validate.filter(F.col(column_name).isNull() | F.isnan(F.col(column_name)))
            elif rule_type == "uniqueness":
                if not column_name: raise ValueError(f"Column name required for uniqueness rule '{rule_name_for_log}'.")
                window_spec = Window.partitionBy(F.col(column_name))
                failing_records_df = df_to_validate.withColumn("_count_for_uniqueness", F.count("*").over(window_spec)) \
                                             .filter(F.col("_count_for_uniqueness") > 1).drop("_count_for_uniqueness")
            elif rule_type == "range_check":
                if not column_name or not all(k in parameters for k in ["min_value", "max_value"]):
                    raise ValueError(f"Column name, min_value, max_value required for range_check rule '{rule_name_for_log}'.")
                min_val, max_val = parameters["min_value"], parameters["max_value"]
                failing_records_df = df_to_validate.filter((F.col(column_name) < min_val) | (F.col(column_name) > max_val))
            elif rule_type == "format_check": 
                if not column_name or "regex_pattern" not in parameters:
                    raise ValueError(f"Column name and regex_pattern required for format_check rule '{rule_name_for_log}'.")
                pattern = parameters["regex_pattern"]
                failing_records_df = df_to_validate.filter(~F.col(column_name).rlike(pattern)) 
            else:
                logger.warning(f"Rule type '{rule_type}' not supported or no SQL condition for rule '{rule_name_for_log}' (ID: {rule_id_for_log}). Skipping.")
                return None 

            if failing_records_df is not None:
                failing_records_df = failing_records_df.withColumn("dq_rule_id", F.lit(rule_config.get("rule_id"))) \
                                                       .withColumn("dq_rule_name", F.lit(rule_config.get("rule_name"))) \
                                                       .withColumn("dq_dimension", F.lit(rule_config.get("dimension")))
            return failing_records_df
        except Exception as e:
            logger.error(f"Error translating/applying rule '{rule_name_for_log}' (ID: {rule_id_for_log}). Type: {rule_type}. Error: {e}", exc_info=True)
            return None


# === src/dq_engine/metrics_calculator.py ===
class DQMetricsCalculator:
    """
    Calculates DQ metrics based on rule execution outcomes.
    (Blueprint Section III.E)
    """
    def __init__(self, spark_session: SparkSession):
        self.spark = spark_session

    def calculate_rule_and_dimension_scores(self,
                                            total_records_in_table: int,
                                            all_failing_records_df: Optional[DataFrame], 
                                            rules_config_df: DataFrame 
                                           ) -> Dict[str, Any]:
        if not self.spark:
            logger.error("SparkSession not available for DQMetricsCalculator.")
            return {"error": "SparkSession not available."}
        
        results = {"overall_dq_score": 100.0, "dimensions": {}, "rules": {}} 
        
        if rules_config_df.isEmpty():
            logger.warning("No rules configured. DQ score defaults to 100%.")
            return results
        
        if total_records_in_table == 0:
            logger.info("No records in table, DQ score is 100%.")
            for rule_row in rules_config_df.collect():
                results["rules"][rule_row.rule_id] = {
                    **rule_row.asDict(), "fail_count": 0, "pass_count": 0, 
                    "total_applicable_records": 0, "pass_percentage": 100.0
                }
            for dim_name in rules_config_df.select("dimension").distinct().rdd.flatMap(lambda x: x).collect():
                results["dimensions"][dim_name] = {"score": 100.0, "weight_sum_rules": 0.0} 
            return results

        if all_failing_records_df is not None and not all_failing_records_df.isEmpty():
            rule_failure_counts_df = all_failing_records_df.groupBy("dq_rule_id") \
                .agg(F.count("*").alias("fail_count"))
        else: 
            schema = StructType([StructField("dq_rule_id", StringType(), True), StructField("fail_count", LongType(), True)])
            rule_failure_counts_df = self.spark.createDataFrame([], schema)

        rules_config_df_renamed = rules_config_df.alias("conf")
        rule_failure_counts_df = rule_failure_counts_df.alias("fail")
        
        rule_stats_df = rules_config_df_renamed.join(
            rule_failure_counts_df,
            F.col("conf.rule_id") == F.col("fail.dq_rule_id"),
            "left_outer"
        ).select(
            F.col("conf.rule_id").alias("rule_id"),
            F.col("conf.rule_name").alias("rule_name"),
            F.col("conf.dimension").alias("dimension"),
            F.col("conf.weight").alias("rule_weight"),
            F.coalesce(F.col("fail.fail_count"), F.lit(0)).alias("fail_count")
        )

        rule_scores_df = rule_stats_df.withColumn("total_applicable_records", F.lit(total_records_in_table))
        rule_scores_df = rule_scores_df.withColumn("pass_count", F.greatest(F.lit(0), F.col("total_applicable_records") - F.col("fail_count"))) 
        rule_scores_df = rule_scores_df.withColumn("pass_percentage",
            (F.col("pass_count") / F.col("total_applicable_records")) * 100
        )
        
        for rule_row in rule_scores_df.collect():
            results["rules"][rule_row.rule_id] = rule_row.asDict()

        rule_scores_df_weighted = rule_scores_df.filter(F.col("rule_weight").isNotNull() & (F.col("rule_weight") > 0))
        if rule_scores_df_weighted.isEmpty():
            logger.warning("No rules with positive weight found for scoring. Overall DQ score might be based on unweighted average or default to 100%.")
            unweighted_avg_pass_pct_df = rule_scores_df.agg(F.avg("pass_percentage").alias("avg_pass"))
            unweighted_avg_pass_pct = unweighted_avg_pass_pct_df.first()["avg_pass"] if unweighted_avg_pass_pct_df.first() else 100.0
            results["overall_dq_score"] = round(unweighted_avg_pass_pct, 2) if unweighted_avg_pass_pct is not None else 100.0
            unweighted_dim_scores_df = rule_scores_df.groupBy("dimension").agg(F.avg("pass_percentage").alias("dim_score"))
            for dim_row in unweighted_dim_scores_df.collect():
                results["dimensions"][dim_row.dimension] = {"score": round(dim_row.dim_score, 2) if dim_row.dim_score is not None else 100.0, "weight_sum_rules": 0.0}
            return results

        dimension_scores_df = rule_scores_df_weighted.groupBy("dimension") \
            .agg(
                (F.sum(F.col("pass_percentage") * F.col("rule_weight")) / F.sum(F.col("rule_weight"))).alias("dimension_score"),
                F.sum(F.col("rule_weight")).alias("total_dimension_weight") 
            )
        
        overall_dq_score_calc_df = dimension_scores_df.filter(F.col("total_dimension_weight") > 0) \
            .agg(
                (F.sum(F.col("dimension_score") * F.col("total_dimension_weight")) / F.sum(F.col("total_dimension_weight"))).alias("overall_score")
            )
        
        overall_score_row = overall_dq_score_calc_df.first()
        if overall_score_row and overall_score_row.overall_score is not None:
            results["overall_dq_score"] = round(overall_score_row.overall_score, 2)
        else: 
            results["overall_dq_score"] = 100.0 
            logger.warning(f"Overall DQ score calculation resulted in None (e.g. no dimensions with weight > 0), defaulting to {results['overall_dq_score']}.")

        for dim_row in dimension_scores_df.collect():
            results["dimensions"][dim_row.dimension] = {
                "score": round(dim_row.dimension_score, 2) if dim_row.dimension_score is not None else 0.0,
                "weight_sum_rules": dim_row.total_dimension_weight
            }
            
        logger.info(f"Calculated DQ metrics. Overall score: {results['overall_dq_score']}")
        return results


# === src/dq_rag/vector_search_interface.py ===
from databricks.vector_search.client import VectorSearchClient
class DatabricksVectorSearchInterface:
    """
    Interface for Databricks Vector Search. (Blueprint Section IV.A)
    """
    def __init__(self, db_workspace_client=None): 
        try:
            self.vsc = VectorSearchClient() 
            logger.info("Databricks VectorSearchClient initialized successfully.")
        except Exception as e:
            logger.error(f"Failed to initialize VectorSearchClient: {e}. Ensure Databricks environment or PAT.", exc_info=True)
            self.vsc = None

    def query_index(self, query_text: str, vs_endpoint_name: str, vs_index_fqn: str,
                    num_results: int = 5,
                    columns_to_return: Optional[List[str]] = None,
                    filters_json_str: Optional[str] = None) -> Optional[List[Dict[str, Any]]]:
        if not self.vsc: logger.error("VectorSearchClient not initialized. Cannot query index."); return None
        if columns_to_return is None: columns_to_return = ["text_content_column", "source_document_id"] 
        
        try:
            logger.info(f"Querying Vector Search index {vs_index_fqn} on endpoint {vs_endpoint_name} with text: '{query_text[:50]}...'")
            index = self.vsc.get_index(endpoint_name=vs_endpoint_name, index_name=vs_index_fqn)
            
            query_params = {
                "query_text": query_text, 
                "columns": columns_to_return,
                "num_results": num_results
            }
            if filters_json_str:
                try:
                    json.loads(filters_json_str) 
                    query_params["filters_json"] = filters_json_str
                except json.JSONDecodeError:
                    logger.error(f"Invalid JSON provided for Vector Search filters: {filters_json_str}")
            
            response = index.similarity_search(**query_params)
            
            retrieved_docs = []
            if response and response.get('result') and response.get('result').get('data_array'):
                data_array = response['result']['data_array']
                for doc_fields_list in data_array:
                    doc_dict = {}
                    for i, col_name in enumerate(columns_to_return):
                        if i < len(doc_fields_list):
                           doc_dict[col_name] = doc_fields_list[i]
                    if len(doc_fields_list) > len(columns_to_return):
                         doc_dict["_score"] = doc_fields_list[len(columns_to_return)] 

                    retrieved_docs.append(doc_dict)
            logger.info(f"Retrieved {len(retrieved_docs)} documents from Vector Search index {vs_index_fqn}.")
            return retrieved_docs
        except Exception as e:
            logger.error(f"Error querying Vector Search index {vs_index_fqn}. Error: {e}", exc_info=True)
            return None


# === src/dq_rag/embedding_generators.py ===
from sentence_transformers import SentenceTransformer 
import ray 

class EmbeddingGenerator:
    """
    Generates embeddings using Hugging Face Sentence Transformers, locally or with Ray.
    (Blueprint Section IV.C for Ray, general embedding for RAG)
    """
    def __init__(self, config_manager_instance: ConfigManager, model_name: str = 'all-MiniLM-L6-v2'):
        self.config_mgr = config_manager_instance
        self.model_name = model_name
        self._local_model: Optional[SentenceTransformer] = None 
        logger.info(f"EmbeddingGenerator initialized with model: {self.model_name}")

    def get_local_model(self) -> SentenceTransformer:
        """Lazily loads the SentenceTransformer model for local use."""
        if self._local_model is None:
            try:
                logger.info(f"Loading SentenceTransformer model '{self.model_name}' locally...")
                self._local_model = SentenceTransformer(self.model_name)
                logger.info(f"SentenceTransformer model '{self.model_name}' loaded successfully locally.")
            except Exception as e:
                logger.error(f"Failed to load SentenceTransformer model '{self.model_name}' locally: {e}", exc_info=True)
                raise 
        return self._local_model

    def generate_embedding_local(self, text_to_embed: Union[str, List[str]]) -> Optional[Union[List[float], List[List[float]]]]:
        """Generates embedding(s) locally for a single text or a list of texts."""
        try:
            model = self.get_local_model()
            logger.debug(f"Generating local embedding for input type: {type(text_to_embed)}")
            embeddings = model.encode(text_to_embed, show_progress_bar=False) 
            return embeddings.tolist() if hasattr(embeddings, 'tolist') else embeddings
        except Exception as e:
            logger.error(f"Error generating local embedding for '{str(text_to_embed)[:100]}...': {e}", exc_info=True)
            return None

    @ray.remote(num_cpus=1) 
    class EmbeddingGeneratorActor:
        def __init__(self, model_name: str):
            self.model = SentenceTransformer(model_name) 
            logger.info(f"Ray Actor (PID: {os.getpid()}): SentenceTransformer model '{model_name}' loaded.")

        def generate_embeddings_batch(self, text_batch: List[str]) -> List[List[float]]:
            logger.debug(f"Ray Actor (PID: {os.getpid()}): Processing batch of {len(text_batch)} texts.")
            embeddings = self.model.encode(text_batch, show_progress_bar=False)
            return embeddings.tolist()

    async def generate_embeddings_with_ray(self, texts: List[str], batch_size: int = 32, num_actors: Optional[int] = None) -> Optional[List[List[float]]]:
        if not texts: return []
        if not ray.is_initialized():
            logger.warning("Ray is not initialized. Attempting to initialize Ray locally with default settings.")
            try:
                ray.init(ignore_reinit_error=True, logging_level=logging.WARNING) 
            except Exception as e:
                logger.error(f"Failed to initialize Ray: {e}. Cannot use Ray for embeddings.", exc_info=True)
                return None
        
        effective_num_actors = num_actors if num_actors is not None else max(1, int(ray.available_resources().get("CPU", 1) // 2)) 
        logger.info(f"Generating embeddings for {len(texts)} texts using Ray with {effective_num_actors} actors and batch size {batch_size}.")
        
        actors = [self.EmbeddingGeneratorActor.remote(self.model_name) for _ in range(effective_num_actors)]
        
        results_refs = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            actor_index = (i // batch_size) % effective_num_actors
            results_refs.append(actors[actor_index].generate_embeddings_batch.remote(batch))
        
        all_embeddings_partitions = await asyncio.gather(*results_refs) 
        
        final_embeddings = [embedding for partition in all_embeddings_partitions for embedding in partition] 
        
        logger.info(f"Successfully generated {len(final_embeddings)} embeddings using Ray.")
        return final_embeddings


# === src/dq_rag/weaviate_fallback_client.py ===
import weaviate 

class WeaviateClientRAG:
    """
    Client for interacting with Weaviate as a RAG fallback. (Blueprint Section IV.B)
    """
    def __init__(self, config_manager_instance: ConfigManager, embedding_generator_instance: EmbeddingGenerator):
        self.config_mgr = config_manager_instance
        self.embed_gen = embedding_generator_instance

        weaviate_url = self.config_mgr.get_config("WEAVIATE_URL")
        weaviate_api_key = self.config_mgr.get_config("WEAVIATE_API_KEY", is_secret=True, secret_scope="weaviate_credentials")
        self.collection_name = self.config_mgr.get_config("WEAVIATE_COLLECTION_NAME", default="DataQualityEmbeddings")
        
        if not weaviate_url:
            logger.error("WEAVIATE_URL not configured. Weaviate client cannot be initialized.")
            self.client = None
            return

        auth_config = weaviate.auth.AuthApiKey(api_key=weaviate_api_key) if weaviate_api_key else None
        grpc_endpoint_str = self.config_mgr.get_config("WEAVIATE_GRPC_ENDPOINT")
        grpc_port_str = self.config_mgr.get_config("WEAVIATE_GRPC_PORT", default="50051")
        
        grpc_host = None
        grpc_port = None
        if grpc_endpoint_str:
            parts = grpc_endpoint_str.split(':')
            grpc_host = parts[0]
            if len(parts) > 1 and parts[1].isdigit(): grpc_port = int(parts[1])
            elif grpc_port_str.isdigit(): grpc_port = int(grpc_port_str)
            else: grpc_port = 50051 
            logger.info(f"Weaviate client attempting to use gRPC: {grpc_host}:{grpc_port}")

        additional_headers = {} 
        init_timeout = int(self.config_mgr.get_config("WEAVIATE_TIMEOUT_INIT", default=30))
        query_timeout = int(self.config_mgr.get_config("WEAVIATE_TIMEOUT_QUERY", default=60))

        try: 
            http_host_parts = weaviate_url.split('//')[-1].split(':')
            http_host = http_host_parts[0]
            http_port_val = 80
            if len(http_host_parts) > 1 and http_host_parts[1].isdigit():
                http_port_val = int(http_host_parts[1])
            elif weaviate_url.startswith("https"):
                http_port_val = 443

            self.client = weaviate.connect_to_custom(
                http_host=http_host, http_port=http_port_val,
                http_secure=weaviate_url.startswith("https"),
                grpc_host=grpc_host, grpc_port=grpc_port,
                grpc_secure=True if grpc_host else False, 
                auth_credentials=auth_config,
                additional_headers=additional_headers,
                timeout_config=(init_timeout, query_timeout)
            )
            logger.info(f"Weaviate client v4 style initialized for URL: {weaviate_url}.")
            if not self.client.is_connected(): 
               logger.warning("Weaviate client (v4) reports not connected after initialization.")
        except Exception as e_v4:
            logger.warning(f"Failed to initialize Weaviate client v4 style: {e_v4}. Attempting v3 style.")
            if hasattr(weaviate, 'Client'):
                connection_params_v3 = {}
                if grpc_host and grpc_port:
                     connection_params_v3["grpc_host"] = grpc_host 
                     connection_params_v3["grpc_port"] = grpc_port
                     connection_params_v3["grpc_secure"] = True
                try:
                    self.client = weaviate.Client(
                        url=weaviate_url, auth_client_secret=auth_config,
                        additional_headers=additional_headers,
                        additional_config=weaviate.config.AdditionalConfig(timeout=(init_timeout, query_timeout)), 
                         **connection_params_v3
                    )
                    logger.info(f"Weaviate client v3 style initialized for URL: {weaviate_url}.")
                except Exception as e_v3_init:
                    logger.error(f"Failed to initialize Weaviate client v3 style as well: {e_v3_init}", exc_info=True)
                    self.client = None
            else:
                self.client = None 
            if not self.client:
                logger.error("Failed to initialize Weaviate client with any available method.")

    def ensure_collection_exists(self, vector_dimensionality: int = 384): 
        if not self.client: logger.error("Weaviate client not initialized. Cannot ensure collection exists."); return
        if not hasattr(self.client, 'collections') or not hasattr(self.client.collections, 'exists'):
            logger.warning("Weaviate client does not support v4 'collections.exists' API. Skipping ensure_collection_exists or adapt for v3.")
            return

        try:
            if not self.client.collections.exists(self.collection_name):
                logger.info(f"Weaviate collection '{self.collection_name}' does not exist. Creating...")
                from weaviate.classes.config import Property, DataType, Configure 
                self.client.collections.create(
                    name=self.collection_name,
                    vectorizer_config=Configure.Vectorizer.none(), 
                    properties=[
                        Property(name="text_content", data_type=DataType.TEXT),
                        Property(name="source_id", data_type=DataType.TEXT), 
                    ]
                )
                logger.info(f"Weaviate collection '{self.collection_name}' created.")
            else:
                logger.info(f"Weaviate collection '{self.collection_name}' already exists.")
        except Exception as e:
            logger.error(f"Error ensuring Weaviate collection '{self.collection_name}': {e}", exc_info=True)

    def add_documents_batch(self, documents: List[Dict[str, Any]], embeddings: List[List[float]]):
        if not self.client: logger.error("Weaviate client not initialized. Cannot add documents."); return
        if not hasattr(self.client, 'collections'): logger.warning("Weaviate client (v4 collections API) not available. Skipping add_documents_batch."); return
        if len(documents) != len(embeddings):
            logger.error("Number of documents and embeddings must match for batch add."); return
        
        try:
            collection = self.client.collections.get(self.collection_name)
            with collection.batch.dynamic() as batch_obj: 
                for i, doc_properties in enumerate(documents):
                    batch_obj.add_object(
                        properties=doc_properties, 
                        vector=embeddings[i]
                    )
            logger.info(f"Attempted to add {len(documents)} documents to Weaviate collection '{self.collection_name}'.")
            if batch_obj.has_errors: 
                 logger.error(f"Failed to insert some objects into Weaviate. Number of failed objects: {len(batch_obj.failed_objects)}")
                 for failed_item in batch_obj.failed_objects: 
                     logger.error(f"Failed object: UUID='{failed_item.uuid}', Message='{failed_item.message}', Original Props='{failed_item.object_.properties if failed_item.object_ else 'N/A'}'")
        except Exception as e:
            logger.error(f"Error batch adding documents to Weaviate collection '{self.collection_name}': {e}", exc_info=True)

    def query_collection(self, query_text: str, num_results: int = 5, certainty_threshold: Optional[float]=None) -> Optional[List[Dict[str, Any]]]:
        if not self.client: logger.error("Weaviate client not initialized. Cannot query."); return None
        if not hasattr(self.client, 'collections'): logger.warning("Weaviate client (v4 collections API) not available. Skipping query_collection."); return None

        query_embedding_result = self.embed_gen.generate_embedding_local(query_text)
        if not query_embedding_result or not isinstance(query_embedding_result, list):
            logger.error("Failed to generate valid embedding for query text.")
            return None
        query_embedding: List[float] = query_embedding_result 

        try:
            from weaviate.classes.query import MetadataQuery 
            collection = self.client.collections.get(self.collection_name)
            
            query_params = {
                "near_vector": query_embedding,
                "limit": num_results,
                "return_metadata": MetadataQuery(certainty=True, distance=True, score=True) 
            }
            
            response = collection.query.near_vector(**query_params)
            
            retrieved_docs = []
            for obj in response.objects:
                doc_data = {"properties": obj.properties}
                metadata_obj = obj.metadata
                if metadata_obj:
                    current_certainty = metadata_obj.certainty
                    if current_certainty is None and metadata_obj.distance is not None: 
                        current_certainty = 1.0 - metadata_obj.distance 
                    
                    doc_data["metadata"] = {
                        "certainty": current_certainty,
                        "distance": metadata_obj.distance,
                        "score": metadata_obj.score, 
                    }
                
                if certainty_threshold is not None:
                    if doc_data.get("metadata", {}).get("certainty") is not None and \
                       doc_data["metadata"]["certainty"] >= certainty_threshold:
                        retrieved_docs.append(doc_data)
                else: 
                    retrieved_docs.append(doc_data)

            logger.info(f"Retrieved {len(retrieved_docs)} documents (after certainty filter: {certainty_threshold}) from Weaviate for query: '{query_text[:50]}...'")
            return retrieved_docs
        except Exception as e:
            logger.error(f"Error querying Weaviate collection '{self.collection_name}': {e}", exc_info=True)
            return None


# === src/dq_reporting/pdf_generator.py ===
from jinja2 import Environment, FileSystemLoader
class PDFReportGenerator:
    """
    Generates PDF reports from DQ results using Jinja2 and Playwright.
    (Blueprint Section V)
    """
    def __init__(self, dbutils_instance, template_dir: str = "templates"):
        self.dbutils = dbutils_instance
        try:
            self.script_dir = os.path.dirname(os.path.abspath(__file__))
        except NameError: 
            self.script_dir = os.getcwd() 
            logger.warning(f"__file__ not defined for PDFReportGenerator, using CWD '{self.script_dir}' for template path resolution. Ensure templates are relative to this.")

        self.template_path = os.path.join(self.script_dir, template_dir)
        
        if not os.path.exists(self.template_path) and self.dbutils and hasattr(self.dbutils, "fs"):
            dbfs_template_path_prefix = "/dbfs/FileStore/dq_report_templates/" 
            if os.path.exists(dbfs_template_path_prefix):
                 self.template_path = dbfs_template_path_prefix
                 logger.info(f"Using DBFS template path for PDF reports: {self.template_path}")
            else: logger.warning(f"Local template path {os.path.join(self.script_dir, template_dir)} and DBFS fallback {dbfs_template_path_prefix} not found.")
        elif not os.path.exists(self.template_path):
             logger.warning(f"Local template path {self.template_path} not found and dbutils not available for DBFS fallback.")

        try:
            self.jinja_env = Environment(loader=FileSystemLoader(self.template_path), autoescape=True, enable_async=False) 
            logger.info(f"Jinja2 Environment initialized with template path: {self.template_path}")
        except Exception as e:
            logger.error(f"Error initializing Jinja2 Environment with path {self.template_path}: {e}", exc_info=True)
            self.jinja_env = None

    def _create_html_report_content(self, report_data: Dict[str, Any], html_template_name: str) -> Optional[str]:
        if not self.jinja_env: 
            logger.error("Jinja2 environment not initialized. Cannot create HTML report content.")
            return None
        try:
            template = self.jinja_env.get_template(html_template_name)
            html_content = template.render(data=report_data)
            return html_content
        except Exception as e: 
            logger.error(f"Error rendering HTML template '{html_template_name}'. Error: {e}", exc_info=True)
            return None

    def generate_pdf_report(self, report_data: Dict[str, Any], html_template_name: str, output_pdf_local_path: str) -> bool:
        html_content = self._create_html_report_content(report_data, html_template_name)
        if not html_content: 
            logger.error("PDF generation failed: Could not render HTML content.")
            return False
        
        try:
            from playwright.sync_api import sync_playwright 
        except ImportError:
            logger.error("Playwright library not found. Please install it (`pip install playwright`) and run `playwright install` to download browser binaries.", exc_info=True)
            return False
        
        try:
            with sync_playwright() as p:
                try: 
                    browser = p.chromium.launch() 
                except Exception as browser_err: 
                    logger.error(f"Failed to launch Playwright browser (Chromium): {browser_err}. Ensure browser binaries are installed (e.g. `playwright install chromium`).", exc_info=True)
                    return False
                
                page = browser.new_page()
                page.set_content(html_content) 
                
                pdf_options = {
                    "path": output_pdf_local_path, "format": "A4", 
                    "print_background": True,
                    "margin": {"top": "20mm", "bottom": "20mm", "left": "15mm", "right": "15mm"}
                }
                page.pdf(**pdf_options)
                browser.close()
            logger.info(f"PDF report generated successfully: {output_pdf_local_path}")
            return True
        except Exception as e:
            logger.error(f"Error generating PDF with Playwright. Error: {e}", exc_info=True)
            return False

    def store_pdf_to_uc_volume_or_dbfs(self, local_pdf_path: str, target_storage_path: str) -> bool:
        if not self.dbutils or not hasattr(self.dbutils, "fs"):
            logger.error("dbutils.fs not available. Cannot store PDF to UC Volume/DBFS.")
            return False
        if not os.path.exists(local_pdf_path): 
            logger.error(f"Local PDF file {local_pdf_path} not found for storing.")
            return False
        
        try:
            dbutils_local_src = f"file:{local_pdf_path}" if not local_pdf_path.startswith("file:") else local_pdf_path
            target_dir = os.path.dirname(target_storage_path)
            if not target_storage_path.startswith("/Volumes/") and target_dir != "dbfs:/": 
                 try:
                     self.dbutils.fs.mkdirs(target_dir)
                     logger.debug(f"Ensured target directory exists: {target_dir}")
                 except Exception as mkdir_e:
                     logger.warning(f"Could not create target directory {target_dir} (it might already exist or permissions issue): {mkdir_e}")

            self.dbutils.fs.cp(dbutils_local_src, target_storage_path, recurse=False)
            logger.info(f"PDF report successfully copied from '{local_pdf_path}' to '{target_storage_path}'")
            return True
        except Exception as e:
            logger.error(f"Error copying PDF from '{local_pdf_path}' to '{target_storage_path}'. Error: {e}", exc_info=True)
            return False


# === src/dq_orchestration/workflow_triggers.py ===
from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs 

class DatabricksWorkflowManager:
    """
    Manages Databricks Jobs programmatically using Databricks SDK.
    (Blueprint Section VII.A)
    """
    def __init__(self, config_manager_instance: ConfigManager):
        self.config_mgr = config_manager_instance
        databricks_host = self.config_mgr.get_config("DATABRICKS_HOST") 
        databricks_token = self.config_mgr.get_config("DATABRICKS_TOKEN", is_secret=True, secret_scope="databricks_sdk_creds") 
        try:
            self.workspace_client = WorkspaceClient(host=databricks_host, token=databricks_token)
            logger.info("Databricks WorkspaceClient initialized.")
        except Exception as e:
            logger.error(f"Failed to initialize Databricks WorkspaceClient: {e}. Ensure DATABRICKS_HOST/TOKEN are set or SDK can auto-configure.", exc_info=True)
            self.workspace_client = None

    def trigger_job_run(self, job_id: int, notebook_params: Optional[Dict[str, str]] = None) -> Optional[int]:
        if not self.workspace_client: 
            logger.error("Databricks WorkspaceClient not initialized. Cannot trigger job.")
            return None
        try:
            run_response = self.workspace_client.jobs.run_now(job_id=job_id, notebook_params=notebook_params)
            logger.info(f"Successfully triggered job ID {job_id}. Run ID: {run_response.run_id}")
            return run_response.run_id
        except Exception as e: 
            logger.error(f"Error triggering job ID {job_id}. Error: {e}", exc_info=True)
            return None

    def get_run_status(self, run_id: int) -> Optional[str]:
        if not self.workspace_client: 
            logger.error("Databricks WorkspaceClient not initialized. Cannot get run status.")
            return None
        try:
            run_details = self.workspace_client.jobs.get_run(run_id=run_id)
            status = run_details.state.life_cycle_state.value 
            logger.debug(f"Status for run ID {run_id}: {status}")
            return status
        except Exception as e:
            logger.error(f"Error getting status for run ID {run_id}. Error: {e}", exc_info=True)
            return None


# === notebooks/run_full_dq_pipeline_job.py (Conceptual main script) ===
# This section outlines the main pipeline logic, designed to be run as a Databricks job.
# It uses the classes defined above and is orchestrated asynchronously.

async def main_dq_pipeline_async(spark_session: SparkSession, dbutils_instance, job_config_dict: Dict[str, Any]):
    """
    Main async function to run the full DQ pipeline, reflecting blueprint orchestration.
    'job_config_dict' holds all necessary parameters, passed via dbutils.widgets or job parameters.
    """
    pipeline_start_time = datetime.now(timezone.utc)
    logger.info(f"Starting Full DQ Pipeline (Async) at {pipeline_start_time.isoformat()}...")
    run_timestamp_str = pipeline_start_time.strftime("%Y%m%d_%H%M%S")

    # 0. Initialize Utilities using job_config_dict and dbutils_instance
    logger.info("Step 0: Initializing utilities...")
    config_mngr_for_secrets = ConfigManager(dbutils_instance=dbutils_instance)

    audit_logger_instance = AuditLogger(spark_session, job_config_dict.get("audit_log_table_fqn"))
    notification_svc = NotificationService(config_mngr_for_secrets) 

    run_as_user = job_config_dict.get("run_as_user", "dq_pipeline_service")
    # Initialize input_table_fqn_for_log; will be updated based on actual source
    input_table_fqn_for_log = job_config_dict.get("input_table_fqn") \
        if job_config_dict.get("source_type", "delta_table").lower() == "delta_table" \
        else job_config_dict.get("source_data_path", "N/A_source_path")


    audit_logger_instance.log_event(
        user_identifier=run_as_user,
        action_taken="DQ_PIPELINE_STARTED",
        event_details={"run_id": f"dq_run_{run_timestamp_str}", "input_source_configured": input_table_fqn_for_log}
    )

    # 1. Data Ingestion / Access
    # This section dynamically selects the ingestion method based on 'source_type'.
    
    source_type = job_config_dict.get("source_type", "delta_table").lower() 
    # Primary identifier for the source (e.g., table name, file path, topic)
    source_identifier = job_config_dict.get("input_table_fqn") # Default for Delta, might be path for files
    if source_type != "delta_table" and job_config_dict.get("source_data_path"): # For file-based or path-based sources
        source_identifier = job_config_dict.get("source_data_path")
    elif source_type == "kafka" and job_config_dict.get("kafka_topic"):
        source_identifier = job_config_dict.get("kafka_topic")
    elif source_type == "jdbc" and job_config_dict.get("jdbc_table_or_query"):
        source_identifier = job_config_dict.get("jdbc_table_or_query")
    
    input_table_fqn_for_log = source_identifier # Use the most relevant identifier for logging

    try:
        logger.info(f"Step 1: Accessing input data source. Type: '{source_type}', Identifier: '{input_table_fqn_for_log}'")
        data_to_validate_df = None
        
        autoloader_mgr = AutoLoaderManager(spark_session, dbutils_instance)
        connector_cli = ConnectorClients(spark_session, config_mngr_for_secrets)
        custom_ingest = CustomIngestors(spark_session, config_mngr_for_secrets, dbutils_instance)

        if source_type == "delta_table":
            if not input_source_identifier: raise ValueError("Missing 'input_table_fqn' for source_type 'delta_table'.")
            data_to_validate_df = spark_session.table(input_source_identifier)
        elif source_type == "file_upload_batch": 
            file_path = job_config_dict.get("source_data_path")
            file_format = job_config_dict.get("source_file_format") 
            if not file_path or not file_format: raise ValueError("Missing 'source_data_path' or 'source_file_format' for 'file_upload_batch'.")
            data_to_validate_df = custom_ingest.process_uploaded_file(file_path, file_format, job_config_dict.get("source_read_options"))
        elif source_type.startswith("autoloader_"): 
            file_format_al = source_type.split("_")[-1]
            al_input_path = job_config_dict.get("source_data_path") # Cloud storage path for AutoLoader
            al_schema_loc = job_config_dict.get("autoloader_schema_location")
            al_checkpoint_loc = job_config_dict.get("autoloader_checkpoint_location") # Checkpoint for the *target* write
            al_target_table = job_config_dict.get("input_table_fqn") # The Delta table AutoLoader writes to, which we read for DQ

            if not all([al_input_path, al_schema_loc, al_checkpoint_loc, al_target_table]):
                raise ValueError("Missing path/schema/checkpoint/target_table for Auto Loader source.")
            
            logger.info(f"Reading target Delta table '{al_target_table}' assumed to be populated by AutoLoader from '{al_input_path}'.")
            data_to_validate_df = spark_session.table(al_target_table)
            input_table_fqn_for_log = al_target_table # Log the table being validated

        elif source_type == "kafka":
            kafka_topic = job_config_dict.get("kafka_topic")
            if not kafka_topic: raise ValueError("Missing 'kafka_topic' for Kafka source.")
            kafka_df_raw = connector_cli.read_from_kafka(
                topic=kafka_topic, 
                starting_offsets=job_config_dict.get("kafka_starting_offsets", "earliest"),
                kafka_options=job_config_dict.get("kafka_options"),
                secret_scope=job_config_dict.get("kafka_secret_scope", "kafka_credentials"),
                is_streaming=False 
            )
            if kafka_df_raw:
                value_schema_struct = job_config_dict.get("kafka_value_schema_struct")
                if not value_schema_struct: raise ValueError("Missing 'kafka_value_schema_struct' for Kafka source to parse value.")
                data_to_validate_df = kafka_df_raw.select(F.col("value").cast("string").alias("json_payload")) \
                                                 .select(F.from_json("json_payload", value_schema_struct).alias("data")) \
                                                 .select("data.*")
            input_table_fqn_for_log = f"kafka_topic_{kafka_topic}"
            
        elif source_type == "jdbc": 
            jdbc_table_or_query_param = job_config_dict.get("jdbc_table_or_query")
            if not jdbc_table_or_query_param: raise ValueError("Missing 'jdbc_table_or_query' for JDBC source.")
            data_to_validate_df = connector_cli.read_from_jdbc(
                table_or_query=jdbc_table_or_query_param,
                jdbc_url_key=job_config_dict.get("jdbc_url_key", "JDBC_URL"),
                user_secret_key=job_config_dict.get("jdbc_user_key"),
                password_secret_key=job_config_dict.get("jdbc_password_key"),
                driver=job_config_dict.get("jdbc_driver"),
                jdbc_options=job_config_dict.get("jdbc_options"),
                secret_scope=job_config_dict.get("jdbc_secret_scope", "jdbc_credentials")
            )
            input_table_fqn_for_log = f"jdbc_source: {jdbc_table_or_query_param[:50]}..." 
        
        elif source_type == "cassandra":
            cass_keyspace = job_config_dict.get("cassandra_keyspace")
            cass_table = job_config_dict.get("cassandra_table")
            cass_host = job_config_dict.get("cassandra_host")
            if not all([cass_keyspace, cass_table, cass_host]): raise ValueError("Missing Cassandra keyspace, table, or host.")
            data_to_validate_df = connector_cli.read_from_cassandra(
                host=cass_host, keyspace=cass_keyspace, table=cass_table,
                secret_scope=job_config_dict.get("cassandra_secret_scope", "cassandra_credentials")
            )
            input_table_fqn_for_log = f"cassandra://{cass_host}/{cass_keyspace}.{cass_table}"

        elif source_type == "mongodb":
            mongo_db = job_config_dict.get("mongodb_database")
            mongo_coll = job_config_dict.get("mongodb_collection")
            if not all([mongo_db, mongo_coll]): raise ValueError("Missing MongoDB database or collection.")
            data_to_validate_df = connector_cli.read_from_mongodb(
                database=mongo_db, collection=mongo_coll,
                secret_scope=job_config_dict.get("mongodb_secret_scope", "mongo_credentials")
            )
            input_table_fqn_for_log = f"mongodb://{mongo_db}.{mongo_coll}"
        
        elif source_type == "web_api":
            api_url = job_config_dict.get("web_api_url")
            api_output_staging_path = job_config_dict.get("web_api_output_staging_path") 
            if not api_url or not api_output_staging_path: raise ValueError("Missing API URL or output staging path for Web API source.")
            custom_ingest.fetch_api_data_and_stage(
                api_url=api_url, output_path=api_output_staging_path,
                api_key_name=job_config_dict.get("web_api_key_name"),
                api_key_scope=job_config_dict.get("web_api_secret_scope", "api_credentials")
            )
            data_to_validate_df = spark_session.read.parquet(api_output_staging_path) 
            input_table_fqn_for_log = f"web_api_staged_at_{api_output_staging_path}"

        else:
            raise ValueError(f"Unsupported 'source_type': {source_type}.")

        if data_to_validate_df is None:
            raise ValueError(f"Failed to load data for source type '{source_type}' with identifier '{input_table_fqn_for_log}'. DataFrame is None.")

        total_records = data_to_validate_df.count()
        logger.info(f"Successfully accessed/loaded data from '{input_table_fqn_for_log}'. Total records: {total_records}")
        if total_records == 0: 
            logger.warning(f"Input source '{input_table_fqn_for_log}' is empty. DQ checks will reflect this.")
    except Exception as e:
        audit_logger_instance.log_event(run_as_user, "DQ_PIPELINE_FAILED", {"reason": f"Failed to load input source {input_table_fqn_for_log}: {str(e)}"})
        logger.error(f"Failed to load input source {input_table_fqn_for_log}: {e}", exc_info=True)
        raise 

    # 2. Data Profiling & LLM Rule Suggestion (Optional, async)
    if str(job_config_dict.get("run_llm_rule_suggestion", "false")).lower() == 'true': 
        logger.info("Step 2: Performing Data Profiling and LLM Rule Suggestion...")
        profiler = DataProfiler(spark_session)
        sample_fraction = float(job_config_dict.get("profiling_sample_fraction", 0.1))
        
        profiled_df_for_llm = data_to_validate_df
        if total_records > 0 and 0.0 < sample_fraction < 1.0:
            profiled_df_for_llm = data_to_validate_df.sample(withReplacement=False, fraction=sample_fraction)
            logger.info(f"Profiling a sample ({sample_fraction*100}%) of the data for LLM rule suggestion.")
        elif total_records == 0:
            logger.warning("Skipping profiling for LLM as input data is empty.")
            profiled_df_for_llm = None 

        if profiled_df_for_llm:
            profile_results = profiler.profile_dataframe(profiled_df_for_llm, input_table_fqn_for_log)
            if 'error' not in profile_results:
                groq_llm_interact = GroqLLMInteraction(config_mngr_for_secrets, llm_model_name=job_config_dict.get("llm_model_for_rules"))
                suggested_rules_list = await groq_llm_interact.suggest_dq_rules(profile_results, num_suggestions=int(job_config_dict.get("num_llm_rule_suggestions", 5)))
                if suggested_rules_list:
                    logger.info(f"LLM suggested {len(suggested_rules_list)} rules.")
                    rule_mngr_for_suggestions = DQRuleManager(spark_session, job_config_dict.get("dq_rules_table_fqn"))
                    adapted_llm_rules = []
                    for s_rule in suggested_rules_list:
                        adapted_llm_rules.append({ 
                            "rule_id": f"llm_sugg_{s_rule.get('rule_name','unnamed_rule').replace(' ','_')}_{run_timestamp_str}",
                            "rule_name": s_rule.get("rule_name"), "rule_type": s_rule.get("rule_type"),
                            "column_name": s_rule.get("column_name"), "description": s_rule.get("description"),
                            "parameters": s_rule.get("parameters", {}), 
                            "spark_sql_condition": s_rule.get("suggested_spark_sql_condition"),
                            "is_active": False, "severity": "SUGGESTION", "dimension": "LLM_SUGGESTED", "weight": 0.0
                        })
                    if adapted_llm_rules: rule_mngr_for_suggestions.save_rules(adapted_llm_rules, mode="append")
                    audit_logger_instance.log_event(run_as_user, "LLM_RULES_SUGGESTED", {"source": input_table_fqn_for_log, "count": len(suggested_rules_list)})
                else: logger.warning(f"LLM did not suggest any rules for {input_table_fqn_for_log} or an error occurred during suggestion.")
            else: logger.error(f"Skipping LLM rule suggestion for {input_table_fqn_for_log} due to profiling error: {profile_results.get('error')}")

    # 3. Load DQ Rules
    dq_rules_table_fqn_param = job_config_dict.get("dq_rules_table_fqn")
    logger.info(f"Step 3: Loading active DQ rules from {dq_rules_table_fqn_param}")
    rule_mgr = DQRuleManager(spark_session, dq_rules_table_fqn_param)
    active_rules_df = rule_mgr.load_active_rules()

    if not active_rules_df or active_rules_df.isEmpty():
        logger.warning(f"No active DQ rules found in {dq_rules_table_fqn_param}. Skipping rule execution and scoring for {input_table_fqn_for_log}.")
        audit_logger_instance.log_event(run_as_user, "DQ_PIPELINE_COMPLETED_NO_RULES", {"source": input_table_fqn_for_log})
        return 

    # 4. Translate and Execute DQ Rules
    logger.info(f"Step 4: Translating and executing {active_rules_df.count()} active DQ rules for {input_table_fqn_for_log}...")
    translator = DQRuleTranslator(spark_session)
    all_failing_records_dfs = []
    
    if total_records > 0: data_to_validate_df.cache() 
    
    active_rules_list_collected = active_rules_df.collect() 
    for rule_row_obj in active_rules_list_collected:
        rule_config_dict = rule_row_obj.asDict()
        logger.debug(f"Applying rule: {rule_config_dict.get('rule_name')} (ID: {rule_config_dict.get('rule_id')}) to {input_table_fqn_for_log}")
        if total_records > 0: 
            failing_df_for_rule = translator.translate_rule_to_spark_df_operation(data_to_validate_df, rule_config_dict)
            if failing_df_for_rule and not failing_df_for_rule.isEmpty():
                all_failing_records_dfs.append(failing_df_for_rule)
                logger.info(f"Rule '{rule_config_dict.get('rule_name')}' found {failing_df_for_rule.count()} failing records.")
            elif failing_df_for_rule is not None: 
                 logger.info(f"Rule '{rule_config_dict.get('rule_name')}' had 0 failing records.")
        else: 
            logger.debug(f"Skipping execution of rule '{rule_config_dict.get('rule_name')}' as input data is empty.")

    if total_records > 0: data_to_validate_df.unpersist() 
    
    final_all_failing_records_df = None
    if all_failing_records_dfs:
        from functools import reduce
        try:
            final_all_failing_records_df = reduce(lambda df1, df2: df1.unionByName(df2, allowMissingColumns=True), all_failing_records_dfs)
            all_failures_table_fqn_param = job_config_dict.get("dq_all_failures_table_fqn")
            final_all_failing_records_df.write.format("delta").mode("overwrite").saveAsTable(all_failures_table_fqn_param)
            num_total_failures = final_all_failing_records_df.count()
            logger.info(f"All {num_total_failures} failing records saved to {all_failures_table_fqn_param}")
            audit_logger_instance.log_event(run_as_user, "DQ_FAILURES_LOGGED", {"source": input_table_fqn_for_log, "log_table": all_failures_table_fqn_param, "num_failure_records_total": num_total_failures})
        except Exception as e:
            logger.error(f"Error during union or saving of all failing records for {input_table_fqn_for_log}: {e}", exc_info=True)
            audit_logger_instance.log_event(run_as_user, "DQ_PIPELINE_ERROR", {"reason": f"Failed to consolidate failing records: {str(e)}"})

    # 5. Calculate DQ Metrics
    logger.info(f"Step 5: Calculating DQ metrics for {input_table_fqn_for_log}...")
    metrics_calc = DQMetricsCalculator(spark_session)
    dq_scores_results = metrics_calc.calculate_rule_and_dimension_scores(
        total_records_in_table=total_records,
        all_failing_records_df=final_all_failing_records_df, 
        rules_config_df=active_rules_df 
    )
    logger.info(f"DQ Scores for {input_table_fqn_for_log}: {json.dumps(dq_scores_results, indent=2, default=str)}")
    
    dq_scores_summary_table_fqn_param = job_config_dict.get("dq_scores_summary_table_fqn")
    try:
        scores_to_save = [{"table_fqn": input_table_fqn_for_log, 
                           "run_timestamp_utc": run_timestamp_str, 
                           "overall_dq_score": dq_scores_results.get("overall_dq_score"),
                           "dimensions_summary_json": json.dumps(dq_scores_results.get("dimensions", {})),
                           "rules_summary_json": json.dumps(dq_scores_results.get("rules", {}), default=str)}]
        
        score_summary_schema = StructType([
            StructField("table_fqn", StringType(), True),
            StructField("run_timestamp_utc", StringType(), True), 
            StructField("overall_dq_score", DoubleType(), True),
            StructField("dimensions_summary_json", StringType(), True),
            StructField("rules_summary_json", StringType(), True)
        ])
        scores_df = spark_session.createDataFrame(scores_to_save, schema=score_summary_schema) 
        scores_df.write.format("delta").mode("append").saveAsTable(dq_scores_summary_table_fqn_param)
        logger.info(f"DQ scores summary for {input_table_fqn_for_log} saved to {dq_scores_summary_table_fqn_param}")
        audit_logger_instance.log_event(run_as_user, "DQ_SCORES_CALCULATED", {"source": input_table_fqn_for_log, "scores_table": dq_scores_summary_table_fqn_param, "overall_score": dq_scores_results.get("overall_dq_score")})
    except Exception as e:
        logger.error(f"Error saving DQ scores summary for {input_table_fqn_for_log}: {e}", exc_info=True)
        audit_logger_instance.log_event(run_as_user, "DQ_PIPELINE_ERROR", {"reason": f"Failed to save DQ scores: {str(e)}"})

    alert_threshold_val = float(job_config_dict.get("alert_threshold", 75.0)) 
    current_overall_score_val = dq_scores_results.get("overall_dq_score", 100.0)
    if current_overall_score_val < alert_threshold_val:
        logger.warning(f"Overall DQ score {current_overall_score_val}% for {input_table_fqn_for_log} is below threshold {alert_threshold_val}%. Sending alert.")
        alert_subject = f"DQ Alert: Score for {input_table_fqn_for_log} is {current_overall_score_val}%"
        alert_body_html = f"""
        <h1>Data Quality Alert</h1>
        <p>The overall Data Quality score for source <strong>{input_table_fqn_for_log}</strong> is currently <strong>{current_overall_score_val}%</strong>,
           which is below the configured threshold of {alert_threshold_val}%.</p>
        <p>Run ID: dq_run_{run_timestamp_str}</p>
        <p>Please investigate the latest DQ report and failure logs.</p>
        <p>Dimensions Summary: {json.dumps(dq_scores_results.get("dimensions", {}), indent=2)}</p>
        """
        notification_svc.send_email(subject=alert_subject, body_html=alert_body_html)
        audit_logger_instance.log_event(run_as_user, "DQ_ALERT_TRIGGERED", {"source": input_table_fqn_for_log, "score": current_overall_score_val, "threshold": alert_threshold_val})

    # 6. Generate PDF Report
    logger.info(f"Step 6: Generating PDF report for {input_table_fqn_for_log}...")
    report_generator = PDFReportGenerator(dbutils_instance=dbutils_instance, template_dir=job_config_dict.get("report_template_dir"))
    
    report_data_for_template = {
        "report_title": f"Data Quality Report for {input_table_fqn_for_log}",
        "overall_score": dq_scores_results.get("overall_dq_score"),
        "dimensions": [], "rules_summary": [],
        "generation_date": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "table_name": input_table_fqn_for_log, "total_rows": total_records,
    }
    for dim_name, dim_data in dq_scores_results.get("dimensions", {}).items():
        report_data_for_template["dimensions"].append({"name": dim_name, "score": dim_data.get("score"), "weight_sum_rules": dim_data.get("weight_sum_rules")})
    for rule_id, rule_data in dq_scores_results.get("rules", {}).items(): 
         report_data_for_template["rules_summary"].append({
             "name": rule_data.get("rule_name"), "dimension": rule_data.get("dimension"),
             "pass_percentage": rule_data.get("pass_percentage"), "fail_count": rule_data.get("fail_count")
         })

    sanitized_source_name = input_table_fqn_for_log.replace('.', '_').replace('/', '_')
    local_pdf_filename = f"/tmp/dq_report_{sanitized_source_name}_{run_timestamp_str}.pdf" 
    
    report_generated_successfully = report_generator.generate_pdf_report(
        report_data=report_data_for_template,
        html_template_name=job_config_dict.get("report_html_template_name"),
        output_pdf_local_path=local_pdf_filename
    )

    if report_generated_successfully:
        target_report_path_prefix = job_config_dict.get("output_report_uc_path_prefix", "/Volumes/my_catalog/my_schema/dq_reports_output/").rstrip('/')
        target_report_full_path = f"{target_report_path_prefix}/dq_report_{sanitized_source_name}_{run_timestamp_str}.pdf" 
        
        report_stored_successfully = report_generator.store_pdf_to_uc_volume_or_dbfs(local_pdf_filename, target_report_full_path)
        if report_stored_successfully:
            audit_logger_instance.log_event(run_as_user, "DQ_REPORT_GENERATED_STORED", {"source": input_table_fqn_for_log, "report_path": target_report_full_path})
        else:
            audit_logger_instance.log_event(run_as_user, "DQ_REPORT_STORAGE_FAILED", {"source": input_table_fqn_for_log, "local_path": local_pdf_filename, "target_path": target_report_full_path})
        
        try: 
            if os.path.exists(local_pdf_filename): os.remove(local_pdf_filename)
        except OSError as e_remove: logger.warning(f"Could not remove temporary PDF file {local_pdf_filename}: {e_remove}")
    else:
        audit_logger_instance.log_event(run_as_user, "DQ_REPORT_GENERATION_FAILED", {"source": input_table_fqn_for_log})

    pipeline_end_time = datetime.now(timezone.utc)
    duration = pipeline_end_time - pipeline_start_time
    logger.info(f"Full DQ Pipeline for {input_table_fqn_for_log} Completed. Duration: {duration}")
    audit_logger_instance.log_event(run_as_user, "DQ_PIPELINE_COMPLETED_SUCCESS", {"source": input_table_fqn_for_log, "overall_score": dq_scores_results.get("overall_dq_score"), "duration_seconds": duration.total_seconds()})


# --- Entry point for the Databricks job ---
if __name__ == "__main__":
    spark_session_main = SparkSession.builder.appName("DQApplicationJob").getOrCreate()
    current_dbutils_main = None 

    EXPECTED_JOB_PARAMS_DEFAULTS = {
        "input_table_fqn": "my_catalog.my_schema.default_dq_target_table", # Placeholder default if source_type is delta_table
        "dq_rules_table_fqn": "my_catalog.my_schema.dq_rules",
        "audit_log_table_fqn": "governance_catalog.audit_db.app_audit_log",
        "dq_all_failures_table_fqn": "my_catalog.my_schema.dq_all_failures",
        "dq_scores_summary_table_fqn": "my_catalog.my_schema.dq_scores_summary",
        "report_template_dir": "templates", 
        "report_html_template_name": "dq_summary_report_template.html",
        "output_report_uc_path_prefix": "/Volumes/my_catalog/my_schema/dq_reports_output/",
        "run_as_user": "job_runner@example.com",
        "run_llm_rule_suggestion": "false", 
        "llm_model_for_rules": GroqLLMInteraction.DEFAULT_GROQ_MODEL,
        "profiling_sample_fraction": "0.1", 
        # "use_delta_source": "true", # Deprecated in favor of source_type
        "source_data_path": None, 
        "alert_threshold": "75.0", 
        "num_llm_rule_suggestions": "5",
        # New parameters for dynamic ingestion
        "source_type": "delta_table", # Default source type
        "source_file_format": None, 
        "source_read_options": None, 
        "autoloader_schema_location": None,
        "autoloader_checkpoint_location": None, # Checkpoint for the *target* table write stream
        "kafka_topic": None,
        "kafka_options": None, 
        "kafka_secret_scope": "kafka_credentials",
        "kafka_value_schema_struct_json": None, 
        "jdbc_table_or_query": None,
        "jdbc_url_key": "JDBC_URL",
        "jdbc_user_key": None, 
        "jdbc_password_key": None, 
        "jdbc_driver": None,
        "jdbc_options": None, 
        "jdbc_secret_scope": "jdbc_credentials",
        "cassandra_keyspace": None,
        "cassandra_table": None,
        "cassandra_host": None,
        "cassandra_secret_scope": "cassandra_credentials",
        "mongodb_database": None,
        "mongodb_collection": None,
        "mongodb_secret_scope": "mongo_credentials",
        "web_api_url": None,
        "web_api_output_staging_path": None, 
        "web_api_key_name": None,
        "web_api_secret_scope": "api_credentials",
        "kafka_starting_offsets": "earliest" 
    }

    if "dbutils" in globals() and hasattr(globals()["dbutils"], "widgets"):
        logger.info("Real dbutils found in globals(). Using dbutils.widgets for job parameters.")
        current_dbutils_main = globals()["dbutils"]
    else:
        logger.warning("dbutils not found or not fully functional. Using a basic mock. Job parameters will be sourced from environment variables or hardcoded defaults.")
        class MockDBUtilsJob:
            def __init__(self, params_config_defaults_dict):
                self.secrets = self._Secrets()
                self.widgets = self._Widgets(params_config_defaults_dict)
                self.fs = self._FS()
            class _Secrets:
                def get(self, scope, key):
                    val = os.getenv(key) 
                    logger.debug(f"MockSecrets: get(scope='{scope}', key='{key}') -> {'****' if val else 'None'}")
                    return val
            class _Widgets:
                def __init__(self, params_config_defaults_dict):
                    self._params_defaults = params_config_defaults_dict
                def get(self, param_name_str): 
                    val = os.getenv(param_name_str.upper()) 
                    if val is None: 
                        val = self._params_defaults.get(param_name_str)
                    logger.debug(f"MockWidgets: get('{param_name_str}') -> '{val}'")
                    return val 
            class _FS:
                def cp(self, src, dest, recurse=False): logger.info(f"MockFS CP: '{src}' to '{dest}'")
                def mv(self, src, dest, recurse=False): logger.info(f"MockFS MV: '{src}' to '{dest}'")
                def rm(self, path, recurse=False): logger.info(f"MockFS RM: '{path}'")
                def mkdirs(self,path): logger.info(f"MockFS MKDIRS: '{path}'")
        current_dbutils_main = MockDBUtilsJob(EXPECTED_JOB_PARAMS_DEFAULTS)

    if load_dotenv(): logger.info(".env file loaded successfully for __main__ block.")
    else: logger.info(".env file not found or not loaded in __main__ block.")

    main_job_config_params_dict = {}
    for key_param, default_param_val in EXPECTED_JOB_PARAMS_DEFAULTS.items():
        try:
            widget_val = current_dbutils_main.widgets.get(key_param)
            if widget_val is not None and widget_val != "": 
                main_job_config_params_dict[key_param] = widget_val
            else: 
                main_job_config_params_dict[key_param] = default_param_val 
                if default_param_val is not None and (widget_val is None or widget_val == "") : 
                     logger.debug(f"For '{key_param}', widget returned '{widget_val}'; using hardcoded default: '{default_param_val}'")
        except Exception as e_widget: 
            # if not isinstance(current_dbutils_main, MockDBUtilsJob): 
            logger.warning(f"Widget for '{key_param}' not found for real dbutils, using default '{default_param_val}'. Error: {e_widget}")
            main_job_config_params_dict[key_param] = default_param_val 

    main_job_config_params_dict["run_llm_rule_suggestion"] = str(main_job_config_params_dict.get("run_llm_rule_suggestion", "false")).lower() == 'true'
    
    for json_opt_key in ["source_read_options", "kafka_options", "jdbc_options"]:
        json_str_val = main_job_config_params_dict.get(json_opt_key)
        if isinstance(json_str_val, str):
            try: main_job_config_params_dict[json_opt_key] = json.loads(json_str_val)
            except json.JSONDecodeError: logger.error(f"Invalid JSON string for '{json_opt_key}': {json_str_val}"); main_job_config_params_dict[json_opt_key] = {} 
        elif json_str_val is None: main_job_config_params_dict[json_opt_key] = {} 
    
    kafka_schema_json = main_job_config_params_dict.get("kafka_value_schema_struct_json")
    if isinstance(kafka_schema_json, str):
        try: main_job_config_params_dict["kafka_value_schema_struct"] = StructType.fromJson(json.loads(kafka_schema_json))
        except Exception as e_schema: logger.error(f"Invalid Kafka value schema JSON: {e_schema}"); main_job_config_params_dict["kafka_value_schema_struct"] = None
    elif kafka_schema_json is None: main_job_config_params_dict["kafka_value_schema_struct"] = None

    # Determine primary input identifier based on source_type for validation
    primary_input_identifier_for_validation = None
    current_source_type = main_job_config_params_dict.get("source_type", "delta_table").lower()

    if current_source_type == "delta_table" or current_source_type.startswith("autoloader_"):
        primary_input_identifier_for_validation = main_job_config_params_dict.get("input_table_fqn")
    elif current_source_type == "file_upload_batch":
        primary_input_identifier_for_validation = main_job_config_params_dict.get("source_data_path")
        if not main_job_config_params_dict.get("source_file_format"): 
             logger.error("Configuration error: 'source_file_format' is required when 'source_type' is 'file_upload_batch'.")
             primary_input_identifier_for_validation = None 
    elif current_source_type == "web_api":
        primary_input_identifier_for_validation = main_job_config_params_dict.get("web_api_url") 
        if not main_job_config_params_dict.get("web_api_output_staging_path"):
            logger.error("Configuration error: 'web_api_output_staging_path' is required for 'web_api' source type.")
            primary_input_identifier_for_validation = None
    elif current_source_type == "kafka":
        primary_input_identifier_for_validation = main_job_config_params_dict.get("kafka_topic")
    elif current_source_type == "jdbc":
        primary_input_identifier_for_validation = main_job_config_params_dict.get("jdbc_table_or_query")
    elif current_source_type == "cassandra":
        if main_job_config_params_dict.get("cassandra_keyspace") and main_job_config_params_dict.get("cassandra_table"):
            primary_input_identifier_for_validation = f"{main_job_config_params_dict.get('cassandra_keyspace')}.{main_job_config_params_dict.get('cassandra_table')}"
    elif current_source_type == "mongodb":
        if main_job_config_params_dict.get("mongodb_database") and main_job_config_params_dict.get("mongodb_collection"):
            primary_input_identifier_for_validation = f"{main_job_config_params_dict.get('mongodb_database')}.{main_job_config_params_dict.get('mongodb_collection')}"
    
    if not primary_input_identifier_for_validation: 
        raise ValueError(f"Critical configuration missing: A primary input identifier (e.g., input_table_fqn, source_data_path, kafka_topic, etc.) is required and could not be determined for source_type '{current_source_type}'. Please check job parameters.")
    if not main_job_config_params_dict.get("dq_rules_table_fqn"): 
        raise ValueError("Critical configuration missing: 'dq_rules_table_fqn' must be provided.")

    try: script_dir_main = os.path.dirname(os.path.abspath(__file__))
    except NameError: script_dir_main = os.getcwd()
    
    template_dir_main = os.path.join(script_dir_main, main_job_config_params_dict.get("report_template_dir", "templates"))
    if not os.path.exists(template_dir_main): 
        try: os.makedirs(template_dir_main, exist_ok=True)
        except Exception as e_mkdir: logger.error(f"Could not create template directory {template_dir_main}: {e_mkdir}")

    html_template_file_main = os.path.join(template_dir_main, main_job_config_params_dict.get("report_html_template_name", "dq_summary_report_template.html"))
    if not os.path.exists(html_template_file_main) and os.path.exists(template_dir_main): 
        logger.info(f"Creating dummy template file at {html_template_file_main} for example run.")
        dummy_template_content = """
        <!DOCTYPE html><html><head><title>{{ data.report_title }}</title></head>
        <body><h1>{{ data.report_title }}</h1><p>Overall Score: {{ data.overall_score }}%</p>
        <p>Generated: {{ data.generation_date }} for table {{ data.table_name }} ({{ data.total_rows }} rows)</p>
        <h2>Dimensions:</h2><ul>{% for dim in data.dimensions %}<li>{{ dim.name }}: {{ dim.score }}%</li>{% endfor %}</ul>
        <h2>Rules Summary (Top 5 Failing):</h2><ul>{% for rule in data.rules_summary | sort(attribute='fail_count', reverse=True) | slice(5) %}
        <li>{{ rule.name }} (Dim: {{rule.dimension}}): {{ rule.pass_percentage }}% passed, {{rule.fail_count}} fails</li>{% endfor %}</ul>
        </body></html>"""
        try:
            with open(html_template_file_main, "w", encoding='utf-8') as f: f.write(dummy_template_content)
        except Exception as e_write_template: logger.error(f"Could not write dummy template file {html_template_file_main}: {e_write_template}")
            
    pipeline_successful = False
    try:
        logger.info(f"Final Job Configuration for Pipeline: {json.dumps(main_job_config_params_dict, default=str, indent=2)}")
        # Apply nest_asyncio if in an environment with a running loop (like Databricks notebooks/jobs)
        try:
            import nest_asyncio
            nest_asyncio.apply()
            logger.info("Applied nest_asyncio for asyncio.run().")
        except ImportError:
            logger.warning("nest_asyncio not found. If 'asyncio.run() cannot be called from a running event loop' error occurs, install nest_asyncio.")
        
        asyncio.run(main_dq_pipeline_async(spark_session_main, current_dbutils_main, main_job_config_params_dict))
        pipeline_successful = True # Mark as successful if asyncio.run completes without exception
    except Exception as pipeline_err:
        logger.critical(f"DQ Pipeline execution failed with error: {pipeline_err}", exc_info=True)
        # Attempt to send failure notification
        try:
            config_mngr_for_failure = ConfigManager(dbutils_instance=current_dbutils_main)
            notifier_for_failure = NotificationService(config_mngr_for_failure)
            notifier_for_failure.send_email(
                subject=f"CRITICAL: DQ Pipeline Failed for {main_job_config_params_dict.get('input_table_fqn', 'Unknown Source')}",
                body_html=f"<p>The DQ pipeline failed with error: {str(pipeline_err)}</p><p>Check logs for run ID around {datetime.now(timezone.utc).isoformat()} for details.</p>"
            )
        except Exception as notify_err_on_failure:
            logger.error(f"Failed to send critical failure notification after pipeline error: {notify_err_on_failure}", exc_info=True)
        # Do not re-raise here if you want finally block to execute cleanly for Spark/Ray shutdown
        # The job will be marked as failed by Databricks if an unhandled exception propagates.
        # If you want to ensure the script exits with an error code:
        # sys.exit(1) 
    finally:
        if ray.is_initialized():
            ray.shutdown()
            logger.info("Ray shut down.")
        spark_session_main.stop()
        logger.info("Spark session stopped.")
        if not pipeline_successful:
            sys.exit(1) # Ensure the job is marked as failed in Databricks if an error occurred



# COMMAND ----------

# dq_application_backend_main.py
# This script consolidates the Python backend code for the Data Quality application.
# It is designed as a comprehensive implementation of the architectural blueprint
# detailed in "Production-Grade Data Quality Application on Databricks: A Petabyte-Scale
# Architectural Blueprint" (document ID: 21851cf4-32af-481f-9b65-1f629e527cdf).
# The code is organized into classes mirroring the modular structure proposed in the blueprint,
# though presented here as a single file for the Canvas environment. In a typical project,
# these classes would be in separate files/modules as per blueprint Section VIII.A.
#
# Key features implemented include:
# - Configuration management prioritizing Databricks utilities and .env fallbacks.
# - Data ingestion framework components (AutoLoader, connectors, custom ingestors).
# - A Data Quality Engine with profiling, Groq LLM-based rule suggestion, rule management,
#   translation, and metrics calculation.
# - A RAG pipeline backend with Databricks Vector Search, Hugging Face embedding generation (via Ray),
#   and a Weaviate fallback client.
# - PDF report generation using Jinja2 and Playwright.
# - Orchestration utilities for Databricks Jobs.
# - Shared utilities for auditing, secret management, Spark operations, and notifications.

import json
import os
import sys
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Union
import asyncio
import httpx
import logging

# PySpark imports
from pyspark.sql import SparkSession, DataFrame, Row
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, LongType, BooleanType,
    TimestampType, DateType, ArrayType, IntegerType)
from pyspark.sql.window import Window

# Setup basic logging
tlogging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(name)s - %(module)s - %(message)s'
)
logger = logging.getLogger(__name__)

# === src/dq_utils/config_manager.py ===
from dotenv import load_dotenv

class ConfigManager:
    """
    Manages configuration loading, prioritizing Databricks widgets/secrets and falling back
    to environment variables or a .env file.
    """
    def __init__(self, dbutils_instance=None, dotenv_path: Optional[str] = None):
        self.dbutils = dbutils_instance
        if dotenv_path and os.path.exists(dotenv_path):
            load_dotenv(dotenv_path)
            logger.info(f"Loaded configurations from .env: {dotenv_path}")
        elif os.path.exists('.env'):
            load_dotenv()
            logger.info("Loaded configurations from .env file in working directory.")
        else:
            logger.info("No .env file found; using Databricks configs or environment variables.")

    def get_config(
        self, key: str, default: Optional[Any] = None,
        is_secret: bool = False, secret_scope: Optional[str] = None
    ) -> Optional[Any]:
        # 1. Widgets
        if self.dbutils and not is_secret and hasattr(self.dbutils, 'widgets'):
            try:
                val = self.dbutils.widgets.get(key)
                if val is not None:
                    logger.debug(f"Config '{key}' from widgets: {val}")
                    return val
            except Exception:
                logger.debug(f"Widget '{key}' not defined.")
        # 2. Secrets
        if self.dbutils and is_secret and secret_scope:
            try:
                val = self.dbutils.secrets.get(scope=secret_scope, key=key)
                if val:
                    logger.debug(f"Secret '{key}' from scope '{secret_scope}' retrieved.")
                    return val
            except Exception:
                logger.warning(f"Cannot retrieve secret '{key}' from scope '{secret_scope}'.")
        # 3. Env var
        env_val = os.getenv(key)
        if env_val is not None:
            logger.debug(f"Config '{key}' from environment: {env_val}")
            return env_val
        # 4. Default
        if default is not None:
            logger.debug(f"Config '{key}' not found; using default: {default}")
            return default
        logger.debug(f"Config '{key}' not found and no default provided.")
        return None

# === src/dq_utils/secrets_manager.py ===
class SecretsManager:
    """
    Utility class for securely retrieving secrets, using ConfigManager.
    """
    def __init__(self, config_manager_instance: ConfigManager, default_secret_scope: str = "dq_app_secrets"):
        self.config_mgr = config_manager_instance
        self.default_secret_scope = default_secret_scope

    def get_secret(self, key: str, scope: Optional[str] = None) -> Optional[str]:
        secret_scope_to_use = scope if scope else self.default_secret_scope
        return self.config_mgr.get_config(key, is_secret=True, secret_scope=secret_scope_to_use)

# === src/dq_utils/audit.py ===
class AuditLogger:
    """
    Handles application-level audit logging to a Delta table.
    Implements blueprint Section VII.D.
    """
    def __init__(self, spark: SparkSession, audit_table_fqn: str = "governance_catalog.audit_db.application_events_log"):
        self.spark = spark
        self.audit_table_fqn = audit_table_fqn
        self._ensure_table()

    def _ensure_table(self):
        try:
            catalog, schema, tbl = self.audit_table_fqn.split('.')
            self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            if not self.spark.catalog.tableExists(self.audit_table_fqn):
                logger.info(f"Creating audit table {self.audit_table_fqn}...")
                schema_df = StructType([
                    StructField("event_timestamp_utc", TimestampType(), False),
                    StructField("user_id", StringType(), True),
                    StructField("action", StringType(), True),
                    StructField("details_json", StringType(), True)
                ])
                self.spark.createDataFrame([], schema_df) \
                    .write.format('delta') \
                    .saveAsTable(self.audit_table_fqn)
                logger.info("Audit table created.")
        except Exception as e:
            logger.error(f"Failed ensure audit table: {e}", exc_info=True)

    def log_event(self, user_id: str, action: str, details: Dict[str, Any]):
        try:
            ts = datetime.now(timezone.utc)
            record = Row(
                event_timestamp_utc=ts,
                user_id=str(user_id),
                action=str(action),
                details_json=json.dumps(details, default=str)
            )
            df = self.spark.createDataFrame([record])
            df.write.format('delta').mode('append').saveAsTable(self.audit_table_fqn)
        except Exception as e:
            logger.error(f"Failed to log audit event: {e}", exc_info=True)

# === src/dq_utils/spark_utils.py ===
class SparkUtils:
    """
    Common PySpark helper functions.
    """
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def optimize_delta_table(self, table_fqn: str, zorder_cols: Optional[List[str]] = None):
        try:
            if zorder_cols:
                self.spark.sql(f"OPTIMIZE {table_fqn} ZORDER BY ({', '.join(zorder_cols)})")
            else:
                self.spark.sql(f"OPTIMIZE {table_fqn}")
        except Exception as e:
            logger.error(f"Failed to optimize table {table_fqn}: {e}", exc_info=True)

    def set_liquid_clustering(self, table_fqn: str, cluster_by_cols: List[str]):
        try:
            alter_query = f"ALTER TABLE {table_fqn} CLUSTER BY ({', '.join(cluster_by_cols)})"
            self.spark.sql(alter_query)
            self.spark.sql(f"OPTIMIZE {table_fqn}")
        except Exception as e:
            logger.error(f"Failed to set Liquid Clustering for {table_fqn}: {e}", exc_info=True)

    def get_table_row_count(self, table_fqn: str) -> Optional[int]:
        try:
            return self.spark.table(table_fqn).count()
        except Exception as e:
            logger.error(f"Could not get row count for {table_fqn}: {e}", exc_info=True)
            return None

# === src/dq_utils/notification_service.py ===
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

class NotificationService:
    """
    Handles sending notifications, e.g., email alerts.
    """
    def __init__(self, config_manager_instance: ConfigManager):
        self.config_mgr = config_manager_instance
        self.smtp_server = self.config_mgr.get_config("SMTP_SERVER")
        smtp_port_str = self.config_mgr.get_config("SMTP_PORT", default="587")
        try:
            self.smtp_port = int(smtp_port_str)
        except ValueError:
            logger.error(f"Invalid SMTP_PORT: '{smtp_port_str}'. Using default 587.")
            self.smtp_port = 587
        self.sender_email = self.config_mgr.get_config("SENDER_EMAIL")
        self.sender_password = self.config_mgr.get_config("SENDER_PASSWORD", is_secret=True, secret_scope="smtp_credentials")
        self.default_recipient_email = self.config_mgr.get_config("RECIPIENT_EMAIL")

    def send_email(self, subject: str, body_html: str, recipient_email: Optional[str] = None, attachments: Optional[List[str]] = None) -> bool:
        if not all([self.smtp_server, self.smtp_port, self.sender_email, self.sender_password]):
            logger.error("SMTP configuration is incomplete. Cannot send email.")
            return False

        to_email = recipient_email if recipient_email else self.default_recipient_email
        if not to_email:
            logger.error("Recipient email not specified and no default is set. Cannot send email.")
            return False

        msg = MIMEMultipart()
        msg['From'] = self.sender_email
        msg['To'] = to_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body_html, 'html'))

        if attachments:
            for file_path in attachments:
                if not os.path.exists(file_path):
                    logger.warning(f"Attachment file not found: {file_path}. Skipping.")
                    continue
                try:
                    with open(file_path, "rb") as attachment_file:
                        part = MIMEBase('application', 'octet-stream')
                        part.set_payload(attachment_file.read())
                    encoders.encode_base64(part)
                    part.add_header('Content-Disposition', f"attachment; filename= {os.path.basename(file_path)}")
                    msg.attach(part)
                    logger.debug(f"Attached file: {file_path}")
                except Exception as e:
                    logger.error(f"Failed to attach file {file_path}: {e}", exc_info=True)
        try:
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.sendmail(self.sender_email, to_email, msg.as_string())
            logger.info(f"Email sent successfully to {to_email} with subject: '{subject}'")
            return True
        except Exception as e:
            logger.error(f"Failed to send email to {to_email} with subject '{subject}'. Error: {e}", exc_info=True)
            return False

# === src/dq_ingestion/autoloader_configs.py ===
class AutoLoaderManager:
    """
    Manages Auto Loader stream configurations for various file types.
    """
    def __init__(self, spark_session: SparkSession, dbutils_instance):
        self.spark = spark_session
        self.dbutils = dbutils_instance

    def _get_base_autoloader_reader(self, schema_location: str,
                                   bad_records_path: Optional[str] = None,
                                   extra_options: Optional[Dict[str, str]] = None) -> Optional[Any]:
        reader = self.spark.readStream.format("cloudFiles") \
            .option("cloudFiles.schemaLocation", schema_location) \
            .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        if bad_records_path:
            reader = reader.option("badRecordsPath", bad_records_path)
        if extra_options:
            for k, v in extra_options.items():
                reader = reader.option(k, v)
        return reader

    def get_autoloader_stream(self,
                              input_path: str,
                              file_format: str,
                              schema_location: str,
                              bad_records_path: Optional[str] = None,
                              extra_options: Optional[Dict[str, str]] = None) -> Optional[DataFrame]:
        base_reader = self._get_base_autoloader_reader(schema_location, bad_records_path, extra_options)
        if not base_reader: return None
        specific_options = {"cloudFiles.format": file_format.lower()}
        if file_format.lower() == "csv":
            specific_options.setdefault("header", "true")
            specific_options.setdefault("inferSchema", "false")
        for k, v in specific_options.items(): base_reader = base_reader.option(k, v)
        try:
            return base_reader.load(input_path)
        except Exception as e:
            logger.error(f"Failed to configure Auto Loader for {file_format.upper()} from path {input_path}. Error: {e}", exc_info=True)
            return None

    def start_autoloader_to_delta(self,
                                 stream_df: DataFrame,
                                 target_table_fqn: str,
                                 checkpoint_location: str,
                                 output_mode: str = "append",
                                 trigger_type: str = "processingTime",
                                 trigger_interval: str = "1 minute") -> Any:
        writer = stream_df.writeStream \
            .format("delta") \
            .outputMode(output_mode) \
            .option("checkpointLocation", checkpoint_location) \
            .option("mergeSchema", "true")
        if trigger_type.lower() == "processingtime":
            writer = writer.trigger(processingTime=trigger_interval)
        return writer.toTable(target_table_fqn)

# === src/dq_ingestion/connector_clients.py ===
class ConnectorClients:
    """
    Clients for reading from various data sources.
    """
    def __init__(self, spark_session: SparkSession, config_manager_instance: ConfigManager):
        self.spark = spark_session
        self.config_mgr = config_manager_instance

    def read_from_cassandra(self, host: str, keyspace: str, table: str,
                            username_secret_key: Optional[str] = "CASSANDRA_USER",
                            password_secret_key: Optional[str] = "CASSANDRA_PASS",
                            secret_scope: Optional[str] = "cassandra_credentials") -> Optional[DataFrame]:
        options = {"spark.cassandra.connection.host": host, "keyspace": keyspace, "table": table}
        username = self.config_mgr.get_config(username_secret_key, is_secret=True, secret_scope=secret_scope)
        password = self.config_mgr.get_config(password_secret_key, is_secret=True, secret_scope=secret_scope)
        if username and password:
            options.update({"spark.cassandra.auth.username": username, "spark.cassandra.auth.password": password})
        try:
            return self.spark.read.format("org.apache.spark.sql.cassandra").options(**options).load()
        except Exception:
            logger.error(f"Error reading from Cassandra {keyspace}.{table}", exc_info=True)
            return None

    def read_from_mongodb(self, database: str, collection: str,
                          connection_uri_secret_key: str = "MONGO_CONNECTION_URI",
                          secret_scope: str = "mongo_credentials") -> Optional[DataFrame]:
        connection_uri = self.config_mgr.get_config(connection_uri_secret_key, is_secret=True, secret_scope=secret_scope)
        if not connection_uri:
            logger.error(f"MongoDB URI secret '{connection_uri_secret_key}' not found.")
            return None
        try:
            return self.spark.read.format("mongodb") \
                .option("spark.mongodb.input.uri", connection_uri) \
                .option("database", database).option("collection", collection).load()
        except Exception:
            logger.error(f"Error reading from MongoDB {database}.{collection}", exc_info=True)
            return None

    def read_from_kafka(self,
                        topic: str,
                        kafka_bootstrap_servers_key: str = "KAFKA_BOOTSTRAP_SERVERS",
                        starting_offsets: str = "earliest",
                        kafka_options: Optional[Dict[str, str]] = None,
                        secret_scope: Optional[str] = "kafka_credentials",
                        is_streaming: bool = False) -> Optional[DataFrame]:
        bootstrap_servers = self.config_mgr.get_config(kafka_bootstrap_servers_key, is_secret=True, secret_scope=secret_scope)
        if not bootstrap_servers:
            logger.error(f"Kafka bootstrap servers key '{kafka_bootstrap_servers_key}' not found.")
            return None
        reader = self.spark.readStream if is_streaming else self.spark.read
        options = {"kafka.bootstrap.servers": bootstrap_servers, "subscribe": topic}
        if is_streaming:
            options["startingOffsets"] = starting_offsets
        if kafka_options: options.update(kafka_options)
        try:
            return reader.format("kafka").options(**options).load()
        except Exception:
            logger.error(f"Error configuring Kafka reader for topic '{topic}'", exc_info=True)
            return None

    def read_from_jdbc(self, table_or_query: str,
                       jdbc_url_key: str = "JDBC_URL",
                       user_secret_key: Optional[str] = "JDBC_USER",
                       password_secret_key: Optional[str] = "JDBC_PASSWORD",
                       driver: Optional[str] = None,
                       jdbc_options: Optional[Dict[str, str]] = None,
                       secret_scope: Optional[str] = "jdbc_credentials") -> Optional[DataFrame]:
        jdbc_url = self.config_mgr.get_config(jdbc_url_key, is_secret=True, secret_scope=secret_scope)
        if not jdbc_url:
            logger.error(f"JDBC URL '{jdbc_url_key}' not found.")
            return None
        options = {"url": jdbc_url}
        if table_or_query.strip().upper().startswith("SELECT "):
            options["query"] = table_or_query
        else:
            options["dbtable"] = table_or_query
        user = self.config_mgr.get_config(user_secret_key, is_secret=True, secret_scope=secret_scope)
        password = self.config_mgr.get_config(password_secret_key, is_secret=True, secret_scope=secret_scope)
        if user is not None and password is not None:
            options["user"] = user
            options["password"] = password
        if driver: options["driver"] = driver
        if jdbc_options: options.update(jdbc_options)
        try:
            return self.spark.read.format("jdbc").options(**options).load()
        except Exception:
            logger.error(f"Error reading from JDBC source '{table_or_query}'", exc_info=True)
            return None

# COMMAND ----------

# dq_application_backend_main.py
# This script consolidates the Python backend code for the Data Quality application.
# It is designed as a comprehensive implementation of the architectural blueprint
# detailed in "Production-Grade Data Quality Application on Databricks: A Petabyte-Scale
# Architectural Blueprint" (document ID: 21851cf4-32af-481f-9b65-1f629e527cdf).
# The code is organized into classes mirroring the modular structure proposed in the blueprint,
# though presented here as a single file for the Canvas environment. In a typical project,
# these classes would be in separate files/modules as per blueprint Section VIII.A.
#
# Key features implemented include:
# - Configuration management prioritizing Databricks utilities and .env fallbacks.
# - Data ingestion framework components (AutoLoader, connectors, custom ingestors).
# - A Data Quality Engine with profiling, Groq LLM-based rule suggestion, rule management,
#   translation, and metrics calculation.
# - A RAG pipeline backend with Databricks Vector Search, Hugging Face embedding generation (via Ray),
#   and a Weaviate fallback client.
# - PDF report generation using Jinja2 and Playwright.
# - Orchestration utilities for Databricks Jobs.
# - Shared utilities for auditing, secret management, Spark operations, and notifications.

import json
import os
import sys
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Union
import asyncio
import httpx
import logging

# PySpark imports
from pyspark.sql import SparkSession, DataFrame, Row
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, LongType, BooleanType,
    TimestampType, DateType, ArrayType, IntegerType)
from pyspark.sql.window import Window

# Setup basic logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(name)s - %(module)s - %(message)s'
)
logger = logging.getLogger(__name__)

# === src/dq_utils/config_manager.py ===
from dotenv import load_dotenv

class ConfigManager:
    """
    Manages configuration loading, prioritizing Databricks widgets/secrets and falling back
    to environment variables or a .env file.
    """
    def __init__(self, dbutils_instance=None, dotenv_path: Optional[str] = None):
        self.dbutils = dbutils_instance
        if dotenv_path and os.path.exists(dotenv_path):
            load_dotenv(dotenv_path)
            logger.info(f"Loaded configurations from .env: {dotenv_path}")
        elif os.path.exists('.env'):
            load_dotenv()
            logger.info("Loaded configurations from .env file in working directory.")
        else:
            logger.info("No .env file found; using Databricks configs or environment variables.")

    def get_config(
        self, key: str, default: Optional[Any] = None,
        is_secret: bool = False, secret_scope: Optional[str] = None
    ) -> Optional[Any]:
        # 1. Widgets
        if self.dbutils and not is_secret and hasattr(self.dbutils, 'widgets'):
            try:
                val = self.dbutils.widgets.get(key)
                if val is not None:
                    logger.debug(f"Config '{key}' from widgets: {val}")
                    return val
            except Exception:
                logger.debug(f"Widget '{key}' not defined.")
        # 2. Secrets
        if self.dbutils and is_secret and secret_scope:
            try:
                val = self.dbutils.secrets.get(scope=secret_scope, key=key)
                if val:
                    logger.debug(f"Secret '{key}' from scope '{secret_scope}' retrieved.")
                    return val
            except Exception:
                logger.warning(f"Cannot retrieve secret '{key}' from scope '{secret_scope}'.")
        # 3. Env var
        env_val = os.getenv(key)
        if env_val is not None:
            logger.debug(f"Config '{key}' from environment: {env_val}")
            return env_val
        # 4. Default
        if default is not None:
            logger.debug(f"Config '{key}' not found; using default: {default}")
            return default
        logger.debug(f"Config '{key}' not found and no default provided.")
        return None

# === src/dq_utils/secrets_manager.py ===
class SecretsManager:
    """
    Utility class for securely retrieving secrets, using ConfigManager.
    """
    def __init__(self, config_manager_instance: ConfigManager, default_secret_scope: str = "dq_app_secrets"):
        self.config_mgr = config_manager_instance
        self.default_secret_scope = default_secret_scope

    def get_secret(self, key: str, scope: Optional[str] = None) -> Optional[str]:
        secret_scope_to_use = scope if scope else self.default_secret_scope
        return self.config_mgr.get_config(key, is_secret=True, secret_scope=secret_scope_to_use)

# === src/dq_utils/audit.py ===
class AuditLogger:
    """
    Handles application-level audit logging to a Delta table.
    Implements blueprint Section VII.D.
    """
    def __init__(self, spark: SparkSession, audit_table_fqn: str = "governance_catalog.audit_db.application_events_log"):
        self.spark = spark
        self.audit_table_fqn = audit_table_fqn
        self._ensure_table()

    def _ensure_table(self):
        try:
            catalog, schema, tbl = self.audit_table_fqn.split('.')
            self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            if not self.spark.catalog.tableExists(self.audit_table_fqn):
                logger.info(f"Creating audit table {self.audit_table_fqn}...")
                schema_df = StructType([
                    StructField("event_timestamp_utc", TimestampType(), False),
                    StructField("user_id", StringType(), True),
                    StructField("action", StringType(), True),
                    StructField("details_json", StringType(), True)
                ])
                self.spark.createDataFrame([], schema_df) \
                    .write.format('delta') \
                    .saveAsTable(self.audit_table_fqn)
                logger.info("Audit table created.")
        except Exception as e:
            logger.error(f"Failed ensure audit table: {e}", exc_info=True)

    def log_event(self, user_id: str, action: str, details: Dict[str, Any]):
        try:
            ts = datetime.now(timezone.utc)
            record = Row(
                event_timestamp_utc=ts,
                user_id=str(user_id),
                action=str(action),
                details_json=json.dumps(details, default=str)
            )
            df = self.spark.createDataFrame([record])
            df.write.format('delta').mode('append').saveAsTable(self.audit_table_fqn)
        except Exception as e:
            logger.error(f"Failed to log audit event: {e}", exc_info=True)

# === src/dq_utils/spark_utils.py ===
class SparkUtils:
    """
    Common PySpark helper functions.
    """
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def optimize_delta_table(self, table_fqn: str, zorder_cols: Optional[List[str]] = None):
        try:
            if zorder_cols:
                self.spark.sql(f"OPTIMIZE {table_fqn} ZORDER BY ({', '.join(zorder_cols)})")
            else:
                self.spark.sql(f"OPTIMIZE {table_fqn}")
        except Exception as e:
            logger.error(f"Failed to optimize table {table_fqn}: {e}", exc_info=True)

    def set_liquid_clustering(self, table_fqn: str, cluster_by_cols: List[str]):
        try:
            alter_query = f"ALTER TABLE {table_fqn} CLUSTER BY ({', '.join(cluster_by_cols)})"
            self.spark.sql(alter_query)
            self.spark.sql(f"OPTIMIZE {table_fqn}")
        except Exception as e:
            logger.error(f"Failed to set Liquid Clustering for {table_fqn}: {e}", exc_info=True)

    def get_table_row_count(self, table_fqn: str) -> Optional[int]:
        try:
            return self.spark.table(table_fqn).count()
        except Exception as e:
            logger.error(f"Could not get row count for {table_fqn}: {e}", exc_info=True)
            return None

# === src/dq_utils/notification_service.py ===
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

class NotificationService:
    """
    Handles sending notifications, e.g., email alerts.
    """
    def __init__(self, config_manager_instance: ConfigManager):
        self.config_mgr = config_manager_instance
        self.smtp_server = self.config_mgr.get_config("SMTP_SERVER")
        smtp_port_str = self.config_mgr.get_config("SMTP_PORT", default="587")
        try:
            self.smtp_port = int(smtp_port_str)
        except ValueError:
            logger.error(f"Invalid SMTP_PORT: '{smtp_port_str}'. Using default 587.")
            self.smtp_port = 587
        self.sender_email = self.config_mgr.get_config("SENDER_EMAIL")
        self.sender_password = self.config_mgr.get_config("SENDER_PASSWORD", is_secret=True, secret_scope="smtp_credentials")
        self.default_recipient_email = self.config_mgr.get_config("RECIPIENT_EMAIL")

    def send_email(self, subject: str, body_html: str, recipient_email: Optional[str] = None, attachments: Optional[List[str]] = None) -> bool:
        if not all([self.smtp_server, self.smtp_port, self.sender_email, self.sender_password]):
            logger.error("SMTP configuration is incomplete. Cannot send email.")
            return False

        to_email = recipient_email if recipient_email else self.default_recipient_email
        if not to_email:
            logger.error("Recipient email not specified and no default is set. Cannot send email.")
            return False

        msg = MIMEMultipart()
        msg['From'] = self.sender_email
        msg['To'] = to_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body_html, 'html'))

        if attachments:
            for file_path in attachments:
                if not os.path.exists(file_path):
                    logger.warning(f"Attachment file not found: {file_path}. Skipping.")
                    continue
                try:
                    with open(file_path, "rb") as attachment_file:
                        part = MIMEBase('application', 'octet-stream')
                        part.set_payload(attachment_file.read())
                    encoders.encode_base64(part)
                    part.add_header('Content-Disposition', f"attachment; filename= {os.path.basename(file_path)}")
                    msg.attach(part)
                    logger.debug(f"Attached file: {file_path}")
                except Exception as e:
                    logger.error(f"Failed to attach file {file_path}: {e}", exc_info=True)
        try:
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.sendmail(self.sender_email, to_email, msg.as_string())
            logger.info(f"Email sent successfully to {to_email} with subject: '{subject}'")
            return True
        except Exception as e:
            logger.error(f"Failed to send email to {to_email} with subject '{subject}'. Error: {e}", exc_info=True)
            return False

# === src/dq_ingestion/autoloader_configs.py ===
class AutoLoaderManager:
    """
    Manages Auto Loader stream configurations for various file types.
    """
    def __init__(self, spark_session: SparkSession, dbutils_instance):
        self.spark = spark_session
        self.dbutils = dbutils_instance

    def _get_base_autoloader_reader(self, schema_location: str,
                                   bad_records_path: Optional[str] = None,
                                   extra_options: Optional[Dict[str, str]] = None) -> Optional[Any]:
        reader = self.spark.readStream.format("cloudFiles") \
            .option("cloudFiles.schemaLocation", schema_location) \
            .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        if bad_records_path:
            reader = reader.option("badRecordsPath", bad_records_path)
        if extra_options:
            for k, v in extra_options.items():
                reader = reader.option(k, v)
        return reader

    def get_autoloader_stream(self,
                              input_path: str,
                              file_format: str,
                              schema_location: str,
                              bad_records_path: Optional[str] = None,
                              extra_options: Optional[Dict[str, str]] = None) -> Optional[DataFrame]:
        base_reader = self._get_base_autoloader_reader(schema_location, bad_records_path, extra_options)
        if not base_reader: return None
        specific_options = {"cloudFiles.format": file_format.lower()}
        if file_format.lower() == "csv":
            specific_options.setdefault("header", "true")
            specific_options.setdefault("inferSchema", "false")
        for k, v in specific_options.items(): base_reader = base_reader.option(k, v)
        try:
            return base_reader.load(input_path)
        except Exception as e:
            logger.error(f"Failed to configure Auto Loader for {file_format.upper()} from path {input_path}. Error: {e}", exc_info=True)
            return None

    def start_autoloader_to_delta(self,
                                 stream_df: DataFrame,
                                 target_table_fqn: str,
                                 checkpoint_location: str,
                                 output_mode: str = "append",
                                 trigger_type: str = "processingTime",
                                 trigger_interval: str = "1 minute") -> Any:
        writer = stream_df.writeStream \
            .format("delta") \
            .outputMode(output_mode) \
            .option("checkpointLocation", checkpoint_location) \
            .option("mergeSchema", "true")
        if trigger_type.lower() == "processingtime":
            writer = writer.trigger(processingTime=trigger_interval)
        return writer.toTable(target_table_fqn)

# === src/dq_ingestion/connector_clients.py ===
class ConnectorClients:
    """
    Clients for reading from various data sources.
    """
    def __init__(self, spark_session: SparkSession, config_manager_instance: ConfigManager):
        self.spark = spark_session
        self.config_mgr = config_manager_instance

    def read_from_cassandra(self, host: str, keyspace: str, table: str,
                            username_secret_key: Optional[str] = "CASSANDRA_USER",
                            password_secret_key: Optional[str] = "CASSANDRA_PASS",
                            secret_scope: Optional[str] = "cassandra_credentials") -> Optional[DataFrame]:
        options = {"spark.cassandra.connection.host": host, "keyspace": keyspace, "table": table}
        username = self.config_mgr.get_config(username_secret_key, is_secret=True, secret_scope=secret_scope)
        password = self.config_mgr.get_config(password_secret_key, is_secret=True, secret_scope=secret_scope)
        if username and password:
            options.update({"spark.cassandra.auth.username": username, "spark.cassandra.auth.password": password})
        try:
            return self.spark.read.format("org.apache.spark.sql.cassandra").options(**options).load()
        except Exception:
            logger.error(f"Error reading from Cassandra {keyspace}.{table}", exc_info=True)
            return None

    def read_from_mongodb(self, database: str, collection: str,
                          connection_uri_secret_key: str = "MONGO_CONNECTION_URI",
                          secret_scope: str = "mongo_credentials") -> Optional[DataFrame]:
        connection_uri = self.config_mgr.get_config(connection_uri_secret_key, is_secret=True, secret_scope=secret_scope)
        if not connection_uri:
            logger.error(f"MongoDB URI secret '{connection_uri_secret_key}' not found.")
            return None
        try:
            return self.spark.read.format("mongodb") \
                .option("spark.mongodb.input.uri", connection_uri) \
                .option("database", database).option("collection", collection).load()
        except Exception:
            logger.error(f"Error reading from MongoDB {database}.{collection}", exc_info=True)
            return None

    def read_from_kafka(self,
                        topic: str,
                        kafka_bootstrap_servers_key: str = "KAFKA_BOOTSTRAP_SERVERS",
                        starting_offsets: str = "earliest",
                        kafka_options: Optional[Dict[str, str]] = None,
                        secret_scope: Optional[str] = "kafka_credentials",
                        is_streaming: bool = False) -> Optional[DataFrame]:
        bootstrap_servers = self.config_mgr.get_config(kafka_bootstrap_servers_key, is_secret=True, secret_scope=secret_scope)
        if not bootstrap_servers:
            logger.error(f"Kafka bootstrap servers key '{kafka_bootstrap_servers_key}' not found.")
            return None
        reader = self.spark.readStream if is_streaming else self.spark.read
        options = {"kafka.bootstrap.servers": bootstrap_servers, "subscribe": topic}
        if is_streaming:
            options["startingOffsets"] = starting_offsets
        if kafka_options: options.update(kafka_options)
        try:
            return reader.format("kafka").options(**options).load()
        except Exception:
            logger.error(f"Error configuring Kafka reader for topic '{topic}'", exc_info=True)
            return None

    def read_from_jdbc(self, table_or_query: str,
                       jdbc_url_key: str = "JDBC_URL",
                       user_secret_key: Optional[str] = "JDBC_USER",
                       password_secret_key: Optional[str] = "JDBC_PASSWORD",
                       driver: Optional[str] = None,
                       jdbc_options: Optional[Dict[str, str]] = None,
                       secret_scope: Optional[str] = "jdbc_credentials") -> Optional[DataFrame]:
        jdbc_url = self.config_mgr.get_config(jdbc_url_key, is_secret=True, secret_scope=secret_scope)
        if not jdbc_url:
            logger.error(f"JDBC URL '{jdbc_url_key}' not found.")
            return None
        options = {"url": jdbc_url}
        if table_or_query.strip().upper().startswith("SELECT "):
            options["query"] = table_or_query
        else:
            options["dbtable"] = table_or_query
        user = self.config_mgr.get_config(user_secret_key, is_secret=True, secret_scope=secret_scope)
        password = self.config_mgr.get_config(password_secret_key, is_secret=True, secret_scope=secret_scope)
        if user is not None and password is not None:
            options["user"] = user
            options["password"] = password
        if driver: options["driver"] = driver
        if jdbc_options: options.update(jdbc_options)
        try:
            return self.spark.read.format("jdbc").options(**options).load()
        except Exception:
            logger.error(f"Error reading from JDBC source '{table_or_query}'", exc_info=True)
            return None

# === src/dq_ingestion/custom_ingestors.py ===
import requests
import pandas as pd

class CustomIngestors:
    """
    Custom ingestion scripts for Web APIs and processing local/DBFS file uploads.
    """
    def __init__(self, spark_session: SparkSession, config_manager_instance: ConfigManager, dbutils_instance=None):
        self.spark = spark_session
        self.config_mgr = config_manager_instance
        self.dbutils = dbutils_instance

    def fetch_api_data_and_stage(self, api_url: str, output_path: str,
                                 api_key_name: Optional[str] = None,
                                 api_key_scope: Optional[str] = "api_credentials",
                                 is_spark_env: bool = True):
        headers = {}
        if api_key_name:
            api_key = self.config_mgr.get_config(api_key_name, is_secret=True, secret_scope=api_key_scope)
            if api_key:
                headers["Authorization"] = f"Bearer {api_key}"
        try:
            response = requests.get(api_url, headers=headers, timeout=30)
            response.raise_for_status()
            data = response.json()
            if is_spark_env and self.spark:
                if isinstance(data, list) and data:
                    df = self.spark.createDataFrame(data)
                elif isinstance(data, dict):
                    df = self.spark.createDataFrame([data])
                else:
                    return
                df.write.mode("overwrite").parquet(output_path)
            else:
                os.makedirs(output_path, exist_ok=True)
                with open(os.path.join(output_path, "api_data.json"), "w") as f:
                    json.dump(data, f, indent=2)
        except Exception:
            logger.error(f"Error fetching/staging API data from {api_url}", exc_info=True)

    def process_uploaded_file(self, file_path: str, file_format: str,
                              read_options: Optional[Dict[str, str]] = None) -> Optional[DataFrame]:
        reader = self.spark.read
        opts = read_options.copy() if read_options else {}
        fmt = file_format.lower()
        try:
            if fmt == "csv":
                reader = reader.format("csv")
                opts.setdefault("header", "true")
                opts.setdefault("inferSchema", "true")
            elif fmt == "json":
                reader = reader.format("json")
                opts.setdefault("multiLine", "true")
            elif fmt == "parquet":
                reader = reader.format("parquet")
            elif fmt == "excel":
                local_path = file_path if file_path.startswith("/dbfs") else f"/dbfs{file_path}"
                df_pd = pd.read_excel(local_path, engine="openpyxl", **opts)
                return self.spark.createDataFrame(df_pd)
            else:
                logger.error(f"Unsupported file format '{fmt}' for processing.")
                return None
            for k, v in opts.items():
                reader = reader.option(k, v)
            return reader.load(file_path)
        except Exception:
            logger.error(f"Error processing uploaded file '{file_path}'", exc_info=True)
            return None

# === src/dq_engine/profiler.py ===
class DataProfiler:
    """
    Profiles data to generate statistics for DQ workflow.
    """
    def __init__(self, spark_session: SparkSession):
        self.spark = spark_session

    def profile_dataframe(self, df: DataFrame, table_name_for_report: str) -> Dict[str, Any]:
        total_rows = df.count()
        profile_summary = {"table_name": table_name_for_report, "total_rows": total_rows, "column_profiles": []}
        for field in df.schema.fields:
            col = field.name
            distinct_count = df.select(F.approx_count_distinct(col)).first()[0]
            null_count = df.filter(F.col(col).isNull() | F.isnan(F.col(col))).count()
            null_pct = round((null_count / total_rows) * 100, 2) if total_rows > 0 else 0
            col_profile = {"column_name": col, "data_type": str(field.dataType),
                           "distinct_count": distinct_count, "null_count": null_count,
                           "null_percentage": null_pct}
            if isinstance(field.dataType, (IntegerType, LongType, DoubleType)):
                stats = df.select(
                    F.min(col).alias("min"), F.max(col).alias("max"),
                    F.mean(col).alias("mean"), F.stddev(col).alias("stddev")
                ).first().asDict()
                col_profile["numeric_stats"] = {k: round(v, 2) if v is not None else None for k, v in stats.items()}
            profile_summary["column_profiles"].append(col_profile)
        return profile_summary

# === src/dq_engine/llm_interaction.py ===
import tiktoken

class GroqLLMInteraction:
    """
    Interact with Groq LLM for DQ rule suggestion.
    """
    DEFAULT_GROQ_MODEL = "llama3-8b-8192"
    MAX_TOKENS_DEFAULT = 8192

    def __init__(self, config_manager_instance: ConfigManager,
                 llm_model_name: Optional[str] = None,
                 max_prompt_tokens: Optional[int] = None):
        self.config_mgr = config_manager_instance
        self.api_key = self.config_mgr.get_config("GROQ_API_KEY", is_secret=True, secret_scope="groq_credentials")
        self.api_url = self.config_mgr.get_config("GROQ_API_URL", default='https://api.groq.com/openai/v1/chat/completions')
        self.model_name = llm_model_name or self.DEFAULT_GROQ_MODEL
        self.model_max_total_tokens = self._get_max_tokens_for_model(self.model_name)
        self.max_prompt_tokens = max_prompt_tokens or int(self.model_max_total_tokens * 0.75)
        try:
            self.tokenizer = tiktoken.encoding_for_model("gpt-3.5-turbo")
        except Exception:
            self.tokenizer = tiktoken.get_encoding("cl100k_base")

    def _get_max_tokens_for_model(self, model_name: str) -> int:
        for part in reversed(model_name.split("-")):
            if part.isdigit(): return int(part)
        return self.MAX_TOKENS_DEFAULT

    def _truncate_prompt(self, prompt: str) -> str:
        tokens = self.tokenizer.encode(prompt)
        if len(tokens) > self.max_prompt_tokens:
            return self.tokenizer.decode(tokens[:self.max_prompt_tokens])
        return prompt

    async def _call_groq_api(self, prompt: str,
                              is_json_response: bool = False,
                              json_schema_obj: Optional[Dict] = None) -> Optional[Union[Dict, str]]:
        if not self.api_key:
            logger.error("Groq API key not configured.")
            return None
        content = self._truncate_prompt(prompt)
        payload = {"model": self.model_name, "messages": [{"role": "user", "content": content}]}
        if is_json_response and json_schema_obj:
            payload["response_format"] = {"type": "json_object"}
        headers = {'Authorization': f'Bearer {self.api_key}', 'Content-Type': 'application/json'}
        async with httpx.AsyncClient(timeout=60) as client:
            try:
                response = await client.post(self.api_url, headers=headers, json=payload)
                response.raise_for_status()
                result = response.json()
                msg = result['choices'][0]['message']['content']
                if is_json_response:
                    return json.loads(msg)
                return msg
            except Exception:
                logger.error("Groq API call failed.", exc_info=True)
                return None

    async def suggest_dq_rules(self, data_profile: Dict[str, Any], num_suggestions: int = 5) -> Optional[List[Dict[str, Any]]]:
        if 'error' in data_profile:
            return None
        prompt = f"Profile: {json.dumps(data_profile)}Suggest {num_suggestions} rules."
        return await self._call_groq_api(prompt, is_json_response=True, json_schema_obj={})

# === src/dq_engine/rule_manager.py ===
class DQRuleManager:
    """
    Manages DQ rule storage and retrieval in Delta.
    """
    def __init__(self, spark_session: SparkSession, rules_table_fqn: str = "my_catalog.my_schema.dq_rules"):
        self.spark = spark_session
        self.rules_table_fqn = rules_table_fqn
        self._ensure_rules_table_exists()

    def _ensure_rules_table_exists(self):
        catalog, schema, tbl = self.rules_table_fqn.split('.')
        self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
        if not self.spark.catalog.tableExists(self.rules_table_fqn):
            schema = StructType([
                StructField("rule_id", StringType(), False),
                StructField("rule_name", StringType(), True),
                StructField("rule_type", StringType(), True),
                StructField("column_name", StringType(), True),
                StructField("description", StringType(), True),
                StructField("parameters_json", StringType(), True),
                StructField("spark_sql_condition", StringType(), True),
                StructField("is_active", BooleanType(), True),
                StructField("severity", StringType(), True),
                StructField("dimension", StringType(), True),
                StructField("weight", DoubleType(), True),
                StructField("created_at", TimestampType(), True),
                StructField("updated_at", TimestampType(), True),
                StructField("version", LongType(), True)
            ])
            self.spark.createDataFrame([], schema).write.format("delta").saveAsTable(self.rules_table_fqn)

    def save_rules(self, rules_config_list: List[Dict[str, Any]], mode: str = "append"):
        rows = []
        for r in rules_config_list:
            rcopy = r.copy()
            rcopy["parameters_json"] = json.dumps(rcopy.pop("parameters", {}))
            rcopy.setdefault("is_active", True)
            rcopy.setdefault("severity", "MEDIUM")
            rcopy.setdefault("dimension", "N/A")
            rcopy.setdefault("weight", 1.0)
            now = datetime.now(timezone.utc)
            rcopy.setdefault("created_at", now)
            rcopy.setdefault("updated_at", now)
            rows.append(Row(**rcopy))
        df = self.spark.createDataFrame(rows)
        df.write.format("delta").mode(mode).option("mergeSchema", "true").saveAsTable(self.rules_table_fqn)

    def load_active_rules(self, dimension_filter: Optional[str] = None) -> DataFrame:
        df = self.spark.read.format("delta").table(self.rules_table_fqn)
        active = df.filter(F.col("is_active") == True)
        if dimension_filter:
            active = active.filter(F.col("dimension") == dimension_filter)
        return active

# === src/dq_engine/rule_translator.py ===
class DQRuleTranslator:
    """
    Translates structured rule definitions into executable PySpark/Spark SQL.
    """
    def __init__(self, spark_session: SparkSession):
        self.spark = spark_session

    def translate_rule_to_spark_df_operation(
        self, df_to_validate: DataFrame, rule_config: Dict[str, Any]
    ) -> Optional[DataFrame]:
        rule_type = rule_config.get("rule_type")
        column = rule_config.get("column_name")
        params = json.loads(rule_config.get("parameters_json", "{}"))
        sql_cond = rule_config.get("spark_sql_condition")
        try:
            if sql_cond:
                failing = df_to_validate.where(sql_cond)
            elif rule_type == "completeness":
                failing = df_to_validate.filter(F.col(column).isNull() | F.isnan(F.col(column)))
            elif rule_type == "uniqueness":
                window = Window.partitionBy(F.col(column))
                failing = df_to_validate.withColumn("_cnt", F.count("*").over(window)) \
                    .filter(F.col("_cnt") > 1).drop("_cnt")
            elif rule_type == "range_check":
                minv, maxv = params.get("min_value"), params.get("max_value")
                failing = df_to_validate.filter((F.col(column) < minv) | (F.col(column) > maxv))
            elif rule_type == "format_check":
                pattern = params.get("regex_pattern")
                failing = df_to_validate.filter(~F.col(column).rlike(pattern))
            else:
                return None
            return failing.withColumn("dq_rule_id", F.lit(rule_config.get("rule_id"))) \
                          .withColumn("dq_rule_name", F.lit(rule_config.get("rule_name")))
        except Exception:
            logger.error(f"Error applying rule {rule_config.get('rule_name')}", exc_info=True)
            return None

# === src/dq_engine/metrics_calculator.py ===
class DQMetricsCalculator:
    """
    Calculates Data Quality metrics based on rule execution outcomes.
    """
    def __init__(self, spark_session: SparkSession):
        self.spark = spark_session

    def calculate_rule_and_dimension_scores(
        self, total_records_in_table: int,
        all_failing_records_df: Optional[DataFrame],
        rules_config_df: DataFrame
    ) -> Dict[str, Any]:
        results = {"overall_dq_score": 100.0, "dimensions": {}, "rules": {}}
        if rules_config_df.rdd.isEmpty(): return results
        if total_records_in_table == 0:
            for row in rules_config_df.collect():
                results["rules"][row.rule_id] = {**row.asDict(), "fail_count": 0, "pass_count": 0, "total_applicable_records": 0, "pass_percentage": 100.0}
            for dim in rules_config_df.select("dimension").distinct().rdd.flatMap(lambda x: x).collect():
                results["dimensions"][dim] = {"score": 100.0, "weight_sum_rules": 0.0}
            return results
        if all_failing_records_df and not all_failing_records_df.rdd.isEmpty():
            fail_counts = all_failing_records_df.groupBy("dq_rule_id").agg(F.count("*").alias("fail_count"))
        else:
            schema = StructType([StructField("dq_rule_id", StringType()), StructField("fail_count", LongType())])
            fail_counts = self.spark.createDataFrame([], schema)
        stats = rules_config_df.alias("r").join(
            fail_counts.alias("f"), F.col("r.rule_id")==F.col("f.dq_rule_id"), "left"
        ).select(
            F.col("r.rule_id"), F.col("r.rule_name"), F.col("r.dimension"), F.col("r.weight"),
            F.coalesce(F.col("f.fail_count"), F.lit(0)).alias("fail_count")
        )
        stats = stats.withColumn("total_applicable_records", F.lit(total_records_in_table)) \
                     .withColumn("pass_count", F.col("total_applicable_records") - F.col("fail_count")) \
                     .withColumn("pass_percentage", (F.col("pass_count") / F.col("total_applicable_records")) * 100)
        for row in stats.collect():
            results["rules"][row.rule_id] = row.asDict()
        weighted = stats.filter(F.col("weight")>0)
        if weighted.rdd.isEmpty():
            avg_pass = stats.agg(F.avg("pass_percentage")).first()[0] or 100.0
            results["overall_dq_score"] = round(avg_pass,2)
            for row in stats.groupBy("dimension").agg(F.avg("pass_percentage").alias("score")).collect():
                results["dimensions"][row.dimension] = {"score": round(row.score,2), "weight_sum_rules": 0.0}
            return results
        dim_scores = weighted.groupBy("dimension").agg(
            (F.sum(F.col("pass_percentage")*F.col("weight"))/F.sum("weight")).alias("dimension_score"),
            F.sum("weight").alias("weight_sum")
        )
        overall = dim_scores.agg((F.sum(F.col("dimension_score")*F.col("weight_sum")) / F.sum("weight_sum")).alias("overall_score")).first().overall_score
        results["overall_dq_score"] = round(overall,2)
        for row in dim_scores.collect():
            results["dimensions"][row.dimension] = {"score": round(row.dimension_score,2), "weight_sum_rules": row.weight_sum}
        return results

# === src/dq_rag/vector_search_interface.py ===
from databricks.vector_search.client import VectorSearchClient
class DatabricksVectorSearchInterface:
    """
    Interface for Databricks Vector Search.
    """
    def __init__(self, db_workspace_client=None):
        try:
            self.vsc = VectorSearchClient()
        except Exception:
            logger.error("Failed to init VectorSearchClient.", exc_info=True)
            self.vsc = None

    def query_index(
        self, query_text: str, vs_endpoint_name: str, vs_index_fqn: str,
        num_results: int = 5, columns_to_return: Optional[List[str]] = None
    ) -> Optional[List[Dict[str,Any]]]:
        if not self.vsc: return None
        columns = columns_to_return or ["text_content_column","source_document_id"]
        idx = self.vsc.get_index(endpoint_name=vs_endpoint_name, index_name=vs_index_fqn)
        resp = idx.similarity_search(query_text=query_text, columns=columns, num_results=num_results)
        docs = []
        for row in resp['result']['data_array']:
            docs.append({columns[i]: row[i] for i in range(len(columns))})
        return docs

# === src/dq_rag/embedding_generators.py ===
from sentence_transformers import SentenceTransformer
import ray
class EmbeddingGenerator:
    """
    Generates embeddings via Hugging Face Sentence Transformers.
    """
    def __init__(self, config_manager_instance: ConfigManager, model_name: str = 'all-MiniLM-L6-v2'):
        self.config_mgr = config_manager_instance
        self.model_name = model_name
        self._local_model = None

    def get_local_model(self) -> SentenceTransformer:
        if not self._local_model:
            self._local_model = SentenceTransformer(self.model_name)
        return self._local_model

    def generate_embedding_local(self, text_to_embed: Union[str,List[str]]) -> Optional[Union[List[float],List[List[float]]]]:
        try:
            model = self.get_local_model()
            emb = model.encode(text_to_embed, show_progress_bar=False)
            return emb.tolist() if hasattr(emb,'tolist') else emb
        except Exception:
            logger.error("Error generating local embedding.", exc_info=True)
            return None

    @ray.remote(num_cpus=1)
    class EmbeddingGeneratorActor:
        def __init__(self, model_name:str):
            self.model = SentenceTransformer(model_name)
        def generate_embeddings_batch(self, texts:List[str]) -> List[List[float]]:
            return self.model.encode(texts, show_progress_bar=False).tolist()

    async def generate_embeddings_with_ray(self, texts: List[str], batch_size:int=32) -> Optional[List[List[float]]]:
        if not ray.is_initialized(): ray.init(ignore_reinit_error=True)
        actors = [self.EmbeddingGeneratorActor.remote(self.model_name) for _ in range(max(1,int(ray.available_resources().get('CPU',1)//2)))]
        parts = []
        for i in range(0,len(texts),batch_size):
            parts.append(actors[i//batch_size % len(actors)].generate_embeddings_batch.remote(texts[i:i+batch_size]))
        results = await asyncio.gather(*parts)
        return [item for sub in results for item in sub]

# === src/dq_rag/weaviate_fallback_client.py ===
import weaviate
class WeaviateClientRAG:
    """
    Client for Weaviate fallback.
    """
    def __init__(self, config_manager_instance: ConfigManager, embedding_generator_instance: EmbeddingGenerator):
        self.config_mgr = config_manager_instance
        self.embed_gen = embedding_generator_instance
        url = self.config_mgr.get_config("WEAVIATE_URL")
        api_key = self.config_mgr.get_config("WEAVIATE_API_KEY", is_secret=True, secret_scope="weaviate_credentials")
        auth = weaviate.AuthApiKey(api_key=api_key) if api_key else None
        self.client = weaviate.connect(url=url, auth_client_secret=auth)
        self.collection = self.config_mgr.get_config("WEAVIATE_COLLECTION_NAME", default="DataQualityEmbeddings")

    def ensure_collection_exists(self, vector_dimensionality: int = 384):
        if not self.client.schema.exists(self.collection):
            self.client.schema.create_class({"class": self.collection, "properties": [{"name":"text_content","dataType":["text"]}]})

    def add_documents_batch(self, documents:List[Dict[str,Any]], embeddings:List[List[float]]):
        with self.client.batch as batch:
            for doc, emb in zip(documents,embeddings):
                batch.add_data_object(properties=doc, class_name=self.collection, vector=emb)

    def query_collection(self, query_text:str, num_results:int=5, certainty_threshold:Optional[float]=None):
        emb = self.embed_gen.generate_embedding_local(query_text)
        res = self.client.query.get(self.collection, ["text_content"]).with_near_vector({"vector":emb,"certainty":certainty_threshold}).with_limit(num_results).do()
        return res

# === src/dq_reporting/pdf_generator.py ===
from jinja2 import Environment, FileSystemLoader
from playwright.sync_api import sync_playwright

class PDFReportGenerator:
    """
    Generates PDF reports from DQ results using Jinja2 and Playwright.
    """
    def __init__(self, dbutils_instance, template_dir: str = "templates"):
        self.dbutils = dbutils_instance
        try:
            self.script_dir = os.path.dirname(os.path.abspath(__file__))
        except NameError:
            self.script_dir = os.getcwd()
        self.template_path = os.path.join(self.script_dir, template_dir)
        if not os.path.exists(self.template_path):
            logger.warning(f"Template directory not found: {self.template_path}")
        self.jinja_env = Environment(
            loader=FileSystemLoader(self.template_path),
            autoescape=True
        )

    def _create_html_report_content(self, report_data: Dict[str, Any], html_template_name: str) -> Optional[str]:
        try:
            template = self.jinja_env.get_template(html_template_name)
            return template.render(data=report_data)
        except Exception as e:
            logger.error(f"Error rendering HTML template '{html_template_name}': {e}", exc_info=True)
            return None

    def generate_pdf_report(self, report_data: Dict[str, Any], html_template_name: str, output_pdf_local_path: str) -> bool:
        html_content = self._create_html_report_content(report_data, html_template_name)
        if not html_content:
            return False
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch()
                page = browser.new_page()
                page.set_content(html_content)
                page.pdf(
                    path=output_pdf_local_path,
                    format="A4",
                    print_background=True,
                    margin={"top": "20mm", "bottom": "20mm", "left": "15mm", "right": "15mm"}
                )
                browser.close()
            logger.info(f"PDF report generated at {output_pdf_local_path}")
            return True
        except Exception as e:
            logger.error(f"Error generating PDF report: {e}", exc_info=True)
            return False

# === src/dq_orchestration/workflow_triggers.py ===
from databricks.sdk import WorkspaceClient

class DatabricksWorkflowManager:
    """
    Manages Databricks Jobs programmatically using Databricks SDK.
    """
    def __init__(self, config_manager_instance: ConfigManager):
        self.config_mgr = config_manager_instance
        host = self.config_mgr.get_config("DATABRICKS_HOST")
        token = self.config_mgr.get_config("DATABRICKS_TOKEN", is_secret=True, secret_scope="databricks_sdk_creds")
        try:
            self.workspace_client = WorkspaceClient(host=host, token=token)
            logger.info("Databricks WorkspaceClient initialized.")
        except Exception as e:
            logger.error(f"Failed to init WorkspaceClient: {e}", exc_info=True)
            self.workspace_client = None

    def trigger_job_run(self, job_id: int, notebook_params: Optional[Dict[str, str]] = None) -> Optional[int]:
        if not self.workspace_client:
            logger.error("WorkspaceClient not initialized.")
            return None
        try:
            resp = self.workspace_client.jobs.run_now(job_id=job_id, notebook_params=notebook_params)
            logger.info(f"Triggered job {job_id}, run_id={resp.run_id}")
            return resp.run_id
        except Exception as e:
            logger.error(f"Error triggering job {job_id}: {e}", exc_info=True)
            return None

    def get_run_status(self, run_id: int) -> Optional[str]:
        if not self.workspace_client:
            logger.error("WorkspaceClient not initialized.")
            return None
        try:
            details = self.workspace_client.jobs.get_run(run_id=run_id)
            return details.state.life_cycle_state.value
        except Exception as e:
            logger.error(f"Error fetching run status for {run_id}: {e}", exc_info=True)
            return None

# === notebooks/run_full_dq_pipeline_job.py ===
async def main_dq_pipeline_async(
    spark_session: SparkSession,
    dbutils_instance,
    job_config_dict: Dict[str, Any]
):
    """
    Main async entrypoint to run the full DQ pipeline.
    """
    # Initialization
    config_mgr = ConfigManager(dbutils_instance=dbutils_instance)
    audit_logger = AuditLogger(spark_session, job_config_dict.get("audit_log_table_fqn"))
    notification_svc = NotificationService(config_mgr)
    run_user = job_config_dict.get("run_as_user", "dq_pipeline_service")

    # Log pipeline start
    audit_logger.log_event(
        user_id=run_user,
        action="DQ_PIPELINE_STARTED",
        details={"config": job_config_dict}
    )

    # 1. Data ingestion (delta_table, file, kafka, etc.)
    source_type = job_config_dict.get("source_type", "delta_table").lower()
    data_df: Optional[DataFrame] = None
    try:
        if source_type == "delta_table":
            table_fqn = job_config_dict["input_table_fqn"]
            data_df = spark_session.table(table_fqn)
        # ... handle other source types ...
    except Exception as e:
        audit_logger.log_event(run_user, "DQ_PIPELINE_FAILED", {"reason": str(e)})
        raise

    total_records = data_df.count() if data_df else 0

    # 2. Profiling & LLM rule suggestion
    if job_config_dict.get("run_llm_rule_suggestion", False) and total_records > 0:
        profiler = DataProfiler(spark_session)
        profile = profiler.profile_dataframe(data_df, job_config_dict.get("input_table_fqn"))
        groq = GroqLLMInteraction(config_mgr)
        suggested = await groq.suggest_dq_rules(profile, num_suggestions=int(job_config_dict.get("num_llm_rule_suggestions",5)))
        if suggested:
            mgr = DQRuleManager(spark_session, job_config_dict.get("dq_rules_table_fqn"))
            mgr.save_rules(suggested, mode="append")
            audit_logger.log_event(run_user, "LLM_RULES_SUGGESTED", {"count": len(suggested)})

    # 3. Load active rules
    rule_mgr = DQRuleManager(spark_session, job_config_dict.get("dq_rules_table_fqn"))
    active_rules_df = rule_mgr.load_active_rules()

    # 4. Execute rules & collect failures
    translator = DQRuleTranslator(spark_session)
    failing_dfs = []
    if total_records > 0:
        for row in active_rules_df.collect():
            df_fail = translator.translate_rule_to_spark_df_operation(data_df, row.asDict())
            if df_fail and not df_fail.rdd.isEmpty():
                failing_dfs.append(df_fail)

    all_failures_df = None
    if failing_dfs:
        from functools import reduce
        all_failures_df = reduce(lambda a,b: a.unionByName(b, allowMissingColumns=True), failing_dfs)
        all_failures_df.write.format("delta").mode("overwrite").saveAsTable(job_config_dict.get("dq_all_failures_table_fqn"))

    # 5. Calculate metrics
    metrics_calc = DQMetricsCalculator(spark_session)
    scores = metrics_calc.calculate_rule_and_dimension_scores(
        total_records_in_table=total_records,
        all_failing_records_df=all_failures_df,
        rules_config_df=active_rules_df
    )
    audit_logger.log_event(run_user, "DQ_SCORES_CALCULATED", {"scores": scores})

    # 6. Send alerts if below threshold
    threshold = float(job_config_dict.get("alert_threshold",75))
    if scores.get("overall_dq_score",100) < threshold:
        notification_svc.send_email(
            subject=f"DQ Alert: Score {scores['overall_dq_score']}% below {threshold}%",
            body_html=f"<p>Overall DQ score {scores['overall_dq_score']}% is below threshold {threshold}%.</p>"
        )
        audit_logger.log_event(run_user, "DQ_ALERT_TRIGGERED", {"score": scores['overall_dq_score']})

    # 7. Generate & store PDF report
    report_gen = PDFReportGenerator(dbutils_instance, template_dir=job_config_dict.get("report_template_dir"))
    report_data = {
        "report_title": f"DQ Report: {job_config_dict.get('input_table_fqn')}",
        "overall_score": scores['overall_dq_score'],
        "dimensions": scores['dimensions'],
        "rules_summary": scores['rules'],
        "generation_date": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    }
    local_pdf = f"/dbfs/tmp/dq_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    if report_gen.generate_pdf_report(report_data, job_config_dict.get("report_html_template_name"), local_pdf):
        target_path = job_config_dict.get("output_report_uc_path_prefix").rstrip('/') + f"/dq_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        report_gen.store_pdf_to_uc_volume_or_dbfs(local_pdf, target_path)
        audit_logger.log_event(run_user, "DQ_REPORT_GENERATED_STORED", {"path": target_path})
        
# run_full_dq_pipeline_job.py
# # Notebook/CLI entrypoint for the Data Quality pipeline.
# Initializes Spark, loads inputs via input_manager, builds job_config, and invokes the async pipeline.

import sys
import asyncio
import logging
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType

# ensure our user workspace modules are on the path
sys.path.insert(0, "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com")

from dq_utils.config_manager import ConfigManager
from dq_utils.input_manager import load_input_dataframe, create_input_widgets
from dq_application_backend_main import main_dq_pipeline_async

# Define all expected widget/env parameters and their defaults
EXPECTED_PARAMS = {
    'input_table_fqn': None,
    'dq_rules_table_fqn': None,
    'dq_all_failures_table_fqn': None,
    'audit_log_table_fqn': None,
    'output_report_uc_path_prefix': None,
    'report_template_dir': 'templates',
    'report_html_template_name': 'dq_report.html',
    'run_llm_rule_suggestion': 'false',
    'num_llm_rule_suggestions': '5',
    'source_type': 'delta_table',
    'source_read_options': '{}',
    'kafka_options': '{}',
    'jdbc_options': '{}',
    'alert_threshold': '75'
}

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

if __name__ == "__main__":
    # 1. Initialize Spark session
    spark = SparkSession.builder.appName("DQApplicationJob").getOrCreate()

    # 2. Obtain dbutils (for widgets & secrets in Databricks notebooks)
    dbutils = globals().get('dbutils', None)

    # 3. Create parameter widgets if running interactively
    if dbutils:
        create_input_widgets(dbutils, EXPECTED_PARAMS)

    # 4. Initialize configuration manager (loads .env, widgets, secrets)
    config_mgr = ConfigManager(dbutils_instance=dbutils)

    # 5. Load input DataFrame via input_manager
    input_df = load_input_dataframe(spark, dbutils, config_mgr)
    total_records = input_df.count() if input_df is not None else 0
    logger.info(f"Loaded input source with {total_records} records.")

    # 6. Build job_config dict from EXPECTED_PARAMS
    job_config = {}
    for key, default in EXPECTED_PARAMS.items():
        job_config[key] = config_mgr.get_config(key, default=default)

    # 7. Validate mandatory parameters
    if not job_config['input_table_fqn']:
        raise ValueError("Missing required parameter 'input_table_fqn'.")
    if not job_config['dq_rules_table_fqn']:
        raise ValueError("Missing required parameter 'dq_rules_table_fqn'.")

    # 8. Ensure input table exists (for delta_table source)
    if job_config['source_type'] == 'delta_table' and not spark.catalog.tableExists(job_config['input_table_fqn']):
        raise ValueError(
            f"Input table '{job_config['input_table_fqn']}' not found."
        )

    # 9. Parse JSON-string options into dicts
    for json_key in ['source_read_options', 'kafka_options', 'jdbc_options']:
        raw = job_config.get(json_key, '{}')
        try:
            job_config[json_key] = json.loads(raw)
        except Exception:
            logger.warning(f"Invalid JSON for {json_key}: {raw}. Defaulting to empty dict.")
            job_config[json_key] = {}

    # 10. Deserialize Kafka schema if provided
    kafka_schema = job_config.get('kafka_value_schema_struct_json')
    if isinstance(kafka_schema, str):
        try:
            schema_dict = json.loads(kafka_schema)
            job_config['kafka_value_schema_struct'] = StructType.fromJson(schema_dict)
        except Exception as e:
            logger.error(f"Invalid Kafka schema JSON: {e}")
            job_config['kafka_value_schema_struct'] = None
    else:
        job_config['kafka_value_schema_struct'] = None

    # 11. Coerce booleans/string flags
    job_config['run_llm_rule_suggestion'] = str(job_config.get('run_llm_rule_suggestion')).lower() == 'true'
    try:
        job_config['num_llm_rule_suggestions'] = int(job_config.get('num_llm_rule_suggestions', 5))
    except ValueError:
        job_config['num_llm_rule_suggestions'] = 5

    # 12. Add runtime context
    job_config['total_records'] = total_records

    # 13. Run the async DQ pipeline
    import nest_asyncio
    nest_asyncio.apply()
    asyncio.run(
        main_dq_pipeline_async(
            spark_session=spark,
            dbutils_instance=dbutils,
            job_config_dict=job_config
        )
    )

    # 14. Stop Spark session
    spark.stop()

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# ─────────╗
# Notebook: DQ Pipeline Launcher with Unity Catalog FQNs
# ─────────╝

# 1️⃣ Setup Python path, .env, and logging
import sys, os, json, asyncio, logging
from datetime import datetime
import nest_asyncio
from dotenv import load_dotenv

# 2️⃣ Spark imports
from pyspark.sql import SparkSession, DataFrame, Row
from pyspark.sql.types import StructType
from pyspark.sql.functions import from_json, col
from typing import Any, Dict
import pandas as pd

# 3️⃣ Load .env (if present) and add your workspace folder to the Python path
load_dotenv()
sys.path.insert(0, "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com")

# 4️⃣ Initialize logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 5️⃣ Imports: ConfigManager, helpers, and the pipeline entrypoint
from dq_utils.config_manager import ConfigManager
# We will override load_input_dataframe below (for Excel/JSON), but keep original in case you need it later
from dq_utils.input_manager import load_input_dataframe as original_load_input
from dq_utils.input_manager import create_input_widgets
from dq_application_backend_main import main_dq_pipeline_async

# 6️⃣ Define expected parameters (with three‐part FQNs for DQ tables)
#    Make sure to replace 'my_catalog.dq_db.dq_rules' etc. with your actual catalog.schema.table names.
EXPECTED_PARAMS: Dict[str, Any] = {
    "source_type":                  "delta_table",            # delta_table | parquet | csv | excel | json | jdbc | kafka
    "input_table_fqn":              "",                       # e.g. my_catalog.raw_db.sales_table
    "input_path":                   "",                       # for file‐based sources
    "file_format":                  "parquet",                # parquet | csv | excel | json
    "jdbc_table_or_query":          "",                       # for JDBC usage
    "kafka_topic":                  "",                       # for Kafka usage
    "kafka_starting_offsets":       "earliest",
    "kafka_value_schema_struct_json": "{}",                   # JSON string of StructType for Kafka

    # IMPORTANT: use valid three‐part FQNs here (catalog.schema.table):
    "dq_rules_table_fqn":           "my_catalog.dq_db.dq_rules",
    "dq_all_failures_table_fqn":    "my_catalog.dq_db.dq_failures",
    "audit_log_table_fqn":          "my_catalog.dq_db.audit_log",

    "output_report_uc_path_prefix": "/tmp/dq_reports",
    "report_template_dir":          "templates",
    "report_html_template_name":    "dq_report.html",
    "run_llm_rule_suggestion":      "false",
    "num_llm_rule_suggestions":     "5",
    "alert_threshold":              "75"
}

# 7️⃣ Initialize Spark and grab dbutils if running in an interactive notebook
spark = SparkSession.builder.appName("DQApplicationJob").getOrCreate()
dbutils = globals().get("dbutils", None)

# 8️⃣ If running interactively, create widgets for all EXPECTED_PARAMS
if dbutils:
    for param, default in EXPECTED_PARAMS.items():
        dbutils.widgets.text(param, str(default), param)

    # (Optional) also create convenience widgets for things like file_format, input_path, etc.
    dbutils.widgets.text("file_format",                  "parquet", "file_format")
    dbutils.widgets.text("input_path",                   "",        "input_path")
    dbutils.widgets.text("input_table_fqn",              "",        "input_table_fqn")
    dbutils.widgets.text("jdbc_table_or_query",          "",        "jdbc_table_or_query")
    dbutils.widgets.text("kafka_topic",                  "",        "kafka_topic")
    dbutils.widgets.text("kafka_starting_offsets",       "earliest","kafka_starting_offsets")
    dbutils.widgets.text("kafka_value_schema_struct_json","{}",     "kafka_value_schema_struct_json")
    dbutils.widgets.text("dq_rules_table_fqn",           "my_catalog.dq_db.dq_rules","dq_rules_table_fqn")
    dbutils.widgets.text("dq_all_failures_table_fqn",    "my_catalog.dq_db.dq_failures","dq_all_failures_table_fqn")
    dbutils.widgets.text("audit_log_table_fqn",          "my_catalog.dq_db.audit_log","audit_log_table_fqn")
    dbutils.widgets.text("output_report_uc_path_prefix", "/tmp/dq_reports","output_report_uc_path_prefix")
    dbutils.widgets.text("report_template_dir",          "templates","report_template_dir")
    dbutils.widgets.text("report_html_template_name",    "dq_report.html","report_html_template_name")
    dbutils.widgets.text("run_llm_rule_suggestion",      "false","run_llm_rule_suggestion")
    dbutils.widgets.text("num_llm_rule_suggestions",     "5","num_llm_rule_suggestions")
    dbutils.widgets.text("alert_threshold",              "75","alert_threshold")

# 9️⃣ Define a custom load_input_dataframe that wraps the original and adds Excel/JSON support
def load_input_dataframe(
    spark: SparkSession,
    dbutils,
    config_mgr: ConfigManager
) -> DataFrame:
    """
    Load an input DataFrame based on source_type, with support for:
      • Delta tables (three-part FQNs)
      • Parquet/CSV/JSON files
      • Excel (via pandas + spark.createDataFrame)
      • JDBC
      • Kafka
    """
    # Gather all widget/env values into a params dict
    params: Dict[str, Any] = {}
    for key, default in EXPECTED_PARAMS.items():
        raw = config_mgr.get_config(key, default=default)
        # If it ends with "_json", parse JSON
        if key.endswith("_json") and isinstance(raw, str):
            try:
                params[key] = json.loads(raw)
            except json.JSONDecodeError:
                params[key] = default
        else:
            params[key] = raw

    source            = params.get("source_type", "delta_table").lower()
    input_table       = params.get("input_table_fqn", "")
    input_path        = params.get("input_path", "")
    file_fmt          = params.get("file_format", "parquet").lower()
    jdbc_query        = params.get("jdbc_table_or_query", "")
    kafka_topic       = params.get("kafka_topic", "")
    kafka_offsets     = params.get("kafka_starting_offsets", "earliest")
    kafka_schema_json = params.get("kafka_value_schema_struct_json", "{}")

    if source == "delta_table":
        # ① Must supply a three-part FQN, e.g. my_catalog.my_db.my_table
        if not input_table:
            raise ValueError("'input_table_fqn' must be provided for source_type='delta_table'.")
        parts = input_table.split(".")
        if len(parts) != 3:
            raise ValueError(f"'input_table_fqn' must be 'catalog.schema.table' (got: {input_table})")
        return spark.table(input_table)

    elif source in ("parquet", "csv", "json", "excel"):
        # ② Must supply input_path for file‐based sources
        if not input_path:
            raise ValueError("'input_path' must be provided for file-based sources.")
        fmt = source  # either "parquet", "csv", "json", or "excel"

        if fmt == "excel":
            # Read Excel into pandas, then convert to Spark
            local_path = input_path if input_path.startswith("/Workspace/") else f"/Workspace{input_path}"
            try:
                pdf = pd.read_excel(local_path, engine="openpyxl")
            except Exception as e:
                raise ValueError(f"Failed to read Excel file at {local_path}: {e}")
            return spark.createDataFrame(pdf)

        else:
            # Use Spark's native reader for parquet/csv/json
            reader = spark.read.format(fmt)
            if fmt == "csv":
                reader = reader.option("header", True).option("inferSchema", True)
            if fmt == "json":
                reader = reader.option("multiLine", True)
            return reader.load(input_path)

    elif source == "jdbc":
        # ③ Must supply a valid JDBC query or table name
        if not jdbc_query:
            raise ValueError("'jdbc_table_or_query' must be provided for source_type='jdbc'.")
        from dq_utils.connector_clients import ConnectorClients
        conn = ConnectorClients(spark, config_mgr)
        return conn.read_from_jdbc(jdbc_query)

    elif source == "kafka":
        # ④ Must supply a Kafka topic
        if not kafka_topic:
            raise ValueError("'kafka_topic' must be provided for source_type='kafka'.")
        struct = None
        if isinstance(kafka_schema_json, dict):
            struct = StructType.fromJson(kafka_schema_json)
        from dq_utils.connector_clients import ConnectorClients
        conn = ConnectorClients(spark, config_mgr)
        df = conn.read_from_kafka(kafka_topic, is_streaming=False)
        if struct is not None:
            df = (
                df.selectExpr("CAST(value AS STRING)")
                  .select(from_json(col("value"), struct).alias("data"))
                  .select("data.*")
            )
        return df

    else:
        raise ValueError(f"Unsupported source_type: {source}")


# 🔟 Load the input DataFrame using our custom function
try:
    config_mgr = ConfigManager(dbutils_instance=dbutils)
    input_df = load_input_dataframe(spark, dbutils, config_mgr)
    total_records = input_df.count() if input_df is not None else 0
    logger.info(f"Loaded input with {total_records} records.")
except Exception as e:
    logger.error(f"Failed to load input DataFrame: {e}")
    raise


# 1️⃣1️⃣ Build a job_config dict from EXPECTED_PARAMS
job_config: Dict[str, Any] = {}
for key, default in EXPECTED_PARAMS.items():
    job_config[key] = config_mgr.get_config(key, default)

# 1️⃣2️⃣ Validate critical parameters
if job_config["source_type"] == "delta_table":
    if not job_config["input_table_fqn"]:
        raise ValueError("Missing required parameter 'input_table_fqn' for delta_table source.")
    # Also check that the three‐part FQNs for DQ tables are correct
    for table_key in ["dq_rules_table_fqn", "dq_all_failures_table_fqn", "audit_log_table_fqn"]:
        fqn = job_config.get(table_key, "")
        if fqn and len(fqn.split(".")) != 3:
            raise ValueError(f"'{table_key}' must be 'catalog.schema.table' (got: {fqn})")

elif job_config["source_type"] == "jdbc":
    if not job_config["jdbc_table_or_query"]:
        raise ValueError("Missing required parameter 'jdbc_table_or_query' for jdbc source.")

elif job_config["source_type"] == "kafka":
    if not job_config["kafka_topic"]:
        raise ValueError("Missing required parameter 'kafka_topic' for kafka source.")

# 1️⃣3️⃣ Parse JSON options (if any)
for j in ["kafka_value_schema_struct_json"]:
    raw = job_config.get(j, "{}")
    try:
        job_config[j] = json.loads(raw)
    except:
        logger.warning(f"Invalid JSON for {j}: {raw}. Defaulting to {{}}.")
        job_config[j] = {}

# 1️⃣4️⃣ Cast booleans and ints
job_config["run_llm_rule_suggestion"] = str(job_config.get("run_llm_rule_suggestion","false")).lower() == "true"
try:
    job_config["num_llm_rule_suggestions"] = int(job_config.get("num_llm_rule_suggestions", 5))
except:
    job_config["num_llm_rule_suggestions"] = 5
job_config["alert_threshold"] = float(job_config.get("alert_threshold", 75))

# 1️⃣5️⃣ Add runtime context
job_config["total_records"] = total_records

# 1️⃣6️⃣ Launch the async pipeline (only once!)
nest_asyncio.apply()
asyncio.run(
    main_dq_pipeline_async(
        spark_session    = spark,
        dbutils_instance = dbutils,
        job_config_dict  = job_config
    )
)

# 1️⃣7️⃣ Stop Spark when done
spark.stop()

# COMMAND ----------

# In a separate notebook cell or spark-sql cell:
spark.sql("SHOW CATALOGS").show()
spark.sql("SHOW SCHEMAS IN my_catalog").show()
spark.sql("SHOW TABLES IN my_catalog.audit_db").show()
spark.sql("SELECT * FROM my_catalog.audit_db.application_events_log LIMIT 1").show()


# COMMAND ----------

spark.sql("SHOW CATALOGS").show()

# COMMAND ----------





# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

spark = SparkSession.builder.appName("DQApplicationNotebook").getOrCreate()
dbutils = globals().get('dbutils', None)

# COMMAND ----------

from dq_utils.config_manager import ConfigManager
from dq_utils.input_manager import load_input_dataframe, create_input_widgets
from dq_application_backend_main import main_dq_pipeline_async

# COMMAND ----------

