# dq_reporting/__init__.py
"""
dq_reporting: PDF reporting for Data Quality results.
"""

from __future__ import annotations

from .pdf_generator import PDFReportGenerator  # noqa: F401

__all__ = [
    "PDFReportGenerator",
]
