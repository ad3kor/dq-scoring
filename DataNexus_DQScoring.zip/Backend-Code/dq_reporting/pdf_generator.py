# dq_reporting/pdf_generator.py
from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional

from jinja2 import Environment, FileSystemLoader
from playwright.sync_api import sync_playwright

logger = logging.getLogger(__name__)


class PDFReportGenerator:
    """
    Generates PDF reports from Data Quality results using Jinja2 + Playwright.
    """

    def __init__(self, dbutils_instance, template_dir: str = "templates"):
        self.dbutils = dbutils_instance
        try:
            self.script_dir = os.path.dirname(os.path.abspath(__file__))
        except NameError:
            self.script_dir = os.getcwd()
        self.template_path = os.path.join(self.script_dir, template_dir)
        if not os.path.exists(self.template_path):
            logger.warning(f"Template directory not found: {self.template_path}")
        self.jinja_env = Environment(
            loader=FileSystemLoader(self.template_path),
            autoescape=True
        )

    def _create_html_report_content(self, report_data: Dict[str, Any], html_template_name: str) -> Optional[str]:
        try:
            template = self.jinja_env.get_template(html_template_name)
            return template.render(data=report_data)
        except Exception as e:
            logger.error(f"Error rendering HTML template '{html_template_name}': {e}", exc_info=True)
            return None

    def generate_pdf_report(
        self,
        report_data: Dict[str, Any],
        html_template_name: str,
        output_pdf_local_path: str
    ) -> bool:
        html_content = self._create_html_report_content(report_data, html_template_name)
        if not html_content:
            return False
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch()
                page = browser.new_page()
                page.set_content(html_content)
                page.pdf(
                    path=output_pdf_local_path,
                    format="A4",
                    print_background=True,
                    margin={"top": "20mm", "bottom": "20mm", "left": "15mm", "right": "15mm"}
                )
                browser.close()
            logger.info(f"PDF report generated at {output_pdf_local_path}")
            return True
        except Exception as e:
            logger.error(f"Error generating PDF report: {e}", exc_info=True)
            return False

    def store_pdf_to_uc_volume_or_dbfs(self, local_pdf: str, target_path: str) -> None:
        """
        Move the local PDF (e.g., /dbfs/tmp/…) to a DBFS path or Unity Catalog volume.
        """
        try:
            # If target_path starts with /dbfs or dbfs:/, Spark can write directly.
            if target_path.startswith("/dbfs"):
                os.replace(local_pdf, target_path)
            elif target_path.startswith("dbfs:/"):
                dbfs_target = target_path.replace("dbfs:/", "/dbfs/")
                os.replace(local_pdf, dbfs_target)
            else:
                # Fallback: copy via dbutils.fs
                from pathlib import Path
                tmp_path = local_pdf
                final_path = target_path
                dbutils = self.dbutils
                if dbutils:
                    dbutils.fs.cp(f"file:{tmp_path}", final_path)
                else:
                    os.replace(tmp_path, final_path)
            logger.info(f"Stored PDF to {target_path}")
        except Exception as e:
            logger.error(f"Failed to store PDF to {target_path}: {e}", exc_info=True)
