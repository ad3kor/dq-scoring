# Databricks notebook source
# Corrected Prerequisite Code to Store Secrets

# The name of the scope you just created
secret_scope = "azure-storage-scope"

# The credentials you provided
client_id_value = "445f258d-a501-469f-944b-6fd190659784"
client_secret_value = "p_C8Q~iRkID7x0aBw2qKUMQ69823t-vwdl5r.aDo"
tenant_id_value = "f4be8764-cbee-4f6a-83c8-12ff39e27e09"

# Store your credentials as secrets within the scope
dbutils.secrets.put(scope=secret_scope, key="client-id", string_value=client_id_value)
dbutils.secrets.put(scope=secret_scope, key="client-secret", string_value=client_secret_value)
dbutils.secrets.put(scope=secret_scope, key="tenant-id", string_value=tenant_id_value)

print(f"✅ Secrets have been successfully stored in the '{secret_scope}' scope.")
print("You can now run the main backend code.")

# COMMAND ----------

# Databricks Notebook: Azure Blob Storage Connector (with Hardcoded Credentials)

import os
from datetime import datetime, timedelta
import json
from pyspark.sql import SparkSession

# --- 1. Configuration and Hardcoded Credentials ---

# Storage account details
STORAGE_ACCOUNT_NAME = "fofstrprdeusdata"
CONTAINER_NAME = "genai"

# --- WARNING: Hardcoded credentials below. Not recommended for production. ---
# Credentials you provided
client_id = "445f258d-a501-469f-944b-6fd190659784"
client_secret = "p_C8Q~iRkID7x0aBw2qKUMQ69823t-vwdl5r.aDo"
tenant_id = "f4be8764-cbee-4f6a-83c8-12ff39e27e09"

print("✅ Using hardcoded credentials to configure the connection.")

# --- Spark Configuration ---
# Configure Spark to use the Service Principal for authentication
spark.conf.set(f"fs.azure.account.auth.type.{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net", "OAuth")
spark.conf.set(f"fs.azure.account.oauth.provider.type.{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set(f"fs.azure.account.oauth2.client.id.{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net", client_id)
spark.conf.set(f"fs.azure.account.oauth2.client.secret.{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net", client_secret)
spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

# Construct the full path for accessing the container
container_path = f"abfss://{CONTAINER_NAME}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/"

print(f"✅ Spark is configured to connect to: {container_path}")


# --- 2. Function to List and Filter Files by Age ---

def list_and_filter_files(path: str, age_in_days: int = None) -> list:
    """
    Lists files in a given storage path and optionally filters them by modification date.
    """
    print(f"\nListing files in: {path}")
    try:
        all_files = dbutils.fs.ls(path)
    except Exception as e:
        print(f"❌ Could not list files. Please ensure the Service Principal has the 'Storage Blob Data Reader' role assigned. Error: {e}")
        return []

    if age_in_days is None:
        print(f"Found {len(all_files)} files. No age filter applied.")
        return [{"name": f.name, "path": f.path, "size": f.size, "modificationTime": datetime.fromtimestamp(f.modificationTime / 1000).isoformat()} for f in all_files]

    cutoff_time = datetime.now() - timedelta(days=age_in_days)
    print(f"Filtering for files modified after: {cutoff_time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    filtered_files = []
    for f in all_files:
        file_mod_time = datetime.fromtimestamp(f.modificationTime / 1000)
        if file_mod_time >= cutoff_time:
            filtered_files.append({
                "name": f.name,
                "path": f.path,
                "size": f.size,
                "modificationTime": file_mod_time.isoformat()
            })
            
    print(f"Found {len(filtered_files)} files matching the filter.")
    return filtered_files


# --- 3. Function to Load Files into Spark DataFrames ---

def load_files(file_list: list) -> dict:
    """
    Loads a list of files into Spark DataFrames.
    """
    loaded_dataframes = {}
    print(f"\nAttempting to load {len(file_list)} files...")
    
    for file_info in file_list:
        file_path = file_info["path"]
        print(f"  > Loading: {file_info['name']}")
        try:
            if file_path.endswith(".csv"):
                df = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(file_path)
            elif file_path.endswith(".parquet"):
                df = spark.read.parquet(file_path)
            elif file_path.endswith((".xlsx", ".xls")):
                # Note: Loading Excel files requires installing the com.crealytics.spark.excel library on your cluster
                df = spark.read.format("com.crealytics.spark.excel").option("header", "true").option("inferSchema", "true").load(file_path)
            else:
                print(f"    - Skipping: Unsupported file format for {file_info['name']}")
                continue
                
            loaded_dataframes[file_path] = df
            print(f"    - Successfully loaded into a DataFrame with {df.count()} rows.")
            
        except Exception as e:
            print(f"    - FAILED to load {file_info['name']}. Error: {e}")
            
    return loaded_dataframes


# --- 4. Example Usage ---
# This demonstrates how your frontend would use these functions.
# The `days_filter` would be passed as a parameter to the Databricks job.

print("\n" + "="*50)
print("EXAMPLE: Fetching files from the last 30 days")
print("="*50)

# The user chooses "1 month ago" (approximated as 30 days)
days_filter = 30 
files_to_load = list_and_filter_files(container_path, age_in_days=days_filter)

# Display the results that would be sent back to the frontend
print("\nFiles to be displayed on the frontend:")
# Using display() for a richer table view in the Databricks UI
if files_to_load:
    display(spark.createDataFrame(files_to_load))
else:
    print("No files found from the last 30 days.")


# Load the filtered files for backend processing
if files_to_load:
    dataframes_dict = load_files(files_to_load)
    
    # Next step would be sampling, as per your instructions...
    print("\nFile loading complete. Ready for next instructions (e.g., sampling).")
else:
    print("\nNo files found matching the filter to load.")

# COMMAND ----------

# Databricks Notebook: Azure Blob Storage Connector (using Credential Passthrough)

from datetime import datetime, timedelta
import json
from pyspark.sql import SparkSession

# --- 1. Configuration ---

# Storage account details are still needed
STORAGE_ACCOUNT_NAME = "fofstrprdeusdata"
CONTAINER_NAME = "genai"

# Construct the full path. No other configuration is needed
# because credential passthrough is enabled on the cluster.
container_path = f"abfss://{CONTAINER_NAME}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/"

print(f"✅ Ready to access storage using your credentials at: {container_path}")


# --- 2. Function to List and Filter Files by Age ---

def list_and_filter_files(path: str, age_in_days: int = None) -> list:
    """
    Lists files in a given storage path and optionally filters them by modification date.
    """
    print(f"\nListing files in: {path}")
    try:
        all_files = dbutils.fs.ls(path)
    except Exception as e:
        # If this fails now, it's likely a network issue or a problem with the passthrough configuration itself.
        print(f"❌ Could not list files. Please ensure credential passthrough is enabled on the cluster. Error: {e}")
        return []

    if age_in_days is None:
        print(f"Found {len(all_files)} files. No age filter applied.")
        # Convert FileInfo object to a serializable dictionary for APIs
        return [{"name": f.name, "path": f.path, "size": f.size, "modificationTime": datetime.fromtimestamp(f.modificationTime / 1000).isoformat()} for f in all_files]

    # Calculate the cutoff time for filtering
    cutoff_time = datetime.now() - timedelta(days=age_in_days)
    print(f"Filtering for files modified after: {cutoff_time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    filtered_files = []
    for f in all_files:
        # modificationTime is in milliseconds, so convert to seconds for datetime
        file_mod_time = datetime.fromtimestamp(f.modificationTime / 1000)
        if file_mod_time >= cutoff_time:
            filtered_files.append({
                "name": f.name,
                "path": f.path,
                "size": f.size,
                "modificationTime": file_mod_time.isoformat()
            })
            
    print(f"Found {len(filtered_files)} files matching the filter.")
    return filtered_files


# --- 3. Function to Load Files into Spark DataFrames ---

def load_files(file_list: list) -> dict:
    """
    Loads a list of files into Spark DataFrames.
    """
    loaded_dataframes = {}
    print(f"\nAttempting to load {len(file_list)} files...")
    
    for file_info in file_list:
        file_path = file_info["path"]
        print(f"  > Loading: {file_info['name']}")
        try:
            if file_path.endswith(".csv"):
                df = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(file_path)
            elif file_path.endswith(".parquet"):
                df = spark.read.parquet(file_path)
            elif file_path.endswith((".xlsx", ".xls")):
                df = spark.read.format("com.crealytics.spark.excel").option("header", "true").option("inferSchema", "true").load(file_path)
            else:
                print(f"    - Skipping: Unsupported file format for {file_info['name']}")
                continue
                
            loaded_dataframes[file_path] = df
            print(f"    - Successfully loaded into a DataFrame with {df.count()} rows.")
            
        except Exception as e:
            print(f"    - FAILED to load {file_info['name']}. Error: {e}")
            
    return loaded_dataframes


# --- 4. Example Usage ---

print("\n" + "="*50)
print("EXAMPLE: Fetching all files in the container using your personal credentials")
print("="*50)

all_files_in_container = list_and_filter_files(container_path)

# Display the results that would be sent back to the frontend
print("\nFiles to be displayed on the frontend:")
if all_files_in_container:
    # Using display() for a richer table view in the Databricks UI
    display(spark.createDataFrame(all_files_in_container))
else:
    print("No files found in the container.")

# COMMAND ----------

