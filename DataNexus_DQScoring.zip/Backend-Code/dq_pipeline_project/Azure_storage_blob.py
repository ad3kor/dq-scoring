# Databricks notebook source
# MAGIC %pip install -r requirements.txt
# MAGIC

# COMMAND ----------

# --- Test Cell for Unity Catalog Connection ---

# 1. Define the path to your container.
#    This is the same URL you used to create the External Location.
container_path = "abfss://genai@fofstrprdeusdata.dfs.core.windows.net/"

print(f"Attempting to list files in '{container_path}' using the Unity Catalog connection...")

# 2. Try to list the files.
#    No spark.conf.set is needed. Unity Catalog handles the authentication.
try:
    # dbutils.fs.ls() will now automatically use the permissions
    # granted through your Storage Credential and External Location.
    files_list = dbutils.fs.ls(container_path)
    
    print("\n✅ SUCCESS: Connection and listing worked!")
    print("Files found in your container:")
    
    # Use display() for a nice table view in Databricks
    display(files_list)

except Exception as e:
    print(f"\n❌ An error occurred. This usually means there is a permission issue with the underlying setup.")
    print("Please double-check the following:")
    print("1. That the Access Connector in Azure has the 'Storage Blob Data Reader' role on the storage account.")
    print("2. That your user account has 'READ FILES' permission on the External Location in Databricks.")
    print(f"\nSpecific Error:")
    print(e)

# COMMAND ----------

# Databricks Notebook: File Lister Backend
# Purpose: Acts as a backend to list files from an Azure storage container.
# It can be parameterized to filter files by age.

import json
from datetime import datetime, timedelta

# --- 1. Configuration ---

# The path to your container, which is accessible via the Unity Catalog External Location.
# No credentials or spark.conf settings are needed.
CONTAINER_PATH = "abfss://genai@fofstrprdeusdata.dfs.core.windows.net/"

# --- 2. Get and Process Job Parameters ---

# Define a widget to accept the time filter from the frontend.
# This value will be passed when the frontend triggers the Databricks Job.
dbutils.widgets.text("age_in_days", "", "Filter files newer than this many days. Leave empty for all files.")

# Get the value from the widget
age_in_days_str = dbutils.widgets.get("age_in_days")
age_in_days_int = None

# Convert the parameter to an integer if it's provided
if age_in_days_str and age_in_days_str.isdigit():
    age_in_days_int = int(age_in_days_str)
    print(f"✅ Received request to filter for files newer than {age_in_days_int} days.")
else:
    print("✅ No age filter provided. Listing all files.")


# --- 3. Function to List and Filter Files ---

def list_and_filter_files(path: str, age_in_days: int = None) -> list:
    """
    Lists files in a storage path and optionally filters them by modification date.

    Args:
        path (str): The storage path to list.
        age_in_days (int, optional): The maximum age of files in days. If None, all files are returned.

    Returns:
        list: A list of dictionaries, where each dictionary contains file details.
    """
    print(f"\nListing files in: {path}")
    try:
        all_files = dbutils.fs.ls(path)
    except Exception as e:
        # If this fails, it's a permission issue with the Unity Catalog setup.
        raise Exception(f"Could not list files. Please ensure your user/principal has 'READ FILES' permission on the External Location. Error: {e}")

    # If no age filter is applied, return all files immediately.
    if age_in_days is None:
        print(f"Found {len(all_files)} files.")
        return [{"name": f.name, "path": f.path, "size": f.size, "modificationTime": datetime.fromtimestamp(f.modificationTime / 1000).isoformat()} for f in all_files]

    # Otherwise, calculate the cutoff time and filter the list.
    cutoff_time = datetime.now() - timedelta(days=age_in_days)
    print(f"Filtering for files modified after: {cutoff_time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    filtered_files = []
    for f in all_files:
        # modificationTime is in milliseconds, so convert it for comparison
        file_mod_time = datetime.fromtimestamp(f.modificationTime / 1000)
        if file_mod_time >= cutoff_time:
            filtered_files.append({
                "name": f.name,
                "path": f.path,
                "size": f.size,
                "modificationTime": file_mod_time.isoformat()
            })
            
    print(f"Found {len(filtered_files)} files matching the filter.")
    return filtered_files


# --- 4. Main Execution and Exit ---

try:
    # Call the function with the path and the parameter received from the widget
    files_to_return = list_and_filter_files(CONTAINER_PATH, age_in_days=age_in_days_int)

    # Prepare the final JSON output for the frontend
    final_output = {
        "status": "SUCCEEDED",
        "message": f"Successfully retrieved {len(files_to_return)} file(s).",
        "files": files_to_return
    }

except Exception as e:
    # Create an error payload if something goes wrong
    final_output = {
        "status": "FAILED",
        "message": str(e),
        "files": []
    }

# Exit the notebook and return the result as a clean JSON string
print("\n--- Exiting notebook with file list JSON ---")
dbutils.notebook.exit(json.dumps(final_output, indent=2))

# COMMAND ----------

