# Databricks notebook source
# MAGIC %pip install -r requirements.txt

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

import sys
sys.argv = [
  'run_pipeline.py',
  '--source-type', 'delta',
  '--table', 'dq_catalog.dq_schema.your_table',
  # You can replace with other args, e.g., file source:
  # '--source-type', 'file', '--file-path', '/dbfs/FileStore/acharjeerishab/sample.csv', '--file-type', 'csv',
  '--report-output-dir', '/dbfs/FileStore/acharjeerishab/reports'
]

# COMMAND ----------

# 1) Pre-populate sys.argv so argparse won’t error
import sys

# Replace these values as needed:
sys.argv = [
    "run_pipeline.py",
    "--source-type", "excel",
    "--path", "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/Copy of Smart Meter Sample Data_v1.xlsx",
    "--report-output-dir", "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/reports"
]

# 2) Call run_pipeline.py using %run (relative path “./” works if it’s in the same folder)

%run ./run_pipeline.py

# COMMAND ----------

# MAGIC %run /Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/run_pipeline.py

# COMMAND ----------

# ----------- run_pipeline.py -----------

import os
import logging
from pyspark.sql import SparkSession
from ingestion.ingestion import IngestionManager
from sampling.stage1_reservoir_sampling import ReservoirSampler
from sampling.stage2_random_downsample import RandomDownSampler
from sampling.stage3_diversity_sampling import DiversitySampler
try:
    from rule_suggester.chunked_rule_suggester import ChunkedRuleSuggester
except ModuleNotFoundError:
    raise ImportError(
        "The module 'langchain_groq' is required but not installed. "
        "Please install it via 'pip install langchain-groq'."
    )

from assessment.dq_assessment import DQAssessment
from reporting.report_generator import ReportGenerator
import pandas as pd

# -----------------------------------
# 1. Create (or update) SparkSession with checkpoint directory
# -----------------------------------
#
# Note: Make sure you've run:
#     dbutils.fs.mkdirs("dbfs:/checkpoints")
# somewhere (e.g., in a separate cell) so that the folder actually exists on DBFS.
#
spark = (
    SparkSession.builder
        .appName("DQ_Pipeline_Fixed_Checkpoint")
        # If you also want to reduce Arrow batch sizes, you can keep this config:
        .config("spark.sql.execution.arrow.maxRecordsPerBatch", "50000")
        # Ensure Spark knows exactly where to write checkpoint files:
        .config("spark.checkpoint.dir", "/dbfs/checkpoints")
        .enableHiveSupport()
        .getOrCreate()
)

# -----------------------------------
# 2. Configure logging
# -----------------------------------
env_logging_conf = os.getenv('LOGGING_CONF', 'configs/logging.conf')
if os.path.exists(env_logging_conf):
    import logging.config
    logging.config.fileConfig(env_logging_conf, disable_existing_loggers=False)
logger = logging.getLogger('dq_pipeline.mitigated')

# Initialize ingestion manager
ingest_manager = IngestionManager(spark)

# -----------------------------------
# 3. Create widgets for user input (Databricks only)
# -----------------------------------
try:
    dbutils.widgets.removeAll()
    source_options = ['delta', 'kafka', 'mongodb', 'relational', 'cassandra', 'file', 's3', 'fivetran']
    dbutils.widgets.dropdown('source_type', 'delta', source_options, 'Source Type')
    dbutils.widgets.text('table', '', 'Delta Table (catalog.schema.table)')
    dbutils.widgets.text('topic', '', 'Kafka Topic')
    dbutils.widgets.text('kafka_servers', '', 'Kafka Bootstrap Servers')
    dbutils.widgets.text('uri', '', 'MongoDB URI')
    dbutils.widgets.text('database', '', 'MongoDB Database')
    dbutils.widgets.text('collection', '', 'MongoDB Collection')
    dbutils.widgets.text('jdbc_url', '', 'JDBC URL')
    dbutils.widgets.text('rel_table', '', 'Relational Table')
    dbutils.widgets.text('rel_user', '', 'Relational User')
    dbutils.widgets.text('rel_pass', '', 'Relational Password')
    dbutils.widgets.text('rel_driver', '', 'JDBC Driver Class')
    dbutils.widgets.text('cass_keyspace', '', 'Cassandra Keyspace')
    dbutils.widgets.text('cass_table', '', 'Cassandra Table')
    dbutils.widgets.text('cass_hosts', '', 'Cassandra Hosts')
    dbutils.widgets.text('cass_port', '', 'Cassandra Port')
    dbutils.widgets.text('file_path', '', 'File Path')
    dbutils.widgets.dropdown('file_type', 'csv', ['csv', 'json', 'parquet', 'excel'], 'File Type')
    dbutils.widgets.text('s3_path', '', 'S3 Path')
    dbutils.widgets.dropdown('s3_format', 'csv', ['csv', 'json', 'parquet'], 'S3 Format')
    dbutils.widgets.text('fivetran_table', '', 'FiveTran Table')
    dbutils.widgets.text('report_output_dir', '/dbfs/FileStore/acharjeerishab/reports', 'Report Output Dir')
except NameError:
    # Not running in Databricks, so ignore widget creation
    pass

# Helper function to fetch widget values
def get_widget(name: str):
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return None

# -----------------------------------
# 4. Read widget values (or fallback defaults)
# -----------------------------------
source_type       = get_widget('source_type')
table             = get_widget('table')
topic             = get_widget('topic')
kafka_servers     = get_widget('kafka_servers')
uri               = get_widget('uri')
database          = get_widget('database')
collection        = get_widget('collection')
jdbc_url          = get_widget('jdbc_url')
rel_table         = get_widget('rel_table')
rel_user          = get_widget('rel_user')
rel_pass          = get_widget('rel_pass')
rel_driver        = get_widget('rel_driver')
cass_keyspace     = get_widget('cass_keyspace')
cass_table        = get_widget('cass_table')
cass_hosts        = get_widget('cass_hosts')
cass_port         = get_widget('cass_port')
file_path         = get_widget('file_path')
file_type         = get_widget('file_type')
s3_path           = get_widget('s3_path')
s3_format         = get_widget('s3_format')
fivetran_table    = get_widget('fivetran_table')
report_output_dir = get_widget('report_output_dir') or '/dbfs/FileStore/acharjeerishab/reports'

# -----------------------------------
# 5. Ingest data based on the chosen source
# -----------------------------------
try:
    logger.info(f"Ingestion source: {source_type}")
    if source_type == 'delta':
        if not table:
            raise ValueError("Delta table must be provided")
        df = ingest_manager.ingest_delta(table)

    elif source_type == 'kafka':
        if not topic or not kafka_servers:
            raise ValueError("Kafka topic and bootstrap servers required")
        df = ingest_manager.ingest_kafka(topic, kafka_servers)
        raise ValueError("Streaming ingestion not supported in interactive batch mode")

    elif source_type == 'mongodb':
        if not (uri and database and collection):
            raise ValueError("MongoDB URI, database, and collection required")
        df = ingest_manager.ingest_mongodb(uri, database, collection)

    elif source_type == 'relational':
        if not (jdbc_url and rel_table and rel_user and rel_pass):
            raise ValueError("JDBC URL, table, user, and password required")
        df = ingest_manager.ingest_relational(jdbc_url, rel_table, rel_user, rel_pass, driver=rel_driver)

    elif source_type == 'cassandra':
        if not (cass_keyspace and cass_table and cass_hosts and cass_port):
            raise ValueError("Cassandra keyspace, table, hosts, and port required")
        df = ingest_manager.ingest_cassandra(
            cass_keyspace,
            cass_table,
            contact_points=cass_hosts,
            port=int(cass_port)
        )

    elif source_type == 'file':
        if not (file_path and file_type):
            raise ValueError("File path and file type required")
        # Normalize the path string
        if file_path.startswith("/Workspace/"):
            norm_path = "dbfs:" + file_path
        elif file_path.startswith("/dbfs/"):
            norm_path = file_path.replace("/dbfs/", "dbfs:/")
        elif file_path.startswith("dbfs:/"):
            norm_path = file_path
        else:
            norm_path = file_path

        logger.info(f"Normalized file path: {norm_path}")
        if file_path.endswith(('xlsx', 'xls')):
            # Use the Spark Excel reader if the file is an Excel workbook
            df = spark.read.format("com.crealytics.spark.excel") \
                         .option("header", "true") \
                         .option("inferSchema", "true") \
                         .load(norm_path)
        else:
            # Otherwise use a generic file ingestion method
            df = ingest_manager.ingest_file(norm_path, file_type)

    elif source_type == 's3':
        if not (s3_path and s3_format):
            raise ValueError("S3 path and format required")
        df = ingest_manager.ingest_s3(s3_path, file_format=s3_format)

    elif source_type == 'fivetran':
        if not fivetran_table:
            raise ValueError("FiveTran table required")
        df = ingest_manager.ingest_fivetran(fivetran_table)

    else:
        raise ValueError(f"Unsupported source: {source_type}")

except Exception as e:
    logger.error(f"Error during ingestion: {e}")
    spark.stop()
    raise

# -----------------------------------
# 6. Validate that the DataFrame is non‐empty
#    (Use head(1) instead of count() to avoid a full scan.)
# -----------------------------------
if df is None or len(df.head(1)) == 0:
    logger.error("DataFrame is empty after ingestion.")
    spark.stop()
    raise ValueError("Empty DataFrame")

# -----------------------------------
# 7. Break lineage early via checkpoint
# -----------------------------------
# Although we already set spark.checkpoint.dir when building the session,
# we explicitly re‐set it here again just before checkpointing, in case
# this notebook session was started earlier without that property.
#
# This double‐setting guarantees no “checkpoint dir not set” error:
# spark.conf.set("spark.checkpoint.dir", "/dbfs/checkpoints")
# Perform checkpoint to truncate lineage
cf_df = df.checkpoint(eager=True)
df = cf_df

# -----------------------------------
# 8. Sampling & rule suggestion
# -----------------------------------
logger.info("Starting sampling & rule suggestion")

# Stage 1: Reservoir Sampling (fraction-based, driver‐safe)
resampler = ReservoirSampler(spark, sample_size=1500)
sample_stage1 = resampler.sample(df)

# Stage 2: Random Downsample
downsampler = RandomDownSampler(spark, target_count=100)
sample_stage2 = downsampler.sample(sample_stage1)

# Limit to a small pandas DataFrame (≤ 5000 rows) for calling the LLM
pdf = sample_stage2.limit(1000).toPandas()

# Stage 3: Diversity Sampling (on the driver, on the small PDF)
diversity_sampler = DiversitySampler(num_clusters=1, samples_per_cluster=1)
final_pdf = diversity_sampler.sample(pdf)

# Collect minimal statistics and invoke the chunked suggester
try:
    chunked_suggester = ChunkedRuleSuggester(model_name='deepseek-r1-distill-llama-70b')
    rules = chunked_suggester.suggest_rules_chunked(final_pdf)
except Exception as e:
    logger.error(f"Error during rule suggestion: {e}")
    spark.stop()
    raise

if not rules:
    logger.warning("No rules generated; skipping DQ assessment")
    spark.stop()
    exit(0)

# -----------------------------------
# 9. Run DQ Assessment (distributed on Spark)
# -----------------------------------
logger.info("Running DQ Assessment")
assessor = DQAssessment(spark)
try:
    results_df = assessor.run_assessment(df, rules)
except Exception as e:
    logger.error(f"Assessment failed: {e}")
    spark.stop()
    raise

# Write results into a Delta table
results_table = os.getenv('DQ_RESULTS_TABLE', 'dq_results.default')
try:
    results_df.write.mode('overwrite').format('delta').saveAsTable(results_table)
    logger.info(f"Results saved to {results_table}")
except Exception as e:
    logger.error(f"Writing results failed: {e}")
    spark.stop()
    raise

# -----------------------------------
# 10. Generate PDF report
# -----------------------------------
logger.info("Generating PDF report")
report_gen = ReportGenerator(output_dir=report_output_dir)
try:
    pdf_path = report_gen.generate(results_df)
    logger.info(f"Report saved at {pdf_path}")
except Exception as e:
    logger.error(f"Report generation failed: {e}")
    spark.stop()
    raise

spark.stop()
logger.info("Pipeline run complete.")


# COMMAND ----------

# MAGIC %pip install langchain_groq langchain langchain_core langchain_community

# COMMAND ----------

dbutils.fs.mkdirs("dbfs:/checkpoints")


# COMMAND ----------

from pyspark.sql import SparkSession

spark = (
    SparkSession.builder
      .appName("DQ_Pipeline_Fixed_Checkpoint")
      .config("spark.checkpoint.dir", "/dbfs/checkpoints")  # valid DBFS path
      .enableHiveSupport()
      .getOrCreate()
)

# COMMAND ----------

# MAGIC %scala
# MAGIC import org.apache.spark.sql.SparkSession
# MAGIC
# MAGIC val spark = SparkSession.builder()
# MAGIC   .appName("AttachSparkExcelAtRuntime")
# MAGIC   .config("spark.jars.packages", "com.crealytics:spark-excel_2.12:0.13.5")
# MAGIC   .getOrCreate()
# MAGIC
# MAGIC spark

# COMMAND ----------

spark.read.format("com.crealytics.spark.excel") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load("dbfs:/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/Copy of Smart Meter Sample Data_v1.xlsx")

# COMMAND ----------

# MAGIC %fs ls "file:/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/"

# COMMAND ----------

# MAGIC %fs cp "file:/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/Copy of Smart Meter Sample Data_v1.xlsx" "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx"

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/FileStore/acharjeerishab/"))

# COMMAND ----------

# ----------- run_pipeline.py -----------

import os
import logging
from pyspark.sql import SparkSession
from ingestion.ingestion import IngestionManager
from sampling.stage1_reservoir_sampling import ReservoirSampler
from sampling.stage2_random_downsample import RandomDownSampler
from sampling.stage3_diversity_sampling import DiversitySampler

try:
    from rule_suggester.chunked_rule_suggester import ChunkedRuleSuggester
except ModuleNotFoundError:
    raise ImportError(
        "The module 'langchain_groq' is required but not installed. "
        "Please install it via 'pip install langchain-groq'."
    )

from assessment.dq_assessment import DQAssessment
from reporting.report_generator import ReportGenerator
import pandas as pd

# -----------------------------------
# 1. Create SparkSession with checkpoint directory
# -----------------------------------
# BEFORE running, ensure the folder exists:
#   dbutils.fs.mkdirs("dbfs:/checkpoints")
spark = (
    SparkSession.builder
        .appName("DQ_Pipeline_Fixed_Checkpoint")
        .config("spark.sql.execution.arrow.maxRecordsPerBatch", "50000")
        .config("spark.checkpoint.dir", "/dbfs/checkpoints")  # builder-time set
        .enableHiveSupport()
        .getOrCreate()
)

# Explicitly set SparkContext checkpoint dir (ensures driver sees it)
spark.sparkContext.setCheckpointDir("/dbfs/checkpoints")  # :contentReference[oaicite:14]{index=14}

# Tweak shuffle partitions & parallelism to prevent oversized partitions
spark.conf.set("spark.sql.shuffle.partitions", "200")         # :contentReference[oaicite:15]{index=15}
spark.conf.set("spark.default.parallelism", "200")            # :contentReference[oaicite:16]{index=16}

# -----------------------------------
# 2. Configure logging
# -----------------------------------
env_logging_conf = os.getenv('LOGGING_CONF', 'configs/logging.conf')
if os.path.exists(env_logging_conf):
    import logging.config
    logging.config.fileConfig(env_logging_conf, disable_existing_loggers=False)
logger = logging.getLogger('dq_pipeline.mitigated')

# Instantiate ingestion manager
ingest_manager = IngestionManager(spark)

# -----------------------------------
# 3. Create widgets for user input (Databricks only)
# -----------------------------------
try:
    dbutils.widgets.removeAll()
    source_options = ['delta', 'kafka', 'mongodb', 'relational', 'cassandra', 'file', 's3', 'fivetran']
    dbutils.widgets.dropdown('source_type', 'delta', source_options, 'Source Type')
    dbutils.widgets.text('table', '', 'Delta Table (catalog.schema.table)')
    dbutils.widgets.text('topic', '', 'Kafka Topic')
    dbutils.widgets.text('kafka_servers', '', 'Kafka Bootstrap Servers')
    dbutils.widgets.text('uri', '', 'MongoDB URI')
    dbutils.widgets.text('database', '', 'MongoDB Database')
    dbutils.widgets.text('collection', '', 'MongoDB Collection')
    dbutils.widgets.text('jdbc_url', '', 'JDBC URL')
    dbutils.widgets.text('rel_table', '', 'Relational Table')
    dbutils.widgets.text('rel_user', '', 'Relational User')
    dbutils.widgets.text('rel_pass', '', 'Relational Password')
    dbutils.widgets.text('rel_driver', '', 'JDBC Driver Class')
    dbutils.widgets.text('cass_keyspace', '', 'Cassandra Keyspace')
    dbutils.widgets.text('cass_table', '', 'Cassandra Table')
    dbutils.widgets.text('cass_hosts', '', 'Cassandra Hosts')
    dbutils.widgets.text('cass_port', '', 'Cassandra Port')
    dbutils.widgets.text('file_path', '', 'File Path')
    dbutils.widgets.dropdown('file_type', 'csv', ['csv', 'json', 'parquet', 'excel'], 'File Type')
    dbutils.widgets.text('s3_path', '', 'S3 Path')
    dbutils.widgets.dropdown('s3_format', 'csv', ['csv', 'json', 'parquet'], 'S3 Format')
    dbutils.widgets.text('fivetran_table', '', 'FiveTran Table')
    dbutils.widgets.text('report_output_dir', '/dbfs/FileStore/acharjeerishab/reports', 'Report Output Dir')
except NameError:
    # Not running in Databricks; skip widgets
    pass

# Helper to fetch widget values
def get_widget(name: str):
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return None

# -----------------------------------
# 4. Read widget values
# -----------------------------------
source_type       = get_widget('source_type')
table             = get_widget('table')
topic             = get_widget('topic')
kafka_servers     = get_widget('kafka_servers')
uri               = get_widget('uri')
database          = get_widget('database')
collection        = get_widget('collection')
jdbc_url          = get_widget('jdbc_url')
rel_table         = get_widget('rel_table')
rel_user          = get_widget('rel_user')
rel_pass          = get_widget('rel_pass')
rel_driver        = get_widget('rel_driver')
cass_keyspace     = get_widget('cass_keyspace')
cass_table        = get_widget('cass_table')
cass_hosts        = get_widget('cass_hosts')
cass_port         = get_widget('cass_port')
file_path         = get_widget('file_path')
file_type         = get_widget('file_type')
s3_path           = get_widget('s3_path')
s3_format         = get_widget('s3_format')
fivetran_table    = get_widget('fivetran_table')
report_output_dir = get_widget('report_output_dir') or '/dbfs/FileStore/acharjeerishab/reports'

# -----------------------------------
# 5. Ingest data based on chosen source
# -----------------------------------
try:
    logger.info(f"Ingestion source: {source_type}")
    if source_type == 'delta':
        if not table:
            raise ValueError("Delta table must be provided")
        df = ingest_manager.ingest_delta(table)

    elif source_type == 'kafka':
        if not topic or not kafka_servers:
            raise ValueError("Kafka topic and bootstrap servers required")
        df = ingest_manager.ingest_kafka(topic, kafka_servers)
        raise ValueError("Streaming ingestion not supported in interactive batch mode")

    elif source_type == 'mongodb':
        if not (uri and database and collection):
            raise ValueError("MongoDB URI, database, and collection required")
        df = ingest_manager.ingest_mongodb(uri, database, collection)

    elif source_type == 'relational':
        if not (jdbc_url and rel_table and rel_user and rel_pass):
            raise ValueError("JDBC URL, table, user, and password required")
        df = ingest_manager.ingest_relational(jdbc_url, rel_table, rel_user, rel_pass, driver=rel_driver)

    elif source_type == 'cassandra':
        if not (cass_keyspace and cass_table and cass_hosts and cass_port):
            raise ValueError("Cassandra keyspace, table, hosts, and port required")
        df = ingest_manager.ingest_cassandra(
            cass_keyspace,
            cass_table,
            contact_points=cass_hosts,
            port=int(cass_port)
        )

    elif source_type == 'file':
        if not (file_path and file_type):
            raise ValueError("File path and file type required")

        # Normalize the file path
        if file_path.startswith("/Workspace/"):
            norm_path = "dbfs:" + file_path
        elif file_path.startswith("/dbfs/"):
            norm_path = file_path.replace("/dbfs/", "dbfs:/")
        elif file_path.startswith("dbfs:/"):
            norm_path = file_path
        else:
            norm_path = file_path

        logger.info(f"Normalized file path: {norm_path}")
        if file_type.lower() == 'excel' and file_path.endswith(('xlsx', 'xls')):
            # Read Excel via Spark Excel connector
            df = spark.read.format("com.crealytics.spark.excel") \
                         .option("header", "true") \
                         .option("inferSchema", "true") \
                         .load(norm_path)
        else:
            # Delegate other formats to ingestion manager
            df = ingest_manager.ingest_file(norm_path, file_type)

    elif source_type == 's3':
        if not (s3_path and s3_format):
            raise ValueError("S3 path and format required")
        df = ingest_manager.ingest_s3(s3_path, file_format=s3_format)

    elif source_type == 'fivetran':
        if not fivetran_table:
            raise ValueError("FiveTran table required")
        df = ingest_manager.ingest_fivetran(fivetran_table)

    else:
        raise ValueError(f"Unsupported source: {source_type}")

except Exception as e:
    logger.error(f"Error during ingestion: {e}")
    spark.stop()
    raise

# -----------------------------------
# 6. Validate non‐empty DataFrame
#    (Use head(1) rather than count() to avoid full scan.)
# -----------------------------------
if df is None or len(df.head(1)) == 0:
    logger.error("DataFrame is empty after ingestion.")
    spark.stop()
    raise ValueError("Empty DataFrame")

# -----------------------------------
# 7. Break lineage early via checkpoint
# -----------------------------------
df = df.checkpoint(eager=True)  # :contentReference[oaicite:17]{index=17}

# -----------------------------------
# 8. Sampling & rule suggestion
# -----------------------------------
logger.info("Starting sampling & rule suggestion")

# Stage 1: Reservoir Sampling
resampler = ReservoirSampler(spark, sample_size=1500)
sample_stage1 = resampler.sample(df)

# Stage 2: Random Downsample
downsampler = RandomDownSampler(spark, target_count=250)
sample_stage2 = downsampler.sample(sample_stage1)

# Select only needed columns before converting to Pandas
# IMPORTANT: replace ['colA','colB','colC'] with your actual columns
selected_cols = sample_stage2.select(['colA', 'colB', 'colC'])  # :contentReference[oaicite:18]{index=18}
pdf = selected_cols.limit(1000).toPandas()                 # keep sample small

# Stage 3: Diversity Sampling
diversity_sampler = DiversitySampler(num_clusters=1, samples_per_cluster=1)
final_pdf = diversity_sampler.sample(pdf)

# Collect minimal stats and invoke the chunked suggester
try:
    chunked_suggester = ChunkedRuleSuggester(model_name='deepseek-r1-distill-llama-70b')
    rules = chunked_suggester.suggest_rules_chunked(final_pdf)
except Exception as e:
    logger.error(f"Error during rule suggestion: {e}")
    spark.stop()
    raise

if not rules:
    logger.warning("No rules generated; skipping DQ assessment")
    spark.stop()
    exit(0)

# -----------------------------------
# 9. Run DQ Assessment (distributed)
# -----------------------------------
logger.info("Running DQ Assessment")
assessor = DQAssessment(spark)
try:
    results_df = assessor.run_assessment(df, rules)
except Exception as e:
    logger.error(f"Assessment failed: {e}")
    spark.stop()
    raise

# Save results as a Delta table
results_table = os.getenv('DQ_RESULTS_TABLE', 'dq_results.default')
try:
    results_df.write.mode('overwrite').format('delta').saveAsTable(results_table)
    logger.info(f"Results saved to {results_table}")
except Exception as e:
    logger.error(f"Writing results failed: {e}")
    spark.stop()
    raise

# -----------------------------------
# 10. Generate PDF report
# -----------------------------------
logger.info("Generating PDF report")
report_gen = ReportGenerator(output_dir=report_output_dir)
try:
    pdf_path = report_gen.generate(results_df)
    logger.info(f"Report saved at {pdf_path}")
except Exception as e:
    logger.error(f"Report generation failed: {e}")
    spark.stop()
    raise

spark.stop()
logger.info("Pipeline run complete.")


# COMMAND ----------

from pyspark.sql import SparkSession

# Create SparkSession and set checkpoint directory.
spark = (
    SparkSession.builder
        .appName("DQ_Pipeline_With_Checkpoint")
        .config("spark.checkpoint.dir", "/dbfs/checkpoints")  # valid DBFS path
        .getOrCreate()
)

# Example of reading from an Excel file on DBFS
# (Replace with your actual file path)
df_excel = spark.read.format("com.crealytics.spark.excel") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load("dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx")

# Checkpoint the DataFrame to truncate lineage
df_excel = df_excel.checkpoint(eager=True)

# Now df_excel is checkpointed and can be used for further transformations
print(df_excel.count())   # Example action to verify checkpoint


# COMMAND ----------

print(spark.sparkContext.getCheckpointDir())  # Likely prints 'None'


# COMMAND ----------

from pyspark.sql import SparkSession

# 1. [Run beforehand in a separate cell] Create the checkpoint folder on DBFS:
#    dbutils.fs.mkdirs("dbfs:/checkpoints")

# 2. Build SparkSession (including checkpoint.dir, though this alone may not suffice)
spark = (
    SparkSession.builder
        .appName("DQ_Pipeline_With_Checkpoint")
        .config("spark.sql.execution.arrow.maxRecordsPerBatch", "500")
        .config("spark.checkpoint.dir", "/dbfs/checkpoints")
        .getOrCreate()
)

# 3. Explicitly set the SparkContext checkpoint directory:
spark.sparkContext.setCheckpointDir("/dbfs/checkpoints")  # Ensures RDD.checkpoint() sees a valid path :contentReference[oaicite:7]{index=7}

# 4. Read the Excel file from DBFS using the Spark Excel connector
df_excel = spark.read.format("com.crealytics.spark.excel") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load("dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx")

# 5. Checkpoint the DataFrame (truncates lineage and writes to /dbfs/checkpoints)
df_excel = df_excel.checkpoint(eager=True)  # Now succeeds without errors :contentReference[oaicite:8]{index=8}

# 6. Verify by performing an action (e.g., count rows)
print(df_excel.count())  # Should print the row count without raising the checkpoint error


# COMMAND ----------

spark.sparkContext.setCheckpointDir("/dbfs/checkpoints")


# COMMAND ----------

print(spark.sparkContext.getCheckpointDir())  # Likely prints 'None'


# COMMAND ----------

# ----------- run_pipeline.py -----------

import os, logging, traceback
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from ingestion.ingestion import IngestionManager
from sampling.stage3_diversity_sampling import DiversitySampler
from assessment.dq_assessment import DQAssessment
from reporting.report_generator import ReportGenerator
import pandas as pd
from pyspark.storagelevel import StorageLevel

# -----------------------------------
# 1. SparkSession (singleNode, local[*,4], more driver memory)
# -----------------------------------
spark = (
    SparkSession.builder
        .appName("DQ_Pipeline_SingleNode")
        .master("local[*,4]")
        .config("spark.databricks.cluster.profile", "singleNode")
        .config("spark.sql.execution.arrow.maxRecordsPerBatch", "50000")
        .config("spark.checkpoint.dir", "/dbfs/checkpoints")
        .config("spark.driver.memory", "8g")
        .config("spark.driver.maxResultSize", "1g")
        .getOrCreate()
)
spark.sparkContext.setCheckpointDir("/dbfs/checkpoints")
spark.conf.set("spark.sql.shuffle.partitions", "50")          # fewer partitions
spark.conf.set("spark.default.parallelism", "50")

# -----------------------------------
# 2. Logging
# -----------------------------------
env_logging_conf = os.getenv('LOGGING_CONF', 'configs/logging.conf')
if os.path.exists(env_logging_conf):
    import logging.config
    logging.config.fileConfig(env_logging_conf, disable_existing_loggers=False)
logger = logging.getLogger('dq_pipeline.singleNode')

def run_pipeline():
    ingest_manager = IngestionManager(spark)

    # (Optional) Widgets omitted for brevity…

    # Example: ingest a Delta table
    df = ingest_manager.ingest_delta("catalog.schema.table")

    # Validate
    if df.rdd.isEmpty():
        raise ValueError("Empty DataFrame after ingestion")

    # Break lineage cheaply
    df = df.localCheckpoint()
    df.persist(StorageLevel.MEMORY_AND_DISK)

    # ----------------------------------------------------------------
    # Sampling: LIMIT only (no full-table shuffle sample)
    # ----------------------------------------------------------------
    logger.info("Sampling first 500 rows for rule suggestion")
    pdf = df.limit(500).toPandas()
    if pdf.empty:
        raise ValueError("No rows sampled. Source too small?")

    # Diversity sampling on driver
    diversity_sampler = DiversitySampler(num_clusters=1, samples_per_cluster=1)
    final_pdf = diversity_sampler.sample(pdf)

    # ----------------------------------------------------------------
    # Rule suggestion (driver-side, small PDF)
    # ----------------------------------------------------------------
    from rule_suggester.chunked_rule_suggester import ChunkedRuleSuggester
    suggester = ChunkedRuleSuggester(model_name='deepseek-r1-distill-llama-70b')
    rules = suggester.suggest_rules_chunked(final_pdf)
    if not rules:
        logger.warning("No rules generated; exiting.")
        return

    # ----------------------------------------------------------------
    # DQ Assessment (distributed)
    # ----------------------------------------------------------------
    assessor = DQAssessment(spark)
    results_df = assessor.run_assessment(df, rules)

    # Persist full results
    results_table = os.getenv('DQ_RESULTS_TABLE', 'dq_results.default')
    results_df.write.mode('overwrite').format('delta').saveAsTable(results_table)

    # ----------------------------------------------------------------
    # PDF Report (off-driver if possible)
    # ----------------------------------------------------------------
    agg_df = (
        results_df
        .groupBy("Dimension","Rule","Column","Status")
        .agg(F.count("*").alias("Affected_Records"))
        .orderBy("Dimension","Rule")
    )
    report_pd = agg_df.limit(1000).toPandas()
    report_dir = "/dbfs/FileStore/acharjeerishab/reports"
    pdf_path = ReportGenerator(output_dir=report_dir).generate(report_pd)
    logger.info(f"Report at {pdf_path}")

if __name__ == "__main__":
    try:
        run_pipeline()
    except Exception:
        logger.error("Fatal error in pipeline:\n" + traceback.format_exc())
        spark.stop()
        raise
    finally:
        spark.stop()
        logger.info("Pipeline complete.")


# COMMAND ----------

# ----------- run_pipeline_single_node_mitigated.py -----------
# This script has been modified to run on a constrained SINGLE-NODE cluster.
# WARNING: To prevent memory crashes, it aggressively limits the input data
# to a small sample (100,000 rows) at the point of ingestion.
# The data quality results are ONLY for this sample, NOT the full dataset.

import os
import logging
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from ingestion.ingestion import IngestionManager
from sampling.stage3_diversity_sampling import DiversitySampler

try:
    from rule_suggester.chunked_rule_suggester import ChunkedRuleSuggester
except ModuleNotFoundError:
    raise ImportError(
        "The module 'langchain_groq' is required but not installed. "
        "Please install it via 'pip install langchain-groq'."
    )

from assessment.dq_assessment import DQAssessment
from reporting.report_generator import ReportGenerator
import pandas as pd

# -----------------------------------
# 1. Create SparkSession with checkpoint directory
# -----------------------------------
# Note: On a single node, many of these Spark configs have minimal effect,
# but are kept for structural consistency.
spark = (
    SparkSession.builder
        .appName("DQ_Pipeline_SingleNode_Mitigated")
        .config("spark.sql.execution.arrow.maxRecordsPerBatch", "10000")
        .config("spark.driver.memory", "40g") # Allocate a large portion of memory to the driver
        .config("spark.checkpoint.dir", "/dbfs/checkpoints")
        .enableHiveSupport()
        .getOrCreate()
)
spark.sparkContext.setCheckpointDir("/dbfs/checkpoints")

# -----------------------------------
# 2. Configure logging
# -----------------------------------
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.mitigated')

ingest_manager = IngestionManager(spark)

# -----------------------------------
# 3. Create widgets for user input (Databricks only)
# -----------------------------------
try:
    dbutils.widgets.removeAll()
    source_options = ['delta', 'kafka', 'mongodb', 'relational', 'cassandra', 'file', 's3', 'fivetran']
    dbutils.widgets.dropdown('source_type', 'delta', source_options, 'Source Type')
    dbutils.widgets.text('table', 'samples.nyctaxi.trips', 'Delta Table (catalog.schema.table)') # Example value
    # ... (other widgets are unchanged) ...
    dbutils.widgets.text('file_path', '', 'File Path')
    dbutils.widgets.dropdown('file_type', 'csv', ['csv', 'json', 'parquet', 'excel'], 'File Type')
    dbutils.widgets.text('report_output_dir', '/dbfs/FileStore/acharjeerishab/reports', 'Report Output Dir')
except NameError:
    pass

def get_widget(name: str):
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return None

# -----------------------------------
# 4. Read widget values
# -----------------------------------
source_type = get_widget('source_type')
table = get_widget('table')
file_path = get_widget('file_path')
file_type = get_widget('file_type')
report_output_dir = get_widget('report_output_dir') or '/dbfs/FileStore/acharjeerishab/reports'
# Ingest all other widgets as needed...

# -----------------------------------
# 5. Ingest a LIMITED SAMPLE of data
# -----------------------------------
# This is the primary mitigation for the OOM error.
MAX_ROWS_FOR_SINGLE_NODE = 100000
df = None

try:
    logger.info(f"Ingestion source: {source_type}")
    
    # Temporarily load the full DataFrame definition
    if source_type == 'delta':
        if not table: raise ValueError("Delta table must be provided")
        temp_df = ingest_manager.ingest_delta(table)
    # ... (all other elif blocks for ingestion are unchanged) ...
    elif source_type == 'file':
        if not (file_path and file_type): raise ValueError("File path and file type required")
        if file_path.startswith("/Workspace/"): norm_path = "dbfs:" + file_path
        elif file_path.startswith("/dbfs/"): norm_path = file_path.replace("/dbfs/", "dbfs:/")
        elif file_path.startswith("dbfs:/"): norm_path = file_path
        else: norm_path = file_path
        logger.info(f"Normalized file path: {norm_path}")
        if file_type.lower() == 'excel' and norm_path.endswith(('xlsx', 'xls')):
            temp_df = spark.read.format("com.crealytics.spark.excel").option("header", "true").option("inferSchema", "true").load(norm_path)
        else:
            temp_df = ingest_manager.ingest_file(norm_path, file_type)
    else:
        raise ValueError(f"Unsupported source: {source_type}")

    # **** CRITICAL OOM MITIGATION ****
    # Immediately apply a hard limit to the DataFrame to prevent loading the full dataset into memory.
    logger.warning(f"SINGLE NODE MODE: Aggressively limiting data to {MAX_ROWS_FOR_SINGLE_NODE} rows to prevent memory crash.")
    df = temp_df.limit(MAX_ROWS_FOR_SINGLE_NODE)
    
except Exception as e:
    logger.error(f"Error during ingestion: {e}", exc_info=True)
    spark.stop()
    raise

# -----------------------------------
# 6. Validate non-empty DataFrame
# -----------------------------------
if df is None or len(df.head(1)) == 0:
    logger.error("DataFrame is empty after ingestion and limiting. No data to process.")
    spark.stop()
    raise ValueError("Empty DataFrame")

# -----------------------------------
# 7. Break lineage early via checkpoint
# -----------------------------------
# This step is less critical with a small dataset but is kept for structural integrity.
df = df.checkpoint(eager=True)

# -----------------------------------
# 8. Sampling & rule suggestion
# -----------------------------------
logger.info("Starting sampling & rule suggestion")
try:
    # MODIFIED SAMPLING LOGIC:
    # The original fraction (0.00001) was for petabytes and would yield 0 rows here.
    # Adjust the fraction to be suitable for the 100k row sample.
    # We aim for a ~1000 row sample to feed to the limit.
    fraction_for_sample = 0.1 # 10% of 100,000 is 10,000
    
    logger.info(f"Sampling the {MAX_ROWS_FOR_SINGLE_NODE}-row limited data to get a smaller subset for the LLM.")
    fractional_sample = df.sample(withReplacement=False, fraction=fraction_for_sample, seed=42)

    sample_for_driver = fractional_sample.limit(500)
    pdf = sample_for_driver.toPandas()
    
    if pdf.empty:
        raise ValueError("LLM sampling resulted in an empty DataFrame.")

    diversity_sampler = DiversitySampler(num_clusters=1, samples_per_cluster=1)
    final_pdf = diversity_sampler.sample(pdf)

except Exception as e:
    logger.error(f"Fatal error during sampling: {e}", exc_info=True)
    spark.stop()
    raise

# ... (Rule suggestion remains the same) ...
try:
    chunked_suggester = ChunkedRuleSuggester(model_name='deepseek-r1-distill-llama-70b')
    rules = chunked_suggester.suggest_rules_chunked(final_pdf)
except Exception as e:
    logger.error(f"Error during rule suggestion: {e}", exc_info=True)
    spark.stop()
    raise

if not rules:
    logger.warning("No rules generated; skipping DQ assessment")
    spark.stop()
    exit(0)

# -----------------------------------
# 9. Run DQ Assessment (on the limited DataFrame)
# -----------------------------------
logger.info(f"Running DQ Assessment on the {MAX_ROWS_FOR_SINGLE_NODE}-row sample.")
assessor = DQAssessment(spark)
try:
    # The assessment now runs on the small 'df', not the full petabyte-scale data.
    results_df = assessor.run_assessment(df, rules)
except Exception as e:
    logger.error(f"Assessment failed: {e}", exc_info=True)
    spark.stop()
    raise

# ... (Saving results and reporting are unchanged as they now operate on small data) ...
# -----------------------------------
# 10. Save and Report Results
# -----------------------------------
try:
    results_table = os.getenv('DQ_RESULTS_TABLE', 'dq_results.default')
    results_df.write.mode('overwrite').format('delta').saveAsTable(results_table)
    logger.info(f"Results from the SAMPLE data have been saved to Delta table: {results_table}")

    logger.info("Aggregating results for the final report.")
    report_data_df = results_df.groupBy("Dimension", "Rule", "Column", "Status").agg(
        F.count("*").alias("Affected Records")
    ).orderBy("Dimension", "Rule")

    report_data_pd = report_data_df.limit(1000).toPandas()

    report_gen = ReportGenerator(output_dir=report_output_dir)
    pdf_path = report_gen.generate(report_data_pd)
    logger.info(f"Report saved at {pdf_path}")

except Exception as e:
    logger.error(f"Failed to save results or generate report: {e}", exc_info=True)
finally:
    spark.stop()
    logger.info("Pipeline run complete.")

# COMMAND ----------

