# Databricks notebook source
# MAGIC %pip install -r requirements.txt
# MAGIC

# COMMAND ----------

# Cell 1: Setup, Configuration, and Widgets

import os
import logging
import json
import gc
from typing import Any, List, Dict
from collections import defaultdict
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType,
    DoubleType, TimestampType, IntegerType
)

# --- Memory Safety & Configuration ---
# Suppress the benign tokenizers parallelism warning
os.environ["TOKENIZERS_PARALLELISM"] = "false"
MAX_ROWS_TO_PROCESS = 50  # A safe, low limit to prevent OOM errors.
# DQ_PARAMS will be dynamically loaded from weights file in Cell 4
# RULES_PATH and WEIGHTS_PATH must match Cell 3's saving location
RULES_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
WEIGHTS_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# --- Spark and Logging Setup ---
spark = SparkSession.builder.appName("DQ_Pipeline_Memory_Safe").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.final')
print("✅ Spark Session and Logger initialized.")

# --- Widget Creation and Parameter Retrieval ---
# When this notebook is run as a Databricks Job by the Next.js API,
# the 'dbutils.widgets.get()' calls will automatically retrieve the
# parameters passed in the 'notebook_params' of the jobs/run-now API call.
# The default values are used only when running interactively in the notebook.
try:
    dbutils.widgets.removeAll() # Clean up any existing widgets

    # Define widgets to receive parameters from Next.js API route
    # These widget names MUST match the keys in 'notebook_params' from your Next.js API route
    dbutils.widgets.text("param_source_type", "Local/Cloud File Upload", "1. Source Type (from Next.js)")
    dbutils.widgets.text("param_file_path", "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx", "2a. File Path (for Local/Cloud)")
    dbutils.widgets.text("param_file_type", "excel", "2b. File Type (for Local/Cloud)")
    dbutils.widgets.text("param_azure_storage_account_name", "fofstrprdeusdata", "3a. Azure Storage Account Name") # Updated default
    dbutils.widgets.text("param_azure_container_name", "genai", "3b. Azure Container Name") # Updated default
    dbutils.widgets.text("param_azure_blob_path", "New_Query_2025_05_09_12_33pm.csv", "3c. Azure Blob Path") # Updated default
    dbutils.widgets.text("param_data_age_months", "0", "4. Data Age in Months") # Default for int conversion

    print("✅ Databricks widgets defined for job parameters.")

    # Retrieve parameters into variables that will be used in Cell 2
    # These variables will carry the values from the Next.js API call (if run as job)
    # or the widget defaults/user selections (if run interactively).
    source_type_param = dbutils.widgets.get("param_source_type")
    file_path_param = dbutils.widgets.get("param_file_path")
    file_type_param = dbutils.widgets.get("param_file_type")
    azure_storage_account_name_param = dbutils.widgets.get("param_azure_storage_account_name")
    azure_container_name_param = dbutils.widgets.get("param_azure_container_name")
    azure_blob_path_param = dbutils.widgets.get("param_azure_blob_path")
    data_age_months_param = dbutils.widgets.get("param_data_age_months")

    print("✅ Parameters retrieved from widgets/job context.")

except Exception as e:
    print(f"⚠️ Could not create or retrieve Databricks widgets. Using hardcoded defaults. Error: {e}")
    # Fallback hardcoded defaults for extreme cases (e.g., dbutils not available)
    source_type_param = "Local/Cloud File Upload"
    file_path_param = "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx"
    file_type_param = "excel"
    azure_storage_account_name_param = "fofstrprdeusdata"
    azure_container_name_param = "genai"
    azure_blob_path_param = "New_Query_2025_05_09_12_33pm.csv"
    data_age_months_param = "0"

# COMMAND ----------

# Cell 2: Data Ingestion and Type Casting (Updated to use parameters from Cell 1)

# Use the parameters retrieved in Cell 1
source_type = source_type_param # from Cell 1
file_path_local_cloud = file_path_param # from Cell 1
file_type_local_cloud = file_type_param.lower() # from Cell 1
azure_storage_account_name = azure_storage_account_name_param # from Cell 1
azure_container_name = azure_container_name_param # from Cell 1
azure_blob_path = azure_blob_path_param # from Cell 1
# data_age_months is retrieved but not used directly in ingestion; its purpose is likely for DQ rules

print(f"Attempting to ingest from: '{file_path_local_cloud}' (Source Type: {source_type})")
print(f"Azure Config: Account='{azure_storage_account_name}', Container='{azure_container_name}', Blob Path='{azure_blob_path}'")

# --- Azure Credentials Configuration (Using Account Key) ---
# IMPORTANT: Replace "<YOUR_AZURE_STORAGE_ACCOUNT_KEY>" with your actual key.
# For production environments, use Databricks Secrets (dbutils.secrets.get) instead of hardcoding.
# Note: You have this key hardcoded. Ensure it's correct for your environment.
AZURE_STORAGE_ACCOUNT_KEY = "uFMlAoFfhS8ljTMXrIxFa76QXotavNGoy89xfkYgck5ob7M5NHkpJUpFGjiFzEDCOxQmZyA96JDW+ASthlLHEA==" 

if source_type == "Azure Blob Storage (WASBS)":
    if not AZURE_STORAGE_ACCOUNT_KEY:
        raise ValueError("Azure Storage Account Key is not set. Please update the AZURE_STORAGE_ACCOUNT_KEY variable in Cell 2.")
    
    spark.conf.set(
        f"fs.azure.account.key.{azure_storage_account_name}.blob.core.windows.net",
        AZURE_STORAGE_ACCOUNT_KEY
    )
    print(f"Configured Spark with account key for storage account: {azure_storage_account_name}")
# --- End Azure Credentials Configuration ---

df_full = None
try:
    if source_type == "Local/Cloud File Upload":
        print(f"Attempting to ingest from local/cloud path: '{file_path_local_cloud}' (Type: {file_type_local_cloud})")
        
        reader = spark.read.option("header", "true").option("inferSchema", "true")
        
        if file_type_local_cloud == "excel":
            df_full = reader.format("com.crealytics.spark.excel").load(file_path_local_cloud)
        elif file_type_local_cloud == "csv":
            df_full = reader.csv(file_path_local_cloud)
        elif file_type_local_cloud == "json":
            df_full = reader.json(file_path_local_cloud)
        elif file_type_local_cloud == "parquet":
            df_full = reader.parquet(file_path_local_cloud)
        else:
            raise ValueError(f"Unsupported file type for local/cloud upload: {file_type_local_cloud}")

    elif source_type == "Azure Blob Storage (WASBS)":
        if not azure_storage_account_name or not azure_container_name or not azure_blob_path:
            raise ValueError("Azure Storage Account, Container, and Blob Path cannot be empty for Azure Blob Storage ingestion.")
        
        wasbs_path = f"wasbs://{azure_container_name}@{azure_storage_account_name}.blob.core.windows.net/{azure_blob_path}"
        print(f"Attempting to ingest from Azure Blob Storage: '{wasbs_path}'")
        
        blob_file_extension = azure_blob_path.split('.')[-1].lower()
        reader = spark.read.option("header", "true").option("inferSchema", "true")

        if blob_file_extension == "csv":
            df_full = reader.csv(wasbs_path)
        elif blob_file_extension == "json":
            df_full = reader.json(wasbs_path)
        elif blob_file_extension == "parquet":
            df_full = reader.parquet(wasbs_path)
        elif blob_file_extension == "xlsx": # For excel from WASBS, still needs the connector
             df_full = reader.format("com.crealytics.spark.excel").load(wasbs_path)
        else:
            print(f"Warning: Auto-detected Azure blob file type '{blob_file_extension}' from path. If incorrect, data might not load correctly.")
            df_full = reader.csv(wasbs_path) 

    else:
        raise ValueError(f"Unknown source type selected: {source_type}")

    # 2. Aggressively limit the DataFrame size IMMEDIATELY after loading
    df_limited = df_full.limit(MAX_ROWS_TO_PROCESS)

    # 3. Explicitly Cast Data Types for Accuracy and Memory Efficiency
    print("Correcting column data types...")
    
    numeric_cols = [
        "current", "voltage", "power_factor", "current_ib", "current_ir", "current_iy",
        "voltage_vbn", "voltage_vrn", "voltage_vyn", "power_factor_b_phase",
        "power_factor_r_phase", "power_factor_y_phase", "cumulative_energy_wh_import",
        "cumulative_energy_wh_export"
    ]
    timestamp_cols = ["receivedTime", "RTC"]
    
    df_typed = df_limited
    for col_name in numeric_cols:
        if col_name in df_typed.columns:
            df_typed = df_typed.withColumn(col_name, F.col(col_name).cast(DoubleType()))

    from pyspark.sql.functions import col, lit, to_timestamp, expr, when, array, to_date 
    from pyspark.sql.types import StringType, TimestampType

    TIMESTAMP_FORMATS = [
        "yyyy-MM-dd HH:mm:ss.SSS",
        "yyyy-MM-dd HH:mm:ss",
        "MM/dd/yyyy HH:mm:ss",
        "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", 
        "yyyy-MM-dd'T'HH:mm:ss",          
        "dd-MM-yyyy HH:mm:ss",              
        "dd/MM/yyyy HH:mm:ss",              
        "yyyy-MM-dd HH:mm:ss,SSS"         
    ]

    DATE_FORMATS = [
        "yyyy-MM-dd",
        "MM/dd/yyyy",
        "dd-MM-yyyy",
        "dd/MM/yyyy"
    ]

    for col_name in timestamp_cols:
        if col_name in df_typed.columns:
            print(f"  > Processing timestamp column: {col_name}")
            
            current_col_type = df_typed.schema[col_name].dataType
            if str(current_col_type) != "StringType":
                df_typed = df_typed.withColumn(col_name, F.col(col_name).cast(StringType()))

            parsed_col = F.lit(None).cast(TimestampType())

            for fmt in TIMESTAMP_FORMATS:
                parsed_col = F.when(
                    F.col(col_name).isNotNull(), 
                    F.coalesce(parsed_col, F.to_timestamp(F.col(col_name), fmt))
                ).otherwise(parsed_col) 

            for fmt in DATE_FORMATS:
                parsed_date_to_ts = F.to_timestamp(F.to_date(F.col(col_name), fmt))
                parsed_col = F.when(
                    F.col(col_name).isNotNull(), 
                    F.coalesce(parsed_col, parsed_date_to_ts)
                ).otherwise(parsed_col)


            df_typed = df_typed.withColumn(col_name, parsed_col)
            print(f"  > Applied robust timestamp parsing for column: {col_name}")

    # 4. Cache the final, small, correctly-typed DataFrame
    df = df_typed.cache()
    row_cnt = df.count() # Trigger cache and get count
    
    print(f"✅ Ingestion successful. Sampled and typed DataFrame 'df' with {row_cnt} rows is ready.")
    df.printSchema()

except Exception as e:
    print(f"❌ Data ingestion failed. Error: {e}")
    raise e

# COMMAND ----------

# MAGIC %pip install reportlab

# COMMAND ----------

# MAGIC %pip install -U threadpoolctl

# COMMAND ----------

# # Cell 3: Data Cleaning & Stateless Interactive Rule Editing Loop (Corrected and Verified)

# import pandas as pd
# from collections import defaultdict
# import json
# from typing import Any, List, Dict
# import logging
# import os
# import numpy as np # Import numpy for numerical comparisons
# import time # Import time for potential small delays

# # Imports for Spark data cleaning
# from pyspark.sql import functions as F
# from pyspark.sql.types import TimestampType

# # Assumes your custom IntelligentRuleSuggester class is available
# # Ensure this class is accessible in your Databricks environment
# from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester 

# # --- Configuration & Logger ---
# # DQ_PARAMS can be dynamically updated by user, so initialize it as a list first
# DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"] 

# # *** UPDATED PATHS FOR STORING RULES AND WEIGHTS ***
# # Define paths with /dbfs prefix for dbutils.fs.put
# RULES_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
# WEIGHTS_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# # Define the *internal* DBFS path without /dbfs prefix for dbutils.fs.head
# DBFS_RULES_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
# DBFS_WEIGHTS_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# logger = logging.getLogger('dq_pipeline.interactive')

# # ==============================================================================
# # 1. Data Cleaning
# # ==============================================================================
# print("--- Step 1: Cleaning timestamps to prevent conversion errors... ---")

# pd_min_ts = pd.Timestamp.min.to_pydatetime()
# pd_max_ts = pd.Timestamp.max.to_pydatetime()
# df_cleaned = df # Assuming 'df' is your Spark DataFrame from previous cell
# timestamp_cols = [field.name for field in df.schema.fields if isinstance(field.dataType, TimestampType)]

# if timestamp_cols:
#     print(f"Found timestamp columns to clean: {timestamp_cols}")
#     for col_name in timestamp_cols:
#         df_cleaned = df_cleaned.withColumn(col_name, F.when((F.col(col_name) >= pd_min_ts) & (F.col(col_name) <= pd_max_ts), F.col(col_name)).otherwise(F.lit(None)))
#     print("✅ Timestamp cleaning complete.")
# else:
#     print("No timestamp columns found to clean.")

# # ==============================================================================
# # 2. Generate Initial Rules
# # ==============================================================================
# print("\n--- Step 2: Generating a new, data-driven set of rules from the LLM... ---")
# # Sample data for LLM if df_cleaned is too large
# # For petabyte scale, this sampling must be distributed and managed by Ray/Spark as per Stage 1 and 2 
# # Here, for demonstration, we'll convert to Pandas, but in a real scenario, you'd apply the multi-stage sampling
# # strategy here to get a 'pdf_for_profiling' that is small and diverse.
# # For now, assuming df_cleaned is small enough for toPandas for prototype
# try:
#     pdf_for_profiling = df_cleaned.toPandas()
# except Exception as e:
#     print(f"Warning: Could not convert Spark DataFrame to Pandas for profiling directly. Error: {e}")
#     print("Using a small sample for LLM profiling.")
#     # Implement a small, direct sample for local profiling if the full conversion fails
#     pdf_for_profiling = df_cleaned.limit(1000).toPandas() # Limit to a small number of rows

# suggester = IntelligentRuleSuggester()
# result = suggester.suggest_rules(pdf_for_profiling) # This should generate initial rules based on the sampled data
# rules: List[Dict[str, Any]] = result.get("rules", []) # Ensure 'rules' is typed correctly

# # Initialize weights based on initial DQ_PARAMS, distributing equally
# # This 'weights' dictionary will be directly modified by the user
# weights = {p: 100.0 / len(DQ_PARAMS) for p in DQ_PARAMS}

# if not rules:
#     print("LLM failed to generate any rules. Attempting to generate default rules for demonstration.")
#     # Fallback to some default rules if LLM fails
#     rules = [
#         {"type": "completeness", "description": "Ensure 'id' column is not null.", "column": "id", "condition": "isNotNull"},
#         {"type": "uniqueness", "description": "Ensure 'id' column is unique.", "column": "id", "condition": "isUnique"},
#         {"type": "accuracy", "description": "Ensure 'email' column has valid format.", "column": "email", "condition": "isValidEmail"},
#         {"type": "consistency", "description": "Ensure 'order_date' is in YYYY-MM-DD format.", "column": "order_date", "condition": "isDateFormat"},
#     ]


# # ==============================================================================
# # 3. Interactive Editing Loop
# # ==============================================================================
# while True:
#     # Organize rules by parameter type for display
#     param_rules = defaultdict(list)
#     for r in rules:
#         param_rules[r.get("type", "other")].append(r)
    
#     # Display current configuration
#     print("\n" + "="*80)
#     print("--- CURRENT DATA QUALITY CONFIGURATION ---")
#     print("\n--- PARAMETER WEIGHTS ---")
#     current_total_weight_display = sum(weights.values())
#     if current_total_weight_display == 0:
#         print("Warning: Total weight is 0. Please adjust weights.")
#         for param in DQ_PARAMS:
#             print(f"PARAMETER: {param.upper()} (Current Weight: {weights.get(param, 0):.1f}%)")
#     else:
#         for param in DQ_PARAMS:
#             display_weight = (weights.get(param, 0) / current_total_weight_display) * 100
#             print(f"PARAMETER: {param.upper()} (Current Weight: {display_weight:.1f}%)")

#     print("\n--- RULES BY PARAMETER ---")
#     # Ensure DQ_PARAMS is iterated to maintain order and show all active parameters
#     for param in DQ_PARAMS: 
#         print(f"\nPARAMETER: {param.upper()}")
#         if rules_list := [r for r in rules if r.get("type") == param]:
#             for i, rule in enumerate(rules_list):
#                 print(f"  {i+1}. {rule.get('description', 'No description')}")
#         else:
#             print("  No rules defined for this parameter.")
#     print("="*80)

#     action = input("\nChoose action: [e]dit configuration, [p]arameters, or [q]uit and save: ").strip().lower()

#     if action == 'q':
#         print("Final configuration set. Saving rules and weights...")
#         break
#     elif action == 'e':
#         # Edit rules or weights for existing parameters
#         param_to_edit = input(f"Which parameter's rules to edit? {DQ_PARAMS}: ").strip().lower()
#         if param_to_edit not in DQ_PARAMS:
#             print("Invalid parameter.")
#             continue
        
#         edit_choice = input(f"Editing '{param_to_edit}'. [w]eight, [a]dd rule, [r]emove rule: ").strip().lower()
        
#         if edit_choice == 'w':
#             try:
#                 current_param_weight = weights.get(param_to_edit, 0.0) # Get current value
#                 new_weight = float(input(f"Enter new weight for '{param_to_edit}' (current: {current_param_weight:.1f}): "))
#                 if new_weight < 0:
#                     print("Weight cannot be negative. Setting to 0.")
#                     weights[param_to_edit] = 0.0
#                 else:
#                     weights[param_to_edit] = new_weight
#                 print(f"Updated weight for '{param_to_edit}'.")
#             except ValueError:
#                 print("Invalid weight. Please enter a number.")
#         elif edit_choice == 'a':
#             print(f"Adding a new rule for '{param_to_edit}'.")
#             rule_desc = input("Enter rule description: ")
#             rule_col = input("Enter column name for the rule (optional): ")
#             rule_condition = input("Enter rule condition (e.g., 'isNotNull', 'isValidEmail') (optional): ")
            
#             new_rule = {"type": param_to_edit, "description": rule_desc}
#             if rule_col:
#                 new_rule["column"] = rule_col
#             if rule_condition:
#                 new_rule["condition"] = rule_condition
#             rules.append(new_rule)
#             print("Rule added.")
#         elif edit_choice == 'r':
#             rules_for_param = [r for r in rules if r.get("type") == param_to_edit]
#             if not rules_for_param:
#                 print(f"No rules to remove for '{param_to_edit}'.")
#                 continue
#             print(f"Rules for '{param_to_edit}':")
#             for i, rule in enumerate(rules_for_param):
#                 print(f"  {i+1}. {rule.get('description', 'No description')}")
            
#             try:
#                 idx_to_remove = int(input("Enter the number of the rule to remove: ")) - 1
#                 if 0 <= idx_to_remove < len(rules_for_param):
#                     # Find the actual rule object in the 'rules' list and remove it
#                     removed_rule = rules_for_param[idx_to_remove]
#                     rules.remove(removed_rule)
#                     print("Rule removed.")
#                 else:
#                     print("Invalid rule number.")
#             except ValueError:
#                 print("Invalid input. Please enter a number.")
#         else:
#             print("Invalid edit choice.")
#     elif action == 'p':
#         # Add or remove parameters
#         param_action = input("[a]dd parameter, [r]emove parameter: ").strip().lower()
#         if param_action == 'a':
#             new_param = input("Enter new parameter name: ").strip().lower()
#             if new_param in DQ_PARAMS:
#                 print(f"Parameter '{new_param}' already exists.")
#             else:
#                 DQ_PARAMS.append(new_param) # Add to the list of active parameters
#                 # Distribute weights equally among all current parameters
#                 # Use current length of DQ_PARAMS including the new one
#                 equal_weight_val = 100.0 / len(DQ_PARAMS)
#                 for p in DQ_PARAMS: # Iterate through the updated DQ_PARAMS
#                     weights[p] = equal_weight_val
#                 print(f"Parameter '{new_param}' added. Weights redistributed equally among all parameters.")
#                 # LLM suggests rules for new parameter (if needed) - placeholder
#                 print(f"LLM will now suggest rules for the new parameter '{new_param}'.")
#                 # In a real scenario, you'd re-profile or use LLM with specific context for new param
#                 # Note: `specific_param` is an assumed argument for `suggest_rules`
#                 new_param_rules_result = suggester.suggest_rules(pdf_for_profiling, specific_param=new_param) 
#                 rules.extend(new_param_rules_result.get("rules", []))
#                 print(f"Suggested rules for '{new_param}' added.")

#         elif param_action == 'r':
#             param_to_remove = input(f"Enter parameter to remove {DQ_PARAMS}: ").strip().lower()
#             if param_to_remove not in DQ_PARAMS:
#                 print("Invalid parameter name.")
#             elif len(DQ_PARAMS) == 1:
#                 print("Cannot remove the last parameter.")
#             else:
#                 DQ_PARAMS.remove(param_to_remove) # Remove from active parameters
#                 if param_to_remove in weights:
#                     del weights[param_to_remove] # Remove its weight
                
#                 # Redistribute weights equally among remaining parameters
#                 if DQ_PARAMS: # Check if any parameters are left
#                     equal_weight_val = 100.0 / len(DQ_PARAMS)
#                     for p in DQ_PARAMS:
#                         weights[p] = equal_weight_val
#                     print(f"Parameter '{param_to_remove}' removed. Weights redistributed equally among remaining parameters.")
#                 else:
#                     print(f"Parameter '{param_to_remove}' removed. No parameters remaining.")
                
#                 # Also remove any rules associated with the removed parameter
#                 rules = [r for r in rules if r.get("type") != param_to_remove]
#                 print("Associated rules removed.")
#         else:
#             print("Invalid parameter action.")
#     else:
#         print("Invalid action.")

# # ==============================================================================
# # 4. Finalization and Verification (Definitive Fix)
# # ==============================================================================
# # The 'weights' dictionary now holds the final raw values from the loop
# print(f"\nDEBUG: Final raw weights from interactive session: {weights}")
# total_weight = sum(weights.values())

# # This dictionary will hold the final weights as normalized values (summing to 1.0)
# final_weights_to_save = {}
# if total_weight > 0:
#     final_weights_to_save = {p: (w / total_weight) for p, w in weights.items()}
# else:
#     # If total_weight is 0, default to equal distribution among *current* DQ_PARAMS
#     if DQ_PARAMS:
#         final_weights_to_save = {p: 1.0 / len(DQ_PARAMS) for p in DQ_PARAMS}
#     else:
#         final_weights_to_save = {} # No parameters, no weights

# print("\n--- FINAL CONFIGURATION SAVED ---")
# # Display the variable that is about to be saved in a human-readable format
# print(f"Final Weights (as percentages): { {k: f'{v*100:.1f}%' for k, v in final_weights_to_save.items()} }")
# print(f"Total Rules: {len(rules)}")

# # Save the final, correct configuration to DBFS
# try:
#     # Ensure the directory exists before writing
#     dbutils.fs.mkdirs("/FileStore/dq_configs/")
#     dbutils.fs.put(RULES_PATH, json.dumps(rules, indent=2), overwrite=True)
#     dbutils.fs.put(WEIGHTS_PATH, json.dumps(final_weights_to_save, indent=2), overwrite=True)
#     print(f"✅ Final rules and weights saved to {RULES_PATH} and {WEIGHTS_PATH}.")
# except Exception as e:
#     print(f"❌ Error saving files to DBFS: {e}")

# # --- Verification Step ---
# print("\n--- VERIFICATION ---")
# try:
#     # Read the content back and verify
#     # Use the internal DBFS path for dbutils.fs.head
#     saved_weights_str = dbutils.fs.head(DBFS_WEIGHTS_PATH_INTERNAL) 
#     saved_data = json.loads(saved_weights_str)
#     print(f"Content of saved weights file ({WEIGHTS_PATH}):\n{saved_weights_str}")
    
#     # Perform a robust numerical check
#     # Check if all keys match and values are numerically close
#     keys_match = set(saved_data.keys()) == set(final_weights_to_save.keys())
#     values_match = True
#     if keys_match:
#         for k, v in final_weights_to_save.items():
#             # Use a small tolerance for floating-point comparison
#             if not np.isclose(saved_data.get(k, 0), v, atol=1e-9): 
#                 values_match = False
#                 break
    
#     if keys_match and values_match:
#         print("✅ Verification successful. The file contents now correctly match the configuration.")
#     else:
#         print("❌ VERIFICATION FAILED: The content saved to the file still does NOT match the configuration.")
#         print(f"Expected: {final_weights_to_save}")
#         print(f"Actual: {saved_data}")
        
# except Exception as e:
#     print(f"❌ Verification failed. Could not read back the saved file or parse its content. Error: {e}")

# print("\nYou may now proceed to the final assessment cell (Cell 4).")
# Cell 3: Data Cleaning & Non-Interactive Rule Setup for Job Execution

import pandas as pd
from collections import defaultdict
import json
from typing import Any, List, Dict
import logging
import os
import numpy as np 
# Removed time import as it's no longer strictly needed here after removing interactive loop

# Imports for Spark data cleaning
from pyspark.sql import functions as F
from pyspark.sql.types import TimestampType

# Assumes your custom IntelligentRuleSuggester class is available
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester 

# --- Configuration & Logger ---
# DQ_PARAMS can be dynamically updated by user, so initialize it as a list first
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"] 

# *** UPDATED PATHS FOR STORING RULES AND WEIGHTS ***
# These paths are where the *interactive* run of the notebook (if you ever do one)
# would save the final rules and weights.
RULES_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
WEIGHTS_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# Define the *internal* DBFS path without /dbfs prefix for dbutils.fs.head
DBFS_RULES_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
DBFS_WEIGHTS_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

logger = logging.getLogger('dq_pipeline.interactive')

# ==============================================================================
# 1. Data Cleaning
# ==============================================================================
print("--- Step 1: Cleaning timestamps to prevent conversion errors... ---")

pd_min_ts = pd.Timestamp.min.to_pydatetime()
pd_max_ts = pd.Timestamp.max.to_pydatetime()
df_cleaned = df # Assuming 'df' is your Spark DataFrame from previous cell
timestamp_cols = [field.name for field in df.schema.fields if isinstance(field.dataType, TimestampType)]

if timestamp_cols:
    print(f"Found timestamp columns to clean: {timestamp_cols}")
    for col_name in timestamp_cols:
        df_cleaned = df_cleaned.withColumn(col_name, F.when((F.col(col_name) >= pd_min_ts) & (F.col(col_name) <= pd_max_ts), F.col(col_name)).otherwise(F.lit(None)))
    print("✅ Timestamp cleaning complete.")
else:
    print("No timestamp columns found to clean.")

# ==============================================================================
# 2. Rule Setup (Non-Interactive for Job Execution)
# ==============================================================================
# When running as a job, we don't interact. We either load previously saved rules
# or generate a default set.

print("\n--- Step 2: Setting up rules and weights (Non-Interactive for Job). ---")

rules: List[Dict[str, Any]] = []
weights: Dict[str, float] = {}

# Option A: Try to load previously saved rules and weights (RECOMMENDED for jobs)
try:
    print(f"Attempting to load rules from {DBFS_RULES_PATH_INTERNAL} and weights from {DBFS_WEIGHTS_PATH_INTERNAL}...")
    rules_str_loaded = dbutils.fs.head(DBFS_RULES_PATH_INTERNAL)
    weights_str_loaded = dbutils.fs.head(DBFS_WEIGHTS_PATH_INTERNAL)
    rules = json.loads(rules_str_loaded)
    weights = json.loads(weights_str_loaded)
    print("✅ Successfully loaded previously saved rules and weights.")
    # Dynamically update DQ_PARAMS based on loaded weights
    global DQ_PARAMS # Declare as global if DQ_PARAMS is modified in other cells
    DQ_PARAMS = list(weights.keys()) 

except Exception as e:
    print(f"⚠️ Could not load saved rules/weights ({e}). Generating initial rules from LLM as fallback.")
    # Option B: Generate initial rules and default weights (FALLBACK if no saved config)
    pdf_for_profiling = None
    try:
        pdf_for_profiling = df_cleaned.toPandas()
    except Exception as e_pandas:
        print(f"Warning: Could not convert Spark DataFrame to Pandas for profiling directly ({e_pandas}). Using a small sample.")
        pdf_for_profiling = df_cleaned.limit(1000).toPandas()

    suggester = IntelligentRuleSuggester()
    result = suggester.suggest_rules(pdf_for_profiling)
    rules = result.get("rules", [])

    if not rules:
        print("LLM failed to generate any rules. Attempting to generate hardcoded default rules.")
        rules = [
            {"type": "completeness", "description": "Ensure 'id' column is not null.", "column": ["id"], "condition": "isNotNull"},
            {"type": "uniqueness", "description": "Ensure 'id' column is unique.", "column": ["id"], "condition": "isUnique"},
            {"type": "accuracy", "description": "Ensure 'email' column has valid format.", "column": ["email"], "condition": "isValidEmail"},
            {"type": "consistency", "description": "Ensure 'order_date' is in YYYY-MM-DD format.", "column": ["order_date"], "condition": "isDateFormat"},
            {"type": "accuracy", "description": "Verify the range of 'event_code' values", "column": ["event_code"]},
            {"type": "completeness", "description": "Cumulative Energy (Wh) Export should not be null", "column": ["cumulative_energy_wh_export"]},
            {"type": "consistency", "description": "Ensure receivedTime and RTC are consistent", "column": ["receivedTime", "RTC"]},
            {"type": "uniqueness", "description": "Ensure uniqueness of Event_ID", "column": ["Event_ID"]},
        ]
        # Ensure 'column' is a list as required by execute_and_gather_evidence
        for r_def in rules:
            if 'column' in r_def and not isinstance(r_def['column'], list):
                r_def['column'] = [r_def['column']]
            elif 'column' not in r_def and 'columns' not in r_def:
                r_def['columns'] = [] # Ensure 'columns' exists as a list

    # Initialize weights for all active DQ_PARAMS
    current_dq_params = list(set([r.get("type") for r in rules if r.get("type")])) # Get actual dimensions from rules
    if not current_dq_params:
        current_dq_params = ["accuracy", "completeness", "consistency", "uniqueness"] # Fallback if no rules found
    weights = {p: (1.0 / len(current_dq_params)) for p in current_dq_params} # Normalize to 1.0

    print("✅ Rules and weights initialized (either loaded or default generated).")

# No interactive loop here for job execution.
# The rules and weights are now prepared for Cell 4.

# COMMAND ----------

# Cell 4: LLM-Powered Score Generation and Reporting (Final Version - LLM Directly Scores with RAG, Job Output)

import json
import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from typing import List, Dict, Any, Optional
import re # Import regex for robust JSON extraction

# --- LLM and Pydantic Imports ---
from langchain_groq.chat_models import ChatGroq
from langchain.schema import SystemMessage, HumanMessage
from pydantic import BaseModel, Field, ValidationError
import logging
import time
import numpy as np

# ==============================================================================
# 0. Configuration & Logger
# ==============================================================================
logger = logging.getLogger('dq_pipeline.llm_scoring')
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Configuration ---
GROQ_API_KEY = "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" # Ensure this is securely managed in production
TOP_K_SAMPLES = 50

# --- RAG Specific Configuration (Conceptual for Weaviate) ---
# These variables would be actual connection details to your deployed Weaviate instance
WEAVIATE_URL = "http://localhost:8080" # Replace with your Weaviate instance URL (e.g., from Zilliz Cloud, self-hosted)
WEAVIATE_API_KEY = "YOUR_WEAVIATE_API_KEY" # Replace with your Weaviate API Key
WEAVIATE_COLLECTION_NAME = "DataQualityInsights" # Or your specific collection name

# ==============================================================================
# 1. Setup and Load Inputs
# ==============================================================================
print("--- Step 1: Loading rules, weights, and the cleaned DataFrame... ---")

# --- IMPORTANT: These paths MUST match what was defined and saved in Cell 3 ---
RULES_PATH_ABS = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
WEIGHTS_PATH_ABS = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

RULES_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
WEIGHTS_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

try:
    rules_str = dbutils.fs.head(RULES_PATH_INTERNAL)
    weights_str = dbutils.fs.head(WEIGHTS_PATH_INTERNAL)
    rules = json.loads(rules_str)
    weights = json.loads(weights_str) # Weights are now normalized (sum to 1.0)
    
    # Dynamically set DQ_PARAMS based on the keys in the loaded weights
    DQ_PARAMS = list(weights.keys())
    
    total_records = df_cleaned.count() # Assuming df_cleaned is available from previous cells
    if total_records == 0:
        raise ValueError("Input DataFrame is empty. Cannot perform scoring.")

    print(f"✅ Loaded {len(rules)} rules and {len(weights)} weights directly from the configuration saved by Cell 3.")
    print(f"Active DQ Parameters: {DQ_PARAMS}")
    print(f"Total records to assess: {total_records}")

except Exception as e:
    print(f"❌ Error loading input files or DataFrame: {e}")
    # In a Databricks Job, dbutils.notebook.exit is preferred for failure
    dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Failed to load necessary inputs: {str(e)}"}))


# ==============================================================================
# 2. LLM Interaction Layer (with JSON Repair and Weaviate RAG Concept)
# ==============================================================================
print("\n--- Step 2: Initializing LLM Interaction Layer with JSON Repair and Conceptual Weaviate RAG... ---")

class LLMRuleScoreResponse(BaseModel):
    rule_score: float = Field(..., description="A score for the rule from 0.0 to 10.0 based on the failure rate.")
    reasoning: str = Field(..., description="Detailed reasoning for the score, explaining the impact of the failing records.")

class LLMDimensionObservationResponse(BaseModel):
    dimension_score: float = Field(..., description="A score for the dimension from 0.0 to 10.0, based on the overall rule outcomes for this dimension.")
    observation: str = Field(..., description="A qualitative observation explaining the provided dimension score, referencing the rule outcomes.")


class LLMOverallReportResponse(BaseModel):
    report: str = Field(..., description="A comprehensive report explaining the final, overall data quality score. This must be a single flat string.")

class LLMScoringAndObservation:
    """Handles all communication with the LLM, now with a JSON repair mechanism and conceptual Weaviate RAG."""
    def __init__(self, api_key: str, model="llama3-8b-8192"):
        if not api_key: raise ValueError("Groq API key is required.")
        self.llm = ChatGroq(model=model, temperature=0.1, api_key=api_key)
        self.repair_llm = ChatGroq(model="llama3-8b-8192", temperature=0.2, api_key=api_key)
        
        # --- Weaviate Client Initialization (Conceptual) ---
        # In a real application, you would initialize your Weaviate client here:
        # try:
        #     import weaviate
        #     self.weaviate_client = weaviate.Client(
        #         url=WEAVIATE_URL,
        #         auth_client_secret=weaviate.AuthApiKey(api_key=WEAVIATE_API_KEY)
        #     )
        #     if self.weaviate_client.is_live():
        #         print("Weaviate client connected successfully.")
        #     else:
        #         print("Weaviate client failed to connect.")
        # except Exception as e:
        #     print(f"Warning: Weaviate client initialization failed: {e}")
        #     self.weaviate_client = None

    def _repair_json(self, broken_json: str) -> Optional[str]:
        try:
            prompt = f"The following is a broken JSON object. Please fix all syntax and schema errors and return only the corrected, valid JSON object. Do not add any text or explanation before or after the JSON.\n\nBROKEN JSON:\n{broken_json}"
            repair_messages = [HumanMessage(content=prompt)]
            response = self.repair_llm.invoke(repair_messages)
            repaired_text = response.content.strip()
            json_match = re.search(r"\{.*\}", repaired_text, re.DOTALL)
            if json_match:
                return json_match.group(0)
            return None
        except Exception as e:
            logger.error(f"JSON repair call failed: {e}")
            return None

    def _invoke_llm(self, messages: List, response_model: BaseModel) -> Optional[Dict[str, Any]]:
        for attempt in range(3): 
            raw_text = None
            try:
                response = self.llm.invoke(messages)
                raw_text = response.content.strip()
                
                json_match = re.search(r"\{.*\}", raw_text, re.DOTALL)
                if json_match:
                    json_str = json_match.group(0)
                    return response_model(**json.loads(json_str)).model_dump()
                else:
                    raise ValueError("No JSON object found in response.")
            except (json.JSONDecodeError, ValidationError, ValueError) as e:
                logger.warning(f"LLM response failed validation on attempt {attempt+1}. Error: {e}. Attempting to repair.")
                if raw_text: 
                    repaired_json_str = self._repair_json(raw_text)
                    if repaired_json_str:
                        try:
                            return response_model(**json.loads(repaired_json_str)).model_dump()
                        except (json.JSONDecodeError, ValidationError) as final_e:
                            logger.error(f"Parsing failed even after repair on attempt {attempt+1}. Final error: {final_e}")
                            continue 
                else: 
                    logger.error(f"LLM returned no content on attempt {attempt+1}.")
        return None 

    def _retrieve_rag_context(self, query_text: str, k: int = 2) -> str:
        """
        Conceptual function to simulate RAG retrieval from Weaviate using Ray-generated embeddings.
        In a real scenario, this would query a Weaviate instance like this:
        
        # if self.weaviate_client:
        #     try:
        #         response = self.weaviate_client.query.get(
        #             class_name=WEAVIATE_COLLECTION_NAME,
        #             properties=["text_content", "title", "doc_type"] # Retrieve relevant fields
        #         ).with_near_text({
        #             "concepts": [query_text]
        #         }).with_limit(k).do()
        #         docs = [item["text_content"] for item in response["data"]["Get"][WEAVIATE_COLLECTION_NAME]]
        #         if docs:
        #             return "\n".join([f"RETRIEVED: {doc}" for doc in docs])
        #     except Exception as e:
        #         logger.warning(f"Weaviate conceptual retrieval failed: {e}. Returning simulated docs.")
        #         # Fallback to simulated docs if real retrieval fails
        """
        retrieved_docs = []
        # Simulate retrieval based on keywords, conceptualizing hybrid search
        if "datetime" in query_text.lower() or "timestamp" in query_text.lower():
            retrieved_docs.append(
                "RAG Context (Weaviate - Keyword Match): SOP-DT-001: All datetime fields (e.g., 'receivedTime', 'RTC') must adhere to ISO 8601, populated by Ray-processed sensor logs. Non-compliant formats are flagged as critical errors. Historical issue #DT-789: inconsistent timestamps from IoT devices led to skewed time-series analysis."
            )
        if "null" in query_text.lower() or "completeness" in query_text.lower() or "missing" in query_text.lower():
            retrieved_docs.append(
                "RAG Context (Weaviate - Keyword Match): Policy-COMP-002: 'Cumulative_Energy_wh_Export' is a primary metric. Missing values (nulls) require immediate investigation, often indicating data loss during FiveTran ingestion. Past incident #COMP-456: 100% nulls in test dataset caused system failure."
            )
        if "uniqueness" in query_text.lower() or "id" in query_text.lower() or "duplicate" in query_text.lower():
            retrieved_docs.append(
                "RAG Context (Weaviate - Hybrid Search Concept): Data Model v3.1: 'Event_ID' and 'Generic_Event_Log_Sequence_Number' are unique identifiers. Ray-generated embeddings of historical anomaly reports indicate that duplicate IDs often stem from Kafka re-processing or database sync issues. Resolution for #UNIQ-112 involved a Delta Lake MERGE operation."
            )
        if "consistency" in query_text.lower() or "event_code" in query_text.lower():
            retrieved_docs.append(
                "RAG Context (Weaviate - Semantic Search Concept): Business Glossary Term: 'Event_Code' defines the type of event, directly linked to 'Event_ID'. An 'Event_ID' should consistently map to only one 'Event_Code'. Discrepancies may indicate faulty Cassandra DB replication or incorrect data transformations by Databricks connectors. See DQ Report 2024-Q1 for similar issues."
            )
        if "report generation" in query_text.lower():
            retrieved_docs.append(
                "RAG Context (Weaviate - General DQ Docs): Best Practices for DQ Reporting: Reports should be comprehensive, actionable, and based on validated DQ rules. Leverage historical DQ reports for trending. Performance optimization for PDF generation involves PySpark and optimized libraries."
            )

        if not retrieved_docs:
            retrieved_docs.append("RAG Context (Weaviate - General): No specific past insights or documentation found for this query, but embeddings were generated via Ray.")

        return "\n".join(retrieved_docs[:k])

    def get_rule_assessment(self, rule_context: str) -> Optional[Dict[str, Any]]:
        rag_context = self._retrieve_rag_context(rule_context)
        
        system_prompt = (
            "You are a highly analytical data quality analyst. "
            "Based on the provided raw evidence (total records, failing records, and actual data samples), "
            "and the following relevant contextual information retrieved from Weaviate (embeddings generated by Ray), " 
            "you MUST directly provide a data quality score for the rule from 0.0 to 10.0. "
            "Here's the scoring guide:\n"
            "- **10.0 (Perfect):** No affected records, or negligible impact (<0.1% affected).\n"
            "- **8.0-9.9 (High Quality):** Very few affected records (0.1% to <1%), minor impact, easy to fix.\n"
            "- **5.0-7.9 (Moderate Quality):** Some affected records (1% to <10%), moderate impact, requires attention.\n"
            "- **1.0-4.9 (Low Quality):** Significant affected records (10% to <50%), high impact, critical issues.\n"
            "- **0.0 (Unusable):** Over 50% affected records, or fundamental flaws making the data entirely unusable for this rule.\n"
            "Carefully analyze the proportion of affected records and the nature of the samples. "
            "Integrate insights from the retrieved Weaviate context if it provides additional understanding of severity, history, or business impact. " 
            "Then, provide a concise reasoning for the score. "
            "Respond with a single JSON object with keys 'rule_score' and 'reasoning'."
        )
        messages = [
            SystemMessage(content=system_prompt), 
            HumanMessage(content=f"--- Rule Evidence ---\n{rule_context}\n\n--- Retrieved Contextual Information from Weaviate ---\n{rag_context}")
        ]
        return self._invoke_llm(messages, LLMRuleScoreResponse)

    def get_dimension_assessment(self, dimension_context: str) -> Optional[Dict[str, Any]]:
        rag_context = self._retrieve_rag_context(dimension_context) 
        
        system_prompt = (
            "You are a highly analytical and holistic data quality expert. "
            "You are given the total number of records in the dataset, and for each rule within a specific data quality dimension, you have its status (Pass/Fail/Error), the number of affected records, and an LLM-generated score with reasoning. "
            "Additionally, you have the following relevant contextual information retrieved from Weaviate (embeddings generated by Ray). " 
            "Your task is to synthesize ALL this information for the dimension to provide a comprehensive overall score (0.0 to 10.0). "
            "Here's the scoring guide for dimensions:\n"
            "- **10.0 (Perfect):** All rules passed, or minor issues with negligible overall impact (<0.1% affected across critical rules).\n"
            "- **8.0-9.9 (High Quality):** Mostly passing rules, very few failures with minor aggregate impact (0.1% to <1% affected across critical rules).\n"
            "- **5.0-7.9 (Moderate Quality):** Mix of passing and failing rules, some moderate aggregate issues (1% to <10% affected across critical rules).\n"
            "- **1.0-4.9 (Low Quality):** Several significant failing rules (10% to <50% affected across critical rule), indicating major problems.\n"
            "- **0.0 (Unusable):** Pervasive failures across critical rules (>50% affected across critical rule), rendering the dimension's data fundamentally unreliable or unusable.\n"
            "Critically weigh the individual rule scores, the proportion of affected records for each rule, and the detailed reasoning provided by the LLM for each rule. "
            "Leverage the retrieved Weaviate context to better understand the severity, history, or business impact of these issues. " 
            "Derive a single, balanced score for the entire dimension that reflects the overall data quality. "
            "Also, provide a concise qualitative observation explaining *why* the dimension received that score, referencing the rule outcomes and their impact. "
            "Your response MUST be a single JSON object with two keys: 'dimension_score' and 'observation'."
        )
        messages = [
            SystemMessage(content=system_prompt), 
            HumanMessage(content=f"--- Dimension Evidence ---\n{dimension_context}\n\n--- Retrieved Contextual Information from Weaviate ---\n{rag_context}")
        ]
        return self._invoke_llm(messages, LLMDimensionObservationResponse)
        
    def get_overall_report(self, final_context: str) -> Optional[Dict[str, Any]]:
        rag_context = self._retrieve_rag_context("overall data quality report generation")
        
        system_prompt = (
            "You are a senior data quality director. Given the final calculated overall data quality score, and a summary of all dimensions including their LLM-generated scores, weights, and observations, "
            "along with general data quality knowledge from our Weaviate knowledge base (embeddings generated by Ray), " 
            "write a comprehensive, executive-level report explaining the overall data quality status of the dataset. "
            "The report should provide actionable insights and a clear summary of strengths and weaknesses across dimensions. "
            "The value for the 'report' key must be a single flat string, formatted professionally (e.g., using markdown if suitable for display, but ensure it's a single string). "
            "Your response MUST be a single JSON object with one key: 'report'."
        )
        messages = [
            SystemMessage(content=system_prompt), 
            HumanMessage(content=f"--- Overall Report Context ---\n{final_context}\n\n--- Retrieved General DQ Information from Weaviate ---\n{rag_context}")
        ]
        return self._invoke_llm(messages, LLMOverallReportResponse)

llm_service = LLMScoringAndObservation(api_key=GROQ_API_KEY)


# ==============================================================================
# 3. Enhanced Rule Execution and Evidence Gathering (Improved Interpreter)
# ==============================================================================
print("\n--- Step 3: Executing Rules and Gathering Evidence for LLM... ---")

def execute_and_gather_evidence(rule: dict, df: "SparkSession.DataFrame", total_records: int) -> dict:
    description = rule.get("description", "").lower()
    columns = rule.get("columns", []) 
    if isinstance(rule.get("column"), str) and not columns:
        columns = [rule["column"]]

    result = {
        "Rule Description": rule.get("description", "N/A"), 
        "Column": ", ".join(columns) if columns else "N/A", 
        "Dimension": rule.get("type", "Other").capitalize(), 
        "Status": "Error", 
        "Details": "Rule could not be processed.",
        "Affected Records": "N/A", 
        "llm_context": "" 
    }
    
    if not columns: 
        result["Details"] = "Rule requires a target column(s) but none specified."
        return result
    
    col_name = columns[0] 
    
    df_with_id = df.withColumn("dq_internal_id", F.monotonically_increasing_id())
    try:
        failing_records_df = None
        
        if "unique" in description:
            if len(columns) > 1:
                group_cols = [F.col(c) for c in columns]
                duplicate_values_df = df.groupBy(*group_cols).count().filter(F.col("count") > 1)
                if duplicate_values_df.count() > 0:
                    failing_records_df = df_with_id.join(duplicate_values_df, on=columns, how="inner")
                else:
                    failing_records_df = spark.createDataFrame([], df_with_id.schema)
            else: 
                duplicate_values_df = df.groupBy(F.col(col_name)).count().filter(F.col("count") > 1).select(col_name)
                if duplicate_values_df.count() > 0:
                    failing_records_df = df_with_id.join(duplicate_values_df, col_name, "inner")
                else:
                    failing_records_df = spark.createDataFrame([], df_with_id.schema)

        elif "null" in description or "empty" in description:
            failing_records_df = df_with_id.filter(F.col(col_name).isNull() | (F.col(col_name) == ""))

        elif "range" in description and "positive" in description:
            failing_records_df = df_with_id.filter(F.col(col_name) <= 0)
        elif "range" in description: 
            print(f"  > NOTE: No explicit range found for rule '{rule.get('description', '')}'. Applying a 3-sigma statistical heuristic.")
            stats = df_with_id.select(F.mean(col_name).alias("mean"), F.stddev(col_name).alias("stddev")).first()
            if stats and stats['mean'] is not None and stats['stddev'] is not None:
                mean, stddev = stats['mean'], stats['stddev']
                upper_bound = mean + 3 * stddev
                lower_bound = mean - 3 * stddev
                failing_records_df = df_with_id.filter((F.col(col_name) < lower_bound) | (F.col(col_name) > upper_bound))
            else:
                result["Details"] = f"Cannot apply range check: column '{col_name}' is not numeric or is empty."
                return result

        elif "email format" in description:
            email_regex = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
            failing_records_df = df_with_id.filter(~F.col(col_name).rlike(email_regex))
            
        elif "date format" in description and ("datetime" in description or "timestamp" in description):
            failing_records_df = df_with_id.filter(F.col(col_name).isNull())
            result["Details"] = "Identified records where datetime parsing failed in ingestion or are null."
            
        elif "allowed values" in description and "status" in description and "SHIPPED, PENDING, CANCELLED" in description:
            allowed_values = ["SHIPPED", "PENDING", "CANCELLED"]
            failing_records_df = df_with_id.filter(~F.col(col_name).isin(allowed_values))

        elif "zip code format" in description and "US zip code format" in description:
            zip_regex = r"^\d{5}(?:[-\s]\d{4})?$" 
            failing_records_df = df_with_id.filter(~F.col(col_name).rlike(zip_regex))
        
        elif "consistency" in description and ("receivedtime" in description or "rtc" in description): 
            if len(columns) >= 2:
                col1_name, col2_name = columns[0], columns[1]
                if col1_name in df_with_id.columns and col2_name in df_with_id.columns:
                    col1, col2 = F.col(col1_name), F.col(col2_name)
                    failing_records_df = df_with_id.filter(
                        (col2.isNotNull() & col1.isNotNull() & (col2 < col1)) |
                        (col2.isNull() != col1.isNull())
                    )
                    result["Details"] = f"Consistency check: '{col2_name}' is before '{col1_name}' or presence is inconsistent."
                else:
                    result["Details"] = f"Consistency rule requires columns '{col1_name}' and '{col2_name}' but one or both not found."
                    return result
            else:
                result["Details"] = "Consistency rule requires at least two columns."
                return result
        
        elif "consistency" in description and ("event_code" in description or "event_id" in description):
            if len(columns) >= 2:
                col1_name, col2_name = columns[0], columns[1] 
                if col1_name in df_with_id.columns and col2_name in df_with_id.columns:
                    col1, col2 = F.col(col1_name), F.col(col2_name) 
                    inconsistent_event_ids = df_with_id.groupBy(col2).agg(F.countDistinct(col1).alias("distinct_codes")) \
                                                .filter(F.col("distinct_codes") > 1).select(col2)
                    
                    failing_records_df = df_with_id.join(inconsistent_event_ids, on=col2.name, how="inner")
                    result["Details"] = f"Consistency check: '{col2_name}' maps to multiple distinct '{col1_name}' values."
                else:
                    result["Details"] = f"Consistency rule requires columns '{col1_name}' and '{col2_name}' but one or both not found."
                    return result
            else:
                result["Details"] = "Consistency rule requires at least two columns."
                return result

        else:
            result["Details"] = f"Rule interpreter could not understand or execute the rule: '{rule.get('description', '')}'"
            return result
            
        affected_count = failing_records_df.count()
        result["Affected Records"] = affected_count
        result["Status"] = "Fail" if affected_count > 0 else "Pass"

        failing_sample = failing_records_df.select(col_name).limit(TOP_K_SAMPLES).toPandas()
        
        passing_sample_df = df_with_id.join(failing_records_df.select("dq_internal_id"), on="dq_internal_id", how="left_anti") \
                                   .select(col_name).limit(TOP_K_SAMPLES)
        passing_sample = passing_sample_df.toPandas()
        
        result["llm_context"] = (
            f"Rule: '{rule['description']}' on column(s) '{', '.join(columns)}'.\n" 
            f"Total Records in Dataset: {total_records}, Records Affected by this rule: {affected_count}.\n"
            f"Failing Samples (first {TOP_K_SAMPLES} rows if any):\n{failing_sample.to_string(index=False)}\n"
            f"Passing Samples (first {TOP_K_SAMPLES} rows if any):\n{passing_sample.to_string(index=False)}\n"
            f"Rule Status from script: {result['Status']}" 
        )
    except Exception as e:
        result["Details"] = f"Error during Spark execution for rule '{rule.get('description', 'N/A')}': {str(e)}"
    return result

# ==============================================================================
# 4. Assessment and Reporting (LLM Directly Scores Rules and Dimensions)
# ==============================================================================
print("\n" + "="*80)
print("--- Step 4: Starting Data Quality Assessment (LLM Directly Scores Rules and Dimensions) ---")
print("="*80)

summary_stats = {"pass": 0, "fail": 0, "error": 0}
rule_results = []

# --- Part A: LLM Assess each rule based on raw evidence ---
for i, rule in enumerate(rules):
    print(f"\nAnalyzing Rule {i+1}/{len(rules)}: \"{rule.get('description', 'Unnamed Rule')}\"...")
    if 'column' in rule and not isinstance(rule['column'], list):
        rule['columns'] = [rule['column']] 
        del rule['column'] 
    elif 'column' not in rule and 'columns' not in rule:
        rule['columns'] = [] 

    evidence = execute_and_gather_evidence(rule, df_cleaned, total_records)
    summary_stats[evidence["Status"].lower()] += 1
    
    rule_result = {
        "Rule Description": evidence["Rule Description"], 
        "Column": evidence["Column"], 
        "Dimension": evidence["Dimension"], 
        "Status": evidence["Status"], 
        "Affected Records": evidence["Affected Records"],
        "Details": evidence["Details"] 
    }
    
    if evidence["Status"] != "Error":
        # Conceptual RAG retrieval for rule context
        rag_context = llm_service._retrieve_rag_context(evidence["Rule Description"]) # Use rule description as query
        llm_assessment = llm_service.get_rule_assessment(f"{evidence['llm_context']}\n\nRetrieved Context from Weaviate:\n{rag_context}") # Pass RAG context
        rule_result["llm_rule_score"] = llm_assessment["rule_score"] if llm_assessment else 0.0
        rule_result["Details"] = llm_assessment["reasoning"] if llm_assessment else "LLM failed to generate reasoning for rule."
        print(f"  > LLM Generated Rule Score: {rule_result['llm_rule_score']:.1f}/10")
    else:
        rule_result["llm_rule_score"] = 0.0
        print(f"  > LLM Rule Score: 0.0/10 (Rule interpreter or execution error)")
            
    rule_results.append(rule_result)

# --- Part B: LLM Assess each dimension based on LLM-generated rule scores ---
print("\n" + "="*80)
print("--- Requesting LLM to Score Dimensions and Generate Observations ---")
print("="*80)

dimension_analysis = []
for dim_name in DQ_PARAMS: 
    print(f"\nAnalyzing Dimension: {dim_name.capitalize()}...")
    
    rules_for_dimension = [res for res in rule_results if res["Dimension"].lower() == dim_name]
    
    rule_summaries_for_llm = []
    for res in rules_for_dimension:
        status_detail = f"Status: {res['Status']}"
        affected_count = res['Affected Records'] if isinstance(res['Affected Records'], (int, float)) else 0
        affected_percentage = (affected_count / total_records) * 100 if total_records > 0 else 0
        
        if res["Status"] != "Error":
            rule_summaries_for_llm.append(
                f"- Rule: '{res['Rule Description']}' on column(s) '{res['Column']}': {status_detail}\n"
                f"  Records Affected: {affected_count} out of {total_records} ({affected_percentage:.2f}%)\n"
                f"  LLM Generated Rule Score: {res['llm_rule_score']:.1f}/10\n"
                f"  LLM Reasoning: {res['Details']}" 
            )
        else:
            rule_summaries_for_llm.append(
                f"- Rule: '{res['Rule Description']}' on column(s) '{res['Column']}': {status_detail}\n"
                f"  Details: {res['Details']}" 
            )

    if not rule_summaries_for_llm:
        rule_summaries_for_llm.append("No rules were defined or successfully executed for this dimension.")

    # Conceptual RAG retrieval for dimension context
    rag_context = llm_service._retrieve_rag_context(f"Data quality assessment for dimension: {dim_name}") # Use dimension name as query

    dim_context_str = (
        f"For the '{dim_name.capitalize()}' data quality dimension, the total dataset size is {total_records} records. "
        f"Here are the detailed results of the individual rules for this dimension:\n"
        + "\n".join(rule_summaries_for_llm) + 
        f"\n\nBased on these detailed rule outcomes (including records affected, LLM-generated rule scores, and their reasoning), "
        f"and the following context retrieved from Weaviate:\n{rag_context}\n" # Include RAG context
        f"assign an overall score (from 0.0 to 10.0) for the '{dim_name.capitalize()}' dimension. Provide a concise observation explaining this score."
    )

    llm_dim_assessment = llm_service.get_dimension_assessment(dim_context_str) 
    
    llm_dimension_score = llm_dim_assessment['dimension_score'] if llm_dim_assessment else 0.0
    observation = llm_dim_assessment['observation'] if llm_dim_assessment else "LLM failed to generate an observation."
    
    print(f"  > LLM Generated Dimension Score: {llm_dimension_score:.1f}/10")
    print(f"  > LLM Observation: {observation}")
    
    dimension_analysis.append({
        "Dimension": dim_name.capitalize(), 
        "Weight (%)": f"{weights.get(dim_name, 0.0) * 100:.1f}", 
        "Score (/10)": f"{llm_dimension_score:.1f}", 
        "Observation": observation,
        "llm_raw_dimension_score": llm_dimension_score 
    })

# --- Part C: Generate Overall Report ---
print("\n" + "="*80)
print("--- Generating Final Overall Report ---")
print("="*80)

# Calculate final weighted score using the loaded normalized weights and LLM-generated dimension scores
overall_score = 0
for item in dimension_analysis:
    score = item['llm_raw_dimension_score'] 
    dim_name_lower = item['Dimension'].lower()
    weight_value = weights.get(dim_name_lower, 0.0) 
    
    overall_score += score * weight_value

final_context_list = [
    f"- {item['Dimension']} (Weight: {item['Weight (%)']}%), Final Score: {item['Score (/10)']}/10, Observation: {item['Observation']}" 
    for item in dimension_analysis
]
final_context_str = (
    f"The final weighted data quality score is {overall_score:.1f}/10, based on the following dimension scores and observations:\n" + 
    "\n".join(final_context_list) + 
    "\n\nPlease provide a comprehensive report explaining this overall score. The report value must be a single flat string."
)

overall_report = llm_service.get_overall_report(final_context_str)
report_text = overall_report['report'] if overall_report else "LLM failed to generate the final report."

# ==============================================================================
# 5. Prepare Final Report for Job Output
# ==============================================================================
# This section replaces the display logic with preparing a JSON object
# that will be returned via dbutils.notebook.exit()

final_report_for_output = {
    "overall_dq_score": float(f"{overall_score:.1f}"),
    "overall_observation": report_text,
    "summary_of_checks": {
        "total_rules_assessed": sum(summary_stats.values()),
        "rules_passed": summary_stats["pass"],
        "rules_failed": summary_stats["fail"],
        "rules_with_errors": summary_stats["error"]
    },
    # Convert dimension_analysis to a list of dicts, dropping internal keys
    "dimension_analysis": [
        {k: v for k, v in d.items() if k != 'llm_raw_dimension_score'}
        for d in dimension_analysis
    ],
    # Convert rule_results to a list of dicts
    "detailed_rule_results": rule_results,
    "timestamp": pd.Timestamp.now().isoformat() # ISO formatted timestamp
}

# --- FINAL STEP: Exit the notebook with the JSON output ---
# This is what the Next.js API route will retrieve from jobs/runs/get-output
dbutils.notebook.exit(json.dumps(final_report_for_output))

# COMMAND ----------

