# Databricks notebook source
# MAGIC %pip install -r requirements.txt
# MAGIC

# COMMAND ----------

# Notebook: DQ_Ingestion_Notebook
# Purpose: Ingest data from source, clean, apply sampling/filtering, and save to Delta table.

import os
import logging
import json
import gc
from typing import Any, List, Dict
from collections import defaultdict
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType,
    DoubleType, TimestampType, IntegerType
)

# --- Configuration for this Notebook ---
MAX_ROWS_TO_PROCESS = 50  # Max rows for LLM profiling later
# Define the Delta table where the cleaned data will be saved
# IMPORTANT: Replace 'hive_metastore.default' with your actual Unity Catalog catalog.schema
CLEANED_DATA_DELTA_TABLE_FQDN = "hive_metastore.default.dq_ingested_clean_sample"

# --- Spark and Logging Setup ---
spark = SparkSession.builder.appName("DQ_Ingestion_Job").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_ingestion_notebook')
print("✅ Spark Session and Logger initialized.")

# --- Widget Creation and Parameter Retrieval (from Next.js API) ---
try:
    dbutils.widgets.removeAll() 
    dbutils.widgets.text("param_source_type", "Azure Blob Storage (WASBS)", "1. Source Type") # Default for job testing
    dbutils.widgets.text("param_file_path", "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx", "2a. File Path (Local/Cloud)")
    dbutils.widgets.text("param_file_type", "excel", "2b. File Type (Local/Cloud)")
    dbutils.widgets.text("param_azure_storage_account_name", "fofstrprdeusdata", "3a. Azure Storage Account Name")
    dbutils.widgets.text("param_azure_container_name", "genai", "3b. Azure Container Name")
    dbutils.widgets.text("param_azure_blob_path", "New_Query_2025_05_09_12_33pm.csv", "3c. Azure Blob Path")
    dbutils.widgets.text("param_data_age_months", "0", "4. Data Age in Months (0 for all)") 

    print("✅ Databricks widgets defined for job parameters.")

    # Retrieve parameters into variables
    source_type_param = dbutils.widgets.get("param_source_type")
    file_path_param = dbutils.widgets.get("param_file_path")
    file_type_param = dbutils.widgets.get("param_file_type")
    azure_storage_account_name_param = dbutils.widgets.get("param_azure_storage_account_name")
    azure_container_name_param = dbutils.widgets.get("param_azure_container_name")
    azure_blob_path_param = dbutils.widgets.get("param_azure_blob_path")
    data_age_months_param = dbutils.widgets.get("param_data_age_months")

    print("✅ Parameters retrieved from widgets/job context.")

except Exception as e:
    print(f"⚠️ Could not create or retrieve Databricks widgets. Using hardcoded defaults. Error: {e}")
    source_type_param = "Azure Blob Storage (WASBS)" # Default for job execution
    file_path_param = "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx"
    file_type_param = "excel"
    azure_storage_account_name_param = "fofstrprdeusdata"
    azure_container_name_param = "genai"
    azure_blob_path_param = "New_Query_2025_05_09_12_33pm.csv"
    data_age_months_param = "0" # Default to 0 (no time filter)


# --- Data Ingestion and Type Casting (from original Cell 2) ---

# Use the parameters retrieved in Cell 1
source_type = source_type_param 
file_path_local_cloud = file_path_param 
file_type_local_cloud = file_type_param.lower() 
azure_storage_account_name = azure_storage_account_name_param 
azure_container_name = azure_container_name_param 
azure_blob_path = azure_blob_path_param 
data_age_months_str = data_age_months_param 

print(f"Attempting to ingest from: '{file_path_local_cloud}' (Source Type: {source_type})")
print(f"Azure Config: Account='{azure_storage_account_name}', Container='{azure_container_name}', Blob Path='{azure_blob_path}'")
print(f"Requested data age for filtering: {data_age_months_str} months behind today.")

# --- Azure Credentials Configuration (Using Account Key) ---
AZURE_STORAGE_ACCOUNT_KEY = "uFMlAoFfhS8ljTMXrIxFa76QXotavNGoy89xfkYgck5ob7M5NHkpJUpFGjiFzEDCOxQmZyA96JDW+ASthlLHEA==" 

if source_type == "Azure Blob Storage (WASBS)":
    if not AZURE_STORAGE_ACCOUNT_KEY:
        raise ValueError("Azure Storage Account Key is not set. Please update the AZURE_STORAGE_ACCOUNT_KEY variable.")
    
    spark.conf.set(
        f"fs.azure.account.key.{azure_storage_account_name}.blob.core.windows.net",
        AZURE_STORAGE_ACCOUNT_KEY
    )
    print(f"Configured Spark with account key for storage account: {azure_storage_account_name}")

df_full = None
try:
    if source_type == "Local/Cloud File Upload":
        print(f"Attempting to ingest from local/cloud path: '{file_path_local_cloud}' (Type: {file_type_local_cloud})")
        reader = spark.read.option("header", "true").option("inferSchema", "true")
        if file_type_local_cloud == "excel":
            df_full = reader.format("com.crealytics.spark.excel").load(file_path_local_cloud)
        elif file_type_local_cloud == "csv":
            df_full = reader.csv(file_path_local_cloud)
        elif file_type_local_cloud == "json":
            df_full = reader.json(file_path_local_cloud)
        elif file_type_local_cloud == "parquet":
            df_full = reader.parquet(file_path_local_cloud)
        else:
            raise ValueError(f"Unsupported file type for local/cloud upload: {file_type_local_cloud}")

    elif source_type == "Azure Blob Storage (WASBS)":
        if not azure_storage_account_name or not azure_container_name or not azure_blob_path:
            raise ValueError("Azure Storage Account, Container, and Blob Path cannot be empty.")
        
        wasbs_path = f"wasbs://{azure_container_name}@{azure_storage_account_name}.blob.core.windows.net/{azure_blob_path}"
        print(f"Attempting to ingest from Azure Blob Storage: '{wasbs_path}'")
        blob_file_extension = azure_blob_path.split('.')[-1].lower()
        reader = spark.read.option("header", "true").option("inferSchema", "true")

        if blob_file_extension == "csv":
            df_full = reader.csv(wasbs_path)
        elif blob_file_extension == "json":
            df_full = reader.json(wasbs_path)
        elif blob_file_extension == "parquet":
            df_full = reader.parquet(wasbs_path)
        elif blob_file_extension == "xlsx": 
             df_full = reader.format("com.crealytics.spark.excel").load(wasbs_path)
        else:
            print(f"Warning: Auto-detected Azure blob file type '{blob_file_extension}' from path. If incorrect, data might not load correctly.")
            df_full = reader.csv(wasbs_path) 
    else:
        raise ValueError(f"Unknown source type selected: {source_type}")

    # --- Apply date filtering before aggressive limit, if param_data_age_months is positive ---
    df_filtered_by_date = df_full
    try:
        data_age_months = int(data_age_months_str)
        if data_age_months > 0:
            print(f"Applying date filter: only data from last {data_age_months} months.")
            date_col_for_filter = "receivedTime" # Choose an appropriate timestamp column from your data

            if date_col_for_filter in df_full.columns:
                from pyspark.sql.functions import current_timestamp, add_months, to_timestamp, col
                from pyspark.sql.types import TimestampType, StringType 
                
                # RE-CHECKED AND FIXED: Ensuring the df.withColumn call's second argument is correctly structured
                # and all parentheses are matched.
                df_temp = df_full.withColumn(
                    date_col_for_filter, # First argument to withColumn
                    (F.coalesce( # Start of the second argument: a F.coalesce expression
                        F.to_timestamp(F.col(date_col_for_filter).cast(StringType()), "yyyy-MM-dd HH:mm:ss.SSS"),
                        F.to_timestamp(F.col(date_col_for_filter).cast(StringType()), "yyyy-MM-dd HH:mm:ss"),
                        F.to_timestamp(F.col(date_col_for_filter).cast(StringType()), "MM/dd/yyyy HH:mm:ss"),
                        F.to_timestamp(F.col(date_col_for_filter).cast(StringType()), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
                        F.to_timestamp(F.col(date_col_for_filter).cast(StringType()), "yyyy-MM-dd'T'HH:mm:ss"),
                        F.to_timestamp(F.col(date_col_for_filter).cast(StringType()), "dd-MM-yyyy HH:mm:ss"),
                        F.to_timestamp(F.col(date_col_for_filter).cast(StringType()), "dd/MM/yyyy HH:mm:ss"),
                        F.to_timestamp(F.col(date_col_for_filter).cast(StringType()), "yyyy-MM-dd HH:mm:ss,SSS"),
                        F.to_timestamp(F.to_date(F.col(date_col_for_filter).cast(StringType()), "yyyy-MM-dd")),
                        F.to_timestamp(F.to_date(F.col(date_col_for_filter).cast(StringType()), "MM/dd/yyyy")),
                        F.to_timestamp(F.to_date(F.col(date_col_for_filter).cast(StringType()), "dd-MM-yyyy")),
                        F.to_timestamp(F.to_date(F.col(date_col_for_filter).cast(StringType()), "dd/MM/yyyy"))
                    ).cast(TimestampType()) # End of F.coalesce expression, cast to TimestampType
                    )) # End of the second argument to withColumn
                # The issue was likely due to a subtle parenthesis mismatch in the previous version,
                # which would cause the interpreter to see the line as incomplete.
                
                # Calculate the cutoff date
                cutoff_date = add_months(current_timestamp(), -data_age_months)
                
                # Apply the filter
                df_filtered_by_date = df_temp.filter(F.col(date_col_for_filter) >= cutoff_date)
                print(f"✅ Data filtered for last {data_age_months} months based on '{date_col_for_filter}'.")
            else:
                print(f"⚠️ Warning: Date filtering requested, but column '{date_col_for_filter}' not found for filtering.")
                df_filtered_by_date = df_full # Skip filter if column not found
        else:
            print("No date filtering applied (param_data_age_months is 0 or non-positive).")

    except ValueError:
        print(f"⚠️ Warning: Invalid value for param_data_age_months ('{data_age_months_str}'). Skipping date filtering.")
        df_filtered_by_date = df_full
    
    # Now apply the aggressive row limit on the potentially date-filtered data
    df_limited = df_filtered_by_date.limit(MAX_ROWS_TO_PROCESS)

    # --- Explicitly Cast Remaining Data Types for Accuracy and Memory Efficiency ---
    print("Correcting column data types for final cleaned sample...")
    
    numeric_cols = [
        "current", "voltage", "power_factor", "current_ib", "current_ir", "current_iy",
        "voltage_vbn", "voltage_vrn", "voltage_vyn", "power_factor_b_phase",
        "power_factor_r_phase", "power_factor_y_phase", "cumulative_energy_wh_import",
        "cumulative_energy_wh_export"
    ]
    timestamp_cols = ["receivedTime", "RTC"] 
    
    df_typed = df_limited
    for col_name in numeric_cols:
        if col_name in df_typed.columns:
            df_typed = df_typed.withColumn(col_name, F.col(col_name).cast(DoubleType()))

    from pyspark.sql.functions import col, lit, to_timestamp, expr, when, array, to_date 
    from pyspark.sql.types import StringType, TimestampType

    TIMESTAMP_FORMATS = [
        "yyyy-MM-dd HH:mm:ss.SSS", "yyyy-MM-dd HH:mm:ss", "MM/dd/yyyy HH:mm:ss",
        "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss",          
        "dd-MM-yyyy HH:mm:ss", "dd/MM/yyyy HH:mm:ss", "yyyy-MM-dd HH:mm:ss,SSS"         
    ]
    DATE_FORMATS = ["yyyy-MM-dd", "MM/dd/yyyy", "dd-MM-yyyy", "dd/MM/yyyy"]

    for col_name in timestamp_cols:
        if col_name in df_typed.columns:
            print(f"  > Processing timestamp column: {col_name}")
            
            # Ensure the column is StringType before parsing for robustness
            df_typed = df_typed.withColumn(col_name, F.col(col_name).cast(StringType()))

            parsed_col = F.lit(None).cast(TimestampType())
            for fmt in TIMESTAMP_FORMATS:
                parsed_col = F.when(F.col(col_name).isNotNull(), F.coalesce(parsed_col, F.to_timestamp(F.col(col_name), fmt))).otherwise(parsed_col) 
            for fmt in DATE_FORMATS:
                parsed_date_to_ts = F.to_timestamp(F.to_date(F.col(col_name), fmt))
                parsed_col = F.when(F.col(col_name).isNotNull(), F.coalesce(parsed_col, parsed_date_to_ts)).otherwise(parsed_col)
            df_typed = df_typed.withColumn(col_name, parsed_col)
            print(f"  > Applied robust timestamp parsing for column: {col_name}")

    # Final result of this notebook: df_cleaned
    df_cleaned = df_typed.cache()
    row_cnt = df_cleaned.count() 
    print(f"✅ Ingestion successful. Cleaned DataFrame 'df_cleaned' with {row_cnt} rows is ready.")
    df_cleaned.printSchema()

    # --- Save the df_cleaned to a Delta table for downstream jobs ---
    print(f"\n--- Saving cleaned data to Delta table: {CLEANED_DATA_DELTA_TABLE_FQDN} ---")
    try:
        spark.sql(f"CREATE DATABASE IF NOT EXISTS hive_metastore.default") 
        df_cleaned.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(CLEANED_DATA_DELTA_TABLE_FQDN)
        print(f"✅ Cleaned data successfully saved to Delta table: {CLEANED_DATA_DELTA_TABLE_FQDN}")
    except Exception as e:
        print(f"❌ Failed to save cleaned data to Delta table: {e}")
        dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Failed to save cleaned data to Delta: {str(e)}"}))

except Exception as e:
    print(f"❌ Error during data ingestion or processing: {e}")
    dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Error during data ingestion or processing: {str(e)}"}))

# COMMAND ----------

