# ingestion/kafka_ingestion.py
from pyspark.sql import SparkSession
import logging

logger = logging.getLogger('dq_pipeline.ingestion.kafka')

class KafkaIngestion:
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def read_stream(self, topic: str, bootstrap_servers: str, starting_offsets: str = 'earliest'):
        """Read from a Kafka topic as streaming DataFrame."""
        logger.debug(f"Connecting to Kafka: {bootstrap_servers}, topic: {topic}")
        df = (self.spark.readStream
              .format("kafka")
              .option("kafka.bootstrap.servers", bootstrap_servers)
              .option("subscribe", topic)
              .option("startingOffsets", starting_offsets)
              .load())
        # Assume value is JSON; parse accordingly
        return df.selectExpr("CAST(value AS STRING) as json_payload")