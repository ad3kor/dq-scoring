# ingestion/fivetran_ingestion.py
import logging
from pyspark.sql import SparkSession

logger = logging.getLogger('dq_pipeline.ingestion.fivetran')

class FivetranIngestion:
    """Illustrative example: Reads data from a Fivetran-managed connector via its destination Delta/SQL table."""
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def read_table(self, fivetran_table: str):
        """Read the Delta/SQL table synced by Fivetran."""
        logger.debug(f"Reading Fivetran table {fivetran_table}")
        try:
            df = self.spark.read.format('delta').table(fivetran_table)
            return df
        except Exception as e:
            logger.error(f"Failed to read Fivetran table {fivetran_table}: {e}")
            raise