# ingestion/adhoc_upload_ingestion.py
import os
import logging
from pyspark.sql import SparkSession
import pandas as pd

logger = logging.getLogger('dq_pipeline.ingestion.adhoc')

class AdhocUploadIngestion:
    """Handles user session-based file uploads (via Streamlit)."""
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def read_uploaded_file(self, local_path: str, file_type: str, **kwargs):
        """Convert a local file (uploaded in UI) to a Spark DataFrame."""
        if file_type.lower() == 'csv':
            logger.debug(f"Reading uploaded CSV from {local_path}")
            return self.spark.read.csv(local_path, header=kwargs.get('header', True), inferSchema=kwargs.get('inferSchema', True))
        elif file_type.lower() == 'json':
            logger.debug(f"Reading uploaded JSON from {local_path}")
            return self.spark.read.json(local_path, multiLine=kwargs.get('multiLine', True))
        elif file_type.lower() == 'parquet':
            logger.debug(f"Reading uploaded Parquet from {local_path}")
            return self.spark.read.parquet(local_path)
        elif file_type.lower() == 'excel':
            logger.debug(f"Reading uploaded Excel from {local_path}")
            return (self.spark.read.format('com.crealytics.spark.excel')
                        .options(inferSchema='true', header='true', sheetName=kwargs.get('sheetName', None))
                        .load(local_path))
        else:
            raise ValueError(f"Unsupported upload file type: {file_type}")