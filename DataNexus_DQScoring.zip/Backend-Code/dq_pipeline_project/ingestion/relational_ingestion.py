# ingestion/relational_ingestion.py
import os
import logging
from pyspark.sql import SparkSession
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger('dq_pipeline.ingestion.relational')

class RelationalIngestion:
    """Handles ingestion from relational databases via JDBC."""
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def read_table(self, jdbc_url: str, table: str, user: str, password: str, driver: str = None, fetchsize: int = 10000):
        """Read a relational table via JDBC into a DataFrame."""
        options = {
            'url': jdbc_url,
            'dbtable': table,
            'user': user,
            'password': password,
            'fetchsize': fetchsize
        }
        if driver:
            options['driver'] = driver
        logger.debug(f"Reading relational table {table} from {jdbc_url}")
        try:
            df = self.spark.read.format('jdbc').options(**options).load()
            return df
        except Exception as e:
            logger.error(f"Failed to read relational table {table}: {e}")
            raise