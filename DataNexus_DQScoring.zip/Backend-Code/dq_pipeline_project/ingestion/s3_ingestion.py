# ingestion/s3_ingestion.py
import logging
from pyspark.sql import SparkSession
import os

logger = logging.getLogger('dq_pipeline.ingestion.s3')

class S3Ingestion:
    """Handles ingestion from AWS S3 or Azure ADLS via Spark."""
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def read_s3(self, s3_path: str, file_format: str = 'parquet', options: dict = None):
        """Read from S3 (or any cloud) path using Spark. Supported formats: parquet, csv, json."""
        options = options or {}
        logger.debug(f"Reading S3 data from {s3_path} as {file_format}")
        if file_format.lower() == 'parquet':
            return self.spark.read.options(**options).parquet(s3_path)
        elif file_format.lower() == 'csv':
            return self.spark.read.options(**options).csv(s3_path)
        elif file_format.lower() == 'json':
            return self.spark.read.options(**options).json(s3_path)
        else:
            raise ValueError(f"Unsupported S3 file format: {file_format}")