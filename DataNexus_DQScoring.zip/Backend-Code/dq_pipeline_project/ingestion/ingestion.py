import os
from pyspark.sql import SparkSession
from dotenv import load_dotenv
import logging

load_dotenv()
logger = logging.getLogger('dq_pipeline.ingestion')

class IngestionManager:
    def __init__(self, spark: SparkSession):
        self.spark = spark
        self.use_delta = os.getenv('USE_DELTA', 'false').lower() == 'true'

    def ingest_delta(self, table_fqn: str):
        logger.info(f"Delta ingestion: {table_fqn}")
        return self.spark.read.format('delta').table(table_fqn)

    def ingest_kafka(self, topic: str, bootstrap_servers: str, starting_offsets: str = 'earliest'):
        logger.info(f"Kafka ingestion: {topic}")
        return (self.spark
                .read
                .format('kafka')
                .option('kafka.bootstrap.servers', bootstrap_servers)
                .option('subscribe', topic)
                .option('startingOffsets', starting_offsets)
                .load())

    def ingest_mongodb(self, uri: str, database: str, collection: str):
        logger.info(f"MongoDB ingestion: {database}.{collection}")
        return (self.spark
                .read
                .format('mongodb')
                .option('uri', uri)
                .option('database', database)
                .option('collection', collection)
                .load())

    def ingest_relational(self, jdbc_url: str, table: str, user: str, password: str, driver: str = None):
        logger.info(f"Relational ingestion: {jdbc_url} {table}")
        reader = (self.spark
                  .read
                  .format('jdbc')
                  .option('url', jdbc_url)
                  .option('dbtable', table)
                  .option('user', user)
                  .option('password', password))
        if driver:
            reader = reader.option('driver', driver)
        return reader.load()

    def ingest_cassandra(self, keyspace: str, table: str, contact_points: str, port: int):
        logger.info(f"Cassandra ingestion: {keyspace}.{table}")
        return (self.spark
                .read
                .format('org.apache.spark.sql.cassandra')
                .option('keyspace', keyspace)
                .option('table', table)
                .option('spark.cassandra.connection.host', contact_points)
                .option('spark.cassandra.connection.port', str(port))
                .load())

    def ingest_file(self, file_path: str, file_type: str):
        logger.info(f"File ingestion: {file_path} (type={file_type})")
        if file_type == 'csv':
            return self.spark.read.option('header', 'true').csv(file_path)
        elif file_type == 'json':
            return self.spark.read.json(file_path)
        elif file_type == 'parquet':
            return self.spark.read.parquet(file_path)
        elif file_type == 'excel':
            # Spark-Excel connector must be attached
            return (self.spark.read
                    .format('com.crealytics.spark.excel')
                    .option('header', 'true')
                    .option('inferSchema', 'true')
                    .load(file_path))
        else:
            raise ValueError(f"Unsupported file type: {file_type}")

    def ingest_s3(self, s3_path: str, file_format: str):
        logger.info(f"S3 ingestion: {s3_path} (format={file_format})")
        if file_format == 'csv':
            return self.spark.read.option('header', 'true').csv(s3_path)
        elif file_format == 'json':
            return self.spark.read.json(s3_path)
        elif file_format == 'parquet':
            return self.spark.read.parquet(s3_path)
        else:
            raise ValueError(f"Unsupported S3 format: {file_format}")

    def ingest_fivetran(self, table: str):
        logger.info(f"FiveTran ingestion: {table}")
        # Assumes FiveTran data is already in a Delta table
        return self.spark.read.format('delta').table(table)