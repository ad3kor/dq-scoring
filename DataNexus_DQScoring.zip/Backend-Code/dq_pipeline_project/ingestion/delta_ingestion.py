# ingestion/delta_ingestion.py
from pyspark.sql import SparkSession
import logging

logger = logging.getLogger('dq_pipeline.ingestion.delta')

class DeltaIngestion:
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def load_table(self, table_fqn: str):
        """Load a Delta table as a DataFrame."""
        logger.debug(f"Loading Delta table: {table_fqn}")
        try:
            df = self.spark.read.format("delta").table(table_fqn)
            return df
        except Exception as e:
            logger.error(f"Failed to load Delta table {table_fqn}: {e}")
            raise