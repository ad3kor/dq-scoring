# ingestion/utils.py
import os
import logging
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger('dq_pipeline.ingestion.utils')

def get_env_variable(name: str, default: str = None) -> str:
    """Fetch environment variable or return default."""
    val = os.getenv(name)
    if val is None:
        if default is not None:
            return default
        else:
            logger.error(f"Environment variable {name} not set and no default provided.")
            raise ValueError(f"Missing required environment variable: {name}")
    return val