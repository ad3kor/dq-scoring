# ingestion/cassandra_ingestion.py
import logging
from pyspark.sql import SparkSession

logger = logging.getLogger('dq_pipeline.ingestion.cassandra')

class CassandraIngestion:
    """Handles ingestion from Cassandra cluster."""
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def read_table(self, keyspace: str, table: str, contact_points: str = '127.0.0.1', port: int = 9042):
        """Read from a Cassandra keyspace.table into a DataFrame."""
        logger.debug(f"Reading Cassandra table {keyspace}.{table}")
        df = (self.spark.read
              .format('org.apache.spark.sql.cassandra')
              .options(table=table, keyspace=keyspace)
              .option('spark.cassandra.connection.host', contact_points)
              .option('spark.cassandra.connection.port', str(port))
              .load())
        return df