# ingestion/file_ingestion.py
import logging
from pyspark.sql import SparkSession
import os

logger = logging.getLogger('dq_pipeline.ingestion.file')

class FileIngestion:
    """Handles ingestion of files: CSV, JSON, Parquet, Excel."""
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def read_csv(self, path: str, header: bool = True, infer_schema: bool = True, sep: str = ','):
        logger.debug(f"Reading CSV file from {path}")
        return self.spark.read.csv(path, header=header, inferSchema=infer_schema, sep=sep)

    def read_json(self, path: str, multi_line: bool = True):
        logger.debug(f"Reading JSON file from {path}")
        return self.spark.read.json(path, multiLine=multi_line)

    def read_parquet(self, path: str):
        logger.debug(f"Reading Parquet file from {path}")
        return self.spark.read.parquet(path)

    def read_excel(self, path: str, sheet_name: str = None):
        logger.debug(f"Reading Excel file from {path}, sheet: {sheet_name}")
        # Requires spark-excel package, ensure spark.jars includes it
        options = {'inferSchema': 'true', 'header': 'true'}
        if sheet_name:
            options['sheetName'] = sheet_name
        return (self.spark.read
                .format('com.crealytics.spark.excel')
                .options(**options)
                .load(path))