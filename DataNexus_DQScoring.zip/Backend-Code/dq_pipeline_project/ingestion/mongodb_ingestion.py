# ingestion/mongodb_ingestion.py
from pyspark.sql import SparkSession
import logging

logger = logging.getLogger('dq_pipeline.ingestion.mongodb')

class MongoDBIngestion:
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def read_collection(self, uri: str, database: str, collection: str):
        """Read a MongoDB collection into a DataFrame."""
        logger.debug(f"Reading MongoDB collection: {database}.{collection}")
        df = (self.spark.read
              .format("mongodb")
              .option("uri", uri)
              .option("database", database)
              .option("collection", collection)
              .load())
        return df
    