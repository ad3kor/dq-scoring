# run_pipeline.py

"""
Interactive notebook for running the DQ pipeline in Databricks.
Uses dbutils.widgets to prompt user at runtime for ingestion choices and parameters.
Place this notebook in the same folder as run_pipeline.py.
"""

import os
import logging

from pyspark.sql import SparkSession
from ingestion.ingestion import IngestionManager
from sampling.stage1_reservoir_sampling import ReservoirSampler
from sampling.stage2_random_downsample import RandomDownSampler
from sampling.stage3_diversity_sampling import DiversitySampler
from rule_suggester.chunked_rule_suggester import ChunkedRuleSuggester
from assessment.dq_assessment import DQAssessment
from reporting.report_generator import ReportGenerator

# Configure logging
env_logging_conf = os.getenv('LOGGING_CONF', 'configs/logging.conf')
if os.path.exists(env_logging_conf):
    import logging.config
    logging.config.fileConfig(env_logging_conf, disable_existing_loggers=False)
logger = logging.getLogger('dq_pipeline.interactive')

# 1. Create widgets for user to select source type
dbutils.widgets.removeAll()
source_options = ['delta', 'kafka', 'mongodb', 'relational', 'cassandra', 'file', 's3', 'fivetran']
dbutils.widgets.dropdown('source_type', 'delta', source_options, 'Source Type')

# 2. Create placeholder widgets for parameters
# Delta
dbutils.widgets.text('table', '', 'Delta Table (catalog.schema.table)')
# Kafka
dbutils.widgets.text('topic', '', 'Kafka Topic')
dbutils.widgets.text('kafka_servers', '', 'Kafka Bootstrap Servers')
# MongoDB
dbutils.widgets.text('uri', '', 'MongoDB URI')
dbutils.widgets.text('database', '', 'MongoDB Database')
dbutils.widgets.text('collection', '', 'MongoDB Collection')
# Relational
dbutils.widgets.text('jdbc_url', '', 'JDBC URL')
dbutils.widgets.text('rel_table', '', 'Relational Table')
dbutils.widgets.text('rel_user', '', 'Relational User')
dbutils.widgets.text('rel_pass', '', 'Relational Password (store in secret scope recommended)')
dbutils.widgets.text('rel_driver', '', 'JDBC Driver Class (optional)')
# Cassandra
dbutils.widgets.text('cass_keyspace', '', 'Cassandra Keyspace')
dbutils.widgets.text('cass_table', '', 'Cassandra Table')
dbutils.widgets.text('cass_hosts', '', 'Cassandra Hosts (comma-separated)')
dbutils.widgets.text('cass_port', '', 'Cassandra Port')
# File
dbutils.widgets.text('file_path', '', 'File Path (DBFS or local)')
dbutils.widgets.dropdown('file_type', 'csv', ['csv', 'json', 'parquet', 'excel'], 'File Type')
# S3
dbutils.widgets.text('s3_path', '', 'S3 Path')
dbutils.widgets.dropdown('s3_format', 'csv', ['csv', 'json', 'parquet'], 'S3 Format')
# FiveTran
dbutils.widgets.text('fivetran_table', '', 'FiveTran Destination Table')

# Common sampling parameters (optional)
dbutils.widgets.text('sample_size', '100000', 'Stage1 Sample Size')
dbutils.widgets.text('downsample_count', '20000', 'Stage2 Downsample Count')
dbutils.widgets.text('diversity_clusters', '100', 'Stage3 # Clusters')
dbutils.widgets.text('diversity_per_cluster', '5', 'Stage3 Samples/Cluster')
# Report
dbutils.widgets.text('report_output_dir', '/dbfs/FileStore/acharjeerishab/reports', 'Report Output Dir')

# 3. Read widget values
def get_widget(name):
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return None

source_type = get_widget('source_type')
table = get_widget('table')
topic = get_widget('topic')
kafka_servers = get_widget('kafka_servers')
uri = get_widget('uri')
database = get_widget('database')
collection = get_widget('collection')
jdbc_url = get_widget('jdbc_url')
rel_table = get_widget('rel_table')
rel_user = get_widget('rel_user')
rel_pass = get_widget('rel_pass')
rel_driver = get_widget('rel_driver')
cass_keyspace = get_widget('cass_keyspace')
cass_table = get_widget('cass_table')
cass_hosts = get_widget('cass_hosts')
cass_port = get_widget('cass_port')
file_path = get_widget('file_path')
file_type = get_widget('file_type')
s3_path = get_widget('s3_path')
s3_format = get_widget('s3_format')
fivetran_table = get_widget('fivetran_table')

# Sampling widgets
sample_size = int(get_widget('sample_size'))
downsample_count = int(get_widget('downsample_count'))
diversity_clusters = int(get_widget('diversity_clusters'))
diversity_per_cluster = int(get_widget('diversity_per_cluster'))
report_output_dir = get_widget('report_output_dir')

# 4. Initialize Spark and other managers
spark = (SparkSession.builder
         .appName("DQ_Pipeline_Interactive")
         .enableHiveSupport()
         .getOrCreate())
ingest_manager = IngestionManager(spark)

# 5. Ingest data based on user choice
df = None
logger.info(f"Ingestion source: {source_type}")
if source_type == 'delta':
    if not table:
        raise ValueError("Delta table must be provided")
    df = ingest_manager.ingest_delta(table)
elif source_type == 'kafka':
    if not topic or not kafka_servers:
        raise ValueError("Kafka topic and bootstrap servers required")
    df = ingest_manager.ingest_kafka(topic, kafka_servers)
    raise ValueError("Streaming ingestion not supported in interactive batch mode")
elif source_type == 'mongodb':
    if not (uri and database and collection):
        raise ValueError("MongoDB URI, database, and collection required")
    df = ingest_manager.ingest_mongodb(uri, database, collection)
elif source_type == 'relational':
    if not (jdbc_url and rel_table and rel_user and rel_pass):
        raise ValueError("JDBC URL, table, user, and password required")
    df = ingest_manager.ingest_relational(jdbc_url, rel_table, rel_user, rel_pass, driver=rel_driver)
elif source_type == 'cassandra':
    if not (cass_keyspace and cass_table and cass_hosts and cass_port):
        raise ValueError("Cassandra keyspace, table, hosts, and port required")
    df = ingest_manager.ingest_cassandra(cass_keyspace, cass_table, contact_points=cass_hosts, port=int(cass_port))
elif source_type == 'file':
    if not (file_path and file_type):
        raise ValueError("File path and file type required")

    # Normalize to a 'dbfs:/' URI
    if file_path.startswith("/Workspace/"):
        norm_path = "dbfs:" + file_path
    elif file_path.startswith("/dbfs/"):
        norm_path = file_path.replace("/dbfs/", "dbfs:/")
    elif file_path.startswith("dbfs:/"):
        norm_path = file_path
    else:
        norm_path = file_path

    logger.info(f"Normalized file path: {norm_path}")

    if file_type == 'excel':
        # Ensure Spark-Excel connector is attached on your cluster
        df = spark.read.format("com.crealytics.spark.excel") \
            .option("header", "true") \
            .option("inferSchema", "true") \
            .load(norm_path)
    else:
        df = ingest_manager.ingest_file(norm_path, file_type)
elif source_type == 's3':
    if not (s3_path and s3_format):
        raise ValueError("S3 path and format required")
    df = ingest_manager.ingest_s3(s3_path, file_format=s3_format)
elif source_type == 'fivetran':
    if not fivetran_table:
        raise ValueError("FiveTran table required")
    df = ingest_manager.ingest_fivetran(fivetran_table)
else:
    raise ValueError(f"Unsupported source: {source_type}")

# Cache ingestion result
if df is None:
    raise ValueError("DataFrame is None after ingestion")
df = df.cache()

# 6. Sampling & chunked rule suggestion
logger.info("Starting sampling & rule suggestion")

# Stage 1: Reservoir Sampling
reservoir_sampler = ReservoirSampler(spark, sample_size=sample_size)
sample_stage1 = reservoir_sampler.sample(df)

# Stage 2: Random Downsample
down_sampler = RandomDownSampler(spark, target_count=downsample_count)
sample_stage2 = down_sampler.sample(sample_stage1)

# To Pandas for Diversity sampling
pdf = sample_stage2.toPandas()

# Stage 3: Diversity Sampling (on Pandas DataFrame)
diversity_sampler = DiversitySampler(num_clusters=diversity_clusters, samples_per_cluster=diversity_per_cluster)
final_pdf = diversity_sampler.sample(pdf)

# Compute column stats on the second-stage sample (pdf)
column_stats = {}
for col in pdf.columns:
    column_stats[col] = {
        'null_count': int(pdf[col].isna().sum()),
        'unique_count': int(pdf[col].nunique()),
        'sample_distinct_values': list(pdf[col].dropna().unique()[:5])
    }

# Use ChunkedRuleSuggester to get rules in a token-aware, batched fashion
logger.info("Building and sending chunked prompts to LLM")
chunked_suggester = ChunkedRuleSuggester(model_name='deepseek-r1-distill-llama-70b')
# final_pdf is a Pandas DataFrame containing the diversity-sampled rows
rules = chunked_suggester.suggest_rules_chunked(final_pdf, target_columns=None)

# 7. Run DQ Assessment
logger.info("Running DQ Assessment")
assessor = DQAssessment(spark)
results_df = assessor.run_assessment(df, rules)
results_table = os.getenv('DQ_RESULTS_TABLE', 'dq_results.default')
results_df.write.mode('overwrite').format('delta').saveAsTable(results_table)
logger.info(f"Results saved to {results_table}")

# 8. Generate PDF report
logger.info("Generating PDF report")
report_gen = ReportGenerator(output_dir=report_output_dir)
pdf_path = report_gen.generate(results_df)
logger.info(f"Report saved at {pdf_path}")

spark.stop()
logger.info("Interactive pipeline run complete.")
