# Databricks notebook source
# MAGIC %pip install -r requirements.txt
# MAGIC

# COMMAND ----------

# Cell 1: Define interactive widgets
dbutils.widgets.removeAll()
dbutils.widgets.dropdown("source_type", "delta", ["delta","file"], "Source Type")
dbutils.widgets.text("table", "samples.nyctaxi.trips", "Delta Table")
dbutils.widgets.text("file_path", "", "File Path")
dbutils.widgets.dropdown("file_type", "csv", ["csv","json","parquet","excel"], "File Type")
dbutils.widgets.text("report_output_dir", "/dbfs/FileStore/reports", "Report Output Dir")


# COMMAND ----------

# Cell 1: Setup, Configuration, and Widgets

import os
import logging
import json
import gc
from typing import Any, List, Dict
from collections import defaultdict
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType,
    DoubleType, TimestampType, IntegerType
)

# --- Memory Safety & Configuration ---
# Suppress the benign tokenizers parallelism warning
os.environ["TOKENIZERS_PARALLELISM"] = "false"
MAX_ROWS_TO_PROCESS = 50  # A safe, low limit to prevent OOM errors.
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]
RULES_PATH = "/dbfs/FileStore/reports/final_rules.json"
WEIGHTS_PATH = "/dbfs/FileStore/reports/final_weights.json"

# --- Spark and Logging Setup ---
spark = SparkSession.builder.appName("DQ_Pipeline_Memory_Safe").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.final')
print("✅ Spark Session and Logger initialized.")

# --- Widget Creation ---
try:
    dbutils.widgets.removeAll()
    dbutils.widgets.text("file_path", "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx", "1. Input File Path")
    dbutils.widgets.text("file_type", "excel", "2. Input File Type")
    print("✅ Widgets created. Please set your input file path above.")
except:
    print("⚠️ Could not create Databricks widgets. Using default file path.")

# COMMAND ----------

# Cell 2: Data Ingestion and Type Casting

file_path = dbutils.widgets.get("file_path")
file_type = dbutils.widgets.get("file_type").lower()

print(f"Attempting to ingest from: '{file_path}'")

try:
    # 1. Ingest the data
    df_full = (
        spark.read.format("com.crealytics.spark.excel")
             .option("header", "true")
             .option("inferSchema", "true") # Let Spark take a first guess at types
             .load(file_path)
    )

    # 2. Aggressively limit the DataFrame size IMMEDIATELY after loading
    df_limited = df_full.limit(MAX_ROWS_TO_PROCESS)

    # 3. Explicitly Cast Data Types for Accuracy and Memory Efficiency
    print("Correcting column data types...")
    # Define your schema based on the provided column list
    numeric_cols = [
        "current", "voltage", "power_factor", "current_ib", "current_ir", "current_iy",
        "voltage_vbn", "voltage_vrn", "voltage_vyn", "power_factor_b_phase",
        "power_factor_r_phase", "power_factor_y_phase", "cumulative_energy_wh_import",
        "cumulative_energy_wh_export"
    ]
    timestamp_cols = ["receivedTime", "RTC"]
    
    df_typed = df_limited
    for col_name in numeric_cols:
        if col_name in df_typed.columns:
            df_typed = df_typed.withColumn(col_name, F.col(col_name).cast(DoubleType()))

    for col_name in timestamp_cols:
        if col_name in df_typed.columns:
            df_typed = df_typed.withColumn(col_name, F.to_timestamp(F.col(col_name)))

    # 4. Cache the final, small, correctly-typed DataFrame
    df = df_typed.cache()
    row_cnt = df.count() # Trigger cache and get count
    
    print(f"✅ Ingestion successful. Sampled and typed DataFrame 'df' with {row_cnt} rows is ready.")
    df.printSchema()

except Exception as e:
    print(f"❌ Data ingestion failed. Error: {e}")
    spark.stop()
    raise e

# COMMAND ----------

# MAGIC %pip install reportlab

# COMMAND ----------

# MAGIC %pip install -U threadpoolctl

# COMMAND ----------

# Cell 3: Data Cleaning & Stateless Interactive Rule Editing Loop (Corrected and Verified)

import pandas as pd
from collections import defaultdict
import json
from typing import Any, List, Dict
import logging
import os
import numpy as np # Import numpy for numerical comparisons
import time # Import time for potential small delays

# Imports for Spark data cleaning
from pyspark.sql import functions as F
from pyspark.sql.types import TimestampType

# Assumes your custom IntelligentRuleSuggester class is available
# Ensure this class is accessible in your Databricks environment
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester 

# --- Configuration & Logger ---
# DQ_PARAMS can be dynamically updated by user, so initialize it as a list first
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"] 

# *** UPDATED PATHS FOR STORING RULES AND WEIGHTS ***
# Define paths with /dbfs prefix for dbutils.fs.put
RULES_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
WEIGHTS_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# Define the *internal* DBFS path without /dbfs prefix for dbutils.fs.head
DBFS_RULES_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
DBFS_WEIGHTS_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

logger = logging.getLogger('dq_pipeline.interactive')

# ==============================================================================
# 1. Data Cleaning
# ==============================================================================
print("--- Step 1: Cleaning timestamps to prevent conversion errors... ---")

pd_min_ts = pd.Timestamp.min.to_pydatetime()
pd_max_ts = pd.Timestamp.max.to_pydatetime()
df_cleaned = df # Assuming 'df' is your Spark DataFrame from previous cell
timestamp_cols = [field.name for field in df.schema.fields if isinstance(field.dataType, TimestampType)]

if timestamp_cols:
    print(f"Found timestamp columns to clean: {timestamp_cols}")
    for col_name in timestamp_cols:
        df_cleaned = df_cleaned.withColumn(col_name, F.when((F.col(col_name) >= pd_min_ts) & (F.col(col_name) <= pd_max_ts), F.col(col_name)).otherwise(F.lit(None)))
    print("✅ Timestamp cleaning complete.")
else:
    print("No timestamp columns found to clean.")

# ==============================================================================
# 2. Generate Initial Rules
# ==============================================================================
print("\n--- Step 2: Generating a new, data-driven set of rules from the LLM... ---")
# Sample data for LLM if df_cleaned is too large
# For petabyte scale, this sampling must be distributed and managed by Ray/Spark as per Stage 1 and 2 
# Here, for demonstration, we'll convert to Pandas, but in a real scenario, you'd apply the multi-stage sampling
# strategy here to get a 'pdf_for_profiling' that is small and diverse.
# For now, assuming df_cleaned is small enough for toPandas for prototype
try:
    pdf_for_profiling = df_cleaned.toPandas()
except Exception as e:
    print(f"Warning: Could not convert Spark DataFrame to Pandas for profiling directly. Error: {e}")
    print("Using a small sample for LLM profiling.")
    # Implement a small, direct sample for local profiling if the full conversion fails
    pdf_for_profiling = df_cleaned.limit(1000).toPandas() # Limit to a small number of rows

suggester = IntelligentRuleSuggester()
result = suggester.suggest_rules(pdf_for_profiling) # This should generate initial rules based on the sampled data
rules: List[Dict[str, Any]] = result.get("rules", []) # Ensure 'rules' is typed correctly

# Initialize weights based on initial DQ_PARAMS, distributing equally
# This 'weights' dictionary will be directly modified by the user
weights = {p: 100.0 / len(DQ_PARAMS) for p in DQ_PARAMS}

if not rules:
    print("LLM failed to generate any rules. Attempting to generate default rules for demonstration.")
    # Fallback to some default rules if LLM fails
    rules = [
        {"type": "completeness", "description": "Ensure 'id' column is not null.", "column": "id", "condition": "isNotNull"},
        {"type": "uniqueness", "description": "Ensure 'id' column is unique.", "column": "id", "condition": "isUnique"},
        {"type": "accuracy", "description": "Ensure 'email' column has valid format.", "column": "email", "condition": "isValidEmail"},
        {"type": "consistency", "description": "Ensure 'order_date' is in YYYY-MM-DD format.", "column": "order_date", "condition": "isDateFormat"},
    ]


# ==============================================================================
# 3. Interactive Editing Loop
# ==============================================================================
while True:
    # Organize rules by parameter type for display
    param_rules = defaultdict(list)
    for r in rules:
        param_rules[r.get("type", "other")].append(r)
    
    # Display current configuration
    print("\n" + "="*80)
    print("--- CURRENT DATA QUALITY CONFIGURATION ---")
    print("\n--- PARAMETER WEIGHTS ---")
    current_total_weight_display = sum(weights.values())
    if current_total_weight_display == 0:
        print("Warning: Total weight is 0. Please adjust weights.")
        for param in DQ_PARAMS:
            print(f"PARAMETER: {param.upper()} (Current Weight: {weights.get(param, 0):.1f}%)")
    else:
        for param in DQ_PARAMS:
            display_weight = (weights.get(param, 0) / current_total_weight_display) * 100
            print(f"PARAMETER: {param.upper()} (Current Weight: {display_weight:.1f}%)")

    print("\n--- RULES BY PARAMETER ---")
    # Ensure DQ_PARAMS is iterated to maintain order and show all active parameters
    for param in DQ_PARAMS: 
        print(f"\nPARAMETER: {param.upper()}")
        if rules_list := [r for r in rules if r.get("type") == param]:
            for i, rule in enumerate(rules_list):
                print(f"  {i+1}. {rule.get('description', 'No description')}")
        else:
            print("  No rules defined for this parameter.")
    print("="*80)

    action = input("\nChoose action: [e]dit configuration, [p]arameters, or [q]uit and save: ").strip().lower()

    if action == 'q':
        print("Final configuration set. Saving rules and weights...")
        break
    elif action == 'e':
        # Edit rules or weights for existing parameters
        param_to_edit = input(f"Which parameter's rules to edit? {DQ_PARAMS}: ").strip().lower()
        if param_to_edit not in DQ_PARAMS:
            print("Invalid parameter.")
            continue
        
        edit_choice = input(f"Editing '{param_to_edit}'. [w]eight, [a]dd rule, [r]emove rule: ").strip().lower()
        
        if edit_choice == 'w':
            try:
                current_param_weight = weights.get(param_to_edit, 0.0) # Get current value
                new_weight = float(input(f"Enter new weight for '{param_to_edit}' (current: {current_param_weight:.1f}): "))
                if new_weight < 0:
                    print("Weight cannot be negative. Setting to 0.")
                    weights[param_to_edit] = 0.0
                else:
                    weights[param_to_edit] = new_weight
                print(f"Updated weight for '{param_to_edit}'.")
            except ValueError:
                print("Invalid weight. Please enter a number.")
        elif edit_choice == 'a':
            print(f"Adding a new rule for '{param_to_edit}'.")
            rule_desc = input("Enter rule description: ")
            rule_col = input("Enter column name for the rule (optional): ")
            rule_condition = input("Enter rule condition (e.g., 'isNotNull', 'isValidEmail') (optional): ")
            
            new_rule = {"type": param_to_edit, "description": rule_desc}
            if rule_col:
                new_rule["column"] = rule_col
            if rule_condition:
                new_rule["condition"] = rule_condition
            rules.append(new_rule)
            print("Rule added.")
        elif edit_choice == 'r':
            rules_for_param = [r for r in rules if r.get("type") == param_to_edit]
            if not rules_for_param:
                print(f"No rules to remove for '{param_to_edit}'.")
                continue
            print(f"Rules for '{param_to_edit}':")
            for i, rule in enumerate(rules_for_param):
                print(f"  {i+1}. {rule.get('description', 'No description')}")
            
            try:
                idx_to_remove = int(input("Enter the number of the rule to remove: ")) - 1
                if 0 <= idx_to_remove < len(rules_for_param):
                    # Find the actual rule object in the 'rules' list and remove it
                    removed_rule = rules_for_param[idx_to_remove]
                    rules.remove(removed_rule)
                    print("Rule removed.")
                else:
                    print("Invalid rule number.")
            except ValueError:
                print("Invalid input. Please enter a number.")
        else:
            print("Invalid edit choice.")
    elif action == 'p':
        # Add or remove parameters
        param_action = input("[a]dd parameter, [r]emove parameter: ").strip().lower()
        if param_action == 'a':
            new_param = input("Enter new parameter name: ").strip().lower()
            if new_param in DQ_PARAMS:
                print(f"Parameter '{new_param}' already exists.")
            else:
                DQ_PARAMS.append(new_param) # Add to the list of active parameters
                # Distribute weights equally among all current parameters
                # Use current length of DQ_PARAMS including the new one
                equal_weight_val = 100.0 / len(DQ_PARAMS)
                for p in DQ_PARAMS: # Iterate through the updated DQ_PARAMS
                    weights[p] = equal_weight_val
                print(f"Parameter '{new_param}' added. Weights redistributed equally among all parameters.")
                # LLM suggests rules for new parameter (if needed) - placeholder
                print(f"LLM will now suggest rules for the new parameter '{new_param}'.")
                # In a real scenario, you'd re-profile or use LLM with specific context for new param
                # Note: `specific_param` is an assumed argument for `suggest_rules`
                new_param_rules_result = suggester.suggest_rules(pdf_for_profiling, specific_param=new_param) 
                rules.extend(new_param_rules_result.get("rules", []))
                print(f"Suggested rules for '{new_param}' added.")

        elif param_action == 'r':
            param_to_remove = input(f"Enter parameter to remove {DQ_PARAMS}: ").strip().lower()
            if param_to_remove not in DQ_PARAMS:
                print("Invalid parameter name.")
            elif len(DQ_PARAMS) == 1:
                print("Cannot remove the last parameter.")
            else:
                DQ_PARAMS.remove(param_to_remove) # Remove from active parameters
                if param_to_remove in weights:
                    del weights[param_to_remove] # Remove its weight
                
                # Redistribute weights equally among remaining parameters
                if DQ_PARAMS: # Check if any parameters are left
                    equal_weight_val = 100.0 / len(DQ_PARAMS)
                    for p in DQ_PARAMS:
                        weights[p] = equal_weight_val
                    print(f"Parameter '{param_to_remove}' removed. Weights redistributed equally among remaining parameters.")
                else:
                    print(f"Parameter '{param_to_remove}' removed. No parameters remaining.")
                
                # Also remove any rules associated with the removed parameter
                rules = [r for r in rules if r.get("type") != param_to_remove]
                print("Associated rules removed.")
        else:
            print("Invalid parameter action.")
    else:
        print("Invalid action.")

# ==============================================================================
# 4. Finalization and Verification (Definitive Fix)
# ==============================================================================
# The 'weights' dictionary now holds the final raw values from the loop
print(f"\nDEBUG: Final raw weights from interactive session: {weights}")
total_weight = sum(weights.values())

# This dictionary will hold the final weights as normalized values (summing to 1.0)
final_weights_to_save = {}
if total_weight > 0:
    final_weights_to_save = {p: (w / total_weight) for p, w in weights.items()}
else:
    # If total_weight is 0, default to equal distribution among *current* DQ_PARAMS
    if DQ_PARAMS:
        final_weights_to_save = {p: 1.0 / len(DQ_PARAMS) for p in DQ_PARAMS}
    else:
        final_weights_to_save = {} # No parameters, no weights

print("\n--- FINAL CONFIGURATION SAVED ---")
# Display the variable that is about to be saved in a human-readable format
print(f"Final Weights (as percentages): { {k: f'{v*100:.1f}%' for k, v in final_weights_to_save.items()} }")
print(f"Total Rules: {len(rules)}")

# Save the final, correct configuration to DBFS
try:
    # Ensure the directory exists before writing
    dbutils.fs.mkdirs("/FileStore/dq_configs/")
    dbutils.fs.put(RULES_PATH, json.dumps(rules, indent=2), overwrite=True)
    dbutils.fs.put(WEIGHTS_PATH, json.dumps(final_weights_to_save, indent=2), overwrite=True)
    print(f"✅ Final rules and weights saved to {RULES_PATH} and {WEIGHTS_PATH}.")
except Exception as e:
    print(f"❌ Error saving files to DBFS: {e}")

# --- Verification Step ---
print("\n--- VERIFICATION ---")
try:
    # Read the content back and verify
    # Use the internal DBFS path for dbutils.fs.head
    saved_weights_str = dbutils.fs.head(DBFS_WEIGHTS_PATH_INTERNAL) 
    saved_data = json.loads(saved_weights_str)
    print(f"Content of saved weights file ({WEIGHTS_PATH}):\n{saved_weights_str}")
    
    # Perform a robust numerical check
    # Check if all keys match and values are numerically close
    keys_match = set(saved_data.keys()) == set(final_weights_to_save.keys())
    values_match = True
    if keys_match:
        for k, v in final_weights_to_save.items():
            # Use a small tolerance for floating-point comparison
            if not np.isclose(saved_data.get(k, 0), v, atol=1e-9): 
                values_match = False
                break
    
    if keys_match and values_match:
        print("✅ Verification successful. The file contents now correctly match the configuration.")
    else:
        print("❌ VERIFICATION FAILED: The content saved to the file still does NOT match the configuration.")
        print(f"Expected: {final_weights_to_save}")
        print(f"Actual: {saved_data}")
        
except Exception as e:
    print(f"❌ Verification failed. Could not read back the saved file or parse its content. Error: {e}")

print("\nYou may now proceed to the final assessment cell (Cell 4).")

# COMMAND ----------

# Cell 4: LLM-Powered Score Generation and Reporting (Final Version)

import json
import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from typing import List, Dict, Any, Optional

# --- LLM and Pydantic Imports ---
from langchain_groq.chat_models import ChatGroq
from langchain.schema import SystemMessage, HumanMessage
from pydantic import BaseModel, Field, ValidationError
import logging
import time
import numpy as np

# ==============================================================================
# 0. Configuration & Logger
# ==============================================================================
logger = logging.getLogger('dq_pipeline.llm_scoring')
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Configuration ---
GROQ_API_KEY = "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" # Ensure this is securely managed in production
TOP_K_SAMPLES = 20

# ==============================================================================
# 1. Setup and Load Inputs
# ==============================================================================
print("--- Step 1: Loading rules, weights, and the cleaned DataFrame... ---")

# --- IMPORTANT: These paths MUST match what was defined and saved in Cell 3 ---
# Define paths with /dbfs prefix for dbutils.fs.put (though we only read here)
RULES_PATH_ABS = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
WEIGHTS_PATH_ABS = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# Define the *internal* DBFS path without /dbfs prefix for dbutils.fs.head
RULES_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
WEIGHTS_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

try:
    # Use the internal DBFS path for dbutils.fs.head as this is a Workspace path
    rules_str = dbutils.fs.head(RULES_PATH_INTERNAL)
    weights_str = dbutils.fs.head(WEIGHTS_PATH_INTERNAL)
    rules = json.loads(rules_str)
    weights = json.loads(weights_str) # Weights are now normalized (sum to 1.0)
    
    # Dynamically set DQ_PARAMS based on the keys in the loaded weights
    DQ_PARAMS = list(weights.keys())
    
    total_records = df_cleaned.count() # Assuming df_cleaned is available from previous cells
    if total_records == 0:
        raise ValueError("Input DataFrame is empty. Cannot perform scoring.")

    print(f"✅ Loaded {len(rules)} rules and {len(weights)} weights directly from the configuration saved by Cell 3.")
    print(f"Active DQ Parameters: {DQ_PARAMS}")
    print(f"Total records to assess: {total_records}")

except Exception as e:
    print(f"❌ Error loading input files or DataFrame: {e}")
    # Using sys.exit is a cleaner way to stop the notebook execution than dbutils.notebook.exit
    # if you are running outside a Databricks Job context where dbutils.notebook.exit is expected.
    # For Databricks notebooks, dbutils.notebook.exit is generally preferred.
    import sys
    sys.exit("Failed to load necessary inputs for scoring.") 

# ==============================================================================
# 2. LLM Interaction Layer (with JSON Repair)
# ==============================================================================
print("\n--- Step 2: Initializing LLM Interaction Layer with JSON Repair... ---")

class LLMRuleScoreResponse(BaseModel):
    rule_score: float = Field(..., description="A score for the rule from 0.0 to 10.0 based on the failure rate.")
    reasoning: str = Field(..., description="Detailed reasoning for the score, explaining the impact of the failing records.")

class LLMDimensionObservationResponse(BaseModel):
    observation: str = Field(..., description="A qualitative observation explaining the provided dimension score, referencing the rule outcomes.")

class LLMOverallReportResponse(BaseModel):
    report: str = Field(..., description="A comprehensive report explaining the final, overall data quality score. This must be a single flat string.")

class LLMScoringAndObservation:
    """Handles all communication with the LLM, now with a JSON repair mechanism."""
    def __init__(self, api_key: str, model="llama3-8b-8192"):
        if not api_key: raise ValueError("Groq API key is required.")
        self.llm = ChatGroq(model=model, temperature=0.1, api_key=api_key)
        self.repair_llm = ChatGroq(model="llama3-8b-8192", temperature=0.0, api_key=api_key)

    def _repair_json(self, broken_json: str) -> Optional[str]:
        try:
            prompt = f"The following is a broken JSON object. Please fix all syntax and schema errors and return only the corrected, valid JSON object. Do not add any text or explanation before or after the JSON.\n\nBROKEN JSON:\n{broken_json}"
            repair_messages = [HumanMessage(content=prompt)]
            response = self.repair_llm.invoke(repair_messages)
            return response.content.strip()
        except Exception as e:
            logger.error(f"JSON repair call failed: {e}")
            return None

    def _invoke_llm(self, messages: List, response_model: BaseModel) -> Optional[Dict[str, Any]]:
        for attempt in range(2):
            try:
                response = self.llm.invoke(messages)
                raw_text = response.content.strip()
                start_index, end_index = raw_text.find('{'), raw_text.rfind('}')
                if start_index != -1 and end_index > start_index:
                    json_str = raw_text[start_index : end_index + 1]
                    return response_model(**json.loads(json_str)).model_dump()
                else:
                    raise ValueError("No JSON object found in response.")
            except (json.JSONDecodeError, ValidationError, ValueError) as e:
                logger.warning(f"LLM response failed validation on attempt {attempt+1}. Error: {e}. Attempting to repair.")
                repaired_json_str = self._repair_json(raw_text)
                if repaired_json_str:
                    try:
                        return response_model(**json.loads(repaired_json_str)).model_dump()
                    except (json.JSONDecodeError, ValidationError) as final_e:
                        logger.error(f"Parsing failed even after repair. Final error: {final_e}")
                        continue
        return None

    def get_rule_assessment(self, rule_context: str) -> Optional[Dict[str, Any]]:
        system_prompt = "You are a data quality analyst. Based on the evidence, provide a score from 0.0 to 10.0 reflecting the failure rate, and a concise reasoning. Respond with a single JSON object with keys 'rule_score' and 'reasoning'."
        messages = [SystemMessage(content=system_prompt), HumanMessage(content=rule_context)]
        return self._invoke_llm(messages, LLMRuleScoreResponse)

    def get_dimension_observation(self, dimension_context: str) -> Optional[Dict[str, Any]]:
        system_prompt = "You are a data quality analyst. Given a calculated dimension score and a summary of rule results, write a concise observation explaining *why* the dimension received that score. Your response MUST be a single JSON object with one key: 'observation'."
        messages = [SystemMessage(content=system_prompt), HumanMessage(content=dimension_context)]
        return self._invoke_llm(messages, LLMDimensionObservationResponse)
        
    def get_overall_report(self, final_context: str) -> Optional[Dict[str, Any]]:
        system_prompt = "You are a data quality analyst. Given a final calculated score and a summary of all dimensions, write a comprehensive report explaining the overall data quality. The value for the 'report' key must be a single flat string, not a nested object. Your response MUST be a single JSON object with one key: 'report'."
        messages = [SystemMessage(content=system_prompt), HumanMessage(content=final_context)]
        return self._invoke_llm(messages, LLMOverallReportResponse)

llm_service = LLMScoringAndObservation(api_key=GROQ_API_KEY)


# ==============================================================================
# 3. Enhanced Rule Execution and Evidence Gathering (Improved Interpreter)
# ==============================================================================
print("\n--- Step 3: Executing Rules and Gathering Evidence for LLM... ---")

# Assumes 'spark' session is already available in the environment
# If not, initialize it: spark = SparkSession.builder.appName("DQ_App").getOrCreate()

def execute_and_gather_evidence(rule: dict, df: "SparkSession.DataFrame", total_records: int) -> dict:
    description = rule.get("description", "").lower()
    # Ensure 'column' is treated as a list, as rules can now have multiple columns
    columns = rule.get("columns", []) 
    # If a single column is specified directly (legacy/simpler rule), convert to list
    if isinstance(rule.get("column"), str) and not columns:
        columns = [rule["column"]]

    result = {
        "Rule Description": rule.get("description", "N/A"), 
        "Column": ", ".join(columns) if columns else "N/A", # Display all columns if multiple
        "Dimension": rule.get("type", "Other").capitalize(), 
        "Status": "Error", 
        "Details": "Rule could not be processed.",
        "Affected Records": "N/A", 
        "llm_context": ""
    }
    
    if not columns: # Handle rules without specified columns, or where first column is needed
        result["Details"] = "Rule requires a target column(s) but none specified."
        return result
    
    # Assume most rules operate on the first column for simplicity, or adapt logic for multiple columns
    col_name = columns[0] 
    
    df_with_id = df.withColumn("dq_internal_id", F.monotonically_increasing_id())
    try:
        failing_records_df = None
        
        # --- Improved Rule Interpreter ---
        if "unique" in description:
            # For uniqueness, if multiple columns are specified, ensure the combination is unique
            if len(columns) > 1:
                group_cols = [F.col(c) for c in columns]
                duplicate_values_df = df.groupBy(*group_cols).count().filter(F.col("count") > 1)
                if duplicate_values_df.count() > 0:
                    failing_records_df = df_with_id.join(duplicate_values_df, on=columns, how="inner")
                else:
                    failing_records_df = spark.createDataFrame([], df_with_id.schema)
            else: # Single column uniqueness
                duplicate_values_df = df.groupBy(F.col(col_name)).count().filter(F.col("count") > 1).select(col_name)
                if duplicate_values_df.count() > 0:
                    failing_records_df = df_with_id.join(duplicate_values_df, col_name, "inner")
                else:
                    failing_records_df = spark.createDataFrame([], df_with_id.schema)


        elif "null" in description or "empty" in description:
            # Check for null or empty strings
            failing_records_df = df_with_id.filter(F.col(col_name).isNull() | (F.col(col_name) == ""))

        elif "range" in description and "positive" in description:
            # Example: "Total amount should be a positive value."
            failing_records_df = df_with_id.filter(F.col(col_name) <= 0)
        elif "range" in description: # General range check if no explicit min/max
            print(f"  > NOTE: No explicit range found for rule '{rule.get('description', '')}'. Applying a 3-sigma statistical heuristic.")
            stats = df_with_id.select(F.mean(col_name).alias("mean"), F.stddev(col_name).alias("stddev")).first()
            if stats and stats['mean'] is not None and stats['stddev'] is not None:
                mean, stddev = stats['mean'], stats['stddev']
                upper_bound = mean + 3 * stddev
                lower_bound = mean - 3 * stddev
                failing_records_df = df_with_id.filter((F.col(col_name) < lower_bound) | (F.col(col_name) > upper_bound))
            else:
                result["Details"] = f"Cannot apply range check: column '{col_name}' is not numeric or is empty."
                return result

        elif "email format" in description:
            email_regex = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
            failing_records_df = df_with_id.filter(~F.col(col_name).rlike(email_regex))
            
        elif "date format" in description and "YYYY-MM-DD" in description:
            # A basic regex for YYYY-MM-DD, more robust date parsing is complex
            date_regex = r"^\d{4}-\d{2}-\d{2}$"
            failing_records_df = df_with_id.filter(~F.col(col_name).rlike(date_regex))

        elif "allowed values" in description and "status" in description and "SHIPPED, PENDING, CANCELLED" in description:
            # Example: "Status should be one of the allowed values (SHIPPED, PENDING, CANCELLED)."
            allowed_values = ["SHIPPED", "PENDING", "CANCELLED"]
            failing_records_df = df_with_id.filter(~F.col(col_name).isin(allowed_values))

        elif "zip code format" in description and "US zip code format" in description:
            zip_regex = r"^\d{5}(?:[-\s]\d{4})?$" # 5 digits or 5+4 digits
            failing_records_df = df_with_id.filter(~F.col(col_name).rlike(zip_regex))
        
        else:
            result["Details"] = f"Rule interpreter could not understand the rule: '{rule.get('description', '')}'"
            return result
            
        affected_count = failing_records_df.count()
        result["Affected Records"] = affected_count
        result["Status"] = "Fail" if affected_count > 0 else "Pass"

        passing_percentage = (total_records - affected_count) / total_records if total_records > 0 else 1.0
        result["script_calculated_score"] = passing_percentage * 10 # Scale to 0-10

        failing_sample = failing_records_df.select(col_name).limit(TOP_K_SAMPLES).toPandas()
        
        # To get passing samples, filter out failing records using dq_internal_id
        passing_sample_df = df_with_id.join(failing_records_df.select("dq_internal_id"), on="dq_internal_id", how="left_anti") \
                                   .select(col_name).limit(TOP_K_SAMPLES)
        passing_sample = passing_sample_df.toPandas()
        
        result["llm_context"] = (
            f"Rule: '{rule['description']}' on column '{', '.join(columns)}'.\n"
            f"Total Records: {total_records}, Failing Records: {affected_count}.\n"
            f"Passing Percentage: {passing_percentage:.2%}\n"
            f"Failing Samples:\n{failing_sample.to_string(index=False)}\n"
            f"Passing Samples:\n{passing_sample.to_string(index=False)}"
        )
    except Exception as e:
        result["Details"] = f"Error during Spark execution for rule '{rule.get('description', 'N/A')}': {str(e)}"
    return result

# ==============================================================================
# 4. Assessment and Reporting (Script Calculates, LLM Explains)
# ==============================================================================
print("\n" + "="*80)
print("--- Step 4: Starting Data Quality Assessment (Script Calculates, LLM Explains) ---")
print("="*80)

summary_stats = {"pass": 0, "fail": 0, "error": 0}
rule_results = []

# --- Part A: Assess each rule ---
for i, rule in enumerate(rules):
    print(f"\nAnalyzing Rule {i+1}/{len(rules)}: \"{rule.get('description', 'Unnamed Rule')}\"...")
    # Ensure 'columns' key is present and is a list for the rule
    # This block ensures backward compatibility if rules were generated with 'column' instead of 'columns'
    if 'column' in rule and not isinstance(rule['column'], list):
        rule['columns'] = [rule['column']] # Convert single string to list
        del rule['column'] # Remove the old key to avoid confusion
    elif 'column' not in rule and 'columns' not in rule:
        rule['columns'] = [] # Default to empty list if neither is present

    evidence = execute_and_gather_evidence(rule, df_cleaned, total_records)
    summary_stats[evidence["Status"].lower()] += 1
    
    rule_result = {
        "Rule Description": evidence["Rule Description"], 
        "Column": evidence["Column"], 
        "Dimension": evidence["Dimension"], 
        "Status": evidence["Status"], 
        "Affected Records": evidence["Affected Records"]
    }
    
    if evidence["Status"] != "Error":
        rule_result["score"] = evidence["script_calculated_score"]
        llm_assessment = llm_service.get_rule_assessment(evidence["llm_context"])
        rule_result["Details"] = llm_assessment["reasoning"] if llm_assessment else "LLM failed to generate reasoning."
        print(f"  > Score (Calculated): {rule_result['score']:.1f}/10")
    else:
        rule_result["score"] = 0.0
        rule_result["Details"] = evidence["Details"]
        print(f"  > Score: 0.0/10 (Rule interpreter or execution error)")
            
    rule_results.append(rule_result)

# --- Part B: Assess each dimension ---
print("\n" + "="*80)
print("--- Aggregating Scores and Generating Dimension Observations ---")
print("="*80)

dimension_analysis = []
# Iterate over DQ_PARAMS to ensure all active dimensions are processed
for dim_name in DQ_PARAMS: 
    print(f"\nAnalyzing Dimension: {dim_name.capitalize()}...")
    
    # Filter rules for the current dimension and ensure they have a valid score
    dim_scores = [res["score"] for res in rule_results 
                  if res["Dimension"].lower() == dim_name and res["Status"] != "Error"]
    
    dim_score = np.mean(dim_scores) if dim_scores else 0.0 # Calculate mean score for the dimension

    # Summarize rules for the current dimension for LLM context
    rule_summaries = [f"- Rule: '{res['Rule Description']}', Score: {res['score']:.1f}/10, Status: {res['Status']}" 
                      for res in rule_results if res["Dimension"].lower() == dim_name]
    
    dim_context_str = (
        f"The calculated score for the '{dim_name.capitalize()}' dimension is {dim_score:.1f}/10. "
        f"This is based on the following rules:\n" + "\n".join(rule_summaries) + 
        "\n\nPlease provide a concise observation explaining this score."
    )

    llm_obs = llm_service.get_dimension_observation(dim_context_str)
    observation = llm_obs['observation'] if llm_obs else "LLM failed to generate an observation."
    
    print(f"  > Dimension Score (Calculated): {dim_score:.1f}/10")
    print(f"  > LLM Observation: {observation}")
    
    # Weights are already normalized (fractions, e.g., 0.25), so display as percentage
    dimension_analysis.append({
        "Dimension": dim_name.capitalize(), 
        "Weight (%)": f"{weights.get(dim_name, 0.0) * 100:.1f}", # Multiply by 100 for display
        "Score (/10)": f"{dim_score:.1f}", # Score is already out of 10
        "Observation": observation
    })

# --- Part C: Generate Overall Report ---
print("\n" + "="*80)
print("--- Generating Final Overall Report ---")
print("="*80)

# Calculate final weighted score using the loaded normalized weights
overall_score = 0
for item in dimension_analysis:
    score = float(item['Score (/10)']) # Get score value
    # The weight is a fraction (e.g., 0.25), directly use it
    dim_name_lower = item['Dimension'].lower()
    weight_value = weights.get(dim_name_lower, 0.0) 
    
    overall_score += score * weight_value

final_context_list = [
    f"- {item['Dimension']} (Weight: {item['Weight (%)']}%), Final Score: {item['Score (/10)']}/10" 
    for item in dimension_analysis
]
final_context_str = (
    f"The final weighted data quality score is {overall_score:.1f}/10, based on this summary:\n" + 
    "\n".join(final_context_list) + 
    "\n\nPlease provide a comprehensive report explaining this score. The report value must be a single flat string."
)

overall_report = llm_service.get_overall_report(final_context_str)
report_text = overall_report['report'] if overall_report else "LLM failed to generate the final report."

# ==============================================================================
# 5. Display Final Report
# ==============================================================================
print("\n\n" + "#"*70)
print("                       FINAL DATA QUALITY REPORT")
print("#"*70)
print(f"Overall DQ Score: {overall_score:.1f}/10")
print(f"\n--- Overall Observation ---\n{report_text}")
print("#"*70, "\n")

print("--- SUMMARY OF CHECKS ---")
print(pd.DataFrame([
    {"Check": "Total Rules Assessed", "Value": sum(summary_stats.values())},
    {"Check": "Rules Passed", "Value": summary_stats["pass"]},
    {"Check": "Rules Failed", "Value": summary_stats["fail"]},
    {"Check": "Rules with Errors", "Value": summary_stats["error"]},
]).to_string(index=False))
print("\n" + "-"*70, "\n")

print("--- DIMENSION ANALYSIS ---")
# Adjust printing for dimension_analysis, especially the score format
print(pd.DataFrame(dimension_analysis).to_string(index=False))
print("\n" + "-"*70, "\n")

print("--- DETAILED RULE RESULTS ---")
# Drop the 'score' column if it's internal and not needed in the final display
print(pd.DataFrame(rule_results).drop(columns=['score']).to_string(index=False)) 
print("\n" + "="*70)
print("--- END OF REPORT ---")
print("="*70)

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# =============================================================================
# FINAL, SELF-CONTAINED, AND INTERACTIVE DATA QUALITY PIPELINE
# =============================================================================
import os
import logging
import json
import gc
from typing import Any, List, Dict
from collections import defaultdict
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType,
    DoubleType, TimestampType
)
import ray
import weaviate
import weaviate.classes.config as wvc
from weaviate.auth import AuthApiKey
from tenacity import retry, stop_after_attempt, wait_exponential
import concurrent.futures
import re

# Assumes custom modules are in your project workspace.
from ingestion.ingestion import IngestionManager
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester
from reporting.report_generator import ReportGenerator
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from sentence_transformers import SentenceTransformer

# --- 1. SETUP & CONFIGURATION ---
print("--- Step 1: Initializing Setup and Widgets ---")
os.environ["TOKENIZERS_PARALLELISM"] = "false"
spark = SparkSession.builder.appName("DQ_Pipeline_Final_Unified").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.final')

MAX_ROWS_TO_PROCESS = 50
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]
INITIAL_WEIGHTS = {p: 25.0 for p in DQ_PARAMS}
RULES_PATH = "/dbfs/FileStore/reports/final_rules.json"
WEIGHTS_PATH = "/dbfs/FileStore/reports/final_weights.json"

try:
    dbutils.widgets.removeAll()
    dbutils.widgets.text("file_path", "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx", "1. Input File Path")
    dbutils.widgets.text("report_output_dir", "/dbfs/FileStore/reports", "2. Report Output Directory")
    print("✅ Widgets created.")
except:
    print("⚠️ Could not create Databricks widgets.")

# --- 2. DYNAMIC DATA INGESTION AND CLEANING ---
print("\n--- Step 2: Ingesting and Preparing Data ---")
file_path = dbutils.widgets.get("file_path")
try:
    df_full = spark.read.format("com.crealytics.spark.excel").option("header", "true").option("inferSchema", "true").load(file_path)
    
    print("Cleaning out-of-bounds timestamps to prevent Arrow errors...")
    pd_min_ts, pd_max_ts = pd.Timestamp.min.to_pydatetime(), pd.Timestamp.max.to_pydatetime()
    df_cleaned = df_full
    timestamp_cols = [f.name for f in df_full.schema.fields if isinstance(f.dataType, TimestampType)]
    for col_name in timestamp_cols:
        df_cleaned = df_cleaned.withColumn(col_name, F.when((F.col(col_name) >= pd_min_ts) & (F.col(col_name) <= pd_max_ts), F.col(col_name)).otherwise(F.lit(None)))
    
    df = df_cleaned.limit(MAX_ROWS_TO_PROCESS).cache()
    df.count()
    print(f"✅ Ingestion successful. Using cleaned DataFrame 'df' with {df.count()} rows.")
except Exception as e:
    print(f"❌ Data ingestion failed. Error: {e}")
    spark.stop()
    raise e

# --- 3. INTERACTIVE RULE GENERATION AND EDITING ---
print("\n--- Step 3: Interactive Rule Generation & Editing ---")
pdf_for_profiling = df.toPandas()
suggester = IntelligentRuleSuggester()
result = suggester.suggest_rules(df_cleaned) # Pass the Spark DataFrame 'df_cleaned' directly
weights = INITIAL_WEIGHTS
if not rules: raise RuntimeError("LLM failed to generate rules.")

while True:
    param_rules = defaultdict(list); [param_rules[r.get("type", "other")].append(r) for r in rules]
    print("\n" + "="*80 + "\n--- CURRENT DATA QUALITY CONFIGURATION ---")
    for param in DQ_PARAMS:
        if rules_list := param_rules.get(param):
            print(f"\nPARAMETER: {param.upper()} (Weight: {weights.get(param, 0):.1f}%)")
            for i, rule in enumerate(rules_list): print(f"  {i+1}. {rule['description']}")
    print("="*80)
    action = input("\nChoose action: [e]dit configuration, or [q]uit and save: ").strip().lower()
    if action == 'q': print("Final configuration set. Saving..."); break
    elif action == 'e':
        param_to_edit = input(f"Parameter to edit? {DQ_PARAMS}: ").strip().lower()
        if param_to_edit not in DQ_PARAMS: print("Invalid parameter."); continue
        edit_choice = input(f"Editing '{param_to_edit}'. Change: [w]eight, [a]dd rule, [r]emove rule: ").strip().lower()
        if edit_choice == 'w':
            try: weights[param_to_edit] = float(input(f"New weight for '{param_to_edit}': "))
            except: print("Invalid weight.")
        elif edit_choice == 'r':
            try:
                idx_to_remove = int(input(f"Rule number to remove for '{param_to_edit}': ")) - 1
                if 0 <= idx_to_remove < len(param_rules[param_to_edit]): param_rules[param_to_edit].pop(idx_to_remove)
                else: print("Invalid rule number.")
            except: print("Invalid input.")
        elif edit_choice == 'a':
            if new_desc := input("Enter description for new rule: ").strip():
                param_rules[param_to_edit].append({"rule_id": f"user_{param_to_edit}", "description": new_desc, "type": param_to_edit, "reasoning": "User-defined."})
    else: print("Invalid action.")
    rules = [rule for rules_list in param_rules.values() for rule in rules_list]

total_weight = sum(weights.values());
final_weights = {p: w/total_weight * 100 for p,w in weights.items()} if total_weight > 0 else INITIAL_WEIGHTS
dbutils.fs.put(RULES_PATH, json.dumps(rules), overwrite=True)
dbutils.fs.put(WEIGHTS_PATH, json.dumps(final_weights), overwrite=True)
final_rules = rules
print("\n--- ✅ Final rules and weights saved. ---")

# --- 4. RAG-BASED ASSESSMENT, VISUALIZATION, AND REPORTING ---
print("\n--- Step 4: Final RAG Assessment, Visualization, and Reporting ---")

def initialize_clients() -> (weaviate.WeaviateClient, ChatGroq, Any):
    print("Initializing clients...")
    llm_client = ChatGroq(model="llama3-8b-8192", temperature=0.1, api_key=os.getenv("GROQ_API_KEY"))
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=4, max=10))
    def get_weaviate_client() -> weaviate.WeaviateClient:
        client = weaviate.connect_to_wcs(cluster_url=os.getenv("WEAVIATE_URL"), auth_credentials=AuthApiKey(api_key=os.getenv("WEAVIATE_API_KEY")), skip_init_checks=True)
        client.connect()
        return client
    weaviate_client = get_weaviate_client()
    @ray.remote 
    class EmbeddingActor:
        def __init__(self): self.model = SentenceTransformer("all-MiniLM-L6-v2")
        def embed(self, texts: List[str]) -> List[List[float]]: return self.model.encode(texts).tolist()
    ray.init(ignore_reinit_error=True); embedding_actor = EmbeddingActor.remote()
    print("✅ Clients Initialized.")
    return weaviate_client, llm_client, embedding_actor

def index_data_in_weaviate(client: weaviate.WeaviateClient, df: 'DataFrame', actor: Any) -> str:
    print("Indexing data sample into Weaviate for RAG...")
    pdf_sample = df.toPandas(); records_as_json = pdf_sample.apply(lambda row: row.to_json(), axis=1).tolist(); del pdf_sample; gc.collect()
    vectors = ray.get(actor.embed.remote(records_as_json))
    collection_name = "DataQualitySample"
    if client.collections.exists(collection_name): client.collections.delete(collection_name)
    collection = client.collections.create(name=collection_name, vectorizer_config=wvc.Configure.Vectorizer.none())
    with collection.batch.dynamic() as batch:
        for i in range(len(records_as_json)): batch.add_object(properties={"record_json": records_as_json[i]}, vector=vectors[i])
    print(f"✅ Indexed {len(records_as_json)} records.")
    return collection_name

def score_rules_with_rag(client: weaviate.WeaviateClient, llm: ChatGroq, actor: Any, rules: List[Dict], collection_name: str) -> List[Dict]:
    print("Scoring each rule with RAG and LLM...")
    collection = client.collections.get(collection_name)
    def score_single_rule(rule: Dict) -> Dict:
        try:
            query_vector = ray.get(actor.embed.remote([rule['description']]))[0]
            retrieved = collection.query.near_vector(near_vector=query_vector, limit=20)
            retrieved_records_str = json.dumps([obj.properties['record_json'] for obj in retrieved.objects])
            prompt = (f"Rule: '{rule['description']}'. Based ONLY on these {len(retrieved.objects)} records, how many fail? Records:\n{retrieved_records_str}\n\nRespond with ONLY a single integer failure count.")
            response = llm.invoke(prompt)
            fail_count = int(re.search(r'\d+', response.content).group(0))
            score = (len(retrieved.objects) - fail_count) / len(retrieved.objects) if retrieved.objects else 1.0
            return {**rule, "Status": "Fail" if fail_count > 0 else "Pass", "Score": score, "Affected Records": fail_count}
        except Exception as e: return {**rule, "Status": "Error", "Score": 0.0, "Affected Records": "N/A"}
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor: return list(executor.map(score_single_rule, rules))

def get_final_summary(scored_rules: List[Dict], weights: Dict, llm: ChatGroq) -> Dict:
    print("Calculating parameter scores and observations...")
    param_summary = {}
    for param in DQ_PARAMS:
        rules_for_param = [r for r in scored_rules if r.get('type') == param]
        if not rules_for_param: param_summary[param] = {"score": 0.0, "observation": "No rules were evaluated."}; continue
        param_score = np.average([r['Score'] for r in rules_for_param if r['Status'] != 'Error']) * 10
        obs_prompt = f"The DQ dimension '{param}' scored {param_score:.1f}/10. Write a one-sentence observation."
        observation = llm.invoke(obs_prompt).content
        param_summary[param] = {"score": round(param_score, 1), "observation": observation}
    print("Generating overall assessment...")
    overall_prompt = (f"Given scores:\n{json.dumps(param_summary, indent=2)}\nAnd weights:\n{json.dumps(weights, indent=2)}\n\nCalculate a weighted score out of 100 and a brief overall assessment. Respond with a JSON object: {{\"overall_score\": int, \"overall_observation\": \"string\"}}.")
    try: overall_data = json.loads(llm.invoke(overall_prompt).content)
    except: overall_data = {"overall_score": 0, "overall_observation": "LLM failed to generate summary."}
    return {"param_summary": param_summary, "overall_data": overall_data}

try:
    weaviate_client, llm_client, embedding_actor = initialize_clients()
    collection_name = index_data_in_weaviate(weaviate_client, df, embedding_actor)
    scored_rules_list = score_rules_with_rag(weaviate_client, llm_client, embedding_actor, final_rules, collection_name)
    final_summary = get_final_summary(scored_rules_list, final_weights, llm_client)

    print("\n" + "="*80 + "\n--- FINAL DATA QUALITY REPORT ---\n" + "="*80)
    dim_analysis_data = [{"Dimension": p.capitalize(), "Weight (%)": f"{final_weights.get(p, 0):.1f}%", "Score (/10)": f"{s['score']:.1f}/10", "Observation": s['observation']} for p, s in final_summary["param_summary"].items()]
    display(pd.DataFrame(dim_analysis_data))
    rule_results_data = [{"Rule Description": r['description'], "Column": ", ".join(r.get('columns', [])), "Dimension": r.get('type', 'other').capitalize(), "Status": r['Status'], "Details": f"Score: {r['Score']:.2f}", "Affected Records": r['Affected Records']} for r in scored_rules_list]
    display(pd.DataFrame(rule_results_data))
    print("\n--- OVERALL ASSESSMENT ---"); print(f"Overall Score: {final_summary['overall_data'].get('overall_score', 0)}/100"); print(f"Summary: {final_summary['overall_data'].get('overall_observation', 'N/A')}")
    
    report_gen = ReportGenerator(output_dir=dbutils.widgets.get("report_output_dir"))
    # The ReportGenerator needs a pandas DF. We'll create one from the summary.
    report_df = pd.DataFrame(rule_results_data)
    report_df.rename(columns={"Rule Description": "Rule Description", "Column": "Columns", "Dimension": "Type", "Affected Records": "Fail Count"}, inplace=True)
    report_df["Score"] = report_df["Details"].apply(lambda x: float(x.split(': ')[1]))
    pdf_path = report_gen.generate(report_df)
    print(f"✅ Final report generated at: {pdf_path}")
finally:
    if 'client' in locals() and client.is_connected(): client.close()
    if 'ray' in locals() and ray.is_initialized(): ray.shutdown()
    spark.stop()
    print("\n--- Pipeline Finished ---")

# COMMAND ----------

# MAGIC %pip install ray

# COMMAND ----------

# MAGIC %pip restart_python

# COMMAND ----------

# Cell 4: RAG-Based Assessment, Scoring, Visualization, and Reporting

import os
import json
import logging
import pandas as pd
import numpy as np
import ray
import weaviate
import weaviate.classes.config as wvc
from weaviate.auth import AuthApiKey
from weaviate.connect import ConnectionParams
from tenacity import retry, stop_after_attempt, wait_exponential
from typing import List, Dict, Any
import concurrent.futures
import re
import matplotlib.pyplot as plt

from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from sentence_transformers import SentenceTransformer

# --- 1. Setup and Initialization ---
logger = logging.getLogger('dq_pipeline.assessment')
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]

def initialize_clients() -> (weaviate.WeaviateClient, ChatGroq, Any):
    """Initializes and returns all necessary clients (Weaviate, LLM, Ray)."""
    print("Initializing clients...")
    
    # Initialize LLM
    llm_client = ChatGroq(model="llama3-8b-8192", temperature=0.1, api_key='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')

    # Initialize Weaviate Client with retry logic
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=4, max=10))
    def get_weaviate_client() -> weaviate.WeaviateClient:
        client = weaviate.connect_to_wcs(
            cluster_url="https://uhhkpzivqgs19vnjsfkpgw.c0.asia-southeast1.gcp.weaviate.cloud",
            auth_credentials=AuthApiKey(api_key="L21sL1FWV3U3aHkwYkJUWl9VZS9ENmtpOXBVSFduRjNTWGZUVU1LNEJLMHNmRUx0aFl5UWtaVmU2QytVPV92MjAw"),
            skip_init_checks=True
        )
        client.connect()
        return client
    
    weaviate_client = get_weaviate_client()

    # Initialize Ray Embedding Actor
    @ray.remote
    class EmbeddingActor:
        def __init__(self): self.model = SentenceTransformer("all-MiniLM-L6-v2")
        def embed(self, texts: List[str]) -> List[List[float]]: return self.model.encode(texts).tolist()

    ray.init(ignore_reinit_error=True)
    embedding_actor = EmbeddingActor.remote()
    
    print("✅ Clients Initialized.")
    return weaviate_client, llm_client, embedding_actor

def index_data_in_weaviate(client: weaviate.WeaviateClient, df: 'DataFrame', actor: Any) -> str:
    """Converts Spark DF to JSON, embeds it with Ray, and indexes it into Weaviate."""
    print("Indexing data sample into Weaviate for RAG...")
    pdf_sample = df.toPandas()
    records_as_json = pdf_sample.apply(lambda row: row.to_json(), axis=1).tolist()
    vectors = ray.get(actor.embed.remote(records_as_json))

    COLLECTION_NAME = "DataQualitySample"
    if client.collections.exists(COLLECTION_NAME):
        client.collections.delete(COLLECTION_NAME)
    collection = client.collections.create(name=COLLECTION_NAME, vectorizer_config=wvc.Configure.Vectorizer.none())

    with collection.batch.dynamic() as batch:
        for i in range(len(records_as_json)):
            batch.add_object(properties={"record_json": records_as_json[i]}, vector=vectors[i])
    
    print(f"✅ Indexed {len(records_as_json)} records into Weaviate.")
    return COLLECTION_NAME

def score_rules_with_rag(client: weaviate.WeaviateClient, llm: ChatGroq, actor: Any, rules: List[Dict], collection_name: str) -> List[Dict]:
    """Scores each rule by retrieving relevant context from Weaviate and querying an LLM."""
    print("Scoring each rule with RAG and LLM...")
    collection = client.collections.get(collection_name)

    def score_single_rule(rule: Dict) -> Dict:
        """Worker function for parallel execution."""
        try:
            query_vector = ray.get(actor.embed.remote([rule['description']]))[0]
            retrieved = collection.query.near_vector(near_vector=query_vector, limit=20)
            retrieved_records_str = json.dumps([obj.properties['record_json'] for obj in retrieved.objects])
            
            prompt = (
                f"Rule: '{rule['description']}'. Based ONLY on the following {len(retrieved.objects)} data records, "
                f"how many records fail this rule? Records:\n{retrieved_records_str}\n\n"
                f"Respond with ONLY a single integer number representing the failure count."
            )
            response = llm.invoke(prompt)
            fail_count = int(re.search(r'\d+', response.content).group(0))
            pass_count = len(retrieved.objects) - fail_count
            score = (pass_count / len(retrieved.objects)) if retrieved.objects else 1.0
            return {**rule, "Status": "Fail" if fail_count > 0 else "Pass", "Score": score, "Affected Records": fail_count}
        except Exception as e:
            logger.warning(f"Could not score rule '{rule.get('description')}'. Error: {e}")
            return {**rule, "Status": "Error", "Score": 0.0, "Affected Records": "N/A"}

    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        scored_rules = list(executor.map(score_single_rule, rules))
    print("✅ All rules scored.")
    return scored_rules

def get_final_summary(scored_rules: List[Dict], weights: Dict, llm: ChatGroq) -> Dict:
    """Calculates per-parameter scores and generates final overall observations from an LLM."""
    print("Calculating parameter scores and generating observations...")
    param_summary = {}
    for param in DQ_PARAMS:
        rules_for_param = [r for r in scored_rules if r.get('type') == param]
        if not rules_for_param:
            param_summary[param] = {"score": 0.0, "observation": "No rules were evaluated."}
            continue
        param_score = np.average([r['Score'] for r in rules_for_param if r['Status'] != 'Error']) * 10
        obs_prompt = f"The data quality dimension '{param}' scored {param_score:.1f}/10. Write a brief, one-sentence observation."
        observation = llm.invoke(obs_prompt).content
        param_summary[param] = {"score": round(param_score, 1), "observation": observation}

    print("Generating overall assessment...")
    overall_prompt = (
        f"Given these per-dimension scores and observations:\n{json.dumps(param_summary, indent=2)}\n"
        f"And these weights:\n{json.dumps(weights, indent=2)}\n"
        f"Calculate a final weighted score out of 100 and provide a brief, overall assessment summary. "
        f"Respond with a JSON object containing 'overall_score' (int) and 'overall_observation' (string)."
    )
    try:
        response = llm.invoke(overall_prompt).content
        overall_data = json.loads(response)
    except (json.JSONDecodeError, AttributeError):
        overall_data = {"overall_score": 0, "overall_observation": "Failed to parse overall assessment."}
        
    return {"param_summary": param_summary, "overall_data": overall_data}

# --- Main Execution for Cell 4 ---
try:
    # Step 1
    weaviate_client, llm_client, embedding_actor = initialize_clients()
    final_rules = json.load(open("/dbfs/FileStore/reports/final_rules.json"))
    final_weights = json.load(open("/dbfs/FileStore/reports/final_weights.json"))

    # Step 2
    collection_name = index_data_in_weaviate(weaviate_client, df, embedding_actor)

    # Step 3
    scored_rules_list = score_rules_with_rag(weaviate_client, llm_client, embedding_actor, final_rules, collection_name)
    
    # Step 4
    final_summary = get_final_summary(scored_rules_list, final_weights, llm_client)
    
    # --- 5. Display All Results ---
    print("\n" + "="*80 + "\n--- FINAL DATA QUALITY REPORT ---\n" + "="*80)
    
    dim_analysis_data = [{"Dimension": p.capitalize(), "Weight (%)": f"{final_weights.get(p, 0):.1f}%", "Score (/10)": f"{s['score']:.1f}/10", "Observation": s['observation']} for p, s in final_summary["param_summary"].items()]
    display(pd.DataFrame(dim_analysis_data))

    rule_results_data = [{"Rule Description": r['description'], "Column": ", ".join(r.get('columns', [])), "Dimension": r.get('type', 'other').capitalize(), "Status": r['Status'], "Details": f"LLM-based score: {r['Score']:.2f}", "Affected Records": r['Affected Records']} for r in scored_rules_list]
    display(pd.DataFrame(rule_results_data))

    print("\n--- OVERALL ASSESSMENT ---")
    print(f"Overall Score: {final_summary['overall_data'].get('overall_score', 0)}/100")
    print(f"Summary: {final_summary['overall_data'].get('overall_observation', 'N/A')}")

    # --- 6. Save for PDF Report Generation ---
    dbutils.fs.put("/dbfs/FileStore/reports/final_assessment.json", json.dumps(final_summary), overwrite=True)
    print("\n✅ Final assessment summary saved. Ready for PDF Reporting cell.")

finally:
    # --- 7. Final Cleanup ---
    if 'client' in locals() and client.is_connected(): client.close()
    if 'ray' in locals() and ray.is_initialized(): ray.shutdown()
    # Don't stop Spark here if you have a subsequent reporting cell

# COMMAND ----------

# Run this in the first cell of your notebook to set up a stable environment
%pip install --upgrade "ray[default]==2.9.3" #"protobuf==3.20.3" "grpcio==1.48.2"

# COMMAND ----------

# =============================================================================
# FINAL, LIGHTWEIGHT, AND INTERACTIVE DATA QUALITY PIPELINE
# This script uses Spark-native profiling to prevent OOM errors.
# =============================================================================

# --- 1. SETUP & CONFIGURATION ---
import os
import logging
import json
import gc
from typing import Any, List, Dict
from collections import defaultdict
import pandas as pd
import matplotlib.pyplot as plt
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (StructType, StructField, StringType, LongType, DoubleType, TimestampType)

# Assumes custom modules are in your project workspace
from ingestion.ingestion import IngestionManager
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester
from reporting.report_generator import ReportGenerator

print("--- Step 1: Initializing Setup ---")
spark = SparkSession.builder.appName("DQ_Pipeline_Lightweight_Final").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.final')

MAX_ROWS_TO_PROCESS = 5000
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]
RULES_PATH = "/dbfs/FileStore/reports/final_rules.json"
WEIGHTS_PATH = "/dbfs/FileStore/reports/final_weights.json"

# --- 2. DYNAMIC DATA INGESTION AND CLEANING ---
print("\n--- Step 2: Ingesting and Preparing Data ---")
try:
    file_path = "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx"
    df_full = spark.read.format("com.crealytics.spark.excel").option("header", "true").option("inferSchema", "true").load(file_path)
    # This script assumes type casting happens correctly during ingestion or is handled in a prior step.
    df = df_full.limit(MAX_ROWS_TO_PROCESS).cache()
    df.count()
    print(f"✅ Ingestion successful. Using DataFrame 'df' with {df.count()} rows.")
except Exception as e:
    print(f"❌ Data ingestion failed. Error: {e}"); spark.stop(); raise e

# --- 3. INTERACTIVE RULE GENERATION AND EDITING ---
print("\n--- Step 3: Interactive Rule Generation & Editing ---")
# The LLM now generates rules based on a Spark DataFrame profile, avoiding .toPandas()
suggester = IntelligentRuleSuggester()
rules = suggester.suggest_rules(df).get("rules", []) # Pass the Spark DF directly
weights = {p: 25.0 for p in DQ_PARAMS}
if not rules: raise RuntimeError("LLM failed to generate rules.")

# The interactive command-line loop for editing rules and weights
while True:
    param_rules = defaultdict(list); [param_rules[r.get("type", "other")].append(r) for r in rules]
    print("\n" + "="*80 + "\n--- CURRENT DATA QUALITY CONFIGURATION ---")
    for param in DQ_PARAMS:
        if rules_list := param_rules.get(param):
            print(f"\nPARAMETER: {param.upper()} (Weight: {weights.get(param, 0):.1f}%)")
            for i, rule in enumerate(rules_list): print(f"  {i+1}. {rule['description']}")
    print("="*80)
    action = input("\nChoose action: [e]dit, or [q]uit and run assessment: ").strip().lower()
    if action == 'q': print("Final configuration set..."); break
    # ... (Full logic for the interactive editing loop is omitted for brevity) ...
    rules = [rule for rules_list in param_rules.values() for rule in rules_list]

total_weight = sum(weights.values());
final_weights = {p: w/total_weight * 100 for p,w in weights.items()} if total_weight > 0 else {p: 25.0 for p in DQ_PARAMS}
final_rules = rules
print("\n--- ✅ Final rules and weights locked in for assessment. ---")

# --- 4. SPARK-BASED ASSESSMENT, VISUALIZATION, AND REPORTING ---
print("\n--- Step 4: Final Assessment, Visualization, and Reporting ---")
# This section uses the memory-efficient Spark Rule Engine.
# (The full run_dq_assessment function and visualization code from the previous response goes here)

# --- Final Cleanup ---
spark.stop()
print("\n--- Pipeline Finished ---")

# COMMAND ----------

# =============================================================================
# FINAL, LIGHTWEIGHT, AND INTERACTIVE DATA QUALITY PIPELINE
# This script is re-architected for memory safety on a single node. It removes
# Ray and Weaviate in favor of a more efficient Spark-based assessment engine.
# =============================================================================

# --- 1. SETUP & CONFIGURATION ---
import os
import logging
import json
import gc
from typing import Any, List, Dict
from collections import defaultdict
import pandas as pd
import matplotlib.pyplot as plt
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType,
    DoubleType, TimestampType
)

# Assumes custom modules are available
from ingestion.ingestion import IngestionManager
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester
from reporting.report_generator import ReportGenerator

print("--- Step 1: Initializing Setup ---")
os.environ["TOKENIZERS_PARALLELISM"] = "false"
spark = SparkSession.builder.appName("DQ_Pipeline_Lightweight").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.final')

MAX_ROWS_TO_PROCESS = 5000
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]
RULES_PATH = "/dbfs/FileStore/reports/final_rules.json"
WEIGHTS_PATH = "/dbfs/FileStore/reports/final_weights.json"

# --- 2. DYNAMIC DATA INGESTION AND CLEANING ---
print("\n--- Step 2: Ingesting and Preparing Data ---")
try:
    # In a real workflow, this would use widgets
    file_path = "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx"
    df_full = spark.read.format("com.crealytics.spark.excel").option("header", "true").option("inferSchema", "true").load(file_path)
    
    pd_min_ts, pd_max_ts = pd.Timestamp.min.to_pydatetime(), pd.Timestamp.max.to_pydatetime()
    df_cleaned = df_full
    timestamp_cols = [f.name for f in df_full.schema.fields if isinstance(f.dataType, TimestampType)]
    for col_name in timestamp_cols:
        df_cleaned = df_cleaned.withColumn(col_name, F.when((F.col(col_name) >= pd_min_ts) & (F.col(col_name) <= pd_max_ts), F.col(col_name)).otherwise(F.lit(None)))
    
    df = df_cleaned.limit(MAX_ROWS_TO_PROCESS).cache()
    df.count()
    print(f"✅ Ingestion successful. Using cleaned DataFrame 'df' with {df.count()} rows.")
except Exception as e:
    print(f"❌ Data ingestion failed. Error: {e}")
    spark.stop()
    raise e

# --- 3. INTERACTIVE RULE GENERATION AND EDITING ---
print("\n--- Step 3: Interactive Rule Generation & Editing ---")
# This stateful loop allows you to iteratively edit rules.
try:
    with open(RULES_PATH, "r") as f: final_rules = json.load(f)
    with open(WEIGHTS_PATH, "r") as f: final_weights = json.load(f)
    print("✅ Loaded previously saved rules and weights.")
except FileNotFoundError:
    print("ℹ️ No saved state found. Generating initial rules from LLM...")
    pdf_for_profiling = df.toPandas()
    suggester = IntelligentRuleSuggester()
    final_rules = suggester.suggest_rules(pdf_for_profiling).get("rules", [])
    final_weights = {p: 25.0 for p in DQ_PARAMS}

# Interactive editing loop (command-line style)
while True:
    param_rules = defaultdict(list); [param_rules[r.get("type", "other")].append(r) for r in final_rules]
    print("\n" + "="*80 + "\n--- CURRENT DATA QUALITY CONFIGURATION ---")
    for param in DQ_PARAMS:
        if rules_list := param_rules.get(param):
            print(f"\nPARAMETER: {param.upper()} (Weight: {final_weights.get(param, 0):.1f}%)")
            for i, rule in enumerate(rules_list): print(f"  {i+1}. {rule['description']}")
    print("="*80)
    action = input("\nChoose action: [e]dit configuration, or [q]uit and save: ").strip().lower()
    if action == 'q': print("Final configuration set. Saving and proceeding to assessment..."); break
    # ... (Full logic for the interactive editing loop is omitted for brevity) ...
# Saving the final state
dbutils.fs.put(RULES_PATH, json.dumps(final_rules), overwrite=True)
dbutils.fs.put(WEIGHTS_PATH, json.dumps(final_weights), overwrite=True)
print("\n--- ✅ Final rules and weights saved. ---")

# --- 4. FINAL ASSESSMENT, VISUALIZATION, AND REPORTING ---
print("\n--- Step 4: Final Assessment, Visualization, and Reporting ---")

def run_dq_assessment(df: 'DataFrame', rules: List[Dict]) -> pd.DataFrame:
    """A memory-efficient rule engine that translates rule templates into Spark SQL."""
    results = []
    total_records = df.count()
    if total_records == 0: return pd.DataFrame()

    for rule in rules:
        fail_count = 0
        status = "Pass"
        details = f"Rule '{rule['description']}' passed."
        try:
            template, columns, params = rule.get("rule_template"), rule.get("columns", []), rule.get("parameters", {})
            if not template or template == "CUSTOM" or not columns:
                status = "Skipped"; details = "Custom or undefined rule."
            else:
                col_name = f"`{columns[0]}`"
                if template == "IS_NOT_NULL": sql_expr = f"{col_name} IS NOT NULL"
                elif template == "IS_BETWEEN": sql_expr = f"CAST({col_name} AS double) BETWEEN {params.get('min')} AND {params.get('max')}"
                else: status = "Skipped"; details = f"Unknown template '{template}'."

                if status == "Pass": # Only execute if template was known
                    fail_count = df.where(f"NOT ({sql_expr})").count()
                    if fail_count > 0:
                        status = "Fail"; details = f"{fail_count} records failed rule '{rule['description']}' on column '{columns[0]}'."
        except Exception as e:
            status = "Error"; details = f"Error processing rule: {e}"
        
        results.append({
            "Rule Description": rule['description'], "Column": ", ".join(columns),
            "Dimension": rule.get('type', 'other').capitalize(), "Status": status,
            "Details": details, "Affected Records": fail_count if status in ["Fail", "Pass"] else "N/A"
        })
    return pd.DataFrame(results)

assessment_results_pd = run_dq_assessment(df, final_rules)

# --- Calculate Scores ---
param_summary = {}
for param in DQ_PARAMS:
    param_df = assessment_results_pd[assessment_results_pd['Dimension'].str.lower() == param]
    if not param_df.empty:
        passed_count = len(param_df[param_df['Status'] == 'Pass'])
        total_param_rules = len(param_df)
        score = (passed_count / total_param_rules) * 10 if total_param_rules > 0 else 10.0
        observation = f"{passed_count}/{total_param_rules} rules passed."
    else:
        score, observation = 0.0, "No rules evaluated."
    param_summary[param] = {"score": round(score, 1), "observation": observation}

# --- Display Results ---
print("\n" + "="*80 + "\n--- FINAL DATA QUALITY REPORT ---\n" + "="*80)
# This table display matches your requested format
dim_analysis_data = [{"Dimension": p.capitalize(), "Weight (%)": f"{final_weights.get(p, 0):.1f}%", "Score (/10)": f"{s['score']:.1f}/10", "Observation": s['observation']} for p, s in param_summary.items()]
display(pd.DataFrame(dim_analysis_data))

print("\n--- DETAILED RULE RESULTS ---")
# This table display matches your requested format
display(assessment_results_pd)

# --- Generate PDF ---
# The report generator can now be called with the final pandas DataFrame
# report_gen = ReportGenerator(...)
# report_gen.generate(assessment_results_pd)

# --- Final Cleanup ---
dbutils.fs.rm(RULES_PATH, recurse=True)
dbutils.fs.rm(WEIGHTS_PATH, recurse=True)
spark.stop()
print("\n--- Pipeline Finished ---")

# COMMAND ----------

# MAGIC %pip install --force --upgrade "google-protobuf==4.25.3" "grpcio==1.60.0" "weaviate-client"

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# ----------- Main Interactive Pipeline Script with Loop -----------
import os
import logging
import pandas as pd
from pyspark.sql import SparkSession
from collections import defaultdict
import json
import gc
from typing import Any

# Assumes custom modules are in your project directory
from ingestion.ingestion import IngestionManager
from sampling.stage3_diversity_sampling import DiversitySampler
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester
# from assessment.dq_assessment import DQAssessment # Using self-contained assessment
# from reporting.report_generator import ReportGenerator

# --- Configuration & Setup ---
MAX_ROWS_TO_PROCESS = 50
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]
RULES_PATH = "/dbfs/FileStore/reports/final_rules.json"
WEIGHTS_PATH = "/dbfs/FileStore/reports/final_weights.json"

spark = SparkSession.builder.appName("DQ_Pipeline_Interactive_Loop").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.interactive')

# ==============================================================================
# 1. Ingest a LIMITED DATA SAMPLE
# ==============================================================================
# Using a default table for this example.
ingest_manager = IngestionManager(spark)
df = ingest_manager.ingest_delta('samples.nyctaxi.trips').limit(MAX_ROWS_TO_PROCESS)
df.cache().count()

# ==============================================================================
# 2. State Management & Interactive Rule Loop
# ==============================================================================
try:
    with open(RULES_PATH, "r") as f:
        final_rules = json.load(f)
    with open(WEIGHTS_PATH, "r") as f:
        final_weights = json.load(f)
    print("✅ Loaded previously saved rules and weights. You can continue editing.")
except FileNotFoundError:
    print("ℹ️ No saved state found. Generating initial rules from LLM...")
    pdf_for_profiling = df.toPandas()
    suggester = IntelligentRuleSuggester()
    result = suggester.suggest_rules(pdf_for_profiling)
    final_rules = result.get("rules", [])
    final_weights = {p: 25.0 for p in DQ_PARAMS}

# --- Display Current State and Create Widgets ---
param_rules = defaultdict(list)
for r in final_rules:
    param_rules[r.get("type", "other")].append(r)

print("\n--- CURRENT DATA QUALITY RULES ---")
for param in DQ_PARAMS:
    if rules_list := param_rules.get(param):
        print(f"\nPARAMETER: {param.upper()} (Current Weight: {final_weights.get(param, 0):.1f}%)")
        for i, rule in enumerate(rules_list):
            print(f"  {i+1}. ID: [{rule['rule_id']}] - {rule['description']}")

dbutils.widgets.removeAll()
dbutils.widgets.text("ACTION", "", "Enter edits in widgets and re-run this cell")
for param in DQ_PARAMS:
    dbutils.widgets.text(f"weight_{param}", str(final_weights.get(param, 25.0)))
    dbutils.widgets.text(f"remove_{param}", "")
    dbutils.widgets.text(f"add_{param}", "")
print("\n--- ✅ Widgets are ready. Re-run this cell to apply edits. ---")

# --- Process Edits on Re-run ---
def get_widget(name: str, default: Any=""):
    try: return dbutils.widgets.get(name)
    except: return default

user_edits = {"weights": {}, "add": {}}
for param in DQ_PARAMS:
    final_weights[param] = float(get_widget(f"weight_{param}", final_weights.get(param, 25.0)))
    if rules_to_remove_str := get_widget(f"remove_{param}"):
        indices_to_remove = {int(x.strip()) - 1 for x in rules_to_remove_str.split(',')}
        param_rules[param] = [rule for i, rule in enumerate(param_rules.get(param, [])) if i not in indices_to_remove]
    if new_rule_desc := get_widget(f"add_{param}"):
        new_rule = {"rule_id": f"user_{param}_{len(param_rules.get(param, [])) + 1}", "description": new_rule_desc, "columns": [], "type": param, "condition": "true", "rule_template": "CUSTOM", "parameters": {}}
        param_rules[param].append(new_rule)

# Recalculate rules and weights after all edits
final_rules = [rule for rules_list in param_rules.values() for rule in rules_list]
total_weight = sum(final_weights.values())
if total_weight > 0:
    final_weights = {p: w / total_weight * 100 for p, w in final_weights.items()}

# --- Save State for Next Iteration or Final Assessment ---
dbutils.fs.put(RULES_PATH, json.dumps(final_rules), overwrite=True)
dbutils.fs.put(WEIGHTS_PATH, json.dumps(final_weights), overwrite=True)
print("\n--- State Saved ---")
print("Re-run this cell to make more changes or proceed to the next cell to run the final assessment.")

# This cell ends here. The final assessment would be in a separate cell,
# where it would load the 'final_rules.json' and 'final_weights.json'.

# COMMAND ----------

# =============================================================================
# FINAL, FULLY DYNAMIC DATA QUALITY PIPELINE
# This single script orchestrates the entire process and is designed to be
# fully dynamic, using the data source you specify in the widgets.
# =============================================================================

# -----------------------------------------------------------------------------
# Cell 1: Setup, Imports, and Widget Creation
# -----------------------------------------------------------------------------
print("--- Step 1: Initializing Setup and Widgets ---")

import os
import logging
import json
import gc
from typing import Any, List, Dict
from collections import defaultdict
import pandas as pd
import matplotlib.pyplot as plt
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType,
    DoubleType, TimestampType, IntegerType
)

# Assumes custom modules are available in your project workspace
from ingestion.ingestion import IngestionManager
from sampling.stage3_diversity_sampling import DiversitySampler
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester
from reporting.report_generator import ReportGenerator

# --- Configuration ---
MAX_ROWS_TO_PROCESS = 5000  # Safe limit for a single node
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]
INITIAL_WEIGHTS = {p: 25.0 for p in DQ_PARAMS}
RULES_PATH = "/dbfs/FileStore/reports/final_rules.json"
WEIGHTS_PATH = "/dbfs/FileStore/reports/final_weights.json"

# --- Spark and Logging Setup ---
spark = SparkSession.builder.appName("DQ_Pipeline_Final_Dynamic").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.final')

# --- Create all necessary widgets upfront ---
try:
    dbutils.widgets.removeAll()
    dbutils.widgets.text("file_path", "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx", "1. Input File Path")
    dbutils.widgets.text("file_type", "excel", "2. Input File Type")
    dbutils.widgets.text("report_output_dir", "/dbfs/FileStore/reports", "3. Report Output Directory")
    print("✅ Widgets created. Please configure your input file path above.")
except Exception:
    print("⚠️ Could not create Databricks widgets. Using default paths.")

# -----------------------------------------------------------------------------
# Cell 2: Dynamic Data Ingestion and Type Casting
# -----------------------------------------------------------------------------
print("\n--- Step 2: Ingesting and Preparing Your Data ---")

file_path = dbutils.widgets.get("file_path")
file_type = dbutils.widgets.get("file_type").lower()
print(f"Attempting to ingest from your specified file: '{file_path}'")

try:
    df_full = (
        spark.read.format("com.crealytics.spark.excel")
             .option("header", "true")
             .option("inferSchema", "true")
             .load(file_path)
    )

    # --- This section casts columns based on the schema you provided ---
    numeric_cols = [
        "current", "voltage", "power_factor", "current_ib", "current_ir", "current_iy",
        "voltage_vbn", "voltage_vrn", "voltage_vyn", "power_factor_b_phase",
        "power_factor_r_phase", "power_factor_y_phase", "cumulative_energy_wh_import",
        "cumulative_energy_wh_export"
    ]
    timestamp_cols = ["receivedTime", "RTC"]
    
    df_typed = df_full
    for col_name in numeric_cols:
        if col_name in df_typed.columns:
            df_typed = df_typed.withColumn(col_name, F.col(col_name).cast(DoubleType()))
    for col_name in timestamp_cols:
        if col_name in df_typed.columns:
            df_typed = df_typed.withColumn(col_name, F.to_timestamp(F.col(col_name)))

    df = df_typed.limit(MAX_ROWS_TO_PROCESS).cache()
    df.count()
    print(f"✅ Ingestion successful. Sampled and typed DataFrame 'df' with {df.count()} rows is ready.")
except Exception as e:
    print(f"❌ Data ingestion failed. Error: {e}")
    spark.stop()
    raise e

# -----------------------------------------------------------------------------
# Cell 3: Interactive Rule Generation and Editing
# -----------------------------------------------------------------------------
# (This section is unchanged - it's already designed to be dynamic)
# ... (Full logic for the interactive widget cell goes here)

# -----------------------------------------------------------------------------
# Cell 4: Final Assessment, Visualization, and Reporting
# -----------------------------------------------------------------------------
# (This section is also unchanged - it will now receive the correct DataFrame)
# ... (The full logic for the final assessment cell goes here)

# --- For clarity, the combined logic is presented below ---

# --- Rule Generation & Interactive Editing ---
print("\n--- Step 3: Generating Dynamic Rules & Awaiting User Edits ---")
# (Full logic from previous correct versions for Cell 3)
# ...

# --- Final Assessment, Visualization & Reporting ---
print("\n--- Step 4: Running Final Assessment and Reporting ---")
# (Full logic from previous correct versions for Cell 4)
# ...

# COMMAND ----------

# Cell 3: Interactive Rule Generation and Editing Loop
# Re-run this cell multiple times to iteratively modify rules and weights.

import pandas as pd
from collections import defaultdict
import json
from typing import Any, List, Dict
import logging

# It is assumed that the 'df' Spark DataFrame from your ingestion cell is available
# and that your custom 'IntelligentRuleSuggester' class is in your workspace.
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester

# --- Configuration & Logger ---
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]
RULES_PATH = "/dbfs/FileStore/reports/final_rules.json"
WEIGHTS_PATH = "/dbfs/FileStore/reports/final_weights.json"
logger = logging.getLogger('dq_pipeline.interactive')

# --- 1. State Management: Load previous edits or generate initial rules ---
try:
    with open(RULES_PATH, "r") as f:
        final_rules = json.load(f)
    with open(WEIGHTS_PATH, "r") as f:
        final_weights = json.load(f)
    print("✅ Loaded previously saved rules and weights. You can continue editing.")
except FileNotFoundError:
    print("ℹ️ No saved state found. Generating initial rules from LLM...")
    # The 'df' DataFrame is available from the previous cell
    pdf_for_profiling = df.toPandas()
    suggester = IntelligentRuleSuggester()
    result = suggester.suggest_rules(pdf_for_profiling)
    final_rules = result.get("rules", [])
    final_weights = {p: 25.0 for p in DQ_PARAMS} # Initial weights as percentages
    if not final_rules:
        # Fallback to ensure the list is never empty
        final_rules = [{"rule_id": "DEFAULT", "description": "No rules generated", "type": "other", "columns": [], "rule_template": "CUSTOM", "parameters": {}}]

# --- 2. Display Current State and Create Widgets for Editing ---
param_rules = defaultdict(list)
for r in final_rules:
    param_rules[r.get("type", "other")].append(r)

print("\n--- CURRENT DATA QUALITY RULES ---")
# This interactive UI allows users to view and modify LLM-generated rules 
for param in DQ_PARAMS:
    if rules_list := param_rules.get(param):
        # The DQ dimensions are based on the categories from the sample report 
        print(f"\nPARAMETER: {param.upper()} (Current Weight: {final_weights.get(param, 0):.1f}%)")
        for i, rule in enumerate(rules_list):
            print(f"  {i+1}. ID: [{rule['rule_id']}] - {rule['description']}")

try:
    dbutils.widgets.removeAll()
    dbutils.widgets.text("ACTION", "", "Enter edits in widgets and re-run this cell")
    for param in DQ_PARAMS:
        dbutils.widgets.text(f"weight_{param}", str(final_weights.get(param, 25.0)))
        dbutils.widgets.text(f"remove_{param}", "")
        dbutils.widgets.text(f"add_{param}", "")
    print("\n--- ✅ Widgets are ready. To save edits, re-run this cell. To finalize, run the next cell. ---")
except Exception:
    logger.warning("Could not create Databricks widgets. This must be run in a Databricks notebook environment.")

# --- 3. Process User Edits on Re-run ---
def get_widget(name: str, default: Any=""):
    try: return dbutils.widgets.get(name)
    except: return default

for param in DQ_PARAMS:
    # Edit weights
    final_weights[param] = float(get_widget(f"weight_{param}", final_weights.get(param, 25.0)))
    
    # Remove rules by their 1-based number
    if rules_to_remove_str := get_widget(f"remove_{param}"):
        indices_to_remove = {int(x.strip()) - 1 for x in rules_to_remove_str.split(',')}
        current_rules = param_rules.get(param, [])
        param_rules[param] = [rule for i, rule in enumerate(current_rules) if i not in indices_to_remove]
        
    # Add a new rule
    if new_rule_desc := get_widget(f"add_{param}"):
        new_rule = {"rule_id": f"user_{param}_{len(param_rules.get(param, [])) + 1}", "description": new_rule_desc, "columns": [], "type": param, "condition": "true", "rule_template": "CUSTOM", "parameters": {}}
        param_rules[param].append(new_rule)

# Recalculate rules and weights after all edits
final_rules = [rule for rules_list in param_rules.values() for rule in rules_list]
total_weight = sum(final_weights.values())
if total_weight > 0:
    final_weights = {p: w / total_weight * 100 for p, w in final_weights.items()}

# --- 4. Save State for Next Iteration or Final Assessment ---
dbutils.fs.put(RULES_PATH, json.dumps(final_rules), overwrite=True)
dbutils.fs.put(WEIGHTS_PATH, json.dumps(final_weights), overwrite=True)
print("\n--- State Saved ---")

# COMMAND ----------

# =============================================================================
# FINAL, DYNAMIC, AND INTERACTIVE DATA QUALITY PIPELINE
# This single, self-contained script handles all steps from setup to reporting,
# engineered for a single-node cluster.
# =============================================================================

# -----------------------------------------------------------------------------
# 1. SETUP, IMPORTS, AND WIDGET CREATION
# -----------------------------------------------------------------------------
print("--- Step 1: Initializing Setup and Widgets ---")

import os
import logging
import json
import gc
from typing import Any, List, Dict
from collections import defaultdict
import pandas as pd
import matplotlib.pyplot as plt
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType,
    DoubleType, TimestampType, IntegerType
)

# Assumes custom modules are in your project workspace
from ingestion.ingestion import IngestionManager
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester
from reporting.report_generator import ReportGenerator

# --- Configuration & Setup ---
# Suppress the benign tokenizers parallelism warning
os.environ["TOKENIZERS_PARALLELISM"] = "false"
spark = SparkSession.builder.appName("DQ_Pipeline_Final_Unified").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.final')

MAX_ROWS_TO_PROCESS = 50
# The four DQ dimensions for the project. 
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]
INITIAL_WEIGHTS = {p: 25.0 for p in DQ_PARAMS}
RULES_PATH = "/dbfs/FileStore/reports/final_rules.json"
WEIGHTS_PATH = "/dbfs/FileStore/reports/final_weights.json"

# --- Create all necessary widgets upfront to prevent errors ---
try:
    dbutils.widgets.removeAll()
    dbutils.widgets.text("file_path", "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx", "1. Input File Path")
    dbutils.widgets.text("report_output_dir", "/dbfs/FileStore/reports", "2. Report Output Directory")
    print("✅ Widgets created. Please configure them above.")
except Exception:
    print("⚠️ Could not create Databricks widgets. Using default paths.")

# -----------------------------------------------------------------------------
# 2. DYNAMIC DATA INGESTION AND TYPE CASTING
# -----------------------------------------------------------------------------
print("\n--- Step 2: Ingesting and Preparing Data ---")
file_path = dbutils.widgets.get("file_path")
try:
    # This dynamic ingestion uses Databricks connectors to handle various sources. 
    df_full = spark.read.format("com.crealytics.spark.excel").option("header", "true").option("inferSchema", "true").load(file_path)
    
    # Explicitly cast data types for accuracy, based on your provided schema
    numeric_cols = ["current", "voltage", "power_factor", "current_ib", "current_ir", "current_iy", "voltage_vbn", "voltage_vrn", "voltage_vyn", "power_factor_b_phase", "power_factor_r_phase", "power_factor_y_phase", "cumulative_energy_wh_import", "cumulative_energy_wh_export"]
    timestamp_cols = ["receivedTime", "RTC"]
    
    df_typed = df_full
    for col_name in numeric_cols:
        if col_name in df_typed.columns: df_typed = df_typed.withColumn(col_name, F.col(col_name).cast(DoubleType()))
    for col_name in timestamp_cols:
        if col_name in df_typed.columns: df_typed = df_typed.withColumn(col_name, F.to_timestamp(F.col(col_name)))
    
    # Limit data size for memory safety on a single node
    df = df_typed.limit(MAX_ROWS_TO_PROCESS).cache()
    df.count() # Trigger cache
    print(f"✅ Ingestion successful. Using DataFrame 'df' with {df.count()} rows for analysis.")
except Exception as e:
    print(f"❌ Data ingestion failed. Error: {e}")
    spark.stop()
    raise e

# -----------------------------------------------------------------------------
# 3. INTERACTIVE RULE GENERATION AND EDITING
# -----------------------------------------------------------------------------
print("\n--- Step 3: Interactive Rule Generation & Editing ---")
# This process uses a stateful loop: it saves your edits to JSON files and re-loads them each time you run the script.
try:
    with open(RULES_PATH, "r") as f: final_rules = json.load(f)
    with open(WEIGHTS_PATH, "r") as f: final_weights = json.load(f)
    print("✅ Loaded previously saved rules and weights.")
except FileNotFoundError:
    print("ℹ️ No saved state found. Generating initial rules from LLM...")
    # The LLM generates rules based on a dynamic profile of the ingested data. 
    pdf_for_profiling = df.toPandas()
    suggester = IntelligentRuleSuggester()
    final_rules = suggester.suggest_rules(pdf_for_profiling).get("rules", [])
    final_weights = INITIAL_WEIGHTS

param_rules = defaultdict(list)
for r in final_rules: param_rules[r.get("type", "other")].append(r)

# This section creates the interactive UI for rule and weight refinement. 
print("\n--- REVIEW & EDIT RULES VIA WIDGETS ---")
for param in DQ_PARAMS:
    if rules_list := param_rules.get(param):
        print(f"\nPARAMETER: {param.upper()} (Weight: {final_weights.get(param, 0):.1f}%)")
        for i, rule in enumerate(rules_list): print(f"  {i+1}. {rule['description']}")
dbutils.widgets.text("ACTION", "", "Enter edits and re-run this cell")
for param in DQ_PARAMS:
    dbutils.widgets.text(f"weight_{param}", str(final_weights.get(param, 25.0)))
    dbutils.widgets.text(f"remove_{param}", ""); dbutils.widgets.text(f"add_{param}", "")
def get_widget(name: str, default: Any=""):
    try: return dbutils.widgets.get(name)
    except: return default

user_edits={"weights":{},"remove":{},"add":{}}
for p in DQ_PARAMS:
    user_edits["weights"][p] = float(get_widget(f"weight_{p}","25.0"))
    if rem_indices := get_widget(f"remove_{p}"): param_rules[p] = [r for i, r in enumerate(param_rules.get(p,[])) if (i+1) not in [int(x.strip()) for x in rem_indices.split(',')]]
    if add_desc := get_widget(f"add_{p}"): param_rules[p].append({"rule_id": f"user_{p}", "description": add_desc, "columns": [], "type": p, "rule_template": "CUSTOM"})
final_rules=[r for r_list in param_rules.values() for r in r_list]
total_w=sum(user_edits["weights"].values());
if total_w > 0: final_weights={p:w/total_w*100 for p,w in user_edits["weights"].items()}
dbutils.fs.put(RULES_PATH, json.dumps(final_rules), overwrite=True)
dbutils.fs.put(WEIGHTS_PATH, json.dumps(final_weights), overwrite=True)
print("\n--- ✅ State Saved. Proceeding to final assessment. ---")

# -----------------------------------------------------------------------------
# 4. FINAL ASSESSMENT, VISUALIZATION, AND REPORTING
# -----------------------------------------------------------------------------
print("\n--- Step 4: Final Assessment, Visualization, and Reporting ---")
def run_dq_assessment(df, rules, spark):
    """The self-contained Rule Engine that translates templates to Spark SQL."""
    results = []; total_records = df.count();
    if total_records == 0: total_records = 1
    for rule in rules:
        template, columns, params = rule.get("rule_template"), rule.get("columns", []), rule.get("parameters", {})
        sql_expr, fail_count = "", 0
        try:
            if not template or template == "CUSTOM" or not columns: continue
            col_name = f"`{columns[0]}`"
            if template == "IS_NOT_NULL": sql_expr = f"{col_name} IS NOT NULL"
            elif template == "IS_BETWEEN": sql_expr = f"CAST({col_name} AS double) BETWEEN {params.get('min')} AND {params.get('max')}"
            else: continue
            if sql_expr: fail_count = df.where(f"NOT ({sql_expr})").count()
        except Exception as e: logger.warning(f"Could not evaluate rule '{rule.get('description')}': {e}"); fail_count = -1
        pass_count = total_records - fail_count if fail_count != -1 else 0
        score = (pass_count / total_records) if fail_count != -1 else 0.0
        results.append({"description": rule.get("description"), "type": rule.get("type"), "columns": ", ".join(columns), "fail_count": int(fail_count), "score": float(score)})
    schema = StructType([StructField("description", StringType()), StructField("type", StringType()), StructField("columns", StringType()), StructField("fail_count", LongType()), StructField("score", DoubleType())])
    return spark.createDataFrame(results, schema=schema)

results_df = run_dq_assessment(df, final_rules, spark); results_df.cache()
results_pd = results_df.toPandas()
param_scores = {p: round(results_pd[results_pd['type'] == p]['score'].mean() * 10, 1) if not results_pd[results_pd['type'] == p].empty else None for p in DQ_PARAMS}
overall_score = sum(param_scores.get(p, 0) * (final_weights.get(p, 0) / 100.0) for p in DQ_PARAMS if param_scores.get(p) is not None) * 10 / (sum(final_weights.get(p,0) for p in DQ_PARAMS if param_scores.get(p) is not None)/100.0) if sum(final_weights.values()) > 0 else 0.0

print("\n--- DATA QUALITY SCORE SUMMARY ---")
for param, score in param_scores.items(): print(f"  - Score for {param.capitalize():<15}: {score if score is not None else 'N/A':>4} / 10.0")
print("-" * 40); print(f"  - Final Weighted Overall Score: {overall_score:.2f} / 10.0")

print("\n--- SCORE VISUALIZATION ---")
labels = [p.capitalize() for p, s in param_scores.items() if s is not None]; scores = [s for s in param_scores.values() if s is not None]
if scores:
    fig, ax = plt.subplots(figsize=(8, 4)); bars = ax.bar(labels, scores)
    ax.set_ylabel('Score (out of 10)'); ax.set_title('Data Quality Scores by Parameter'); ax.set_ylim(0, 10.5)
    for bar in bars: yval = bar.get_height(); plt.text(bar.get_x() + bar.get_width()/2.0, yval + 0.1, f'{yval:.1f}', ha='center', va='bottom')
    display(fig)

print("\n--- DETAILED RULE ASSESSMENT RESULTS ---")
display(results_df.selectExpr("type as Parameter", "description as `Rule Description`", "columns as `Applied to Columns`", "fail_count as `Failure Count`"))

print("\n--- Generating Final PDF Report ---")
try:
    report_df_for_pdf = results_df.selectExpr("description AS `Rule Description`", "columns AS `Columns`", "type AS `Type`", f"score * {df.count()} AS `Score`", "fail_count AS `Fail Count`")
    report_gen = ReportGenerator(output_dir=dbutils.widgets.get("report_output_dir"))
    pdf_path = report_gen.generate(report_df_for_pdf)
    print(f"✅ Final report generated at: {pdf_path}")
except Exception as e:
    print(f"⚠️ Could not generate PDF report. Error: {e}")

# -----------------------------------------------------------------------------
# 5. FINAL CLEANUP
# -----------------------------------------------------------------------------
dbutils.fs.rm(RULES_PATH, recurse=True)
dbutils.fs.rm(WEIGHTS_PATH, recurse=True)
spark.stop()
print("\n--- Pipeline Finished ---")

# COMMAND ----------

# MAGIC %sh curl -v https://y95r4psrbn1n5q4cqk5w.c0.asia-southeast1.gcp.weaviate.cloud/v1/meta

# COMMAND ----------

