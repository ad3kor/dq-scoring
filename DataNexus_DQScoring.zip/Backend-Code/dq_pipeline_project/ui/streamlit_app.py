# ui/streamlit_app.py (fully integrated with dynamic rule management)
import os
import streamlit as st
import pandas as pd
from dotenv import load_dotenv
from pyspark.sql import SparkSession
from ingestion.ingestion import IngestionManager
from sampling.stage1_reservoir_sampling import ReservoirSampler
from sampling.stage2_random_downsample import RandomDownSampler
from sampling.stage3_diversity_sampling import DiversitySampler
from rule_suggester.rule_suggester import RuleSuggester
from assessment.dq_assessment import DQAssessment
from reporting.report_generator import ReportGenerator
import logging
import logging.config

load_dotenv()
logging.config.fileConfig('configs/logging.conf', disable_existing_loggers=False)
logger = logging.getLogger('dq_pipeline.ui')

st.set_page_config(page_title="Data Quality Pipeline", layout="wide")

# Initialize Spark once
def init_spark():
    spark = (SparkSession.builder
             .appName("DQ_Pipeline")
             .enableHiveSupport()
             .getOrCreate())
    return spark

# Use st.cache_resource for Spark context reuse
tspark = st.cache_resource(init_spark)()
ingest_manager = IngestionManager(tspark)

# Initialize session state containers
if 'raw_df' not in st.session_state:
    st.session_state['raw_df'] = None
if 'parameters' not in st.session_state:
    st.session_state['parameters'] = []  # list of column names
if 'rules_df' not in st.session_state:
    st.session_state['rules_df'] = pd.DataFrame()  # DataFrame with rules and weights
if 'column_stats' not in st.session_state:
    st.session_state['column_stats'] = {}
if 'sample_pdf' not in st.session_state:
    st.session_state['sample_pdf'] = pd.DataFrame()
if 'final_pdf' not in st.session_state:
    st.session_state['final_pdf'] = pd.DataFrame()

st.title("Petabyte-Scale Data Quality Pipeline")

# --- Sidebar: Data Source Selection ---
st.sidebar.header("1. Select Data Source")
source_type = st.sidebar.selectbox("Source Type", ["Delta Table", "Kafka Topic", "MongoDB Collection", "Relational DB", "Cassandra", "FiveTran Table", "File (CSV/JSON/Parquet/Excel)", "S3/Cloud Path", "Upload File"])

# Collect inputs based on source_type
# Sidebar: Data Source Selection & Ingestion
if source_type == "Delta Table":
    table_fqn = st.sidebar.text_input("Delta Table FQN", "catalog.schema.table")
elif source_type == "Kafka Topic":
    topic = st.sidebar.text_input("Kafka Topic", "topic_name")
    kafka_servers = st.sidebar.text_input("Kafka Bootstrap Servers", os.getenv('KAFKA_BOOTSTRAP_SERVERS',''))
elif source_type == "MongoDB Collection":
    m_uri = st.sidebar.text_input("MongoDB URI", os.getenv('MONGODB_URI','mongodb://localhost:27017'))
    m_db = st.sidebar.text_input("DB", "test_db")
    m_coll = st.sidebar.text_input("Collection", "test_coll")
elif source_type == "Relational":
    jdbc_url = st.sidebar.text_input("JDBC URL", "jdbc:postgresql://...")
    rel_table = st.sidebar.text_input("Rel Table", "public.my_table")
    rel_user = st.sidebar.text_input("Rel User", "username")
    rel_pass = st.sidebar.text_input("Rel Password", "", type="password")
    rel_driver = st.sidebar.text_input("JDBC Driver (optional)", "")
elif source_type == "Cassandra":
    cass_keyspace = st.sidebar.text_input("Keyspace", "my_keyspace")
    cass_table = st.sidebar.text_input("Table", "my_table")
    cass_hosts = st.sidebar.text_input("Hosts (comma-separated)", "127.0.0.1")
    cass_port = st.sidebar.text_input("Port", "9042")
elif source_type == "File":
    file_path = st.sidebar.text_input("File Path", "/Workspace/Users/.../data.xlsx")
    file_type = st.sidebar.selectbox("File Type", ["csv","json","parquet","excel"])
elif source_type == "S3":
    s3_path = st.sidebar.text_input("S3 Path", "s3a://bucket/data.csv")
    s3_format = st.sidebar.selectbox("S3 Format", ["csv","json","parquet"])
elif source_type == "FiveTran":
    fivetran_table = st.sidebar.text_input("FiveTran Table", "analytics.my_dest")

# --- Button to Load Raw Data ---
if st.sidebar.button("Load Data"):
    try:
        if source_type == "Delta Table":
            df = ingest_manager.ingest_delta(table_fqn)
        elif source_type == "Kafka Topic":
            df = ingest_manager.ingest_kafka(topic, kafka_servers)
            st.warning("Streaming ingestion selected. Not fully supported in batch mode.")
        elif source_type == "MongoDB Collection":
            df = ingest_manager.ingest_mongodb(m_uri, m_db, m_coll)
        elif source_type == "Relational":
            df = ingest_manager.ingest_relational(jdbc_url, rel_table, rel_user, rel_pass, driver=rel_driver)
        elif source_type == "Cassandra":
            df = ingest_manager.ingest_cassandra(cass_keyspace, cass_table, contact_points=cass_hosts, port=int(cass_port))
        elif source_type == "File":
            # Normalize path
            if file_path.startswith("/Workspace/"):
                norm_path = "dbfs:" + file_path
            elif file_path.startswith("/dbfs/"):
                norm_path = file_path.replace("/dbfs/","dbfs:/")
            elif file_path.startswith("dbfs:/"):
                norm_path = file_path
            else:
                norm_path = file_path
            logger.info(f"Normalized file path: {norm_path}")
            if file_type == 'excel':
                df = (spark.read.format("com.crealytics.spark.excel")
                      .option("header","true").option("inferSchema","true").load(norm_path))
            else:
                df = ingest_manager.ingest_file(norm_path, file_type)
        elif source_type == "S3":
            df = ingest_manager.ingest_s3(s3_path, file_format=s3_format)
        elif source_type == "FiveTran":
            df = ingest_manager.ingest_fivetran(fivetran_table)
        else:
            st.error(f"Unsupported source: {source_type}")
            df = None
        if df is not None:
            st.session_state['raw_df'] = df.cache()
            st.success("Data loaded into session.")
    except Exception as e:
        st.error(f"Error during ingestion: {e}")

# --- Step 2: Sample & Suggest Rules ---
st.sidebar.header("2. Generate Rule Suggestions")
if st.session_state.get('raw_df', None) is not None:
    if st.sidebar.button("Run Profiling & Suggest Rules"):
        raw_df = st.session_state['raw_df']
        total_count = raw_df.count()
        st.info(f"Total records: {total_count}")

        # Stage 1 sampling
        reservoir_sampler = ReservoirSampler(tspark, sample_size=100000)
        sample_stage1 = reservoir_sampler.sample(raw_df)

        # Stage 2 downsample to 20000
        down_sampler = RandomDownSampler(tspark, target_count=20000)
        sample_stage2 = down_sampler.sample(sample_stage1)

        # Convert to pandas
        pdf = sample_stage2.toPandas()

        # Stage 3 diversity sampling (to 500)
        diversity_sampler = DiversitySampler(num_clusters=100, samples_per_cluster=5)
        final_pdf = diversity_sampler.sample(pdf)

        # Compute column stats from full sample_stage2
        column_stats = {}
        for col in pdf.columns:
            column_stats[col] = {
                'null_count': int(pdf[col].isna().sum()),
                'unique_count': int(pdf[col].nunique()),
                'sample_distinct_values': list(pdf[col].dropna().unique()[:5])
            }
        # Store parameters and stats in session
        st.session_state['parameters'] = list(column_stats.keys())
        st.session_state['column_stats'] = column_stats
        st.session_state['sample_pdf'] = pdf
        st.session_state['final_pdf'] = final_pdf

        # Suggest rules for all parameters
        suggester = RuleSuggester()
        rules = suggester.suggest_rules(final_pdf.to_dict(orient='records'), column_stats)
        rules_df = pd.DataFrame(rules)
        # Assign initial equal weights per parameter
        num_params = len(st.session_state['parameters'])
        if num_params > 0:
            equal_weight = 1.0 / num_params
            rules_df['weight'] = rules_df['columns'].apply(lambda cols: sum([equal_weight for c in cols if c in st.session_state['parameters']]))
        else:
            rules_df['weight'] = 1.0
        st.session_state['rules_df'] = rules_df
        st.success("Initial rules suggested. Edit as needed below.")
else:
    st.info("Load data first to generate rule suggestions.")

# --- UI for Editing Rules and Managing Parameters ---
if not st.session_state['rules_df'].empty:
    st.subheader("Current Parameters and Weights")
    param_weights = {p: 0.0 for p in st.session_state['parameters']}
    # Sum weights by parameter
    for idx, row in st.session_state['rules_df'].iterrows():
        for col in row['columns']:
            if col in param_weights:
                param_weights[col] += row['weight']
    weights_df = pd.DataFrame([{'parameter': k, 'weight': v} for k, v in param_weights.items()])
    edited_weights = st.data_editor(weights_df, num_rows="dynamic", use_container_width=True)
    # Update weights in session (normalized by parameter)
    updated_param_weights = dict(zip(edited_weights['parameter'], edited_weights['weight']))

    st.subheader("Current Rules")
    # Display rules with editable weight
    rules_display_df = st.session_state['rules_df'].copy()
    rules_display_df['columns_str'] = rules_display_df['columns'].apply(lambda x: ", ".join(x))
    columns_order = ['rule_id', 'description', 'columns_str', 'type', 'weight', 'condition']
    rules_display_df_to_show = rules_display_df[columns_order]
    edited_rules = st.experimental_data_editor(rules_display_df_to_show, use_container_width=True)
    # Map edited weights back
    for idx, r in edited_rules.iterrows():
        st.session_state['rules_df'].at[idx, 'weight'] = r['weight']

    # --- Controls for Adding/Removing Parameters ---
    st.subheader("Modify Parameters")
    col1, col2 = st.columns(2)
    with col1:
        new_param = st.text_input("Add Parameter (column name)")
        if st.button("Add Parameter", key="add_param"):
            if new_param in st.session_state['parameters']:
                st.warning(f"Parameter '{new_param}' already exists.")
            elif new_param not in st.session_state['column_stats']:
                st.error(f"Column '{new_param}' not found in dataset.")
            else:
                stats = st.session_state['column_stats']
                pdf_for_llm = st.session_state['final_pdf']
                new_rules = suggester.suggest_rules(
                    pdf_for_llm.to_dict(orient='records'), stats, target_columns=[new_param]
                )
                new_rules_df = pd.DataFrame(new_rules)
                # Assign equal weight to new param
                num_params = len(st.session_state['parameters']) + 1
                equal_weight = 1.0 / num_params
                # Update existing params: redistribute weights
                for idx in st.session_state['rules_df'].index:
                    cols = st.session_state['rules_df'].at[idx, 'columns']
                    if any(p in cols for p in st.session_state['parameters']):
                        st.session_state['rules_df'].at[idx, 'weight'] = equal_weight
                new_rules_df['weight'] = equal_weight
                st.session_state['rules_df'] = pd.concat([st.session_state['rules_df'], new_rules_df], ignore_index=True)
                st.session_state['parameters'].append(new_param)
                st.success(f"Added parameter '{new_param}' and new rules.")
    with col2:
        rem_param = st.selectbox("Remove Parameter", options=st.session_state['parameters'] + ["(none)"])
        if st.button("Remove Parameter", key="remove_param"):
            if rem_param == "(none)":
                st.warning("Select a parameter to remove.")
            else:
                df_rules = st.session_state['rules_df']
                mask = df_rules['columns'].apply(lambda cols: rem_param not in cols)
                st.session_state['rules_df'] = df_rules[mask].reset_index(drop=True)
                st.session_state['parameters'].remove(rem_param)
                num_params = len(st.session_state['parameters'])
                if num_params > 0:
                    equal_weight = 1.0 / num_params
                    for idx in st.session_state['rules_df'].index:
                        cols = st.session_state['rules_df'].at[idx, 'columns']
                        if any(p in cols for p in st.session_state['parameters']):
                            st.session_state['rules_df'].at[idx, 'weight'] = equal_weight
                st.success(f"Removed parameter '{rem_param}' and recalculated weights.")

# --- Step 3: Run DQ Assessment ---
st.sidebar.header("3. Run Data Quality Assessment")
if st.sidebar.button("Run Assessment"):
    if (not st.session_state['rules_df'].empty) and st.session_state.get('raw_df', None):
        df = st.session_state['raw_df']
        finalized_rules = st.session_state['rules_df'].to_dict(orient='records')
        assessor = DQAssessment(tspark)
        results_df = assessor.run_assessment(df, finalized_rules)
        results_table = os.getenv('DQ_RESULTS_TABLE', 'dq_results.default')
        results_df.write.mode('overwrite').format('delta').saveAsTable(results_table)
        st.success(f"DQ results saved to {results_table}")
        st.session_state['dq_results'] = results_df
    else:
        st.warning("Define and save rules first.")

# --- Step 4: Generate & Download PDF Report ---
st.sidebar.header("4. Generate Report")
if st.sidebar.button("Generate PDF Report"):
    if st.session_state.get('dq_results', None):
        report_gen = ReportGenerator()
        pdf_path = report_gen.generate(st.session_state['dq_results'])
        with open(pdf_path, 'rb') as f:
            st.download_button(
                label="Download Report PDF",
                data=f,
                file_name=os.path.basename(pdf_path),
                mime="application/pdf"
            )
    else:
        st.warning("Run assessment first to generate report.")

# --- Step 5: Interactive Chat/RAG Query ---
st.sidebar.header("5. Ask a Question (RAG)")
query = st.sidebar.text_input("Your question:")
if st.sidebar.button("Submit Query"):
    if query:
        from rag.rag_query import RAGQuery
        rag = RAGQuery()
        answer = rag.run_query(query)
        st.session_state['last_answer'] = answer
if st.session_state.get('last_answer'):
    st.write("**Answer:**")
    st.write(st.session_state['last_answer'])