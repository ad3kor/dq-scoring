import os
import logging
from databricks import dbsql

logger = logging.getLogger('dq_pipeline.rag.vector_search_query')

class VectorSearchQuery:
    def __init__(self):
        self.index_name = os.getenv('VECTOR_SEARCH_INDEX')
        self.client = dbsql.connect(
            server_hostname=os.getenv('DBSQL_HOST'),
            http_path=os.getenv('DBSQL_PATH'),
            access_token=os.getenv('DBSQL_TOKEN')
        )

    def query(self, user_query: str, k: int = 5):
        """Retrieve top-k most similar documents using the Vector Search index."""
        sql = f"""
        SELECT *, similarity_search(
            '{self.index_name}',
            embedding => embed_text('{user_query}'),
            limit => {k}
        ) AS _meta
        FROM {self.index_name}
        """
        logger.debug(f"RAG SQL: {sql}")
        cursor = self.client.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
        cursor.close()
        return rows