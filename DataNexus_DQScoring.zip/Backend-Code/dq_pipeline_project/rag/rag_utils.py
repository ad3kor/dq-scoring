import pandas as pd
import logging

logger = logging.getLogger('dq_pipeline.rag.utils')

def chunk_dataframe(df: pd.DataFrame, chunk_size: int, overlap: int) -> list:
    """Break a pandas DataFrame into overlapping chunks of rows."""
    chunks = []
    step = chunk_size - overlap
    total = len(df)
    for start in range(0, total, step):
        end = min(start + chunk_size, total)
        chunks.append(df.iloc[start:end])
        if end == total:
            break
    logger.debug(f"Split DataFrame of size {total} into {len(chunks)} chunks.")
    return chunks