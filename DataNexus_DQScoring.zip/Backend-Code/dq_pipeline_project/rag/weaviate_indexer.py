# rag/weaviate_indexer.py
import os
import logging
import weaviate
import weaviate.classes.config as wvc
from weaviate.auth import AuthApiKey
from pyspark.sql import SparkSession
from rag.ray_embedding_pipeline import RayEmbeddingPipeline # Assuming this class exists
from tenacity import retry, stop_after_attempt, wait_exponential

logger = logging.getLogger('dq_pipeline.rag.weaviate_indexer')

class WeaviateIndexer:
    """Handles connection, schema creation, and data ingestion into Weaviate using the v4 client."""

    def __init__(self, spark: SparkSession):
        """Initializes a resilient Weaviate client."""
        self.spark = spark
        self.client = self._get_weaviate_client()
        self.collection_name = os.getenv('WEAVIATE_COLLECTION_NAME', 'DataQualityRecords')
        self._ensure_schema()

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    def _get_weaviate_client(self) -> weaviate.WeaviateClient:
        """Connects to Weaviate with retry logic."""
        weaviate_url = os.getenv('WEAVIATE_URL')
        weaviate_api_key = os.getenv('WEAVIATE_API_KEY')
        if not weaviate_url or not weaviate_api_key:
            raise ValueError("WEAVIATE_URL and WEAVIATE_API_KEY environment variables must be set.")
        
        client = weaviate.connect_to_wcs(
            cluster_url=weaviate_url,
            auth_credentials=AuthApiKey(api_key=weaviate_api_key),
            skip_init_checks=True # Bypasses the /meta check for stability
        )
        client.connect()
        logger.info("Successfully connected to Weaviate.")
        return client

    def _ensure_schema(self):
        """Ensures the Weaviate collection exists with the correct schema using the v4 API."""
        if not self.client.collections.exists(self.collection_name):
            logger.info(f"Creating Weaviate collection '{self.collection_name}'...")
            self.client.collections.create(
                name=self.collection_name,
                properties=[
                    wvc.Property(name="text", data_type=wvc.DataType.TEXT),
                    wvc.Property(name="metadata", data_type=wvc.DataType.TEXT),
                ],
                vectorizer_config=wvc.Configure.Vectorizer.none(),
                vector_index_config=wvc.Configure.VectorIndex.hnsw(
                    distance_metric=wvc.VectorDistances.COSINE
                )
            )

    def ingest(self, source_table: str, text_col: str, metadata_cols: list):
        """Ingests data from a Spark table into Weaviate using Ray for embedding."""
        df = self.spark.table(source_table)
        
        # Assuming RayEmbeddingPipeline correctly returns a list of dicts:
        # [{'text': str, 'metadata': dict, 'vector': list[float]}, ...]
        ray_pipeline = RayEmbeddingPipeline(self.spark, df.select(text_col, *metadata_cols), text_col, metadata_cols)
        records_to_ingest = ray_pipeline.run()
        
        # Get the collection object
        collection = self.client.collections.get(self.collection_name)

        # Ingest data in batches using the v4 batch context manager
        with collection.batch.dynamic() as batch:
            for record in records_to_ingest:
                batch.add_object(
                    properties={
                        'text': record['text'],
                        'metadata': str(record['metadata']) # Ensure metadata is a string
                    },
                    vector=record['vector']
                )
        
        logger.info(f"Ingestion complete. Added {len(records_to_ingest)} objects to Weaviate collection '{self.collection_name}'.")

    def close(self):
        """Closes the Weaviate client connection."""
        self.client.close()