# rag/weaviate_query.py
import os
import logging
import weaviate
from weaviate.auth import AuthApiKey
from sentence_transformers import SentenceTransformer
import requests
from typing import List

logger = logging.getLogger('dq_pipeline.rag.weaviate_query')

class WeaviateQuery:
    """Handles RAG queries against Weaviate using the v4 client."""

    def __init__(self):
        """Initializes the Weaviate client, embedder, and LLM configuration."""
        self.client = self._get_weaviate_client()
        self.collection_name = os.getenv('WEAVIATE_COLLECTION_NAME', 'DataQualityRecords')
        self.embed_model = SentenceTransformer('all-MiniLM-L6-v2')
        self.llm_api_key = os.getenv('GROQ_API_KEY')
        self.llm_url = os.getenv('GROQ_API_URL', 'https://api.groq.com/openai/v1/chat/completions')

    def _get_weaviate_client(self) -> weaviate.WeaviateClient:
        """Connects to Weaviate."""
        weaviate_url = os.getenv('WEAVIATE_URL')
        weaviate_api_key = os.getenv('WEAVIATE_API_KEY')
        if not weaviate_url or not weaviate_api_key:
            raise ValueError("WEAVIATE_URL and WEAVIATE_API_KEY environment variables must be set.")
        
        client = weaviate.connect_to_wcs(
            cluster_url=weaviate_url,
            auth_credentials=AuthApiKey(api_key=weaviate_api_key),
            skip_init_checks=True
        )
        client.connect()
        return client

    def run_query(self, user_query: str, top_k: int = 5) -> str:
        """Runs a hybrid search query and generates an answer using an LLM."""
        
        # Step 1: Get the collection object
        collection = self.client.collections.get(self.collection_name)
        
        # Step 2: Embed the user query (no change needed here)
        query_vector = self.embed_model.encode(user_query).tolist()

        # Step 3: Hybrid search using the v4 API
        response = collection.query.hybrid(
            query=user_query,
            vector=query_vector,
            alpha=0.5, # 0.0 for pure keyword, 1.0 for pure vector
            limit=top_k,
            return_properties=["text", "metadata"]
        )
        
        # The v4 response object is a list of objects with a 'properties' attribute
        contexts = [obj.properties['text'] for obj in response.objects]

        if not contexts:
            return "Could not find any relevant information to answer the question."

        # Step 4: Build prompt and call LLM (no change needed here)
        prompt = (
            "You are a data quality insights assistant. Use the following retrieved contexts to answer the user's question.\n\n"
            "--- Contexts ---\n"
            + "\n\n".join(contexts)
            + f"\n\n--- Question ---\n{user_query}\n\nAnswer:"
        )
        
        headers = {'Authorization': f"Bearer {self.llm_api_key}", 'Content-Type': 'application/json'}
        payload = {
            'model': 'llama3-8b-8192', # Using a reliable model
            'messages': [{'role': 'user', 'content': prompt}],
            'max_tokens': 512
        }
        
        try:
            llm_response = requests.post(self.llm_url, headers=headers, json=payload, timeout=60)
            llm_response.raise_for_status() # Raise an exception for bad status codes
            return llm_response.json()['choices'][0]['message']['content']
        except requests.exceptions.RequestException as e:
            logger.error(f"LLM query failed: {e}")
            return "Failed to generate an answer from the LLM."
            
    def close(self):
        """Closes the Weaviate client connection."""
        self.client.close()