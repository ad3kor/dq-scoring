# rag/ray_embedding_pipeline.py
import ray
from sentence_transformers import SentenceTransformer
import logging
import pandas as pd
from pyspark.sql import SparkSession

logger = logging.getLogger('dq_pipeline.rag.ray_embedding')

@ray.remote
class EmbedWorker:
    def __init__(self, model_name: str):
        # Only initialize embedding model; no SparkContext here
        self.model = SentenceTransformer(model_name)

    def embed_batch(self, batch: list) -> list:
        """
        :param batch: List[Dict], each dict must have at least {"text": str, "metadata": ...}
        :return: List[Dict] with 'vector' added
        """
        texts = [r['text'] for r in batch]
        embeddings = self.model.encode(texts).tolist()
        return [
            {'text': r['text'], 'metadata': r['metadata'], 'vector': emb}
            for r, emb in zip(batch, embeddings)
        ]

class RayEmbeddingPipeline:
    """Generate embeddings via Ray without capturing SparkContext in closures."""
    def __init__(
        self,
        spark: SparkSession,
        source_df,
        text_col: str,
        metadata_cols: list,
        chunk_size: int = 5000,
        overlap: int = 500
    ):
        ray.init(ignore_reinit_error=True)
        self.spark = spark  # Only used on driver
        # Select only required columns here; no spark usage in remote tasks
        self.source_df = source_df.select(text_col, *metadata_cols)
        self.text_col = text_col
        self.metadata_cols = metadata_cols
        self.chunk_size = chunk_size
        self.overlap = overlap

    def run(self) -> list:
        """
        1. Count total rows on the driver.
        2. Iterate in batches of `batch_size` rows each.
        3. For each batch, use RDD.zipWithIndex to slice rows.
        4. Convert slice to Pandas (driver side) and chunk.
        5. Launch Ray workers with pure Python data.
        """
        # 1) Total rows on driver
        total_count = self.source_df.count()
        batch_size = 100_000
        embed_futures = []

        for start_idx in range(0, total_count, batch_size):
            end_idx = min(start_idx + batch_size, total_count)

            # Build RDD of (row, idx) pairs
            rdd_with_index = self.source_df.rdd.zipWithIndex()

            # Filter rows in [start_idx, end_idx)
            sliced_rdd = (
                rdd_with_index
                .filter(lambda pair: start_idx <= pair[1] < end_idx)
                .map(lambda pair: pair[0])  # extract original Row
            )
            # Create DataFrame slice on driver
            slice_df = self.spark.createDataFrame(sliced_rdd, schema=self.source_df.schema)

            # Convert slice to Pandas (driver)
            pandas_df: pd.DataFrame = slice_df.toPandas()

            # Chunk into overlapping pieces
            from rag.rag_utils import chunk_dataframe
            pandas_core = pandas_df[[self.text_col] + self.metadata_cols]
            chunks = chunk_dataframe(pandas_core, self.chunk_size, self.overlap)

            # Launch Ray workers for each chunk
            for chunk_df in chunks:
                records = chunk_df.to_dict(orient='records')
                worker = EmbedWorker.remote('all-MiniLM-L6-v2')
                fut = worker.embed_batch.remote(records)
                embed_futures.append(fut)

        # 7) Gather results on driver
        results = ray.get(embed_futures)

        # 8) Flatten and return
        flattened = [item for sublist in results for item in sublist]
        logger.info(f"Generated {len(flattened)} embeddings via Ray.")
        return flattened