import os
import logging
from pyspark.sql import SparkSession

logger = logging.getLogger('dq_pipeline.rag.vector_search_indexer')

class VectorSearchIndexer:
    def __init__(self, spark: SparkSession):
        self.spark = spark
        self.index_name = os.getenv('VECTOR_SEARCH_INDEX')  # e.g. "catalog.schema.index_name"
        self.endpoint_url = os.getenv('VECTOR_SEARCH_ENDPOINT')

    def create_index(self, source_table: str, text_column: str, metadata_columns: list):
        """Create or replace a Vector Search index on a Delta table."""
        cols_to_index = ", ".join(metadata_columns + [text_column])
        create_stmt = (
            f"CREATE OR REPLACE VECTOR INDEX {self.index_name} "
            f"ON {source_table} ({cols_to_index}) "
            f"USING VECTOR SEARCH OPTIONS ('endpoint' = '{self.endpoint_url}')"
        )
        logger.info(f"Creating Vector Search index: {create_stmt}")
        self.spark.sql(create_stmt)

    def enable_delta_sync(self, source_table: str):
        """Enable continuous Delta Sync for the Vector Search index."""
        sync_stmt = (
            f"ALTER VECTOR INDEX {self.index_name} "
            f"SET TBLPROPERTIES ( 'deltaSync.sourceTable' = '{source_table}', 'deltaSync.mode' = 'Continuous' )"
        )
        logger.info(f"Enabling Delta Sync: {sync_stmt}")
        self.spark.sql(sync_stmt)