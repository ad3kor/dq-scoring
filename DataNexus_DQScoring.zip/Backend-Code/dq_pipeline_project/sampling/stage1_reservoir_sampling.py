# ----------- sampling/stage1_reservoir_sampling.py -----------

from pyspark.sql import DataFrame, SparkSession
import logging

logger = logging.getLogger('dq_pipeline.sampling.stage1')

class ReservoirSampler:
    """
    Simplified: uses fraction-based sampling to avoid RDD.collect() on driver.
    """
    def __init__(self, spark: SparkSession, sample_size: int = 5000):
        self.spark = spark
        self.sample_size = sample_size

    def sample(self, df: DataFrame) -> DataFrame:
        total_count = df.count()
        if total_count <= self.sample_size:
            return df
        fraction = float(self.sample_size) / float(total_count)
        return df.sample(withReplacement=False, fraction=fraction, seed=42)
