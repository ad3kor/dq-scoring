# ----------- sampling/stage3_diversity_sampling.py -----------

import pandas as pd
from sklearn.cluster import KMeans
import numpy as np
from sentence_transformers import SentenceTransformer
import json
import logging

logger = logging.getLogger('dq_pipeline.sampling.stage3')

class DiversitySampler:
    """Performs clustering-based sampling on a small pandas DataFrame."""
    def __init__(self, num_clusters: int = 10, samples_per_cluster: int = 1):
        self.num_clusters = num_clusters
        self.samples_per_cluster = samples_per_cluster
        self.embedder = SentenceTransformer('all-MiniLM-L6-v2')

    def sample(self, pdf: pd.DataFrame) -> pd.DataFrame:
        # Truncate if > 5000 rows
        max_rows = 5000
        if len(pdf) > max_rows:
            logger.debug(f"Truncating pandas_df from {len(pdf)} to {max_rows} rows.")
            pdf = pdf.sample(n=max_rows, random_state=42)

        texts = pdf.apply(lambda row: json.dumps(row.to_dict(), default=str), axis=1).tolist()
        embeddings = self.embedder.encode(texts, show_progress_bar=False)

        n_clusters = min(self.num_clusters, len(texts))
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=5).fit(embeddings)
        labels = kmeans.labels_
        pdf['cluster'] = labels

        sampled_indices = []
        for cid in np.unique(labels):
            indices = pdf.index[pdf['cluster'] == cid].tolist()
            if len(indices) <= self.samples_per_cluster:
                sampled_indices.extend(indices)
            else:
                sampled_indices.extend(np.random.choice(indices, self.samples_per_cluster, replace=False).tolist())

        result = pdf.loc[sampled_indices].drop(columns=['cluster'])
        return result