# ----------- sampling/stage2_random_downsample.py -----------

from pyspark.sql import DataFrame, SparkSession
import logging

logger = logging.getLogger('dq_pipeline.sampling.stage2')

class RandomDownSampler:
    """Simple random sampling to a fixed target count."""
    def __init__(self, spark: SparkSession, target_count: int = 2000):
        self.spark = spark
        self.target_count = target_count

    def sample(self, df: DataFrame) -> DataFrame:
        total = df.count()
        if total <= self.target_count:
            return df
        fraction = float(self.target_count) / float(total)
        sampled_df = df.sample(withReplacement=False, fraction=fraction, seed=42)
        return sampled_df.limit(self.target_count)