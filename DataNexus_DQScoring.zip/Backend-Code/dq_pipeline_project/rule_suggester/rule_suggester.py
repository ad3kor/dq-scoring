# File: rule_suggester/chunked_rule_suggester.py
import os
os.environ["THREADPOOLCTL_CONF"]    = "none"
os.environ["THREADPOOLCTL_VERBOSE"] = "0"
os.environ["OMP_NUM_THREADS"]       = "1"
os.environ["MKL_NUM_THREADS"]       = "1"

import logging
from typing import List, Optional, Dict, Any
import numpy as np
import pandas as pd
from pydantic import BaseModel, Field, RootModel
from sentence_transformers import SentenceTransformer
from langchain_groq.chat_models import ChatGroq
from langchain.output_parsers import PydanticOutputParser, OutputFixingParser
from langchain.schema import SystemMessage, HumanMessage

logger = logging.getLogger("dq_pipeline.chunked_rule_suggester")

class Rule(BaseModel):
    rule_id: str  = Field(..., description="Unique identifier")
    description: str
    columns: List[str]
    type: str
    condition: str

class RuleList(RootModel[List[Rule]]):
    pass

def _unwrap_any(x):
    while isinstance(x, (list, tuple)) and x:
        x = x[0]
    return x

class ChunkedRuleSuggester:
    def __init__(self, model_name: str = "deepseek-r1-distill-llama-70b", temperature: float = 0.2):
        self.llm      = ChatGroq(model=model_name, temperature=temperature)
        self.embedder = SentenceTransformer("all-MiniLM-L6-v2")
        base_parser = PydanticOutputParser(pydantic_object=RuleList)
        self.parser = OutputFixingParser.from_llm(self.llm, base_parser)

    @staticmethod
    def _pick_cols(df: pd.DataFrame, k: int = 10) -> List[str]:
        cand = [c for c in df.columns
                if "id" not in c.lower()
                and not np.issubdtype(df[c].dtype, np.datetime64)]
        if len(cand) <= k:
            return cand
        null_ratio = df.isna().mean()
        return sorted(cand, key=null_ratio.get, reverse=True)[:k]

    @staticmethod
    def _stats_text(df: pd.DataFrame, cols: List[str]) -> str:
        total = len(df) or 1
        lines = []
        for c in cols:
            s = df[c]
            lines.append(
                f"- {c}: null%={round(s.isna().mean()*100,2)}, "
                f"uniq={int(s.nunique())}, "
                f"top5={s.value_counts(dropna=True).nlargest(5).index.tolist()}"
            )
        return "\n".join(lines)

    def _ask(self, prompt: str, tok: int = 512) -> List[Rule]:
        sys = SystemMessage(
            content="You are a data-quality expert. "
                    "Respond ONLY with JSON matching the provided schema."
        )
        raw = self.llm.generate([[sys, HumanMessage(content=prompt)]], max_tokens=tok)
        txt = _unwrap_any(raw).generations[0][0].message.content
        try:
            return self.parser.parse(txt).root
        except Exception as e:
            logger.error("Pydantic validation failed: %s", e)
            return []

    def suggest_rules_chunked(
        self,
        pdf: pd.DataFrame,
        target_columns: Optional[List[str]] = None,
        user_edits: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Suggest rules per parameter/column; optionally apply user-edits at runtime.
        user_edits: {
            'add_columns': [col, ...],
            'remove_columns': [col, ...],
            'add_rules': {col: [<custom_rule_dict>], ...},
            'remove_rules': {col: [rule_id1, rule_id2, ...], ...},
            'weights': {col: float, ...}
        }
        Returns:
            {"rules": List[Rule], "weights": Dict[str, float]}
        """
        if target_columns is None:
            target_columns = self._pick_cols(pdf)

        # --- 1. LLM Initial Suggestion ---
        stats = self._stats_text(pdf, target_columns)
        prompt = (
            f"Column stats:\n{stats}\n\n"
            "Generate 3–6 high-level DQ rules as a JSON array."
        )
        rules = self._ask(prompt, tok=768)

        # --- 2. Organize rules by column ---
        from collections import defaultdict
        param_rule_map = defaultdict(list)
        for rule in rules:
            for col in rule.columns:
                param_rule_map[col].append(rule)

        # --- 3. Apply user runtime edits ---
        if user_edits is None:
            user_edits = {}

        # Remove columns
        remove_columns = user_edits.get("remove_columns", [])
        for col in remove_columns:
            if col in param_rule_map:
                del param_rule_map[col]

        # Add columns (LLM suggest rules for them)
        add_columns = user_edits.get("add_columns", [])
        for col in add_columns:
            if col not in param_rule_map and col in pdf.columns:
                more_rules = self._ask(
                    f"Column: {col}\nStats: {self._stats_text(pdf, [col])}\n"
                    f"Suggest 2-4 DQ rules for this column only (JSON array).", tok=512
                )
                for rule in more_rules:
                    param_rule_map[col].append(rule)

        # Remove specific rules by rule_id
        remove_rules = user_edits.get("remove_rules", {})
        for col, rmlist in remove_rules.items():
            param_rule_map[col] = [r for r in param_rule_map.get(col, []) if r.rule_id not in rmlist]

        # Add custom rules directly
        add_rules = user_edits.get("add_rules", {})
        for col, rules_to_add in add_rules.items():
            for r in rules_to_add:
                rule = Rule(**r)
                param_rule_map[col].append(rule)

        # --- 4. Flatten rules for scoring ---
        final_rules = [r for rules in param_rule_map.values() for r in rules]

        # --- 5. Compute/adjust weights ---
        col_list = list(param_rule_map.keys())
        weights = user_edits.get("weights", {})
        # If no weights or any missing, distribute equally
        if not weights or set(weights) != set(col_list):
            equal = 1.0 / max(1, len(col_list))
            weights = {col: equal for col in col_list}
        else:
            # Normalize weights to sum to 1.0
            total = sum(weights.values())
            if abs(total - 1.0) > 1e-6:
                weights = {col: w / total for col, w in weights.items()}

        # --- 6. Always at least one rule ---
        if not final_rules:
            final_rules = [Rule(
                rule_id="DEFAULT",
                description="Fallback rule – no rule generated",
                columns=[],
                type="NoOp",
                condition="true"
            )]

        # --- 7. Return both rules and weights ---
        return {
            "rules": [r.model_dump() for r in final_rules],
            "weights": weights,
            "columns": col_list
        }
