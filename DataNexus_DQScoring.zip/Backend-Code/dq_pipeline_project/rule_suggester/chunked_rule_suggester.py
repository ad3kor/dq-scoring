# File: rule_suggester/intelligent_rule_suggester.py
"""
An advanced rule suggester that first performs a detailed data profile
and then uses targeted prompts to generate data-driven DQ rules for each
of the four key parameters.
"""
import os
import json
import logging
from typing import List, Dict, Any
import re

import pandas as pd
from pydantic import BaseModel, Field, ValidationError
from langchain_groq.chat_models import ChatGroq
from langchain.schema import SystemMessage, HumanMessage, AIMessage

os.environ["THREADPOOLCTL_CONF"] = "none"
logger = logging.getLogger("dq_pipeline.intelligent_rule_suggester")

class Rule(BaseModel):
    rule_id: str = Field(..., description="Unique rule identifier")
    description: str
    columns: List[str]
    type: str = Field(..., description="MUST be 'accuracy', 'completeness', 'consistency', or 'uniqueness'")
    condition: str

class IntelligentRuleSuggester:
    """Generates data-driven DQ rules by profiling the data first."""

    def __init__(self, model_name="llama3-8b-8192", temperature=0.1):
        self.llm = ChatGroq(model=model_name, temperature=temperature)

    def _create_data_profile(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Performs a detailed analysis of the DataFrame to create a rich profile."""
        profile = {"columns": {}}
        total_rows = len(df)
        if total_rows == 0: return profile

        for col in df.columns:
            column_series = df[col]
            # Basic Stats
            null_count = column_series.isnull().sum()
            unique_count = column_series.nunique()
            
            col_profile = {
                "dtype": str(column_series.dtype),
                "completeness": round((1 - (null_count / total_rows)) * 100, 2),
                "uniqueness_ratio": round(unique_count / total_rows, 2) if total_rows > 0 else 0,
            }

            # Type-specific analysis
            if pd.api.types.is_numeric_dtype(column_series):
                desc = column_series.describe()
                col_profile.update({
                    "min": desc.get("min", 0), "max": desc.get("max", 0),
                    "mean": desc.get("mean", 0), "std": desc.get("std", 0)
                })
            elif pd.api.types.is_string_dtype(column_series):
                # Simple pattern inference
                non_null_series = column_series.dropna()
                if not non_null_series.empty:
                    sample_value = non_null_series.iloc[0]
                    if re.match(r"[^@]+@[^@]+\.[^@]+", str(sample_value)):
                        col_profile["inferred_pattern"] = "email"
                    elif re.match(r"^\d{4}-\d{2}-\d{2}$", str(sample_value)):
                        col_profile["inferred_pattern"] = "YYYY-MM-DD date"
            
            profile["columns"][col] = col_profile
        return profile

    def _ask_llm_for_rules(self, prompt: str) -> List[Dict]:
        """A robust method to call the LLM and parse its JSON response."""
        system_prompt = (
            "You are a data quality expert. You MUST respond with ONLY a valid JSON array of rule objects. "
            "Each object must strictly have these keys: 'rule_id', 'description', 'columns', 'type', 'condition'. "
            "The 'type' key MUST be one of these four values: 'accuracy', 'completeness', 'consistency', or 'uniqueness'. "
            "Do not add any conversational text or markdown formatting."
        )
        messages = [SystemMessage(content=system_prompt), HumanMessage(content=prompt)]
        
        try:
            response = self.llm.invoke(messages)
            raw_text = response.content.strip()
            
            start_index = raw_text.find('[')
            end_index = raw_text.rfind(']')
            if start_index == -1 or end_index < start_index: return []

            json_str = raw_text[start_index : end_index + 1]
            parsed_list = json.loads(json_str)

            # Sanitize and validate with Pydantic
            validated_rules = []
            for item in parsed_list:
                if isinstance(item, dict):
                    item['rule_id'] = str(item.get('rule_id', 'unknown'))
                    validated_rules.append(Rule(**item).model_dump())
            return validated_rules
        except (json.JSONDecodeError, ValidationError, Exception) as e:
            logger.error(f"Failed to get valid rules from LLM: {e}")
            return []

    def suggest_rules(self, pdf: pd.DataFrame) -> Dict[str, Any]:
        """Main method to profile data and generate targeted rules."""
        profile = self._create_data_profile(pdf)
        if not profile["columns"]:
            return {"rules": [], "weights": {}}

        profile_text = json.dumps(profile, indent=2)
        all_rules = []

        # 1. Prompt for Completeness rules
        completeness_prompt = (
            f"Based on this data profile, suggest 'completeness' rules. Focus on columns where 'completeness' is less than 100% "
            f"but greater than 0%. For example, a column with 98% completeness is a good candidate for a 'should not be null' rule.\n\nProfile:\n{profile_text}"
        )
        all_rules.extend(self._ask_llm_for_rules(completeness_prompt))

        # 2. Prompt for Uniqueness rules
        uniqueness_prompt = (
            f"Based on this data profile, suggest 'uniqueness' rules. Focus on columns where 'uniqueness_ratio' is very high (close to 1.0), "
            f"as they are likely identifiers that should be unique.\n\nProfile:\n{profile_text}"
        )
        all_rules.extend(self._ask_llm_for_rules(uniqueness_prompt))

        # 3. Prompt for Accuracy rules
        accuracy_prompt = (
            f"Based on this data profile, suggest 'accuracy' rules. For numeric columns, check for strange min/max values. "
            f"For string columns, suggest format checks based on the 'inferred_pattern', if any.\n\nProfile:\n{profile_text}"
        )
        all_rules.extend(self._ask_llm_for_rules(accuracy_prompt))
        
        # 4. Prompt for Consistency rules
        consistency_prompt = (
            f"Based on this list of all columns and their types, suggest logical 'consistency' rules. "
            f"For example, if you see start and end date columns, suggest a rule that 'end_date' must be after 'start_date'. "
            f"If you see a status column and a date column (e.g., 'order_status' and 'ship_date'), suggest a rule that if status is 'shipped', 'ship_date' must not be null.\n\nProfile:\n{profile_text}"
        )
        all_rules.extend(self._ask_llm_for_rules(consistency_prompt))

        # Ensure uniqueness of rule_ids
        final_rules = list({r['rule_id']: r for r in all_rules}.values())
        
        return {"rules": final_rules}