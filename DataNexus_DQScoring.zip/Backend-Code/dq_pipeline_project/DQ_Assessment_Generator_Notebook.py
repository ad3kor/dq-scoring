# Databricks notebook source
# MAGIC %pip install -r requirements.txt
# MAGIC

# COMMAND ----------

# Assuming you have weaviate-client installed (%pip install weaviate-client)
import weaviate
from weaviate.auth import AuthApiKey
from weaviate.classes.init import Auth 
from weaviate.classes.config import Configure # For Configure.Collection
from weaviate.classes.config import Property # For Property.text


WEAVIATE_URL = "https://uhhkpzivqgs19vnjsfkpgw.c0.asia-southeast1.gcp.weaviate.cloud" 
WEAVIATE_API_KEY="UFprcmhzdnZVUzEyTlJYbl9GV0VWYjVqNUM0dG53dG5Ea2VSWlhoNEh4YlhyQmxTajIvM1B4TzZGYVFBPV92MjAw"
WEAVIATE_COLLECTION_NAME = "DataQualitySample" # Confirmed from screenshot

try:
    client = weaviate.connect_to_weaviate_cloud(
        cluster_url=WEAVIATE_URL, 
        auth_credentials=Auth.api_key(WEAVIATE_API_KEY),
    )

    if client.is_ready(): 
        print("✅ Weaviate client connected successfully.")
        
        try:
            # --- Check if collection exists, if not, create it ---
            if not client.collections.exists(WEAVIATE_COLLECTION_NAME):
                print(f"Collection '{WEAVIATE_COLLECTION_NAME}' does not exist. Creating it...")
                client.collections.create(
                    name=WEAVIATE_COLLECTION_NAME,
                    vectorizer_config=Configure.Vectorizer.none(), # Use Configure.Vectorizer.none()
                    properties=[
                        Property(
                            name="record_json",
                            data_type=weaviate.classes.config.DataType.TEXT, 
                        )
                    ],
                )
                print(f"✅ Collection '{WEAVIATE_COLLECTION_NAME}' created.")
            else:
                print(f"Collection '{WEAVIATE_COLLECTION_NAME}' already exists.")
            
            # Now, safely get the collection object
            collection = client.collections.get(WEAVIATE_COLLECTION_NAME)
            print("Fetching collection schema details...")

            # --- FIX: Try to get vectorizer config more directly and robustly ---
            # Attempt 1: direct attribute on collection (common for simple vectorizer)
            vectorizer_config_details = None
            try:
                vectorizer_config_details = collection.vectorizer # This attribute *might* hold it directly
            except AttributeError:
                pass # Not found, try other ways
            
            # Attempt 2: check inside collection.config (which is CollectionConfig)
            # The config object itself has attributes corresponding to its properties.
            # For 'vectorizer_config' this should be available directly on `collection.config`
            # or `collection.config.vectorizer_config` or similar depending on client minor version.
            if vectorizer_config_details is None:
                if hasattr(collection.config, 'vectorizer_config'): # Check if the attribute exists on config
                    vectorizer_config_details = collection.config.vectorizer_config
                elif hasattr(collection.config, 'vectorizer'): # Another possibility if named differently
                    vectorizer_config_details = collection.config.vectorizer
                else:
                    # Fallback to getting all config as dict and checking 'vectorizer' key (less common in strict v4)
                    try:
                        collection_full_config_dict = collection.config.get() # .get() might work on config object
                        vectorizer_config_details = collection_full_config_dict.get('vectorizer')
                    except Exception:
                        pass # Could not get as dict either

            vectorizer_class_name = "none" # Default if vectorizer is None (as per your screenshot)
            if vectorizer_config_details:
                # If a vectorizer is actually configured, its class name is often accessible via 'vectorizer_class_name' attribute
                if hasattr(vectorizer_config_details, 'vectorizer_class_name'):
                    vectorizer_class_name = vectorizer_config_details.vectorizer_class_name
                elif hasattr(vectorizer_config_details, 'model'): # For some specific models like text2vec-openai
                    vectorizer_class_name = vectorizer_config_details.model
                else:
                    # Fallback to string representation if attributes not found
                    vectorizer_class_name = str(vectorizer_config_details) 
            
            print(f"\nSchema for collection '{WEAVIATE_COLLECTION_NAME}':")
            print(f"  Vectorizer: {vectorizer_class_name}")

            if vectorizer_class_name == 'none': 
                print("✅ Collection is configured for external embeddings ('vectorizer: none').")
                print("   This means you WILL need to generate query embeddings externally (e.g., using Hugging Face API) for 'with_near_vector' queries.")
            else:
                print(f"⚠️ Collection is configured with an internal vectorizer: '{vectorizer_class_name}'.")
                print("   This means Weaviate will generate embeddings internally for 'with_near_text' queries.")
            
            # --- Good Practice: Close the client connection ---
            client.close()
            print("✅ Weaviate client connection closed.")

        except Exception as e_schema:
            print(f"❌ Error fetching/creating schema for collection '{WEAVIATE_COLLECTION_NAME}': {e_schema}")
            print("Please ensure the collection name and properties are correct in the create call.")
            if client.is_ready():
                client.close()
                print("✅ Weaviate client connection closed due to error.")

    else:
        print("❌ Weaviate client failed to connect. Please check URL and API Key.")
        if client.is_ready():
            client.close()
            print("✅ Weaviate client connection closed after failed check.")

except Exception as e:
    print(f"An error occurred during Weaviate connection or schema check: {e}")
    print("Please ensure your Weaviate URL and API Key are correct, and the instance is running.")

# COMMAND ----------

# from weaviate.classes.config import Configure, Property, DataType
# import weaviate

# WEAVIATE_URL = "https://uhhkpzivqgs19vnjsfkpgw.c0.asia-southeast1.gcp.weaviate.cloud"
# WEAVIATE_API_KEY = "UFprcmhzdnZVUzEyTlJYbl9GV0VWYjVqNUM0dG53dG5Ea2VSWlhoNEh4YlhyQmxTajIvM1B4TzZGYVFBPV92MjAw"          # redacted
# COLL = "DataQualitySample"
# # 
# client = weaviate.connect_to_weaviate_cloud(
#     cluster_url=WEAVIATE_URL,
#     auth_credentials = Auth.api_key(WEAVIATE_API_KEY),
# )

# try:
#     # 1️⃣ make sure the collection exists
#     if not client.collections.exists(COLL):
#         client.collections.create(
#             name=COLL,
#             vectorizer_config=Configure.Vectorizer.none(),
#             properties=[
#                 Property(
#                     name="record_json",
#                     data_type=DataType.TEXT,
#                 )
#             ],
#         )
#         print(f"✅  Created collection “{COLL}”")

#     # 2️⃣ fetch the *server* config safely
#     cfg = client.collections.get(COLL).config.get()   # <- note the .get()
#     vec_cfg = cfg.vectorizer_config                   # None if “vectorizer: none”

#     if vec_cfg is None:
#         print("Vectorizer: none (BYO embeddings)")
#     else:
#         # vec_cfg is e.g. _VectorizerOpenAIConfig or similar
#         print(f"Vectorizer module: {vec_cfg.vectorizer}")
#         # For OpenAI-style configs you can also inspect .model, .dimensions, etc.

# finally:
#     client.close()


# COMMAND ----------

#   # Notebook: DQ_Assessment_Generator_Notebook
# # Purpose: Load cleaned data and rules, generate DQ assessment, and return report.

# import json
# import pandas as pd
# import pyspark.sql.functions as F
# from pyspark.sql import SparkSession
# from typing import List, Dict, Any, Optional
# import re 
# import datetime # Import datetime for potential date conversion issues if not using pd.Timestamp.now() directly

# # Import all Spark functions at the top level for clarity and consistency
# from pyspark.sql.functions import col, lit, to_timestamp, expr, when, array, to_date, current_timestamp, add_months
# from pyspark.sql.types import StringType, TimestampType # Also import types here

# # --- LLM and Pydantic Imports ---
# from langchain_groq.chat_models import ChatGroq
# from langchain.schema import SystemMessage, HumanMessage
# from pydantic import BaseModel, Field, ValidationError
# import logging
# import time
# import numpy as np

# # --- Spark and Logging Setup ---
# spark = SparkSession.builder.appName("DQ_Assessment_Job").getOrCreate()
# logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
# logger = logging.getLogger('dq_assessment_notebook')
# print("✅ Spark Session and Logger initialized.")

# # --- Configuration ---
# GROQ_API_KEY = "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" 
# TOP_K_SAMPLES = 50

# # Define the Delta table where cleaned data is read from
# CLEANED_DATA_DELTA_TABLE_FQDN = "hive_metastore.default.dq_ingested_clean_sample" # Must match Notebook 1

# # Paths for rules and weights (fallback if not passed as parameters)
# RULES_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
# WEIGHTS_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# # --- RAG Specific Configuration (Conceptual for Weaviate) ---
# WEAVIATE_URL = "http://localhost:8080" 
# WEAVIATE_API_KEY = "YOUR_WEAVIATE_API_KEY" 
# WEAVIATE_COLLECTION_NAME = "DataQualityInsights" 

# # ==============================================================================
# # 1. Setup and Load Inputs (from original Cell 4)
# # ==============================================================================
# print("--- Step 1: Loading cleaned data, rules, and weights... ---")

# # --- Define and Retrieve Job Parameters (for rules/weights from frontend) ---
# try:
#     dbutils.widgets.removeAll()
#     dbutils.widgets.text("param_rules_json", "", "Frontend Rules JSON")
#     dbutils.widgets.text("param_weights_json", "", "Frontend Weights JSON")
#     # Also define widgets for ingestion params if this job needs to re-read data based on them
#     # Ensure these match the notebook_params keys passed from Next.js /api/run-databricks-assessment/route.ts
#     dbutils.widgets.text("param_source_type", "Azure Blob Storage (WASBS)", "Source Type")
#     dbutils.widgets.text("param_file_path", "", "File Path")
#     dbutils.widgets.text("param_file_type", "", "File Type")
#     dbutils.widgets.text("param_azure_storage_account_name", "", "Azure Storage Account Name")
#     dbutils.widgets.text("param_azure_container_name", "", "Azure Container Name")
#     dbutils.widgets.text("param_azure_blob_path", "", "Azure Blob Path")
#     dbutils.widgets.text("param_data_age_months", "0", "Data Age in Months")
#     print("✅ Widgets defined for job parameters.")

#     custom_rules_json_param = dbutils.widgets.get("param_rules_json")
#     custom_weights_json_param = dbutils.widgets.get("param_weights_json")
    
#     # Retrieve ingestion params (even if not directly used for loading df_cleaned, good to log)
#     param_source_type = dbutils.widgets.get("param_source_type") 
#     param_file_path = dbutils.widgets.get("param_file_path")
#     param_file_type = dbutils.widgets.get("param_file_type")
#     param_azure_storage_account_name = dbutils.widgets.get("param_azure_storage_account_name")
#     param_azure_container_name = dbutils.widgets.get("param_azure_container_name")
#     param_azure_blob_path = dbutils.widgets.get("param_azure_blob_path")
#     param_data_age_months = dbutils.widgets.get("param_data_age_months")

#     print("✅ Parameters retrieved from widgets/job context.")

# except Exception as e:
#     print(f"⚠️ Could not create or retrieve Databricks widgets for parameters. Error: {e}")
#     # Set empty strings if widgets not available (e.g., interactive run without params)
#     custom_rules_json_param = ""
#     custom_weights_json_param = ""


# # Load cleaned data from Delta table (this job assumes DQ_Ingestion_Notebook already ran)
# try:
#     df_cleaned = spark.read.format("delta").table(CLEANED_DATA_DELTA_TABLE_FQDN)
#     total_records = df_cleaned.count()
#     if total_records == 0:
#         raise ValueError(f"Cleaned DataFrame '{CLEANED_DATA_DELTA_TABLE_FQDN}' is empty. Cannot perform scoring.")
#     print(f"✅ Loaded cleaned data (df_cleaned) with {total_records} rows.")
# except Exception as e:
#     print(f"❌ Error loading cleaned data from Delta table: {e}")
#     dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Failed to load cleaned data: {str(e)}"}))

# # --- Load rules and weights (PRIORITIZE parameters from frontend) ---
# rules = []
# weights = {}
# # Default DQ_PARAMS list. It will be updated based on loaded weights.
# DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"] 

# if custom_rules_json_param and custom_weights_json_param:
#     print("Attempting to load rules and weights from Next.js parameters...")
#     try:
#         rules = json.loads(custom_rules_json_param)
#         weights = json.loads(custom_weights_json_param)
#         print("✅ Successfully loaded rules and weights from Next.js parameters.")
#     except json.JSONDecodeError as e:
#         print(f"❌ Error parsing rules/weights from Next.js parameters: {e}. Falling back to DBFS files.")
#         # Do not clear params here, let the fallback logic below handle it
# else:
#     print("No custom rules/weights parameters provided. Loading from DBFS files as fallback.")

# # Fallback to DBFS files if parameters were not provided or failed to parse
# if not rules or not weights: # If rules or weights are still empty after attempting from parameters
#     try:
#         rules_str = dbutils.fs.head(RULES_PATH_INTERNAL)
#         weights_str = dbutils.fs.head(WEIGHTS_PATH_INTERNAL)
#         rules = json.loads(rules_str)
#         weights = json.loads(weights_str)
#         print("✅ Loaded rules and weights from DBFS files.")
#     except Exception as e_dbfs:
#         print(f"❌ Error loading rules/weights from DBFS: {e_dbfs}. Exiting.")
#         dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Failed to load rules/weights from DBFS: {str(e_dbfs)}"}))

# # Final check for rules and weights after all loading attempts
# if not rules:
#     print("❌ No rules loaded from any source. Exiting assessment.")
#     dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": "No rules available for assessment."}))
# if not weights:
#     print("❌ No weights loaded from any source. Exiting assessment.")
#     dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": "No weights available for assessment."}))

# # Ensure DQ_PARAMS is updated based on the actual loaded weights
# DQ_PARAMS = list(weights.keys()) 

# print(f"✅ Loaded {len(rules)} rules and {len(weights)} weights.")
# print(f"Active DQ Parameters: {DQ_PARAMS}")


# # ==============================================================================
# # 2. LLM Interaction Layer (from original Cell 4)
# # ==============================================================================
# print("\n--- Step 2: Initializing LLM Interaction Layer... ---")

# class LLMRuleScoreResponse(BaseModel):
#     rule_score: float = Field(..., description="A score for the rule from 0.0 to 10.0 based on the failure rate.")
#     reasoning: str = Field(..., description="Detailed reasoning for the score, explaining the impact of the failing records.")

# class LLMDimensionObservationResponse(BaseModel):
#     dimension_score: float = Field(..., description="A score for the dimension from 0.0 to 10.0, based on the overall rule outcomes for this dimension.")
#     observation: str = Field(..., description="A qualitative observation explaining the provided dimension score, referencing the rule outcomes.")

# class LLMOverallReportResponse(BaseModel):
#     report: str = Field(..., description="A comprehensive report explaining the final, overall data quality score. This must be a single flat string.")

# class LLMScoringAndObservation:
#     """Handles all communication with the LLM, now with a JSON repair mechanism and conceptual Weaviate RAG."""
#     def __init__(self, api_key: str, model="llama3-8b-8192"):
#         if not api_key: raise ValueError("Groq API key is required.")
#         self.llm = ChatGroq(model=model, temperature=0.1, api_key=api_key)
#         self.repair_llm = ChatGroq(model="llama3-8b-8192", temperature=0.0, api_key=api_key)
#         # Weaviate client init would go here if live.

#     def _repair_json(self, broken_json: str) -> Optional[str]:
#         try:
#             prompt = f"The following is a broken JSON object. Please fix all syntax and schema errors and return only the corrected, valid JSON object. Do not add any text or explanation before or after the JSON.\n\nBROKEN JSON:\n{broken_json}"
#             repair_messages = [HumanMessage(content=prompt)]
#             response = self.repair_llm.invoke(repair_messages)
#             repaired_text = response.content.strip()
#             json_match = re.search(r"\{.*\}", repaired_text, re.DOTALL)
#             if json_match:
#                 return json_match.group(0)
#             return None
#         except Exception as e:
#             logger.error(f"JSON repair call failed: {e}")
#             return None

#     def _invoke_llm(self, messages: List, response_model: BaseModel) -> Optional[Dict[str, Any]]:
#         for attempt in range(3): 
#             raw_text = None
#             try:
#                 response = self.llm.invoke(messages)
#                 raw_text = response.content.strip()
#                 json_match = re.search(r"\{.*\}", raw_text, re.DOTALL)
#                 if json_match:
#                     json_str = json_match.group(0)
#                     return response_model(**json.loads(json_str)).model_dump()
#                 else:
#                     raise ValueError("No JSON object found in response.")
#             except (json.JSONDecodeError, ValidationError, ValueError) as e:
#                 logger.warning(f"LLM response failed validation on attempt {attempt+1}. Error: {e}. Attempting to repair.")
#                 repaired_json_str = self._repair_json(raw_text)
#                 if repaired_json_str:
#                     try:
#                         return response_model(**json.loads(repaired_json_str)).model_dump()
#                     except (json.JSONDecodeError, ValidationError) as final_e:
#                         logger.error(f"Parsing failed even after repair on attempt {attempt+1}. Final error: {final_e}")
#                         continue 
#                 else: 
#                     logger.error(f"LLM returned no content on attempt {attempt+1}.")
#         return None 

#     def _retrieve_rag_context(self, query_text: str, k: int = 2) -> str:
#         """Conceptual function to simulate RAG retrieval."""
#         retrieved_docs = []
#         if "datetime" in query_text.lower() or "timestamp" in query_text.lower():
#             retrieved_docs.append("RAG Context: SOP-DT-001: All datetime fields (e.g., 'receivedTime', 'RTC') must adhere to ISO 8601, populated by Ray-processed sensor logs. Non-compliant formats are flagged as critical errors. Historical issue #DT-789: inconsistent timestamps from IoT devices impacted analytics.")
#         if "null" in query_text.lower() or "completeness" in query_text.lower() or "missing" in query_text.lower():
#             retrieved_docs.append("RAG Context: Policy-COMP-002: 'Cumulative_Energy_wh_Export' and 'receivedTime' are mandatory. Missing values (nulls) are critical completeness failures. Past incident #COMP-456: 100% nulls in test dataset caused system failure.")
#         if "uniqueness" in query_text.lower() or "id" in query_text.lower() or "duplicate" in query_text.lower():
#             retrieved_docs.append("RAG Context: Data Model v3.1: 'Event_ID' and 'Generic_Event_Log_Sequence_Number' are unique identifiers. Duplicates indicate ingestion errors. Resolution for #UNIQ-112 involved Delta Lake MERGE.")
#         if "consistency" in query_text.lower() or "event_code" in query_text.lower():
#              retrieved_docs.append("RAG Context: Business Glossary Term: 'Event_Code' defines event type, linked to 'Event_ID'. An 'Event_ID' should consistently map to only one 'Event_Code'. Discrepancies indicate faulty replication. See DQ Report 2024-Q1.")
#         if "report generation" in query_text.lower():
#             retrieved_docs.append("RAG Context: Best Practices for DQ Reporting: Reports should be comprehensive, actionable, and based on validated DQ rules. Leverage historical DQ reports for trending. Performance optimization for PDF generation involves PySpark.")
#         if not retrieved_docs:
#             retrieved_docs.append("RAG Context: No specific past insights or documentation found for this query.")
#         return "\n".join(retrieved_docs[:k])

#     def get_rule_assessment(self, rule_context: str) -> Optional[Dict[str, Any]]:
#         rag_context = self._retrieve_rag_context(rule_context)
#         system_prompt = ("You are a highly analytical data quality analyst. Based on the provided raw evidence (total records, failing records, and actual data samples), and the following relevant contextual information retrieved from Weaviate (embeddings generated by Ray), you MUST directly provide a data quality score for the rule from 0.0 to 10.0. Here's the scoring guide:\n- **10.0 (Perfect):** No affected records, or negligible impact (<0.1% affected).\n- **8.0-9.9 (High Quality):** Very few affected records (0.1% to <1%), minor impact, easy to fix.\n- **5.0-7.9 (Moderate Quality):** Some affected records (1% to <10%), moderate impact, requires attention.\n- **1.0-4.9 (Low Quality):** Significant affected records (10% to <50%), high impact, critical issues.\n- **0.0 (Unusable):** Over 50% affected records, or fundamental flaws making the data entirely unusable for this rule.\nCarefully analyze the proportion of affected records and the nature of the samples. Integrate insights from the retrieved Weaviate context if it provides additional understanding of severity, history, or business impact. Then, provide a concise reasoning for the score. Respond with a single JSON object with keys 'rule_score' and 'reasoning'.")
#         messages = [SystemMessage(content=system_prompt), HumanMessage(content=f"--- Rule Evidence ---\n{rule_context}\n\n--- Retrieved Contextual Information from Weaviate ---\n{rag_context}")]
#         return self._invoke_llm(messages, LLMRuleScoreResponse)

#     def get_dimension_assessment(self, dimension_context: str) -> Optional[Dict[str, Any]]:
#         rag_context = self._retrieve_rag_context(dimension_context) 
#         system_prompt = ("You are a highly analytical and holistic data quality expert. You are given the total number of records in the dataset, and for each rule within a specific data quality dimension, you have its status (Pass/Fail/Error), the number of affected records, and an LLM-generated score with reasoning. Additionally, you have the following relevant contextual information retrieved from Weaviate (embeddings generated by Ray). Your task is to synthesize ALL this information for the dimension to provide a comprehensive overall score (0.0 to 10.0). Here's the scoring guide for dimensions:\n- **10.0 (Perfect):** All rules passed, or minor issues with negligible overall impact (<0.1% affected across critical rules).\n- **8.0-9.9 (High Quality):** Mostly passing rules, very few failures with minor aggregate impact (0.1% to <1% affected across critical rules).\n- **5.0-7.9 (Moderate Quality):** Mix of passing and failing rules, some moderate aggregate issues (1% to <10% affected across critical rules).\n- **1.0-4.9 (Low Quality):** Several significant failing rules (10% to <50% affected across critical rule), indicating major problems.\n- **0.0 (Unusable):** Pervasive failures across critical rules (>50% affected across critical rule), rendering the dimension's data fundamentally unreliable or unusable.\nCritically weigh the individual rule scores, the proportion of affected records for each rule, and the detailed reasoning provided by the LLM for each rule. Leverage the retrieved Weaviate context to better understand the severity, history, or business impact of these issues. Derive a single, balanced score for the entire dimension that reflects the overall data quality. Also, provide a concise qualitative observation explaining *why* the dimension received that score, referencing the rule outcomes and their impact. Your response MUST be a single JSON object with two keys: 'dimension_score' and 'observation'.")
#         messages = [SystemMessage(content=system_prompt), HumanMessage(content=f"--- Dimension Evidence ---\n{dimension_context}\n\n--- Retrieved Contextual Information from Weaviate ---\n{rag_context}")]
#         return self._invoke_llm(messages, LLMDimensionObservationResponse)
        
#     def get_overall_report(self, final_context: str) -> Optional[Dict[str, Any]]:
#         rag_context = self._retrieve_rag_context("overall data quality report generation")
#         system_prompt = ("You are a senior data quality director. Given the final calculated overall data quality score, and a summary of all dimensions including their LLM-generated scores, weights, and observations, along with general data quality knowledge from our Weaviate knowledge base (embeddings generated by Ray), write a comprehensive, executive-level report explaining the overall data quality status of the dataset. The report should provide actionable insights and a clear summary of strengths and weaknesses across dimensions. The value for the 'report' key must be a single flat string, formatted professionally (e.g., using markdown if suitable for display, but ensure it's a single string). Your response MUST be a single JSON object with one key: 'report'.")
#         messages = [SystemMessage(content=system_prompt), HumanMessage(content=f"--- Overall Report Context ---\n{final_context}\n\n--- Retrieved General DQ Information from Weaviate ---\n{rag_context}")]
#         return self._invoke_llm(messages, LLMOverallReportResponse)

# llm_service = LLMScoringAndObservation(api_key=GROQ_API_KEY)


# # ==============================================================================
# # 3. Enhanced Rule Execution and Evidence Gathering (from original Cell 4)
# # ==============================================================================
# print("\n--- Step 3: Executing Rules and Gathering Evidence for LLM... ---")

# def execute_and_gather_evidence(rule: dict, df: "SparkSession.DataFrame", total_records: int) -> dict:
#     description = rule.get("description", "").lower()
#     columns = rule.get("columns", []) 
#     if isinstance(rule.get("column"), str) and not columns:
#         columns = [rule["column"]]

#     result = {
#         "Rule Description": rule.get("description", "N/A"), 
#         "Column": ", ".join(columns) if columns else "N/A", 
#         "Dimension": rule.get("type", "Other").capitalize(), 
#         "Status": "Error", 
#         "Details": "Rule could not be processed.",
#         "Affected Records": "N/A", 
#         "llm_context": "" 
#     }
    
#     if not columns: 
#         result["Details"] = "Rule requires a target column(s) but none specified."
#         return result
    
#     col_name = columns[0] 
    
#     df_with_id = df.withColumn("dq_internal_id", F.monotonically_increasing_id())
#     try:
#         failing_records_df = None
        
#         if "unique" in description:
#             if len(columns) > 1:
#                 group_cols = [F.col(c) for c in columns]
#                 duplicate_values_df = df.groupBy(*group_cols).count().filter(F.col("count") > 1)
#                 if duplicate_values_df.count() > 0:
#                     failing_records_df = df_with_id.join(duplicate_values_df, on=columns, how="inner")
#                 else:
#                     failing_records_df = spark.createDataFrame([], df_with_id.schema)
#             else: 
#                 duplicate_values_df = df.groupBy(F.col(col_name)).count().filter(F.col("count") > 1).select(col_name)
#                 if duplicate_values_df.count() > 0:
#                     failing_records_df = df_with_id.join(duplicate_values_df, col_name, "inner")
#                 else:
#                     failing_records_df = spark.createDataFrame([], df_with_id.schema)

#         elif "null" in description or "empty" in description:
#             failing_records_df = df_with_id.filter(F.col(col_name).isNull() | (F.col(col_name) == ""))

#         elif "range" in description and "positive" in description:
#             failing_records_df = df_with_id.filter(F.col(col_name) <= 0)
#         elif "range" in description: 
#             print(f"  > NOTE: No explicit range found for rule '{rule.get('description', '')}'. Applying a 3-sigma statistical heuristic.")
#             stats = df_with_id.select(F.mean(col_name).alias("mean"), F.stddev(col_name).alias("stddev")).first()
#             if stats and stats['mean'] is not None and stats['stddev'] is not None:
#                 mean, stddev = stats['mean'], stats['stddev']
#                 upper_bound = mean + 3 * stddev
#                 lower_bound = mean - 3 * stddev
#                 failing_records_df = df_with_id.filter((F.col(col_name) < lower_bound) | (F.col(col_name) > upper_bound))
#             else:
#                 result["Details"] = f"Cannot apply range check: column '{col_name}' is not numeric or is empty."
#                 return result

#         elif "email format" in description:
#             # CORRECTED LINE: email_regex re-typed clean
#             email_regex = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
#             failing_records_df = df_with_id.filter(~F.col(col_name).rlike(email_regex))
            
#         elif "date format" in description and ("datetime" in description or "timestamp" in description):
#             failing_records_df = df_with_id.filter(F.col(col_name).isNull())
#             result["Details"] = "Identified records where datetime parsing failed in ingestion or are null."
            
#         elif "allowed values" in description and "status" in description and "SHIPPED, PENDING, CANCELLED" in description:
#             allowed_values = ["SHIPPED", "PENDING", "CANCELLED"]
#             failing_records_df = df_with_id.filter(~F.col(col_name).isin(allowed_values))

#         elif "zip code format" in description and "US zip code format" in description:
#             # CORRECTED LINE: zip_regex re-typed clean
#             zip_regex = r"^\d{5}(?:[-\s]\d{4})?$"
#             failing_records_df = df_with_id.filter(~F.col(col_name).rlike(zip_regex))
            
#         elif "consistency" in description and ("receivedtime" in description or "rtc" in description): 
#             if len(columns) >= 2:
#                 col1_name, col2_name = columns[0], columns[1]
#                 if col1_name in df_with_id.columns and col2_name in df_with_id.columns:
#                     col1, col2 = F.col(col1_name), F.col(col2_name)
#                     failing_records_df = df_with_id.filter(
#                         (col2.isNotNull() & col1.isNotNull() & (col2 < col1)) |
#                         (col2.isNull() != col1.isNull())
#                     )
#                     result["Details"] = f"Consistency check: '{col2_name}' is before '{col1_name}' or presence is inconsistent."
#                 else:
#                     result["Details"] = f"Consistency rule requires columns '{col1_name}' and '{col2_name}' but one or both not found."
#                     return result
#             else:
#                 result["Details"] = "Consistency rule requires at least two columns."
#                 return result
        
#         elif "consistency" in description and ("event_code" in description or "event_id" in description):
#             if len(columns) >= 2:
#                 col1_name, col2_name = columns[0], columns[1] 
#                 if col1_name in df_with_id.columns and col2_name in df_with_id.columns:
#                     col1, col2 = F.col(col1_name), F.col(col2_name) 
#                     inconsistent_event_ids = df_with_id.groupBy(col2).agg(F.countDistinct(col1).alias("distinct_codes")) \
#                                                 .filter(F.col("distinct_codes") > 1).select(col2)
                    
#                     failing_records_df = df_with_id.join(inconsistent_event_ids, on=col2.name, how="inner")
#                     result["Details"] = f"Consistency check: '{col2_name}' maps to multiple distinct '{col1_name}' values."
#                 else:
#                     result["Details"] = f"Consistency rule requires columns '{col1_name}' and '{col2_name}' but one or both not found."
#                     return result
#             else:
#                 result["Details"] = "Consistency rule requires at least two columns."
#                 return result

#         else:
#             result["Details"] = f"Rule interpreter could not understand or execute the rule: '{rule.get('description', '')}'"
#             return result
            
#         affected_count = failing_records_df.count()
#         result["Affected Records"] = affected_count
#         result["Status"] = "Fail" if affected_count > 0 else "Pass"

#         failing_sample = failing_records_df.select(col_name).limit(TOP_K_SAMPLES).toPandas()
        
#         passing_sample_df = df_with_id.join(failing_records_df.select("dq_internal_id"), on="dq_internal_id", how="left_anti") \
#                                    .select(col_name).limit(TOP_K_SAMPLES)
#         passing_sample = passing_sample_df.toPandas()
        
#         result["llm_context"] = (
#             f"Rule: '{rule['description']}' on column(s) '{', '.join(columns)}'.\n"
#             f"Total Records in Dataset: {total_records}, Records Affected by this rule: {affected_count}.\n"
#             f"Failing Samples (first {TOP_K_SAMPLES} rows if any):\n{failing_sample.to_string(index=False)}\n"
#             f"Passing Samples (first {TOP_K_SAMPLES} rows if any):\n{passing_sample.to_string(index=False)}\n"
#             f"Rule Status from script: {result['Status']}" 
#         )
#     except Exception as e:
#         result["Details"] = f"Error during Spark execution for rule '{rule.get('description', 'N/A')}': {str(e)}"
#     return result

# # ==============================================================================
# # 4. Assessment and Reporting (LLM Directly Scores Rules and Dimensions)
# # ==============================================================================
# print("\n" + "="*80)
# print("--- Step 4: Starting Data Quality Assessment (LLM Directly Scores Rules and Dimensions) ---")
# print("="*80)

# summary_stats = {"pass": 0, "fail": 0, "error": 0}
# rule_results = []

# # --- Part A: LLM Assess each rule based on raw evidence ---
# for i, rule in enumerate(rules):
#     print(f"\nAnalyzing Rule {i+1}/{len(rules)}: \"{rule.get('description', 'Unnamed Rule')}\"...")
#     if 'column' in rule and not isinstance(rule['column'], list):
#         rule['columns'] = [rule['column']] 
#         del rule['column'] 
#     elif 'column' not in rule and 'columns' not in rule:
#         rule['columns'] = [] 

#     evidence = execute_and_gather_evidence(rule, df_cleaned, total_records)
#     summary_stats[evidence["Status"].lower()] += 1
    
#     rule_result = {
#         "Rule Description": evidence["Rule Description"], 
#         "Column": evidence["Column"], 
#         "Dimension": evidence["Dimension"], 
#         "Status": evidence["Status"], 
#         "Affected Records": evidence["Affected Records"],
#         "Details": evidence["Details"] 
#     }
    
#     if evidence["Status"] != "Error":
#         rag_context = llm_service._retrieve_rag_context(evidence["Rule Description"]) 
#         llm_assessment = llm_service.get_rule_assessment(f"{evidence['llm_context']}\n\nRetrieved Context from Weaviate:\n{rag_context}") 
#         rule_result["llm_rule_score"] = llm_assessment["rule_score"] if llm_assessment else 0.0
#         rule_result["Details"] = llm_assessment["reasoning"] if llm_assessment else "LLM failed to generate reasoning for rule."
#         print(f"  > LLM Generated Rule Score: {rule_result['llm_rule_score']:.1f}/10")
#     else:
#         rule_result["llm_rule_score"] = 0.0
#         print(f"  > LLM Rule Score: 0.0/10 (Rule interpreter or execution error)")
            
#     rule_results.append(rule_result)

# # --- Part B: LLM Assess each dimension based on LLM-generated rule scores ---
# print("\n" + "="*80)
# print("--- Requesting LLM to Score Dimensions and Generate Observations ---")
# print("="*80)

# dimension_analysis = []
# for dim_name in DQ_PARAMS: 
#     # Manually re-type this print line
#     print(f"\nAnalyzing Dimension: {dim_name.capitalize()}...")
    
#     rules_for_dimension = [res for res in rule_results if res["Dimension"].lower() == dim_name]
    
#     rule_summaries_for_llm = []
#     for res in rules_for_dimension:
#         status_detail = f"Status: {res['Status']}"
#         affected_count = res['Affected Records'] if isinstance(res['Affected Records'], (int, float)) else 0
#         affected_percentage = (affected_count / total_records) * 100 if total_records > 0 else 0
        
#         if res["Status"] != "Error":
#             rule_summaries_for_llm.append(
#                 # Manually re-type these f-strings
#                 f"- Rule: '{res['Rule Description']}' on column(s) '{res['Column']}': {status_detail}\n"
#                 f"  Records Affected: {affected_count} out of {total_records} ({affected_percentage:.2f}%)\n"
#                 f"  LLM Generated Rule Score: {res['llm_rule_score']:.1f}/10\n"
#                 f"  LLM Reasoning: {res['Details']}" 
#             )
#         else:
#             rule_summaries_for_llm.append(
#                 # Manually re-type these f-strings
#                 f"- Rule: '{res['Rule Description']}' on column(s) '{res['Column']}': {status_detail}\n"
#                 f"  Details: {res['Details']}" 
#             )

#     if not rule_summaries_for_llm:
#         rule_summaries_for_llm.append("No rules were defined or successfully executed for this dimension.")

#     rag_context = llm_service._retrieve_rag_context(f"Data quality assessment for dimension: {dim_name}") 

#     # Manually re-type this entire dim_context_str assignment (including its f-strings)
#     dim_context_str = (
#         f"For the '{dim_name.capitalize()}' data quality dimension, the total dataset size is {total_records} records. "
#         f"Here are the detailed results of the individual rules for this dimension:\n"
#         + "\n".join(rule_summaries_for_llm) + 
#         f"\n\nBased on these detailed rule outcomes (including records affected, LLM-generated rule scores, and their reasoning), "
#         f"and the following context retrieved from Weaviate:\n{rag_context}\n"
#         f"assign an overall score (from 0.0 to 10.0) for the '{dim_name.capitalize()}' dimension. Provide a concise observation explaining this score."
#     )

#     llm_dim_assessment = llm_service.get_dimension_assessment(dim_context_str) 
    
#     llm_dimension_score = llm_dim_assessment['dimension_score'] if llm_dim_assessment else 0.0
#     observation = llm_dim_assessment['observation'] if llm_dim_assessment else "LLM failed to generate an observation."
    
#     # Manually re-type these print lines
#     print(f"  > LLM Generated Dimension Score: {llm_dimension_score:.1f}/10")
#     print(f"  > LLM Observation: {observation}")
    
#     dimension_analysis.append({
#         "Dimension": dim_name.capitalize(), 
#         "Weight (%)": f"{weights.get(dim_name, 0.0) * 100:.1f}", 
#         "Score (/10)": f"{llm_dimension_score:.1f}", 
#         "Observation": observation,
#         "llm_raw_dimension_score": llm_dimension_score 
#     })

# # --- Part C: Generate Overall Report ---
# print("\n" + "="*80)
# print("--- Generating Final Overall Report ---")
# print("="*80)

# overall_score = 0
# for item in dimension_analysis:
#     score = item['llm_raw_dimension_score'] 
#     dim_name_lower = item['Dimension'].lower()
#     weight_value = weights.get(dim_name_lower, 0.0) 
#     overall_score += score * weight_value

# final_context_list = [
#     # Manually re-type this entire f-string line
#     f"- {item['Dimension']} (Weight: {item['Weight (%)']}%), Final Score: {item['Score (/10)']}/10, Observation: {item['Observation']}" 
#     for item in dimension_analysis
# ]
# # Manually re-type this entire final_context_str assignment (including its f-string parts)
# final_context_str = (
#     f"The final weighted data quality score is {overall_score:.1f}/10, based on the following dimension scores and observations:\n" + 
#     "\n".join(final_context_list) + 
#     f"\n\nPlease provide a comprehensive report explaining this overall score. The report value must be a single flat string."
# )


# overall_report = llm_service.get_overall_report(final_context_str)
# report_text = overall_report['report'] if overall_report else "LLM failed to generate the final report."

# # ==============================================================================
# # 5. Prepare Final Report for Job Output (from original Cell 4)
# # ==============================================================================
# # This section prepares a structured JSON object to be returned via dbutils.notebook.exit()
# # Ensure the report summary is concise enough for Databricks job output limits.

# final_report_for_output = {
#     "overall_dq_score": float(f"{overall_score:.1f}"),
#     "overall_observation": report_text,
#     "summary_of_checks": {
#         "total_rules_assessed": sum(summary_stats.values()),
#         "rules_passed": summary_stats["pass"],
#         "rules_failed": summary_stats["fail"],
#         "rules_with_errors": summary_stats["error"]
#     },
#     "dimension_analysis": [
#         {k: v for k, v in d.items() if k != 'llm_raw_dimension_score'}
#         for d in dimension_analysis
#     ],
#     "detailed_rule_results_summary": [
#         {k: v for k, v in r.items() if k not in ['llm_context', 'llm_rule_score', 'Details']} # Keep core summary
#         for r in rule_results
#     ],
#     "timestamp": pd.Timestamp.now().isoformat()
# }

# # --- FINAL STEP: Exit the notebook with the JSON output ---
# # This is what the Next.js API route will retrieve from jobs/runs/get-output
# dbutils.notebook.exit(json.dumps(final_report_for_output))

# COMMAND ----------

# MAGIC %pip install langchain_groq langchain langchain_core langchain_community langchain_huggingface

# COMMAND ----------

# Notebook Cell to Fix final_rules.json

import json

# The path where your rules file is stored.
# Ensure this matches the path in your assessment script.
rules_file_path = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"

# This is the correct, structured JSON content that the assessment script needs.
correct_rules_structure = [
  {
    "name": "Check for invalid datetime values in receivedTime and RTC columns",
    "dimension": "Accuracy",
    "rule_type": "IS_DATETIME",
    "columns": ["receivedTime", "RTC"],
    "params": {"format": "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"}
  },
  {
    "name": "Validate that energy values are not negative",
    "dimension": "Accuracy",
    "rule_type": "SQL_EXPRESSION",
    "columns": ["cumulative_energy_wh_import", "cumulative_energy_wh_export"],
    "params": {
      "expression": "cumulative_energy_wh_import >= 0 AND cumulative_energy_wh_export >= 0"
    }
  },
  {
    "name": "Ensure 'receivedTime' and 'RTC' columns are not null",
    "dimension": "Completeness",
    "rule_type": "IS_NOT_NULL",
    "columns": ["receivedTime", "RTC"]
  },
  {
    "name": "Ensure key Event fields are not null",
    "dimension": "Completeness",
    "rule_type": "IS_NOT_NULL",
    "columns": ["Event_ID", "Event_Type", "Event_Name", "Status", "Discom", "Date", "Time", "Generic_Event_Log_Sequence_Number"]
  },
  {
    "name": "Check for consistency between Date and RTC columns",
    "dimension": "Consistency",
    "rule_type": "SQL_EXPRESSION",
    "columns": ["Date", "RTC"],
    "params": {
      "expression": "to_date(RTC) = to_date(Date, 'M/d/yyyy')"
    }
  },
  {
    "name": "Check that energy import is greater than or equal to export",
    "dimension": "Consistency",
    "rule_type": "SQL_EXPRESSION",
    "columns": ["cumulative_energy_wh_import", "cumulative_energy_wh_export"],
     "params": {
      "expression": "cumulative_energy_wh_import >= cumulative_energy_wh_export"
    }
  },
  {
    "name": "Unique Event ID",
    "dimension": "Uniqueness",
    "rule_type": "IS_UNIQUE",
    "columns": ["Event_ID"]
  },
  {
    "name": "Unique Device ID",
    "dimension": "Uniqueness",
    "rule_type": "IS_UNIQUE",
    "columns": ["deviceId"]
  }
]

# Convert the Python dictionary to a JSON string
rules_json_string = json.dumps(correct_rules_structure, indent=2)

# Write the correct content to the file in DBFS, overwriting the old file
dbutils.fs.put(rules_file_path, rules_json_string, overwrite=True)

print(f"✅ Successfully created and saved the corrected rules file to:\n{rules_file_path}")
print("\nYou can now re-run your main assessment notebook.")

# COMMAND ----------

# Notebook: Populate_Weaviate_Notebook
# Purpose: To embed sample data and index it into the Weaviate vector database.

import json
import os
import weaviate
from weaviate.classes.init import Auth
from langchain_huggingface import HuggingFaceEmbeddings
from pyspark.sql import SparkSession
import pandas as pd

print("--- Initializing ---")
# --- Spark Session ---
spark = SparkSession.builder.appName("Weaviate_Indexing_Job").getOrCreate()

# --- Configuration and Secure Credential Loading ---
# Using Databricks Secrets is the recommended best practice for security.
try:
    HF_API_KEY = "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"
    WEAVIATE_URL = "https://uhhkpzivqgs19vnjsfkpgw.c0.asia-southeast1.gcp.weaviate.cloud"
    WEAVIATE_API_KEY = "UFprcmhzdnZVUzEyTlJYbl9GV0VWYjVqNUM0dG53dG5Ea2VSWlhoNEh4YlhyQmxTajIvM1B4TzZGYVFBPV92MjAw"
    print("✅ Successfully loaded API credentials from Databricks Secrets.")
except Exception as e:
    print(f"❌ Could not load credentials from Databricks Secrets. Please create a scope named 'api_keys' with the required keys. Error: {e}")
    dbutils.notebook.exit("Failed to load secrets.")

# Set Hugging Face API token as an environment variable for the library to detect
os.environ['HUGGINGFACEHUB_API_TOKEN'] = HF_API_KEY

# --- Constants ---
# The table containing the data you want to create the RAG context from
SOURCE_DATA_TABLE = "hive_metastore.default.dq_ingested_clean_sample" 
# The Weaviate collection name from your screenshot
WEAVIATE_COLLECTION_NAME = "DataQualitySample" 
# Number of sample records to index
SAMPLE_SIZE = 20

print(f"--- Connecting to Weaviate and Initializing Models ---")
# --- Initialize Weaviate Client ---
client = weaviate.connect_to_weaviate_cloud(
    cluster_url=WEAVIATE_URL,
    auth_credentials=Auth.api_key(WEAVIATE_API_KEY)
)

# --- Initialize Hugging Face Embedding Model ---
# This model will be used to turn your text data into vector embeddings
try:
    embeddings_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    print(f"✅ HuggingFaceEmbeddings model initialized.")
except Exception as e:
    print(f"❌ Failed to initialize HuggingFaceEmbeddings model: {e}")
    client.close()
    dbutils.notebook.exit("Embedding model failure.")

try:
    print(f"--- Preparing Weaviate Collection: {WEAVIATE_COLLECTION_NAME} ---")
    # Get the collection object
    collection = client.collections.get(WEAVIATE_COLLECTION_NAME)

    print(f"--- Loading and Sampling Data from {SOURCE_DATA_TABLE} ---")
    # Load data and take a sample
    df_sample = spark.read.format("delta").table(SOURCE_DATA_TABLE).limit(SAMPLE_SIZE)
    pdf_sample = df_sample.toPandas()
    print(f"✅ Loaded {len(pdf_sample)} records to be indexed.")

    print(f"--- Generating Embeddings and Indexing Data ---")
    # Configure Weaviate for a batch import
    with collection.batch.dynamic() as batch:
        for index, row in pdf_sample.iterrows():
            # Convert the entire row to a JSON string. This will be our text property.
            record_text = row.to_json()
            
            # Generate the vector embedding for the text
            embedding_vector = embeddings_model.embed_query(record_text)
            
            # Create the properties dictionary for the Weaviate object
            properties = {
                "record_json": record_text,
            }

            # Add the object with its properties and vector to the batch
            batch.add_object(
                properties=properties,
                vector=embedding_vector 
            )
            if (index + 1) % 100 == 0:
                print(f"  > Prepared {index + 1}/{len(pdf_sample)} objects for indexing...")

    print(f"✅ Successfully indexed {len(pdf_sample)} documents into the '{WEAVIATE_COLLECTION_NAME}' collection.")

finally:
    # Always ensure the client connection is closed
    if 'client' in locals() and client:
        client.close()
        print("✅ Weaviate client connection closed.")

# COMMAND ----------

# Notebook: DQ_Assessment_Generator_Notebook (Runtime Parameter Enabled)
# Purpose: Accept rules/weights as job parameters, perform RAG assessment, and return a report.

# --- Dependency Installation ---
%pip install langchain-huggingface weaviate-client>=4.0.0 langchain-groq pandas numpy

import json
from typing import Type, List, Dict, Any, Optional
import re
import logging
import os
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.functions as F

# --- LLM, Pydantic, and Weaviate Imports ---
from langchain_groq.chat_models import ChatGroq
from langchain.schema import SystemMessage, HumanMessage
from pydantic import BaseModel, Field
try:
    import weaviate
    from weaviate.classes.init import Auth
    from langchain_huggingface import HuggingFaceEmbeddings
    WEAVIATE_CLIENT_AVAILABLE = True
    print("✅ 'weaviate-client' and 'langchain_huggingface' modules are available.")
except ImportError:
    WEAVIATE_CLIENT_AVAILABLE = False
    print("⚠️ Weaviate or Langchain module missing. RAG will be disabled.")

# --- Spark and Logging Setup ---
spark = SparkSession.builder.appName("DQ_Assessment_Job_RAG_Final").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_assessment_notebook_rag_final')
print("✅ Spark Session and Logger initialized.")

# ==============================================================================
# 1. Configuration and Credential Loading
# ==============================================================================
print("\n--- Step 1: Loading Configuration and Credentials ---")
# Using Databricks Secrets is the recommended best practice for security.
try:
    GROQ_API_KEY = "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"
    HF_API_KEY = "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"
    WEAVIATE_URL = "https://uhhkpzivqgs19vnjsfkpgw.c0.asia-southeast1.gcp.weaviate.cloud"
    WEAVIATE_API_KEY = "UFprcmhzdnZVUzEyTlJYbl9GV0VWYjVqNUM0dG53dG5Ea2VSWlhoNEh4YlhyQmxTajIvM1B4TzZGYVFBPV92MjAw"
    print("✅ Successfully loaded API credentials from Databricks Secrets.")
except Exception as e:
    dbutils.notebook.exit(f"❌ Failed to load secrets: {e}")

os.environ['HUGGINGFACEHUB_API_TOKEN'] = HF_API_KEY

# --- Define Paths and Constants ---
RULES_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
WEIGHTS_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"
CLEANED_DATA_DELTA_TABLE_FQDN = "hive_metastore.default.dq_ingested_clean_sample"
TOP_K_SAMPLES = 10
WEAVIATE_COLLECTION_NAME = "DataQualitySample"
RAG_RETRIEVAL_COUNT = 5


# ==============================================================================
# 2. LLM and RAG Interaction Layer
# ==============================================================================
print("\n--- Step 2: Initializing LLM and RAG Interaction Layer... ---")
# (This class remains unchanged from the previous version)
class LLMRuleScoreResponse(BaseModel):
    rule_score: float = Field(...)
    reasoning: str = Field(...)
class LLMDimensionObservationResponse(BaseModel):
    dimension_score: float = Field(...)
    observation: str = Field(...)
class LLMFinalAssessmentResponse(BaseModel):
    final_score: float = Field(...)
    final_observation: str = Field(...)
class LLMScoringAndObservation:
    def __init__(self, groq_api_key: str, weaviate_url: str, weaviate_api_key: str):
        self.llm = ChatGroq(model="llama3-8b-8192", temperature=0.1, api_key=groq_api_key)
        self.weaviate_client = None
        self.hf_embeddings_model = None
        if WEAVIATE_CLIENT_AVAILABLE:
            try:
                self.weaviate_client = weaviate.connect_to_weaviate_cloud(cluster_url=weaviate_url, auth_credentials=Auth.api_key(weaviate_api_key))
                self.hf_embeddings_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
                if self.weaviate_client.is_ready(): print("✅ Weaviate client and HuggingFace Embeddings model initialized successfully.")
            except Exception as e:
                print(f"❌ Weaviate/HF-Embeddings initialization failed: {e}. RAG will be disabled.")
                if self.weaviate_client: self.weaviate_client.close()
                self.weaviate_client = None
    def close_connections(self):
        if self.weaviate_client: self.weaviate_client.close(); print("✅ Weaviate client connection closed.")
    def _retrieve_rag_context(self, query_text: str) -> str:
        if not self.weaviate_client or not self.hf_embeddings_model: return "RAG DISABLED"
        try:
            query_vector = self.hf_embeddings_model.embed_query(query_text)
            collection = self.weaviate_client.collections.get(WEAVIATE_COLLECTION_NAME)
            response = collection.query.near_vector(near_vector=query_vector, limit=RAG_RETRIEVAL_COUNT, return_properties=["record_json"])
            if not response.objects: return "RAG CONTEXT: No relevant documents found."
            retrieved_docs = [f"- {obj.properties['record_json'][:250]}..." for obj in response.objects]
            return "--- START RETRIEVED RAG CONTEXT ---\n" + "\n".join(retrieved_docs) + "\n--- END RETRIEVED RAG CONTEXT ---"
        except Exception as e:
            return f"RAG FAILED: {e}"
    def _invoke_llm(self, messages: List, response_schema: Type[BaseModel]) -> Dict[str, Any]:
        try:
            raw_response = self.llm.invoke(messages).content
            match = re.search(r'\{.*\}', raw_response, re.DOTALL)
            json_str = match.group(0) if match else raw_response
            return response_schema.model_validate_json(json_str).model_dump()
        except Exception as e:
            error_message = f"LLM call or JSON parsing failed. Error: {str(e)}"
            logger.error(error_message, exc_info=True)
            return {"error": error_message}
    def _create_prompt(self, task_description: str, context: str, schema: Type[BaseModel], example: str) -> List[SystemMessage | HumanMessage]:
        system_prompt = (f"You are an API that returns a single, valid JSON object conforming to the '{schema.__name__}' schema. "
                         f"Do not include explanations. Your response must be ONLY the JSON object. Example:\n{example}\n\nTASK: {task_description}")
        return [SystemMessage(content=system_prompt), HumanMessage(content=f"---CONTEXT---\n{context}")]
    def get_rule_assessment(self, rule_context: str) -> Dict[str, Any]:
        rag_context = self._retrieve_rag_context(rule_context)
        augmented_context = f"{rule_context}\n\n{rag_context}"
        task = "Analyze the rule evidence, augmented with RAG context, to generate a DQ score and reasoning."
        example = '{"rule_score": 7.5, "reasoning": "Based on RAG context, this failure is medium severity."}'
        return self._invoke_llm(self._create_prompt(task, augmented_context, LLMRuleScoreResponse, example), LLMRuleScoreResponse)
    def get_dimension_assessment(self, dim_context: str) -> Dict[str, Any]:
        task = "Synthesize all rule outcomes for the dimension, augmented with RAG context, to provide an overall score and observation."
        example = '{"dimension_score": 8.2, "observation": "This dimension is in good health."}'
        return self._invoke_llm(self._create_prompt(task, dim_context, LLMDimensionObservationResponse, example), LLMDimensionObservationResponse)
    def get_final_assessment(self, final_context: str) -> Dict[str, Any]:
        task = "Calculate the final weighted score and write an executive summary."
        example = '{"final_score": 6.8, "final_observation": "Overall quality is moderate."}'
        return self._invoke_llm(self._create_prompt(task, final_context, LLMFinalAssessmentResponse, example), LLMFinalAssessmentResponse)


# ==============================================================================
# 3. Robust Rule Execution Engine
# ==============================================================================
print("\n--- Step 3: Initializing Rule Execution Engine ---")
# (This function remains unchanged)
def execute_structured_rule(rule: dict, df: "SparkSession.DataFrame") -> dict:
    rule_name, dimension, rule_type, columns, params = rule.get("name"), rule.get("dimension"), rule.get("rule_type"), rule.get("columns", []), rule.get("params", {})
    result = {"Rule Description": rule_name, "Column": ", ".join(columns), "Dimension": dimension, "Status": "Error", "Affected Records": 0, "Details": f"Rule type '{rule_type}' is not supported.", "llm_context": ""}
    if not rule_type or not columns or not all(c in df.columns for c in columns):
        result["Details"] = "Rule is misconfigured (missing type, columns, or column not in DataFrame)."
        return result
    try:
        failing_records_df = None
        if rule_type == "IS_NOT_NULL":
            failing_records_df = df.filter(" OR ".join([f"`{c}` IS NULL" for c in columns]))
        elif rule_type == "IS_UNIQUE":
            failing_records_df = df.groupBy(*columns).count().filter("count > 1").join(df, columns, "inner")
        elif rule_type == "SQL_EXPRESSION":
            expression = params.get("expression")
            if not expression: result["Details"] = "SQL_EXPRESSION rule is missing 'expression' parameter."; return result
            failing_records_df = df.filter(f"NOT ({expression})")
        elif rule_type == "IS_DATETIME":
            date_col = columns[0]
            failing_records_df = df.withColumn("casted_date", F.to_timestamp(F.col(date_col))).filter(F.col(date_col).isNotNull() & F.col("casted_date").isNull())
        else:
            return result
        affected_count = failing_records_df.count()
        result.update({"Affected Records": affected_count, "Status": "Fail" if affected_count > 0 else "Pass", "Details": f"Found {affected_count} failing records." if affected_count > 0 else "All records passed."})
        failing_sample_pd = failing_records_df.select(*columns).limit(TOP_K_SAMPLES).toPandas()
        result["llm_context"] = f"Rule: '{rule_name}'.\nTotal Records: {df.count()}, Failing Records: {affected_count}.\nFailing Samples:\n{failing_sample_pd.to_string(index=False)}"
        return result
    except Exception as e:
        result["Details"] = f"Spark execution failed: {str(e)}"; return result


# ==============================================================================
# 4. Main Application Logic
# ==============================================================================
print("\n--- Step 4: Starting Data Quality Assessment ---")

llm_service = None
try:
    # --- Define and Retrieve Job Parameters (Widgets) ---
    dbutils.widgets.text("rules_json", "", "Rules configuration as a JSON string")
    dbutils.widgets.text("weights_json", "", "Weights configuration as a JSON string")
    
    rules_param = dbutils.widgets.get("rules_json")
    weights_param = dbutils.widgets.get("weights_json")

    # --- Load Rules and Weights (Prioritize Job Parameters) ---
    rules, weights = [], {}
    if rules_param and weights_param:
        print("✅ Loading rules and weights from job parameters.")
        rules = json.loads(rules_param)
        weights = json.loads(weights_param)
    else:
        print("⚠️ Job parameters not found. Falling back to loading from DBFS files.")
        rules = json.loads(dbutils.fs.head(RULES_PATH_INTERNAL))
        weights = json.loads(dbutils.fs.head(WEIGHTS_PATH_INTERNAL))

    if not isinstance(rules, list) or not rules: raise ValueError("Rules are not a valid list or are empty.")
    if not weights: raise ValueError("Weights could not be loaded.")
    print(f"✅ Loaded {len(rules)} rules and {len(weights)} weights.")

    # --- Load Data and Initialize Services ---
    df_cleaned = spark.read.format("delta").table(CLEANED_DATA_DELTA_TABLE_FQDN)
    summary_stats = {"pass": 0, "fail": 0, "error": 0}
    rule_results = []
    llm_service = LLMScoringAndObservation(GROQ_API_KEY, WEAVIATE_URL, WEAVIATE_API_KEY)

    # --- Part A: Assess each rule ---
    for rule in rules:
        # ... (This loop remains unchanged) ...
        if not isinstance(rule, dict): continue
        print(f"\nAnalyzing Rule: \"{rule.get('name', 'Unnamed Rule')}\"...")
        evidence = execute_structured_rule(rule, df_cleaned)
        summary_stats[evidence["Status"].lower()] += 1
        
        if evidence["Status"] != "Error":
            llm_assessment = llm_service.get_rule_assessment(evidence['llm_context'])
            if "error" in llm_assessment:
                evidence["llm_rule_score"] = 0.0
                evidence["Details"] = llm_assessment["error"]
            else:
                evidence["llm_rule_score"] = llm_assessment.get("rule_score", 0.0)
                evidence["Details"] = llm_assessment.get("reasoning", "LLM reasoning missing.")
        else:
            evidence["llm_rule_score"] = 0.0
        
        print(f"  > Rule Score: {evidence.get('llm_rule_score', 0.0):.1f}/10")
        rule_results.append(evidence)

    # --- Part B: Assess each dimension ---
    print("\n--- Scoring Dimensions using LLM ---")
    dimension_analysis = []
    for dim_name in list(weights.keys()):
        # ... (This loop remains unchanged) ...
        rules_for_dim = [res for res in rule_results if res["Dimension"].lower() == dim_name]
        dim_context_str = f"For the '{dim_name.capitalize()}' dimension (Weight: {weights.get(dim_name, 0)*100}%):\n" + "\n".join([f"- Rule: '{r['Rule Description']}' | Score: {r.get('llm_rule_score', 0.0):.1f}" for r in rules_for_dim])
        llm_dim_assessment = llm_service.get_dimension_assessment(dim_context_str)
        dimension_analysis.append({"Dimension": dim_name.capitalize(), "Weight (%)": f"{weights.get(dim_name, 0.0) * 100:.1f}", "Score (/10)": f"{llm_dim_assessment.get('dimension_score', 0.0):.1f}", "Observation": llm_dim_assessment.get("observation", "LLM assessment failed.")})


    # --- Part C: Generate Final Report ---
    print("\n--- Generating Final Report using LLM ---")
    final_context_list = [f"- {d['Dimension']} (Weight: {d['Weight (%)']}%): Score={d['Score (/10)']}/10" for d in dimension_analysis]
    final_context_str = "Calculate the final score and provide an executive summary:\n" + "\n".join(final_context_list)
    final_assessment = llm_service.get_final_assessment(final_context_str)
    overall_score = final_assessment.get("final_score", 0.0)
    report_text = final_assessment.get("final_observation", "LLM failed to generate the final report.")
    
    # --- Assemble Final Report ---
    final_report_for_output = {"overall_dq_score": float(f"{overall_score:.2f}"), "overall_observation": report_text, "summary_of_checks": { "total_rules_assessed": len(rules), **summary_stats }, "dimension_analysis": dimension_analysis, "detailed_rule_results": [{k: v for k, v in r.items() if k not in ['llm_context', 'llm_rule_score']} for r in rule_results], "timestamp": pd.Timestamp.now().isoformat()}
    
except Exception as e:
    logger.error(f"An unexpected error occurred: {e}", exc_info=True)
    dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"An unexpected error occurred: {e}"}))
finally:
    if llm_service: llm_service.close_connections()

print("\n--- Assessment Complete. Exiting notebook with final report. ---")
dbutils.notebook.exit(json.dumps(final_report_for_output, indent=2))

# COMMAND ----------

