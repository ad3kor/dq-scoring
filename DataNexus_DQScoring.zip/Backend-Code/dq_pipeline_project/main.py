# Databricks notebook source
import os
import requests

# (Optional) If you set environment variables:
# host = os.getenv('DATABRICKS_HOST')
# token = os.getenv('DATABRICKS_TOKEN')

# Or hard-code (not recommended for production):
host = "https://adb-615732812296608.8.azuredatabricks.net"
token = "dapi87fc9a58a4c685b4f729feaf46ac9d1a-3"

# Example: List workspace files under a path
api_url = f"{host}/api/2.0/workspace/list"
payload = {"path": "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/notebook"}
headers = {"Authorization": f"Bearer {token}"}

response = requests.get(api_url, headers=headers, json=payload)
if response.status_code == 200:
    print(response.json())
else:
    print(f"Error {response.status_code}: {response.text}")

# COMMAND ----------

import os
import requests
import base64

# host = os.getenv("DATABRICKS_HOST")
# token = os.getenv("DATABRICKS_TOKEN")
# headers = {"Authorization": f"Bearer {token}"}

# Read .dbc archive binary
with open("/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/notebook/notebook.py", "rb") as f:
    content = base64.b64encode(f.read()).decode("utf-8")

payload = {
    "path": "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/notebook",
    "format": "DBC",
    "content": content,
    # omit or set overwrite to False for DBC
    "overwrite": False
}
url = f"{host}/api/2.0/workspace/import"
response = requests.post(url, headers=headers, json=payload)
print(response.status_code, response.text)

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# Create a new Job that runs a notebook on your existing cluster
job_spec = {
    "name": "DQ_Assessment_Job_REST",
    "existing_cluster_id": "0528-062614-4bed8314",  # your Cluster ID
    "notebook_task": {
        "notebook_path": "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/notebook/notebook.py"
    }
}

url = f"{host}/api/2.0/jobs/create"
response = requests.post(url, headers=headers, json=job_spec)
print(response.status_code, response.json())  # JSON contains "job_id"

# COMMAND ----------

update_spec = {
    "job_id": 9964461470638,  # the job ID you got earlier
    "new_settings": {
        "existing_cluster_id": "0528-062614-4bed8314",
        "notebook_task": { "notebook_path": "/Workspace/Users/.../new_notebook" }
    }
}

url = f"{host}/api/2.0/jobs/reset"
response = requests.post(url, headers=headers, json=update_spec)
print(response.status_code)

# COMMAND ----------

run_spec = {"job_id": 763028447018713}
url = f"{host}/api/2.0/jobs/run-now"
response = requests.post(url, headers=headers, json=run_spec)
print(response.status_code, response.json())  # JSON has "run_id"

# COMMAND ----------

# MAGIC %pip install -r /Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/requirements.txt

# COMMAND ----------

# MAGIC %sh
# MAGIC cd /Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/ui
# MAGIC streamlit run streamlit_app.py --server.port 8501 --server.address 127.0.0.1 --server.port 8000 

# COMMAND ----------



# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

