# Databricks notebook source
# MAGIC %pip install -r requirements.txt
# MAGIC

# COMMAND ----------

# ----------- run_pipeline_single_node.py -----------
# Runs on a memory-constrained, single-node Databricks cluster.
# Limits the dataset to 10,000 rows to avoid OOM and performs
# data quality analysis on that bounded sample.

import os
import logging
import traceback

from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import pandas as pd

from ingestion.ingestion import IngestionManager
from sampling.stage3_diversity_sampling import DiversitySampler
from rule_suggester.chunked_rule_suggester import ChunkedRuleSuggester
from assessment.dq_assessment import DQAssessment
from reporting.report_generator import ReportGenerator

# COMMAND ----------

# Cell 1: Setup, Configuration, and Widgets

import os
import logging
import json
import gc
from typing import Any, List, Dict
from collections import defaultdict
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType,
    DoubleType, TimestampType, IntegerType
)

# --- Memory Safety & Configuration ---
# Suppress the benign tokenizers parallelism warning
os.environ["TOKENIZERS_PARALLELISM"] = "false"
MAX_ROWS_TO_PROCESS = 50  # A safe, low limit to prevent OOM errors.
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]
RULES_PATH = "/dbfs/FileStore/reports/final_rules.json"
WEIGHTS_PATH = "/dbfs/FileStore/reports/final_weights.json"

# --- Spark and Logging Setup ---
spark = SparkSession.builder.appName("DQ_Pipeline_Memory_Safe").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.final')
print("✅ Spark Session and Logger initialized.")

# --- Widget Creation ---
try:
    dbutils.widgets.removeAll()
    dbutils.widgets.text("file_path", "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx", "1. Input File Path")
    dbutils.widgets.text("file_type", "excel", "2. Input File Type")
    print("✅ Widgets created. Please set your input file path above.")
except:
    print("⚠️ Could not create Databricks widgets. Using default file path.")

# COMMAND ----------

# Cell 2: Data Ingestion and Type Casting

file_path = dbutils.widgets.get("file_path")
file_type = dbutils.widgets.get("file_type").lower()

print(f"Attempting to ingest from: '{file_path}'")

tr# Fetch values from the widgets      .load(file_path)
    )

    # 2. Aggressively limit the DataFrame size IMMEDIATELY after loading
    df_limited = df_full.limit(MAX_ROWS_TO_PROCESS)

    # 3. Explicitly Cast Data Types for Accuracy and Memory Efficiency
    print("Correcting column data types...")
    # Define your schema based on the provided column list
    numeric_cols = [
        "current", "voltage", "power_factor", "current_ib", "current_ir", "current_iy",
        "voltage_vbn", "voltage_vrn", "voltage_vyn", "power_factor_b_phase",
        "power_factor_r_phase", "power_factor_y_phase", "cumulative_energy_wh_import",
        "cumulative_energy_wh_export"
    ]
    timestamp_cols = ["receivedTime", "RTC"]
    
    df_typed = df_limited
    for col_name in numeric_cols:
        if col_name in df_typed.columns:
            df_typed = df_typed.withColumn(col_name, F.col(col_name).cast(DoubleType()))

    for col_name in timestamp_cols:
        if col_name in df_typed.columns:
            df_typed = df_typed.withColumn(col_name, F.to_timestamp(F.col(col_name)))

    # 4. Cache the final, small, correctly-typed DataFrame
    df = df_typed.cache()
    row_cnt = df.count() # Trigger cache and get count
    
    print(f"✅ Ingestion successful. Sampled and typed DataFrame 'df' with {row_cnt} rows is ready.")
    df.printSchema()

except Exception as e:
    print(f"❌ Data ingestion failed. Error: {e}")
    spark.stop()
    raise e

# COMMAND ----------

# Cell 3: Interactive Rule Generation and Editing Loop
# Re-run this cell multiple times to apply edits from the widgets.

# Assumes custom class is available
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester

# --- 1. State Management: Load or Generate Rules ---
try:
    with open(RULES_PATH, "r") as f: final_rules = json.load(f)
    with open(WEIGHTS_PATH, "r") as f: final_weights = json.load(f)
    print("✅ Loaded previously saved rules and weights.")
except FileNotFoundError:
    print("ℹ️ Generating initial rules from LLM...")
    pdf_for_profiling = df.toPandas()
    suggester = IntelligentRuleSuggester()
    initial_rules = suggester.suggest_rules(pdf_for_profiling).get("rules", [])
    final_weights = {p: 25.0 for p in DQ_PARAMS}
    # Fallback mechanism to ensure all 4 parameters are present
    existing_param_types = {r.get('type') for r in initial_rules}
    for param in DQ_PARAMS:
        if param not in existing_param_types:
            initial_rules.append({"rule_id": f"{param[:3].upper()}_DEFAULT", "description": f"Default placeholder for {param}.", "columns": [], "type": param, "rule_template": "CUSTOM", "parameters": {}})
    final_rules = initial_rules

# --- 2. Display Current State and Create Widgets ---
param_rules = defaultdict(list)
for r in final_rules: param_rules[r.get("type", "other")].append(r)

print("\n--- CURRENT DATA QUALITY RULES ---")
for param in DQ_PARAMS:
    if rules_list := param_rules.get(param):
        print(f"\nPARAMETER: {param.upper()} (Current Weight: {final_weights.get(param, 0):.1f}%)")
        for i, rule in enumerate(rules_list): print(f"  {i+1}. {rule['description']}")

dbutils.widgets.text("ACTION", "", "Enter edits in widgets and re-run this cell")
for param in DQ_PARAMS:
    dbutils.widgets.text(f"weight_{param}", str(final_weights.get(param, 25.0)))
    dbutils.widgets.text(f"remove_{param}", "")
    dbutils.widgets.text(f"add_{param}", "")
print("\n--- ✅ Widgets ready. Re-run cell to apply edits. ---")

# --- 3. Process Edits ---
def get_widget(name: str, default: Any=""):
    try: return dbutils.widgets.get(name)
    except: return default

for param in DQ_PARAMS:
    final_weights[param] = float(get_widget(f"weight_{param}", final_weights.get(param, 25.0)))
    if rules_to_remove := get_widget(f"remove_{param}"):
        indices = {int(x.strip()) - 1 for x in rules_to_remove.split(',')}
        param_rules[param] = [rule for i, rule in enumerate(param_rules.get(param, [])) if i not in indices]
    if new_desc := get_widget(f"add_{param}"):
        param_rules[param].append({"rule_id": f"user_{param}", "description": new_desc, "columns": [], "type": param, "rule_template": "CUSTOM"})

final_rules = [r for r_list in param_rules.values() for r in r_list]
total_weight = sum(final_weights.values())
if total_weight > 0: final_weights = {p: w / total_weight * 100 for p, w in final_weights.items()}

# --- 4. Save State ---
dbutils.fs.put(RULES_PATH, json.dumps(final_rules), overwrite=True)
dbutils.fs.put(WEIGHTS_PATH, json.dumps(final_weights), overwrite=True)
print("\n--- State Saved ---")

# COMMAND ----------

/dbfs/FileStore/reports/DQ_Report_20250611_101433.pdf

# COMMAND ----------

# --- Execution ---
# This ensures the code runs when executed as a notebook cell
if 'spark' not in locals():
    spark = SparkSession.builder.appName("DQ_Pipeline_Wrapper").getOrCreate()

main()

# Stop the spark session after the main function has completed
spark.stop()
logger.info("Pipeline run complete. Spark session stopped.")

# COMMAND ----------

# =============================================================================
# FINAL, DYNAMIC, AND INTERACTIVE DATA QUALITY PIPELINE
# This single, self-contained script handles all steps from setup to reporting,
# engineered for a single-node cluster.
# =============================================================================

# -----------------------------------------------------------------------------
# 1. SETUP, IMPORTS, AND WIDGET CREATION
# -----------------------------------------------------------------------------
print("--- Step 1: Initializing Setup and Widgets ---")

import os
import logging
import json
import gc
from typing import Any, List, Dict
from collections import defaultdict
import pandas as pd
import matplotlib.pyplot as plt
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType,
    DoubleType, TimestampType, IntegerType
)

# Assumes custom modules are in your project workspace
from ingestion.ingestion import IngestionManager
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester
from reporting.report_generator import ReportGenerator

# --- Configuration & Setup ---
# Suppress the benign tokenizers parallelism warning
os.environ["TOKENIZERS_PARALLELISM"] = "false"
spark = SparkSession.builder.appName("DQ_Pipeline_Final_Unified").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.final')

MAX_ROWS_TO_PROCESS = 50
# The four DQ dimensions for the project. 
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]
INITIAL_WEIGHTS = {p: 25.0 for p in DQ_PARAMS}
RULES_PATH = "/dbfs/FileStore/reports/final_rules.json"
WEIGHTS_PATH = "/dbfs/FileStore/reports/final_weights.json"

# --- Create all necessary widgets upfront to prevent errors ---
try:
    dbutils.widgets.removeAll()
    dbutils.widgets.text("file_path", "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx", "1. Input File Path")
    dbutils.widgets.text("report_output_dir", "/dbfs/FileStore/reports", "2. Report Output Directory")
    print("✅ Widgets created. Please configure them above.")
except Exception:
    print("⚠️ Could not create Databricks widgets. Using default paths.")

# -----------------------------------------------------------------------------
# 2. DYNAMIC DATA INGESTION AND TYPE CASTING
# -----------------------------------------------------------------------------
print("\n--- Step 2: Ingesting and Preparing Data ---")
file_path = dbutils.widgets.get("file_path")
try:
    # This dynamic ingestion uses Databricks connectors to handle various sources. 
    df_full = spark.read.format("com.crealytics.spark.excel").option("header", "true").option("inferSchema", "true").load(file_path)
    
    # Explicitly cast data types for accuracy, based on your provided schema
    numeric_cols = ["current", "voltage", "power_factor", "current_ib", "current_ir", "current_iy", "voltage_vbn", "voltage_vrn", "voltage_vyn", "power_factor_b_phase", "power_factor_r_phase", "power_factor_y_phase", "cumulative_energy_wh_import", "cumulative_energy_wh_export"]
    timestamp_cols = ["receivedTime", "RTC"]
    
    df_typed = df_full
    for col_name in numeric_cols:
        if col_name in df_typed.columns: df_typed = df_typed.withColumn(col_name, F.col(col_name).cast(DoubleType()))
    for col_name in timestamp_cols:
        if col_name in df_typed.columns: df_typed = df_typed.withColumn(col_name, F.to_timestamp(F.col(col_name)))
    
    # Limit data size for memory safety on a single node
    df = df_typed.limit(MAX_ROWS_TO_PROCESS).cache()
    df.count() # Trigger cache
    print(f"✅ Ingestion successful. Using DataFrame 'df' with {df.count()} rows for analysis.")
except Exception as e:
    print(f"❌ Data ingestion failed. Error: {e}")
    spark.stop()
    raise e

# -----------------------------------------------------------------------------
# 3. INTERACTIVE RULE GENERATION AND EDITING
# -----------------------------------------------------------------------------
print("\n--- Step 3: Interactive Rule Generation & Editing ---")
# This process uses a stateful loop: it saves your edits to JSON files and re-loads them each time you run the script.
try:
    with open(RULES_PATH, "r") as f: final_rules = json.load(f)
    with open(WEIGHTS_PATH, "r") as f: final_weights = json.load(f)
    print("✅ Loaded previously saved rules and weights.")
except FileNotFoundError:
    print("ℹ️ No saved state found. Generating initial rules from LLM...")
    # The LLM generates rules based on a dynamic profile of the ingested data. 
    pdf_for_profiling = df.toPandas()
    suggester = IntelligentRuleSuggester()
    final_rules = suggester.suggest_rules(pdf_for_profiling).get("rules", [])
    final_weights = INITIAL_WEIGHTS

param_rules = defaultdict(list)
for r in final_rules: param_rules[r.get("type", "other")].append(r)

# This section creates the interactive UI for rule and weight refinement. 
print("\n--- REVIEW & EDIT RULES VIA WIDGETS ---")
for param in DQ_PARAMS:
    if rules_list := param_rules.get(param):
        print(f"\nPARAMETER: {param.upper()} (Weight: {final_weights.get(param, 0):.1f}%)")
        for i, rule in enumerate(rules_list): print(f"  {i+1}. {rule['description']}")
dbutils.widgets.text("ACTION", "", "Enter edits and re-run this cell")
for param in DQ_PARAMS:
    dbutils.widgets.text(f"weight_{param}", str(final_weights.get(param, 25.0)))
    dbutils.widgets.text(f"remove_{param}", ""); dbutils.widgets.text(f"add_{param}", "")
def get_widget(name: str, default: Any=""):
    try: return dbutils.widgets.get(name)
    except: return default

user_edits={"weights":{},"remove":{},"add":{}}
for p in DQ_PARAMS:
    user_edits["weights"][p] = float(get_widget(f"weight_{p}","25.0"))
    if rem_indices := get_widget(f"remove_{p}"): param_rules[p] = [r for i, r in enumerate(param_rules.get(p,[])) if (i+1) not in [int(x.strip()) for x in rem_indices.split(',')]]
    if add_desc := get_widget(f"add_{p}"): param_rules[p].append({"rule_id": f"user_{p}", "description": add_desc, "columns": [], "type": p, "rule_template": "CUSTOM"})
final_rules=[r for r_list in param_rules.values() for r in r_list]
total_w=sum(user_edits["weights"].values());
if total_w > 0: final_weights={p:w/total_w*100 for p,w in user_edits["weights"].items()}
dbutils.fs.put(RULES_PATH, json.dumps(final_rules), overwrite=True)
dbutils.fs.put(WEIGHTS_PATH, json.dumps(final_weights), overwrite=True)
print("\n--- ✅ State Saved. Proceeding to final assessment. ---")

# -----------------------------------------------------------------------------
# 4. FINAL ASSESSMENT, VISUALIZATION, AND REPORTING
# -----------------------------------------------------------------------------
print("\n--- Step 4: Final Assessment, Visualization, and Reporting ---")
def run_dq_assessment(df, rules, spark):
    """The self-contained Rule Engine that translates templates to Spark SQL."""
    results = []; total_records = df.count();
    if total_records == 0: total_records = 1
    for rule in rules:
        template, columns, params = rule.get("rule_template"), rule.get("columns", []), rule.get("parameters", {})
        sql_expr, fail_count = "", 0
        try:
            if not template or template == "CUSTOM" or not columns: continue
            col_name = f"`{columns[0]}`"
            if template == "IS_NOT_NULL": sql_expr = f"{col_name} IS NOT NULL"
            elif template == "IS_BETWEEN": sql_expr = f"CAST({col_name} AS double) BETWEEN {params.get('min')} AND {params.get('max')}"
            else: continue
            if sql_expr: fail_count = df.where(f"NOT ({sql_expr})").count()
        except Exception as e: logger.warning(f"Could not evaluate rule '{rule.get('description')}': {e}"); fail_count = -1
        pass_count = total_records - fail_count if fail_count != -1 else 0
        score = (pass_count / total_records) if fail_count != -1 else 0.0
        results.append({"description": rule.get("description"), "type": rule.get("type"), "columns": ", ".join(columns), "fail_count": int(fail_count), "score": float(score)})
    schema = StructType([StructField("description", StringType()), StructField("type", StringType()), StructField("columns", StringType()), StructField("fail_count", LongType()), StructField("score", DoubleType())])
    return spark.createDataFrame(results, schema=schema)

results_df = run_dq_assessment(df, final_rules, spark); results_df.cache()
results_pd = results_df.toPandas()
param_scores = {p: round(results_pd[results_pd['type'] == p]['score'].mean() * 10, 1) if not results_pd[results_pd['type'] == p].empty else None for p in DQ_PARAMS}
overall_score = sum(param_scores.get(p, 0) * (final_weights.get(p, 0) / 100.0) for p in DQ_PARAMS if param_scores.get(p) is not None) * 10 / (sum(final_weights.get(p,0) for p in DQ_PARAMS if param_scores.get(p) is not None)/100.0) if sum(final_weights.values()) > 0 else 0.0

print("\n--- DATA QUALITY SCORE SUMMARY ---")
for param, score in param_scores.items(): print(f"  - Score for {param.capitalize():<15}: {score if score is not None else 'N/A':>4} / 10.0")
print("-" * 40); print(f"  - Final Weighted Overall Score: {overall_score:.2f} / 10.0")

print("\n--- SCORE VISUALIZATION ---")
labels = [p.capitalize() for p, s in param_scores.items() if s is not None]; scores = [s for s in param_scores.values() if s is not None]
if scores:
    fig, ax = plt.subplots(figsize=(8, 4)); bars = ax.bar(labels, scores)
    ax.set_ylabel('Score (out of 10)'); ax.set_title('Data Quality Scores by Parameter'); ax.set_ylim(0, 10.5)
    for bar in bars: yval = bar.get_height(); plt.text(bar.get_x() + bar.get_width()/2.0, yval + 0.1, f'{yval:.1f}', ha='center', va='bottom')
    display(fig)

print("\n--- DETAILED RULE ASSESSMENT RESULTS ---")
display(results_df.selectExpr("type as Parameter", "description as `Rule Description`", "columns as `Applied to Columns`", "fail_count as `Failure Count`"))

print("\n--- Generating Final PDF Report ---")
try:
    report_df_for_pdf = results_df.selectExpr("description AS `Rule Description`", "columns AS `Columns`", "type AS `Type`", f"score * {df.count()} AS `Score`", "fail_count AS `Fail Count`")
    report_gen = ReportGenerator(output_dir="/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_reports")
    pdf_path = report_gen.generate(report_df_for_pdf)
    print(f"✅ Final report generated at: {pdf_path}")
except Exception as e:
    print(f"⚠️ Could not generate PDF report. Error: {e}")

# -----------------------------------------------------------------------------
# 5. FINAL CLEANUP
# -----------------------------------------------------------------------------
dbutils.fs.rm(RULES_PATH, recurse=True)
dbutils.fs.rm(WEIGHTS_PATH, recurse=True)
spark.stop()
print("\n--- Pipeline Finished ---")

# COMMAND ----------

import os
from langchain_groq.chat_models import ChatGroq
from langchain.schema import SystemMessage, HumanMessage, AIMessage

print("--- Starting Groq LLM Connection Debugging ---")

# 1. Check for the GROQ_API_KEY environment variable
# In Databricks, this must be set up via Secrets.
api_key = os.environ.get("GROQ_API_KEY")
if not api_key:
    print("\nERROR: GROQ_API_KEY environment variable not found!")
    print("ACTION: Please ensure your API key is stored as a Databricks secret and that the cluster has access to it.")
else:
    print(f"\nSUCCESS: Found GROQ_API_KEY environment variable starting with '{api_key[:4]}...'.")

# 2. Attempt a direct and simple API call
if api_key:
    try:
        print("\nAttempting a simple test call to the Groq API...")
        
        # Using a standard, reliable model for the test
        llm = ChatGroq(model_name="llama3-8b-8192", temperature=0)
        
        messages = [
            SystemMessage(content="You are a helpful assistant."),
            HumanMessage(content="Simply respond with the word 'Success' and nothing else."),
        ]
        
        response = llm.invoke(messages)
        
        # 3. Print the raw response object and its type for inspection
        print("\n--- Raw LLM Response ---")
        print(f"Response Object Type: {type(response)}")
        print(f"Raw Response Object: {response}")
        
        # 4. Check if the response is valid and contains the expected content
        print("\n--- Verifying Response Content ---")
        if isinstance(response, AIMessage) and hasattr(response, 'content'):
            print(f"SUCCESS: The response object is valid. Content: '{response.content.strip()}'")
        else:
            print("ERROR: The response object is not a valid AIMessage or lacks a '.content' attribute.")
            print("This indicates the API call failed and returned an error object instead of a successful response.")

    except Exception as e:
        print(f"\n--- AN ERROR OCCURRED DURING THE API CALL ---")
        print("The API call failed with a critical exception, which is the likely cause of your pipeline's failure.")
        print(f"Error Type: {type(e)}")
        print(f"Error Details: {e}")

print("\n--- End of Debugging ---")

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# MAGIC %pip install reportlab

# COMMAND ----------

# MAGIC %pip install -U threadpoolctl

# COMMAND ----------

# Cell 4: Rule Engine, Assessment, and Scoring

import json
import pyspark.sql.functions as F
from pyspark.sql.types import StructType, StructField, StringType, LongType, DoubleType
from typing import List, Dict, Any

# ==============================================================================
# 1. Load Final Rules and Weights from Cell 3
# ==============================================================================
print("Step 1: Loading final rules and weights...")

RULES_PATH = "/dbfs/FileStore/reports/final_rules.json"
WEIGHTS_PATH = "/dbfs/FileStore/reports/final_weights.json"
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"]

try:
    with open(RULES_PATH, "r") as f:
        final_rules = json.load(f)
    with open(WEIGHTS_PATH, "r") as f:
        weights = json.load(f) # These are percentages, e.g., {'accuracy': 25.0, ...}
    print(f"✅ Loaded {len(final_rules)} final rules and weights.")
except FileNotFoundError:
    raise FileNotFoundError("Could not find rules/weights files. Please ensure Cell 3 has been run successfully.")

# ==============================================================================
# 2. Define the Rule Engine Function (Replaces DQAssessment)
# ==============================================================================
def run_dq_assessment(df: 'DataFrame', rules: List[Dict], spark: 'SparkSession') -> 'DataFrame':
    """
    Acts as a rule engine to reliably execute DQ rule templates against a Spark DataFrame.
    """
    results = []
    total_records = df.count()
    if total_records == 0:
        total_records = 1  # Avoid division by zero

    for rule in rules:
        template = rule.get("rule_template")
        columns = rule.get("columns", [])
        params = rule.get("parameters", {})
        sql_expr = ""
        fail_count = 0

        try:
            if not template or template == "CUSTOM":
                # Skip user-added custom rules that don't have a defined template
                logger.warning(f"Skipping rule with custom/unknown template: {rule.get('description')}")
                continue

            if not columns:
                raise ValueError("Rule is missing the 'columns' field.")

            col_name = f"`{columns[0]}`"

            # --- Rule Template to SQL Translation Logic ---
            if template == "IS_NOT_NULL":
                sql_expr = f"{col_name} IS NOT NULL"
            elif template == "IS_BETWEEN":
                min_val, max_val = params.get("min"), params.get("max")
                if min_val is None or max_val is None: raise ValueError("IS_BETWEEN requires 'min' and 'max' parameters.")
                sql_expr = f"CAST({col_name} AS double) BETWEEN {min_val} AND {max_val}"
            elif template == "IS_UNIQUE":
                duplicate_df = df.groupBy(columns).count().where("count > 1")
                # Sum the counts of the duplicated groups to get the total number of non-unique records
                fail_count = duplicate_df.agg(F.sum("count")).first()[0]
                fail_count = int(fail_count) if fail_count is not None else 0
            # Add other templates here as needed
            else:
                raise ValueError(f"Unknown rule template: {template}")

            if sql_expr:  # For rules that produce a row-level SQL expression
                failure_condition = f"NOT ({sql_expr})"
                fail_count = df.where(failure_condition).count()

        except Exception as e:
            logger.warning(f"Could not evaluate rule '{rule.get('description')}': {e}")
            fail_count = -1  # Signify an evaluation error

        # Score is the percentage of passing records
        pass_count = total_records - fail_count if fail_count != -1 else 0
        score = pass_count / total_records if fail_count != -1 else 0.0

        results.append({
            "description": rule.get("description", "N/A"),
            "type": rule.get("type", "other"),
            "score": float(score)
        })

    results_schema = StructType([
        StructField("description", StringType(), True),
        StructField("type", StringType(), True),
        StructField("score", DoubleType(), True),
    ])
    return spark.createDataFrame(results, schema=results_schema)

# ==============================================================================
# 3. Execute Assessment and Calculate Final Scores
# ==============================================================================
print("\nStep 2: Executing data quality assessment...")
if 'df' not in locals():
    raise NameError("DataFrame 'df' not found. Please run the ingestion cell first.")

results_df = run_dq_assessment(df, final_rules, spark)
results_df.cache()
print("✅ Assessment complete.")
display(results_df)

# --- Calculate final scores per parameter ---
results_pd = results_df.toPandas()
param_scores = {}
param_obs = {}

for p in DQ_PARAMS:
    param_df = results_pd[results_pd['type'] == p]
    if not param_df.empty:
        avg_score = param_df['score'].mean() * 10
        param_scores[p] = round(avg_score, 1)
    else:
        param_scores[p] = None # Use None if no rules were evaluated for the param

    # Generate a simple observation based on the score
    score = param_scores.get(p)
    if score is None: param_obs[p] = "No rules of this type were evaluated."
    elif score >= 9: param_obs[p] = f"Data quality for {p} is excellent."
    elif score >= 7: param_obs[p] = f"Data quality for {p} is good, with minor issues found."
    else: param_obs[p] = f"Significant {p} issues detected; improvement recommended."

# --- Compute overall weighted DQ score ---
overall_score = 0.0
total_weight = sum(weights.values())
if total_weight > 0:
    # Weights are given as percentages (e.g., 25.0), so we divide by 100
    weighted_score_sum = sum(param_scores.get(p, 0) * (weights.get(p, 0)/100.0) for p in DQ_PARAMS if param_scores.get(p) is not None)
    overall_score = round(weighted_score_sum, 2)

# ==============================================================================
# 4. Save Summary for Final Report
# ==============================================================================
print("\nStep 3: Saving summary for report generation...")
summary_stats = {
    "overall_score": overall_score,
    "param_scores": param_scores,
    "param_obs": param_obs,
    "weights": weights
}

with open("/dbfs/FileStore/reports/summary_stats.json", "w") as f:
    json.dump(summary_stats, f)
print("✅ Summary stats saved. Ready for Cell 5 (Reporting).")

# COMMAND ----------

# Cell 5 – Display Results and PDF Report with Dimension Breakdown

import pickle,os
from reporting.report_generator import ReportGenerator

# Load stats prepared in cell 4
with open("/dbfs/FileStore/reports/summary_stats.pkl", "rb") as f:
    summary_stats = pickle.load(f)

# Load rule-level summary DataFrame (produced in Cell 4 and saved as parquet/csv/pkl)
import pandas as pd
rule_summary_path = "/dbfs/FileStore/reports/summary_df.pkl"
if os.path.exists(rule_summary_path):
    summary_df = pd.read_pickle(rule_summary_path)
else:
    # fallback: create dummy
    summary_df = pd.DataFrame(columns=["Rule Description", "Columns", "Type", "Score", "Fail Count"])

# Show summary in notebook
print(f"\nOverall DQ Score: {summary_stats['overall_score']}/10")
print("Overall Assessment:", summary_stats["overall_assessment"])
print("Summary of Checks:")
print(f"  Total Rules Assessed: {summary_stats['total_rules']}")
print(f"  Rules Passed: {summary_stats['rules_passed']}")
print(f"  Rules Failed: {summary_stats['rules_failed']}")
print(f"  Rules with Errors: {summary_stats['rules_with_error']}")

print("\nDimension Analysis:")
dim_data = []
for p in summary_stats["param_scores"]:
    dim_data.append({
        "Dimension": p.capitalize(),
        "Weight (%)": f"{int(summary_stats['weights'][p]*100)}%",
        "Score (/10)": f"{summary_stats['param_scores'][p]}/10" if summary_stats['param_scores'][p] is not None else "-",
        "Observation": summary_stats["param_obs"][p]
    })
dim_df = pd.DataFrame(dim_data)
display(dim_df)

# Show all rule results in notebook for completeness
if summary_df is not None and not summary_df.empty:
    display(summary_df)
else:
    print("No rule summary data to display.")


# Create PDF report (fpdf in ReportGenerator)
output_dir = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_reports"
report_gen = ReportGenerator(output_dir=output_dir)
pdf_path   = report_gen.generate_dimension_summary(summary_stats, dim_df, summary_df)
print(f"Report saved at: {pdf_path}")
