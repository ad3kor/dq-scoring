# Databricks notebook source
# MAGIC %pip install -r requirements.txt
# MAGIC

# COMMAND ----------

# Cell 1: Setup, Configuration, and Widgets

import os
import logging
import json
import gc
from typing import Any, List, Dict
from collections import defaultdict
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType,
    DoubleType, TimestampType, IntegerType
)

# --- Memory Safety & Configuration ---
# Suppress the benign tokenizers parallelism warning
os.environ["TOKENIZERS_PARALLELISM"] = "false"
MAX_ROWS_TO_PROCESS = 50  # A safe, low limit to prevent OOM errors.
# DQ_PARAMS will be dynamically loaded from weights file in Cell 4
# RULES_PATH and WEIGHTS_PATH must match Cell 3's saving location
RULES_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
WEIGHTS_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# --- Spark and Logging Setup ---
spark = SparkSession.builder.appName("DQ_Pipeline_Memory_Safe").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_pipeline.final')
print("✅ Spark Session and Logger initialized.")

# --- Widget Creation and Parameter Retrieval ---
# When this notebook is run as a Databricks Job by the Next.js API,
# the 'dbutils.widgets.get()' calls will automatically retrieve the
# parameters passed in the 'notebook_params' of the jobs/run-now API call.
# The default values are used only when running interactively in the notebook.
try:
    dbutils.widgets.removeAll() # Clean up any existing widgets

    # Define widgets to receive parameters from Next.js API route
    # These widget names MUST match the keys in 'notebook_params' from your Next.js API route
    dbutils.widgets.text("param_source_type", "Local/Cloud File Upload", "1. Source Type (from Next.js)")
    dbutils.widgets.text("param_file_path", "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx", "2a. File Path (for Local/Cloud)")
    dbutils.widgets.text("param_file_type", "excel", "2b. File Type (for Local/Cloud)")
    dbutils.widgets.text("param_azure_storage_account_name", "fofstrprdeusdata", "3a. Azure Storage Account Name") # Updated default
    dbutils.widgets.text("param_azure_container_name", "genai", "3b. Azure Container Name") # Updated default
    dbutils.widgets.text("param_azure_blob_path", "New_Query_2025_05_09_12_33pm.csv", "3c. Azure Blob Path") # Updated default
    dbutils.widgets.text("param_data_age_months", "0", "4. Data Age in Months") # Default for int conversion

    print("✅ Databricks widgets defined for job parameters.")

    # Retrieve parameters into variables that will be used in Cell 2
    # These variables will carry the values from the Next.js API call (if run as job)
    # or the widget defaults/user selections (if run interactively).
    source_type_param = dbutils.widgets.get("param_source_type")
    file_path_param = dbutils.widgets.get("param_file_path")
    file_type_param = dbutils.widgets.get("param_file_type")
    azure_storage_account_name_param = dbutils.widgets.get("param_azure_storage_account_name")
    azure_container_name_param = dbutils.widgets.get("param_azure_container_name")
    azure_blob_path_param = dbutils.widgets.get("param_azure_blob_path")
    data_age_months_param = dbutils.widgets.get("param_data_age_months")

    print("✅ Parameters retrieved from widgets/job context.")

except Exception as e:
    print(f"⚠️ Could not create or retrieve Databricks widgets. Using hardcoded defaults. Error: {e}")
    # Fallback hardcoded defaults for extreme cases (e.g., dbutils not available)
    source_type_param = "Local/Cloud File Upload"
    file_path_param = "dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx"
    file_type_param = "excel"
    azure_storage_account_name_param = "fofstrprdeusdata"
    azure_container_name_param = "genai"
    azure_blob_path_param = "New_Query_2025_05_09_12_33pm.csv"
    data_age_months_param = "0"

# COMMAND ----------

# Cell 2: Data Ingestion and Type Casting (Updated to use parameters from Cell 1)

# Use the parameters retrieved in Cell 1
source_type = source_type_param # from Cell 1
file_path_local_cloud = file_path_param # from Cell 1
file_type_local_cloud = file_type_param.lower() # from Cell 1
azure_storage_account_name = azure_storage_account_name_param # from Cell 1
azure_container_name = azure_container_name_param # from Cell 1
azure_blob_path = azure_blob_path_param # from Cell 1
# data_age_months is retrieved but not used directly in ingestion; its purpose is likely for DQ rules

print(f"Attempting to ingest from: '{file_path_local_cloud}' (Source Type: {source_type})")
print(f"Azure Config: Account='{azure_storage_account_name}', Container='{azure_container_name}', Blob Path='{azure_blob_path}'")

# --- Azure Credentials Configuration (Using Account Key) ---
# IMPORTANT: Replace "<YOUR_AZURE_STORAGE_ACCOUNT_KEY>" with your actual key.
# For production environments, use Databricks Secrets (dbutils.secrets.get) instead of hardcoding.
# Note: You have this key hardcoded. Ensure it's correct for your environment.
AZURE_STORAGE_ACCOUNT_KEY = "uFMlAoFfhS8ljTMXrIxFa76QXotavNGoy89xfkYgck5ob7M5NHkpJUpFGjiFzEDCOxQmZyA96JDW+ASthlLHEA==" 

if source_type == "Azure Blob Storage (WASBS)":
    if not AZURE_STORAGE_ACCOUNT_KEY:
        raise ValueError("Azure Storage Account Key is not set. Please update the AZURE_STORAGE_ACCOUNT_KEY variable in Cell 2.")
    
    spark.conf.set(
        f"fs.azure.account.key.{azure_storage_account_name}.blob.core.windows.net",
        AZURE_STORAGE_ACCOUNT_KEY
    )
    print(f"Configured Spark with account key for storage account: {azure_storage_account_name}")
# --- End Azure Credentials Configuration ---

df_full = None
try:
    if source_type == "Local/Cloud File Upload":
        print(f"Attempting to ingest from local/cloud path: '{file_path_local_cloud}' (Type: {file_type_local_cloud})")
        
        reader = spark.read.option("header", "true").option("inferSchema", "true")
        
        if file_type_local_cloud == "excel":
            df_full = reader.format("com.crealytics.spark.excel").load(file_path_local_cloud)
        elif file_type_local_cloud == "csv":
            df_full = reader.csv(file_path_local_cloud)
        elif file_type_local_cloud == "json":
            df_full = reader.json(file_path_local_cloud)
        elif file_type_local_cloud == "parquet":
            df_full = reader.parquet(file_path_local_cloud)
        else:
            raise ValueError(f"Unsupported file type for local/cloud upload: {file_type_local_cloud}")

    elif source_type == "Azure Blob Storage (WASBS)":
        if not azure_storage_account_name or not azure_container_name or not azure_blob_path:
            raise ValueError("Azure Storage Account, Container, and Blob Path cannot be empty for Azure Blob Storage ingestion.")
        
        wasbs_path = f"wasbs://{azure_container_name}@{azure_storage_account_name}.blob.core.windows.net/{azure_blob_path}"
        print(f"Attempting to ingest from Azure Blob Storage: '{wasbs_path}'")
        
        blob_file_extension = azure_blob_path.split('.')[-1].lower()
        reader = spark.read.option("header", "true").option("inferSchema", "true")

        if blob_file_extension == "csv":
            df_full = reader.csv(wasbs_path)
        elif blob_file_extension == "json":
            df_full = reader.json(wasbs_path)
        elif blob_file_extension == "parquet":
            df_full = reader.parquet(wasbs_path)
        elif blob_file_extension == "xlsx": # For excel from WASBS, still needs the connector
             df_full = reader.format("com.crealytics.spark.excel").load(wasbs_path)
        else:
            print(f"Warning: Auto-detected Azure blob file type '{blob_file_extension}' from path. If incorrect, data might not load correctly.")
            df_full = reader.csv(wasbs_path) 

    else:
        raise ValueError(f"Unknown source type selected: {source_type}")

    # 2. Aggressively limit the DataFrame size IMMEDIATELY after loading
    df_limited = df_full.limit(MAX_ROWS_TO_PROCESS)

    # 3. Explicitly Cast Data Types for Accuracy and Memory Efficiency
    print("Correcting column data types...")
    
    numeric_cols = [
        "current", "voltage", "power_factor", "current_ib", "current_ir", "current_iy",
        "voltage_vbn", "voltage_vrn", "voltage_vyn", "power_factor_b_phase",
        "power_factor_r_phase", "power_factor_y_phase", "cumulative_energy_wh_import",
        "cumulative_energy_wh_export"
    ]
    timestamp_cols = ["receivedTime", "RTC"]
    
    df_typed = df_limited
    for col_name in numeric_cols:
        if col_name in df_typed.columns:
            df_typed = df_typed.withColumn(col_name, F.col(col_name).cast(DoubleType()))

    from pyspark.sql.functions import col, lit, to_timestamp, expr, when, array, to_date 
    from pyspark.sql.types import StringType, TimestampType

    TIMESTAMP_FORMATS = [
        "yyyy-MM-dd HH:mm:ss.SSS",
        "yyyy-MM-dd HH:mm:ss",
        "MM/dd/yyyy HH:mm:ss",
        "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", 
        "yyyy-MM-dd'T'HH:mm:ss",          
        "dd-MM-yyyy HH:mm:ss",              
        "dd/MM/yyyy HH:mm:ss",              
        "yyyy-MM-dd HH:mm:ss,SSS"         
    ]

    DATE_FORMATS = [
        "yyyy-MM-dd",
        "MM/dd/yyyy",
        "dd-MM-yyyy",
        "dd/MM/yyyy"
    ]

    for col_name in timestamp_cols:
        if col_name in df_typed.columns:
            print(f"  > Processing timestamp column: {col_name}")
            
            current_col_type = df_typed.schema[col_name].dataType
            if str(current_col_type) != "StringType":
                df_typed = df_typed.withColumn(col_name, F.col(col_name).cast(StringType()))

            parsed_col = F.lit(None).cast(TimestampType())

            for fmt in TIMESTAMP_FORMATS:
                parsed_col = F.when(
                    F.col(col_name).isNotNull(), 
                    F.coalesce(parsed_col, F.to_timestamp(F.col(col_name), fmt))
                ).otherwise(parsed_col) 

            for fmt in DATE_FORMATS:
                parsed_date_to_ts = F.to_timestamp(F.to_date(F.col(col_name), fmt))
                parsed_col = F.when(
                    F.col(col_name).isNotNull(), 
                    F.coalesce(parsed_col, parsed_date_to_ts)
                ).otherwise(parsed_col)


            df_typed = df_typed.withColumn(col_name, parsed_col)
            print(f"  > Applied robust timestamp parsing for column: {col_name}")

    # 4. Cache the final, small, correctly-typed DataFrame
    df = df_typed.cache()
    row_cnt = df.count() # Trigger cache and get count
    
    print(f"✅ Ingestion successful. Sampled and typed DataFrame 'df' with {row_cnt} rows is ready.")
    df.printSchema()

except Exception as e:
    print(f"❌ Data ingestion failed. Error: {e}")
    raise e

# COMMAND ----------

# MAGIC %pip install reportlab

# COMMAND ----------

# MAGIC %pip install -U threadpoolctl

# COMMAND ----------

# Cell 3: Data Cleaning & Stateless Interactive Rule Editing Loop (Corrected and Verified)

import pandas as pd
from collections import defaultdict
import json
from typing import Any, List, Dict
import logging
import os
import numpy as np # Import numpy for numerical comparisons
import time # Import time for potential small delays

# Imports for Spark data cleaning
from pyspark.sql import functions as F
from pyspark.sql.types import TimestampType

# Assumes your custom IntelligentRuleSuggester class is available
# Ensure this class is accessible in your Databricks environment
from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester 

# --- Configuration & Logger ---
# DQ_PARAMS can be dynamically updated by user, so initialize it as a list first
DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"] 

# *** UPDATED PATHS FOR STORING RULES AND WEIGHTS ***
# Define paths with /dbfs prefix for dbutils.fs.put
RULES_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
WEIGHTS_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# Define the *internal* DBFS path without /dbfs prefix for dbutils.fs.head
DBFS_RULES_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
DBFS_WEIGHTS_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

logger = logging.getLogger('dq_pipeline.interactive')

# ==============================================================================
# 1. Data Cleaning
# ==============================================================================
print("--- Step 1: Cleaning timestamps to prevent conversion errors... ---")

pd_min_ts = pd.Timestamp.min.to_pydatetime()
pd_max_ts = pd.Timestamp.max.to_pydatetime()
df_cleaned = df # Assuming 'df' is your Spark DataFrame from previous cell
timestamp_cols = [field.name for field in df.schema.fields if isinstance(field.dataType, TimestampType)]

if timestamp_cols:
    print(f"Found timestamp columns to clean: {timestamp_cols}")
    for col_name in timestamp_cols:
        df_cleaned = df_cleaned.withColumn(col_name, F.when((F.col(col_name) >= pd_min_ts) & (F.col(col_name) <= pd_max_ts), F.col(col_name)).otherwise(F.lit(None)))
    print("✅ Timestamp cleaning complete.")
else:
    print("No timestamp columns found to clean.")

# ==============================================================================
# 2. Generate Initial Rules
# ==============================================================================
print("\n--- Step 2: Generating a new, data-driven set of rules from the LLM... ---")
# Sample data for LLM if df_cleaned is too large
# For petabyte scale, this sampling must be distributed and managed by Ray/Spark as per Stage 1 and 2 
# Here, for demonstration, we'll convert to Pandas, but in a real scenario, you'd apply the multi-stage sampling
# strategy here to get a 'pdf_for_profiling' that is small and diverse.
# For now, assuming df_cleaned is small enough for toPandas for prototype
try:
    pdf_for_profiling = df_cleaned.toPandas()
except Exception as e:
    print(f"Warning: Could not convert Spark DataFrame to Pandas for profiling directly. Error: {e}")
    print("Using a small sample for LLM profiling.")
    # Implement a small, direct sample for local profiling if the full conversion fails
    pdf_for_profiling = df_cleaned.limit(1000).toPandas() # Limit to a small number of rows

suggester = IntelligentRuleSuggester()
result = suggester.suggest_rules(pdf_for_profiling) # This should generate initial rules based on the sampled data
rules: List[Dict[str, Any]] = result.get("rules", []) # Ensure 'rules' is typed correctly

# Initialize weights based on initial DQ_PARAMS, distributing equally
# This 'weights' dictionary will be directly modified by the user
weights = {p: 100.0 / len(DQ_PARAMS) for p in DQ_PARAMS}

if not rules:
    print("LLM failed to generate any rules. Attempting to generate default rules for demonstration.")
    # Fallback to some default rules if LLM fails
    rules = [
        {"type": "completeness", "description": "Ensure 'id' column is not null.", "column": "id", "condition": "isNotNull"},
        {"type": "uniqueness", "description": "Ensure 'id' column is unique.", "column": "id", "condition": "isUnique"},
        {"type": "accuracy", "description": "Ensure 'email' column has valid format.", "column": "email", "condition": "isValidEmail"},
        {"type": "consistency", "description": "Ensure 'order_date' is in YYYY-MM-DD format.", "column": "order_date", "condition": "isDateFormat"},
    ]


# ==============================================================================
# 3. Interactive Editing Loop
# ==============================================================================
while True:
    # Organize rules by parameter type for display
    param_rules = defaultdict(list)
    for r in rules:
        param_rules[r.get("type", "other")].append(r)
    
    # Display current configuration
    print("\n" + "="*80)
    print("--- CURRENT DATA QUALITY CONFIGURATION ---")
    print("\n--- PARAMETER WEIGHTS ---")
    current_total_weight_display = sum(weights.values())
    if current_total_weight_display == 0:
        print("Warning: Total weight is 0. Please adjust weights.")
        for param in DQ_PARAMS:
            print(f"PARAMETER: {param.upper()} (Current Weight: {weights.get(param, 0):.1f}%)")
    else:
        for param in DQ_PARAMS:
            display_weight = (weights.get(param, 0) / current_total_weight_display) * 100
            print(f"PARAMETER: {param.upper()} (Current Weight: {display_weight:.1f}%)")

    print("\n--- RULES BY PARAMETER ---")
    # Ensure DQ_PARAMS is iterated to maintain order and show all active parameters
    for param in DQ_PARAMS: 
        print(f"\nPARAMETER: {param.upper()}")
        if rules_list := [r for r in rules if r.get("type") == param]:
            for i, rule in enumerate(rules_list):
                print(f"  {i+1}. {rule.get('description', 'No description')}")
        else:
            print("  No rules defined for this parameter.")
    print("="*80)

    action = input("\nChoose action: [e]dit configuration, [p]arameters, or [q]uit and save: ").strip().lower()

    if action == 'q':
        print("Final configuration set. Saving rules and weights...")
        break
    elif action == 'e':
        # Edit rules or weights for existing parameters
        param_to_edit = input(f"Which parameter's rules to edit? {DQ_PARAMS}: ").strip().lower()
        if param_to_edit not in DQ_PARAMS:
            print("Invalid parameter.")
            continue
        
        edit_choice = input(f"Editing '{param_to_edit}'. [w]eight, [a]dd rule, [r]emove rule: ").strip().lower()
        
        if edit_choice == 'w':
            try:
                current_param_weight = weights.get(param_to_edit, 0.0) # Get current value
                new_weight = float(input(f"Enter new weight for '{param_to_edit}' (current: {current_param_weight:.1f}): "))
                if new_weight < 0:
                    print("Weight cannot be negative. Setting to 0.")
                    weights[param_to_edit] = 0.0
                else:
                    weights[param_to_edit] = new_weight
                print(f"Updated weight for '{param_to_edit}'.")
            except ValueError:
                print("Invalid weight. Please enter a number.")
        elif edit_choice == 'a':
            print(f"Adding a new rule for '{param_to_edit}'.")
            rule_desc = input("Enter rule description: ")
            rule_col = input("Enter column name for the rule (optional): ")
            rule_condition = input("Enter rule condition (e.g., 'isNotNull', 'isValidEmail') (optional): ")
            
            new_rule = {"type": param_to_edit, "description": rule_desc}
            if rule_col:
                new_rule["column"] = rule_col
            if rule_condition:
                new_rule["condition"] = rule_condition
            rules.append(new_rule)
            print("Rule added.")
        elif edit_choice == 'r':
            rules_for_param = [r for r in rules if r.get("type") == param_to_edit]
            if not rules_for_param:
                print(f"No rules to remove for '{param_to_edit}'.")
                continue
            print(f"Rules for '{param_to_edit}':")
            for i, rule in enumerate(rules_for_param):
                print(f"  {i+1}. {rule.get('description', 'No description')}")
            
            try:
                idx_to_remove = int(input("Enter the number of the rule to remove: ")) - 1
                if 0 <= idx_to_remove < len(rules_for_param):
                    # Find the actual rule object in the 'rules' list and remove it
                    removed_rule = rules_for_param[idx_to_remove]
                    rules.remove(removed_rule)
                    print("Rule removed.")
                else:
                    print("Invalid rule number.")
            except ValueError:
                print("Invalid input. Please enter a number.")
        else:
            print("Invalid edit choice.")
    elif action == 'p':
        # Add or remove parameters
        param_action = input("[a]dd parameter, [r]emove parameter: ").strip().lower()
        if param_action == 'a':
            new_param = input("Enter new parameter name: ").strip().lower()
            if new_param in DQ_PARAMS:
                print(f"Parameter '{new_param}' already exists.")
            else:
                DQ_PARAMS.append(new_param) # Add to the list of active parameters
                # Distribute weights equally among all current parameters
                # Use current length of DQ_PARAMS including the new one
                equal_weight_val = 100.0 / len(DQ_PARAMS)
                for p in DQ_PARAMS: # Iterate through the updated DQ_PARAMS
                    weights[p] = equal_weight_val
                print(f"Parameter '{new_param}' added. Weights redistributed equally among all parameters.")
                # LLM suggests rules for new parameter (if needed) - placeholder
                print(f"LLM will now suggest rules for the new parameter '{new_param}'.")
                # In a real scenario, you'd re-profile or use LLM with specific context for new param
                # Note: `specific_param` is an assumed argument for `suggest_rules`
                new_param_rules_result = suggester.suggest_rules(pdf_for_profiling, specific_param=new_param) 
                rules.extend(new_param_rules_result.get("rules", []))
                print(f"Suggested rules for '{new_param}' added.")

        elif param_action == 'r':
            param_to_remove = input(f"Enter parameter to remove {DQ_PARAMS}: ").strip().lower()
            if param_to_remove not in DQ_PARAMS:
                print("Invalid parameter name.")
            elif len(DQ_PARAMS) == 1:
                print("Cannot remove the last parameter.")
            else:
                DQ_PARAMS.remove(param_to_remove) # Remove from active parameters
                if param_to_remove in weights:
                    del weights[param_to_remove] # Remove its weight
                
                # Redistribute weights equally among remaining parameters
                if DQ_PARAMS: # Check if any parameters are left
                    equal_weight_val = 100.0 / len(DQ_PARAMS)
                    for p in DQ_PARAMS:
                        weights[p] = equal_weight_val
                    print(f"Parameter '{param_to_remove}' removed. Weights redistributed equally among remaining parameters.")
                else:
                    print(f"Parameter '{param_to_remove}' removed. No parameters remaining.")
                
                # Also remove any rules associated with the removed parameter
                rules = [r for r in rules if r.get("type") != param_to_remove]
                print("Associated rules removed.")
        else:
            print("Invalid parameter action.")
    else:
        print("Invalid action.")

# ==============================================================================
# 4. Finalization and Verification (Definitive Fix)
# ==============================================================================
# The 'weights' dictionary now holds the final raw values from the loop
print(f"\nDEBUG: Final raw weights from interactive session: {weights}")
total_weight = sum(weights.values())

# This dictionary will hold the final weights as normalized values (summing to 1.0)
final_weights_to_save = {}
if total_weight > 0:
    final_weights_to_save = {p: (w / total_weight) for p, w in weights.items()}
else:
    # If total_weight is 0, default to equal distribution among *current* DQ_PARAMS
    if DQ_PARAMS:
        final_weights_to_save = {p: 1.0 / len(DQ_PARAMS) for p in DQ_PARAMS}
    else:
        final_weights_to_save = {} # No parameters, no weights

print("\n--- FINAL CONFIGURATION SAVED ---")
# Display the variable that is about to be saved in a human-readable format
print(f"Final Weights (as percentages): { {k: f'{v*100:.1f}%' for k, v in final_weights_to_save.items()} }")
print(f"Total Rules: {len(rules)}")

# Save the final, correct configuration to DBFS
try:
    # Ensure the directory exists before writing
    dbutils.fs.mkdirs("/FileStore/dq_configs/")
    dbutils.fs.put(RULES_PATH, json.dumps(rules, indent=2), overwrite=True)
    dbutils.fs.put(WEIGHTS_PATH, json.dumps(final_weights_to_save, indent=2), overwrite=True)
    print(f"✅ Final rules and weights saved to {RULES_PATH} and {WEIGHTS_PATH}.")
except Exception as e:
    print(f"❌ Error saving files to DBFS: {e}")

# --- Verification Step ---
print("\n--- VERIFICATION ---")
try:
    # Read the content back and verify
    # Use the internal DBFS path for dbutils.fs.head
    saved_weights_str = dbutils.fs.head(DBFS_WEIGHTS_PATH_INTERNAL) 
    saved_data = json.loads(saved_weights_str)
    print(f"Content of saved weights file ({WEIGHTS_PATH}):\n{saved_weights_str}")
    
    # Perform a robust numerical check
    # Check if all keys match and values are numerically close
    keys_match = set(saved_data.keys()) == set(final_weights_to_save.keys())
    values_match = True
    if keys_match:
        for k, v in final_weights_to_save.items():
            # Use a small tolerance for floating-point comparison
            if not np.isclose(saved_data.get(k, 0), v, atol=1e-9): 
                values_match = False
                break
    
    if keys_match and values_match:
        print("✅ Verification successful. The file contents now correctly match the configuration.")
    else:
        print("❌ VERIFICATION FAILED: The content saved to the file still does NOT match the configuration.")
        print(f"Expected: {final_weights_to_save}")
        print(f"Actual: {saved_data}")
        
except Exception as e:
    print(f"❌ Verification failed. Could not read back the saved file or parse its content. Error: {e}")

print("\nYou may now proceed to the final assessment cell (Cell 4).")
# Cell 3: Data Cleaning & Non-Interactive Rule Setup for Job Execution

# import pandas as pd
# from collections import defaultdict
# import json
# from typing import Any, List, Dict
# import logging
# import os
# import numpy as np 
# # Removed time import as it's no longer strictly needed here after removing interactive loop

# # Imports for Spark data cleaning
# from pyspark.sql import functions as F
# from pyspark.sql.types import TimestampType

# # Assumes your custom IntelligentRuleSuggester class is available
# from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester 

# # --- Configuration & Logger ---
# # DQ_PARAMS can be dynamically updated by user, so initialize it as a list first
# DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"] 

# # *** UPDATED PATHS FOR STORING RULES AND WEIGHTS ***
# # These paths are where the *interactive* run of the notebook (if you ever do one)
# # would save the final rules and weights.
# RULES_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
# WEIGHTS_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# # Define the *internal* DBFS path without /dbfs prefix for dbutils.fs.head
# DBFS_RULES_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
# DBFS_WEIGHTS_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# logger = logging.getLogger('dq_pipeline.interactive')

# # ==============================================================================
# # 1. Data Cleaning
# # ==============================================================================
# print("--- Step 1: Cleaning timestamps to prevent conversion errors... ---")

# pd_min_ts = pd.Timestamp.min.to_pydatetime()
# pd_max_ts = pd.Timestamp.max.to_pydatetime()
# df_cleaned = df # Assuming 'df' is your Spark DataFrame from previous cell
# timestamp_cols = [field.name for field in df.schema.fields if isinstance(field.dataType, TimestampType)]

# if timestamp_cols:
#     print(f"Found timestamp columns to clean: {timestamp_cols}")
#     for col_name in timestamp_cols:
#         df_cleaned = df_cleaned.withColumn(col_name, F.when((F.col(col_name) >= pd_min_ts) & (F.col(col_name) <= pd_max_ts), F.col(col_name)).otherwise(F.lit(None)))
#     print("✅ Timestamp cleaning complete.")
# else:
#     print("No timestamp columns found to clean.")

# # ==============================================================================
# # 2. Rule Setup (Non-Interactive for Job Execution)
# # ==============================================================================
# # When running as a job, we don't interact. We either load previously saved rules
# # or generate a default set.

# print("\n--- Step 2: Setting up rules and weights (Non-Interactive for Job). ---")

# rules: List[Dict[str, Any]] = []
# weights: Dict[str, float] = {}

# # Option A: Try to load previously saved rules and weights (RECOMMENDED for jobs)
# try:
#     print(f"Attempting to load rules from {DBFS_RULES_PATH_INTERNAL} and weights from {DBFS_WEIGHTS_PATH_INTERNAL}...")
#     rules_str_loaded = dbutils.fs.head(DBFS_RULES_PATH_INTERNAL)
#     weights_str_loaded = dbutils.fs.head(DBFS_WEIGHTS_PATH_INTERNAL)
#     rules = json.loads(rules_str_loaded)
#     weights = json.loads(weights_str_loaded)
#     print("✅ Successfully loaded previously saved rules and weights.")
#     # Dynamically update DQ_PARAMS based on loaded weights
#     global DQ_PARAMS # Declare as global if DQ_PARAMS is modified in other cells
#     DQ_PARAMS = list(weights.keys()) 

# except Exception as e:
#     print(f"⚠️ Could not load saved rules/weights ({e}). Generating initial rules from LLM as fallback.")
#     # Option B: Generate initial rules and default weights (FALLBACK if no saved config)
#     pdf_for_profiling = None
#     try:
#         pdf_for_profiling = df_cleaned.toPandas()
#     except Exception as e_pandas:
#         print(f"Warning: Could not convert Spark DataFrame to Pandas for profiling directly ({e_pandas}). Using a small sample.")
#         pdf_for_profiling = df_cleaned.limit(1000).toPandas()

#     suggester = IntelligentRuleSuggester()
#     result = suggester.suggest_rules(pdf_for_profiling)
#     rules = result.get("rules", [])

#     if not rules:
#         print("LLM failed to generate any rules. Attempting to generate hardcoded default rules.")
#         rules = [
#             {"type": "completeness", "description": "Ensure 'id' column is not null.", "column": ["id"], "condition": "isNotNull"},
#             {"type": "uniqueness", "description": "Ensure 'id' column is unique.", "column": ["id"], "condition": "isUnique"},
#             {"type": "accuracy", "description": "Ensure 'email' column has valid format.", "column": ["email"], "condition": "isValidEmail"},
#             {"type": "consistency", "description": "Ensure 'order_date' is in YYYY-MM-DD format.", "column": ["order_date"], "condition": "isDateFormat"},
#             {"type": "accuracy", "description": "Verify the range of 'event_code' values", "column": ["event_code"]},
#             {"type": "completeness", "description": "Cumulative Energy (Wh) Export should not be null", "column": ["cumulative_energy_wh_export"]},
#             {"type": "consistency", "description": "Ensure receivedTime and RTC are consistent", "column": ["receivedTime", "RTC"]},
#             {"type": "uniqueness", "description": "Ensure uniqueness of Event_ID", "column": ["Event_ID"]},
#         ]
#         # Ensure 'column' is a list as required by execute_and_gather_evidence
#         for r_def in rules:
#             if 'column' in r_def and not isinstance(r_def['column'], list):
#                 r_def['column'] = [r_def['column']]
#             elif 'column' not in r_def and 'columns' not in r_def:
#                 r_def['columns'] = [] # Ensure 'columns' exists as a list

#     # Initialize weights for all active DQ_PARAMS
#     current_dq_params = list(set([r.get("type") for r in rules if r.get("type")])) # Get actual dimensions from rules
#     if not current_dq_params:
#         current_dq_params = ["accuracy", "completeness", "consistency", "uniqueness"] # Fallback if no rules found
#     weights = {p: (1.0 / len(current_dq_params)) for p in current_dq_params} # Normalize to 1.0

#     print("✅ Rules and weights initialized (either loaded or default generated).")

# # No interactive loop here for job execution.
# # The rules and weights are now prepared for Cell 4.