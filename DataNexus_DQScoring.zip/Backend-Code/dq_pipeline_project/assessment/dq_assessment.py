# ----------- assessment/dq_assessment.py -----------

from pyspark.sql import SparkSession, DataFrame
import pyspark.sql.functions as F
from pyspark.sql.types import StructType, StructField, StringType, LongType, DoubleType, ArrayType
import logging
from typing import List, Dict

logger = logging.getLogger('dq_pipeline.assessment')

class DQAssessment:
    """
    Executes DQ rules using a memory-efficient, single-pass Spark aggregation.
    This class contains the "Rule Engine" logic.
    """
    def __init__(self, spark: SparkSession):
        self.spark = spark

    def run_assessment(self, df: DataFrame, rules: List[Dict]) -> DataFrame:
        """
        Translates rule templates into a single Spark query and executes it.
        This approach is highly performant and avoids OOM errors.
        """
        df.cache() # Cache the input DataFrame for performance during multiple aggregations
        total_records = df.count()

        if total_records == 0:
            df.unpersist()
            # Return an empty DataFrame with the correct schema if there's no data
            return self.spark.createDataFrame([], schema=self._get_results_schema())

        agg_expressions = []
        rule_metadata_map = {} # Use a map for easy lookup after aggregation

        for i, rule in enumerate(rules):
            # The rule's 'rule_id' is used to uniquely identify its result
            rule_id = rule.get("rule_id", f"rule_{i}")
            template = rule.get("rule_template")
            columns = rule.get("columns", [])
            params = rule.get("parameters", {})
            
            # Skip user-defined or improperly structured rules
            if not template or template == "CUSTOM" or not columns:
                continue
            
            sql_expr = ""
            col_name = f"`{columns[0]}`"
            
            # This layer translates the rule intent into executable Spark SQL.
            if template == "IS_NOT_NULL":
                sql_expr = f"{col_name} IS NOT NULL"
            elif template == "IS_BETWEEN":
                min_val, max_val = params.get("min"), params.get("max")
                if min_val is not None and max_val is not None:
                    sql_expr = f"CAST({col_name} AS double) BETWEEN {min_val} AND {max_val}"
            # Add other templates here as needed
            
            if sql_expr:
                # Create an aggregation expression to count failures for this rule.
                # The condition for failure is the logical inverse of the rule.
                failure_condition = F.when(F.expr(f"NOT ({sql_expr})"), 1).otherwise(0)
                agg_alias = f"fails_{rule_id}"
                agg_expressions.append(F.sum(failure_condition).alias(agg_alias))
                rule_metadata_map[agg_alias] = rule

        if not agg_expressions:
            df.unpersist()
            logger.warning("No executable rules found to assess.")
            return self.spark.createDataFrame([], schema=self._get_results_schema())

        # --- Execute all rules in a SINGLE, optimized Spark Action ---
        failure_counts_row = df.agg(*agg_expressions).first()
        df.unpersist() # Release the cache after use

        # --- Process the single row of results ---
        results_data = []
        for agg_alias, fail_count in failure_counts_row.asDict().items():
            meta = rule_metadata_map[agg_alias]
            pass_count = total_records - fail_count
            score = (pass_count / total_records) if total_records > 0 else 0.0
            
            results_data.append((
                meta.get('rule_id'), meta.get('description'), meta.get('columns'),
                meta.get('type', 'other'), float(score), int(fail_count)
            ))

        return self.spark.createDataFrame(results_data, schema=self._get_results_schema())

    def _get_results_schema(self) -> StructType:
        """Defines the consistent output schema for the assessment results."""
        return StructType([
            StructField("rule_id", StringType()),
            StructField("description", StringType()),
            StructField("columns", ArrayType(StringType())),
            StructField("type", StringType()),
            StructField("score", DoubleType()),
            StructField("fail_count", LongType())
        ])