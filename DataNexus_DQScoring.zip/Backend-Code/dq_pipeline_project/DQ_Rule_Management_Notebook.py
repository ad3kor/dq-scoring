# Databricks notebook source
# MAGIC %pip install -r requirements.txt
# MAGIC

# COMMAND ----------

# # Notebook: DQ_Rule_Management_Notebook
# # Purpose: Load cleaned data, manage (non-interactive for jobs) DQ rules and weights, and save them.

# import pandas as pd
# from collections import defaultdict
# import json
# from typing import Any, List, Dict
# import logging
# import os
# import numpy as np 

# # --- Spark and Logging Setup ---
# from pyspark.sql import SparkSession
# spark = SparkSession.builder.appName("DQ_Rule_Management_Job").getOrCreate()
# logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
# logger = logging.getLogger('dq_rule_management_notebook')
# print("✅ Spark Session and Logger initialized.")

# # --- Custom Module (IntelligentRuleSuggester) Setup ---
# try:
#     from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester
#     print("✅ IntelligentRuleSuggester module imported.")
# except ImportError as e:
#     print(f"❌ Error importing IntelligentRuleSuggester: {e}")
#     print("Please ensure 'rule_suggester' is installed as a cluster library or accessible in your job environment.")
#     dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Missing custom module: {str(e)}"}))


# # --- Configuration ---
# CLEANED_DATA_DELTA_TABLE_FQDN = "hive_metastore.default.dq_ingested_clean_sample" # Must match Notebook 1
# RULES_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
# WEIGHTS_PATH = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"
# DBFS_RULES_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_rules.json"
# DBFS_WEIGHTS_PATH_INTERNAL = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_configs/final_weights.json"

# # Define the standard DQ Parameters/Dimensions
# DQ_PARAMS = ["accuracy", "completeness", "consistency", "uniqueness"] 

# # ==============================================================================
# # 1. Load Cleaned Data (from DQ_Ingestion_Notebook output)
# # ==============================================================================
# print(f"--- Step 1: Loading cleaned data from Delta table: {CLEANED_DATA_DELTA_TABLE_FQDN} ---")
# try:
#     df_cleaned = spark.read.format("delta").table(CLEANED_DATA_DELTA_TABLE_FQDN)
#     if df_cleaned.count() == 0:
#         print("⚠️ Warning: Loaded cleaned DataFrame is empty. Rule generation might be limited.")
#     print(f"✅ Loaded cleaned data (df_cleaned) with {df_cleaned.count()} rows.")
#     df_cleaned.printSchema()
# except Exception as e:
#     print(f"❌ Error loading cleaned data from Delta table: {e}")
#     dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Failed to load cleaned data: {str(e)}"}))

# # ==============================================================================
# # 2. Rule Setup (Non-Interactive for Job Execution - from original Cell 3)
# # ==============================================================================
# print("\n--- Step 2: Setting up rules and weights (Non-Interactive for Job Execution). ---")

# rules: List[Dict[str, Any]] = []
# weights: Dict[str, float] = {}

# # Option A: Try to load previously saved rules and weights (RECOMMENDED for jobs)
# try:
#     print(f"Attempting to load rules from {DBFS_RULES_PATH_INTERNAL} and weights from {DBFS_WEIGHTS_PATH_INTERNAL}...")
#     rules_str_loaded = dbutils.fs.head(DBFS_RULES_PATH_INTERNAL)
#     weights_str_loaded = dbutils.fs.head(DBFS_WEIGHTS_PATH_INTERNAL)
#     rules = json.loads(rules_str_loaded)
#     weights = json.loads(weights_str_loaded)
#     print("✅ Successfully loaded previously saved rules and weights.")
    
#     # After loading, ensure DQ_PARAMS is updated to reflect loaded weights' keys
#     # (if rules/weights were saved with different DQ_PARAMS)
#     DQ_PARAMS = list(weights.keys()) 

# except Exception as e:
#     print(f"⚠️ Could not load saved rules/weights ({e}). Generating initial rules from LLM and setting default 25% weights as fallback.")
    
#     # --- FIX: Explicitly set default weights to 25% (0.25) when no saved config is found ---
#     # This ensures that if the LLM or hardcoded rules are used, the weights are set to 25% for the standard dimensions.
#     weights = {p: 0.25 for p in DQ_PARAMS} # Set to 0.25 (25% as a fraction) for each default DQ_PARAM
#     print(f"✅ Initializing weights to 25% for {DQ_PARAMS} as no saved configuration was found.")


#     # Option B: Generate initial rules (FALLBACK if no saved config)
#     pdf_for_profiling = None
#     try:
#         pdf_for_profiling = df_cleaned.limit(MAX_ROWS_TO_PROCESS).toPandas()
#     except Exception as e_pandas:
#         print(f"Warning: Could not convert Spark DataFrame to Pandas for profiling directly ({e_pandas}). Using a small sample.")
#         pdf_for_profiling = df_cleaned.limit(50).toPandas() 

#     suggester = IntelligentRuleSuggester()
#     result = suggester.suggest_rules(pdf_for_profiling)
#     rules = result.get("rules", [])

#     if not rules:
#         print("LLM failed to generate any rules. Attempting to generate hardcoded default rules.")
#         rules = [
#             {"type": "completeness", "description": "Ensure 'id' column is not null.", "column": ["id"], "condition": "isNotNull"},
#             {"type": "uniqueness", "description": "Ensure 'id' column is unique.", "column": ["id"], "condition": "isUnique"},
#             {"type": "accuracy", "description": "Ensure 'email' column has valid format.", "column": ["email"], "condition": "isValidEmail"},
#             {"type": "consistency", "description": "Ensure 'order_date' is inimbra-MM-DD format.", "column": ["order_date"], "condition": "isDateFormat"},
#             {"type": "accuracy", "description": "Verify the range of 'event_code' values", "column": ["event_code"]},
#             {"type": "completeness", "description": "Cumulative Energy (Wh) Export should not be null", "column": ["cumulative_energy_wh_export"]},
#             {"type": "consistency", "description": "Ensure receivedTime and RTC are consistent", "column": ["receivedTime", "RTC"]},
#             {"type": "uniqueness", "description": "Ensure uniqueness of Event_ID", "column": ["Event_ID"]},
#         ]
#         for r_def in rules:
#             if 'column' in r_def and not isinstance(r_def['column'], list):
#                 r_def['column'] = [r_def['column']]
#             elif 'column' not in r_def and 'columns' not in r_def:
#                 r_def['columns'] = [] 

#     # If rules were generated (either LLM or hardcoded), ensure DQ_PARAMS is updated to reflect *their* types
#     if rules:
#         DQ_PARAMS = list(set([r.get("type") for r in rules if r.get("type")]))
#         # Re-initialize weights for these specific DQ_PARAMS to ensure they sum to 1.0
#         # This will override the 0.25 initial set if current_dq_params had different types
#         # This ensures the total weight remains normalized if rules fallback adds/removes parameters.
#         if DQ_PARAMS: # Only if there are valid DQ_PARAMS
#             initial_normalized_weight = 1.0 / len(DQ_PARAMS)
#             weights = {p: initial_normalized_weight for p in DQ_PARAMS}
#         else:
#             weights = {} # No valid rules, no weights


#     print("✅ Rules and weights initialized (either loaded, LLM-generated, or default hardcoded).")

# # ==============================================================================
# # 3. Finalize and Save Rules/Weights for Downstream Job
# # ==============================================================================
# print("\n--- Step 3: Finalizing and Saving Rules and Weights to DBFS/Workspace ---")

# total_weight = sum(weights.values())
# final_weights_to_save = {}

# # Normalize weights to sum to 1.0 (for fractions) for saving.
# # This logic ensures that even if individual weights were set to 25.0 in the `weights` dictionary (for display as percentage),
# # they are saved as normalized fractions (0.25).
# if total_weight > 0:
#     for p, w in weights.items():
#         # --- FIX: Ensure no NaN or NaT values are in weights before JSON dumping ---
#         # Convert any float NaN or pd.NaT to None, which is JSON serializable as null.
#         if isinstance(w, (float, int)): 
#             if np.isnan(w): 
#                 final_weights_to_save[p] = None
#             else:
#                 final_weights_to_save[p] = w / total_weight # Normalize valid numbers
#         elif pd.isna(w): # Catches pd.NaT and other Pandas/Numpy nulls
#             final_weights_to_save[p] = None
#         else:
#             # Fallback for unexpected types, try to convert or set to None
#             try:
#                 final_weights_to_save[p] = float(w) / total_weight
#             except (ValueError, TypeError):
#                 final_weights_to_save[p] = None 
# else:
#     # If total_weight is 0 (e.g., all weights set to 0), default to equal distribution among *current* DQ_PARAMS
#     if DQ_PARAMS:
#         initial_normalized_weight = 1.0 / len(DQ_PARAMS)
#         final_weights_to_save = {p: initial_normalized_weight for p in DQ_PARAMS}
#     else:
#         final_weights_to_save = {} 

# print(f"Final Weights (as percentages): { {k: f'{v*100:.1f}%' for k, v in final_weights_to_save.items()} }")
# print(f"Total Rules: {len(rules)}")

# try:
#     # Ensure the directory exists (for Workspace paths, this is crucial)
#     dbutils.fs.mkdirs(os.path.dirname(RULES_PATH)) 
    
#     dbutils.fs.put(RULES_PATH, json.dumps(rules, indent=2), overwrite=True)
#     dbutils.fs.put(WEIGHTS_PATH, json.dumps(final_weights_to_save, indent=2), overwrite=True)
#     print(f"✅ Final rules and weights saved to {RULES_PATH} and {WEIGHTS_PATH}.")
# except Exception as e:
#     print(f"❌ Error saving files to DBFS/Workspace: {e}")
#     dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Failed to save rules/weights: {str(e)}"}))

# COMMAND ----------

# Notebook: DQ_Rule_Management_Notebook (Corrected with 2-Stage Translation)
# Purpose: Generate descriptive rules and reliably translate them into an executable format.

import pandas as pd
import json
import logging
import re
from typing import List, Dict, Any, Optional

# --- Library Imports ---
from pyspark.sql import SparkSession
from langchain_groq.chat_models import ChatGroq
from langchain.schema import SystemMessage, HumanMessage
from pydantic import BaseModel, Field, ValidationError

# --- Spark and Logging Setup ---
spark = SparkSession.builder.appName("DQ_Rule_Suggester_Job").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_rule_suggester_notebook')
logger.info("✅ Spark Session and Logger initialized.")

# --- Custom Module Import ---
try:
    from rule_suggester.intelligent_rule_suggester import IntelligentRuleSuggester
    logger.info("✅ IntelligentRuleSuggester module imported.")
except ImportError as e:
    dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Missing custom module 'IntelligentRuleSuggester': {str(e)}"}))

# --- Pydantic Models for Executable Logic ---
class ExecutableParams(BaseModel):
    expression: Optional[str] = None

class ExecutableLogic(BaseModel):
    rule_type: str = Field(..., description="MUST be 'IS_NOT_NULL', 'IS_UNIQUE', or 'SQL_EXPRESSION'")
    params: ExecutableParams = Field(default_factory=ExecutableParams)


# ==============================================================================
# 1. Get Input Data Sample from Job Parameters
# ==============================================================================
logger.info("--- Step 1: Retrieving data sample from job parameters... ---")
dbutils.widgets.text("data_sample_json", "", "The data sample as a JSON string from the frontend")
data_sample_json_str = dbutils.widgets.get("data_sample_json")

if not data_sample_json_str:
    dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": "Job parameter 'data_sample_json' was empty."}))

try:
    sample_data_list = json.loads(data_sample_json_str)
    pdf_for_profiling = pd.DataFrame(sample_data_list)
    logger.info(f"✅ Created a Pandas DataFrame with {len(pdf_for_profiling)} rows from the input sample.")
except Exception as e:
    dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Could not parse 'data_sample_json'. Error: {str(e)}"}))


# ==============================================================================
# 2. Generate Descriptive Data Quality Rules using LLM
# ==============================================================================
logger.info("\n--- Step 2: Generating initial descriptive DQ rules... ---")
try:
    suggester = IntelligentRuleSuggester(temperature=0.6)
    llm_result = suggester.suggest_rules(pdf_for_profiling)
    descriptive_rules = llm_result.get("rules", [])
    
    descriptive_rules = [rule for rule in descriptive_rules if "This is a fallback" not in rule.get("reasoning", "")]
    if not descriptive_rules:
        dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": "LLM failed to generate any valid rules from the sample."}))

    logger.info(f"✅ LLM successfully generated {len(descriptive_rules)} initial descriptive rules.")
except Exception as e:
    dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"An error occurred during rule suggestion. Error: {str(e)}"}))


# ==============================================================================
# 3. Determine Executable Logic for each Descriptive Rule
# ==============================================================================
logger.info("\n--- Step 3: Determining executable logic for each descriptive rule... ---")

logic_determiner_llm = ChatGroq(model="llama3-8b-8192", temperature=0.0, api_key="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")

def determine_executable_logic(description: str, columns: List[str]) -> Optional[Dict[str, Any]]:
    """Uses a focused LLM call to determine only the 'rule_type' and 'params'."""
    system_prompt = (
        "You are a system that returns a JSON object containing the executable logic for a data quality rule. "
        "Based on the rule's description, determine the `rule_type` ('IS_NOT_NULL', 'IS_UNIQUE', or 'SQL_EXPRESSION') "
        "and the `params` containing the SQL `expression` if required. Respond with ONLY the JSON object."
    )
    
    human_prompt = (
        "Here are examples:\n"
        "INPUT: Description='Ensure Event ID is unique', Columns=['Event_ID']\n"
        'OUTPUT: {"rule_type": "IS_UNIQUE", "params": {}}\n\n'
        "INPUT: Description='Value for total_amount must be positive', Columns=['total_amount']\n"
        'OUTPUT: {"rule_type": "SQL_EXPRESSION", "params": {"expression": "total_amount >= 0"}}\n\n'
        "INPUT: Description='The customer_id field should not contain any nulls', Columns=['customer_id']\n"
        'OUTPUT: {"rule_type": "IS_NOT_NULL", "params": {}}\n\n'
        "Now, determine the logic for this rule:\n"
        f"INPUT: Description='{description}', Columns={columns}"
    )
    
    messages = [SystemMessage(content=system_prompt), HumanMessage(content=human_prompt)]
    try:
        response = logic_determiner_llm.invoke(messages).content
        match = re.search(r'\{.*\}', response, re.DOTALL)
        if not match: return None
        
        logic_data = json.loads(match.group(0))
        return ExecutableLogic(**logic_data).model_dump(exclude_unset=True)
    except (ValidationError, json.JSONDecodeError, Exception) as e:
        logger.error(f"Failed to determine logic for rule '{description}'. Error: {e}")
        return None

executable_rules = []
for rule in descriptive_rules:
    logger.info(f"  > Translating rule: '{rule.get('description')}'")
    logic = determine_executable_logic(rule.get("description"), rule.get("columns"))
    
    if logic:
        # Combine the original description with the new executable logic
        final_rule = {
            "name": rule.get("description"),
            "dimension": rule.get("type", "Other").capitalize(),
            "columns": rule.get("columns", []),
            "rule_type": logic.get("rule_type"),
            "params": logic.get("params", {})
        }
        executable_rules.append(final_rule)
    else:
        logger.warning(f"  > Skipping rule '{rule.get('description')}' due to translation failure.")


if not executable_rules:
    dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": "Failed to translate any of the LLM-suggested rules into an executable format."}))

logger.info(f"✅ Successfully created {len(executable_rules)} executable rules.")

# ==============================================================================
# 4. Prepare Final Output Payload
# ==============================================================================
logger.info("\n--- Step 4: Preparing final JSON output with rules and fixed default weights... ---")
standard_dimensions = ["Accuracy", "Completeness", "Consistency", "Uniqueness"]
default_weights = {dim: 0.25 for dim in standard_dimensions}
logger.info(f"Assigned fixed 25% initial weights to standard dimensions.")

final_output = {
    "status": "SUCCEEDED",
    "message": f"Successfully generated and translated {len(executable_rules)} rules.",
    "suggested_rules": executable_rules,
    "default_weights": default_weights
}

final_json_string = json.dumps(final_output, indent=2)
logger.info("\n--- Exiting notebook with suggested rules JSON ---")
dbutils.notebook.exit(final_json_string)

# COMMAND ----------

