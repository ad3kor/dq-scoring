# File: reporting/report_generator.py
import os
import datetime
import logging
import pandas as pd
from typing import Union
from pyspark.sql import DataFrame as SparkDF

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer)
from reportlab.lib.styles import getSampleStyleSheet

logger = logging.getLogger("dq_pipeline.reporting")

class ReportGenerator:
    """Uses ReportLab to build a PDF from a DataFrame."""

    def __init__(self, output_dir: str = "/dbfs/FileStore/reports"):
        self.output_dir = output_dir
        if output_dir.startswith('/dbfs/'):
            os.makedirs(output_dir, exist_ok=True)

    def _to_pandas(self, df: Union[SparkDF, pd.DataFrame]) -> pd.DataFrame:
        if isinstance(df, SparkDF): return df.toPandas()
        return df

    def generate(self, df: Union[SparkDF, pd.DataFrame]) -> str:
        pdf_df = self._to_pandas(df)
        expected_columns = ["Rule Description", "Columns", "Type", "Score", "Fail Count"]
        missing_cols = [c for c in expected_columns if c not in pdf_df.columns]
        if missing_cols: raise ValueError(f"DataFrame is missing required columns for the report: {missing_cols}")

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = os.path.join(self.output_dir, f"DQ_Report_{timestamp}.pdf")
        
        doc = SimpleDocTemplate(output_path, pagesize=letter)
        styles, story = getSampleStyleSheet(), []
        
        story.append(Paragraph("Data Quality Report", styles['Title']))
        story.append(Spacer(1, 12))
        story.append(Paragraph(f"Generated: {datetime.datetime.now():%Y-%m-%d, %H:%M:%S}", styles['Normal']))
        story.append(Spacer(1, 24))

        table_data = [expected_columns] + pdf_df[expected_columns].astype(str).values.tolist()
        report_table = Table(table_data, repeatRows=1, hAlign='LEFT')
        report_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#CCCCCC")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
        ]))
        story.append(report_table)

        doc.build(story)
        logger.info(f"PDF report generated at: {output_path}")
        return output_path