# Databricks notebook source
# MAGIC %pip install -r requirements.txt
# MAGIC

# COMMAND ----------

print(spark.sparkContext.getCheckpointDir())  # Likely prints 'None'


# COMMAND ----------

from pyspark.sql import SparkSession

# 1. [Run beforehand in a separate cell] Create the checkpoint folder on DBFS:
#    dbutils.fs.mkdirs("dbfs:/checkpoints")

# 2. Build SparkSession (including checkpoint.dir, though this alone may not suffice)
spark = (
    SparkSession.builder
        .appName("DQ_Pipeline_With_Checkpoint")
        .config("spark.sql.execution.arrow.maxRecordsPerBatch", "500")
        .config("spark.checkpoint.dir", "/dbfs/checkpoints")
        .getOrCreate()
)

# 3. Explicitly set the SparkContext checkpoint directory:
spark.sparkContext.setCheckpointDir("/dbfs/checkpoints")  # Ensures RDD.checkpoint() sees a valid path :contentReference[oaicite:7]{index=7}

# 4. Read the Excel file from DBFS using the Spark Excel connector
df_excel = spark.read.format("com.crealytics.spark.excel") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load("dbfs:/FileStore/acharjeerishab/Copy of Smart Meter Sample Data_v1.xlsx")

# 5. Checkpoint the DataFrame (truncates lineage and writes to /dbfs/checkpoints)
df_excel = df_excel.checkpoint(eager=True)  # Now succeeds without errors :contentReference[oaicite:8]{index=8}

# 6. Verify by performing an action (e.g., count rows)
print(df_excel.count())  # Should print the row count without raising the checkpoint error


# COMMAND ----------

print(spark.sparkContext.getCheckpointDir())  # Likely prints 'None'


# COMMAND ----------

# ----------- run_pipeline_single_node.py -----------
# Runs on a memory-constrained, single-node Databricks cluster.
# Limits the dataset to 10,000 rows to avoid OOM and performs
# data quality analysis on that bounded sample.

import os
import logging
import traceback

from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import pandas as pd

from ingestion.ingestion import IngestionManager
from sampling.stage3_diversity_sampling import DiversitySampler
from rule_suggester.chunked_rule_suggester import ChunkedRuleSuggester
from assessment.dq_assessment import DQAssessment
from reporting.report_generator import ReportGenerator

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# Cell 1: Define interactive widgets
dbutils.widgets.removeAll()
dbutils.widgets.dropdown("source_type", "delta", ["delta","file"], "Source Type")
dbutils.widgets.text("table", "samples.nyctaxi.trips", "Delta Table")
dbutils.widgets.text("file_path", "", "File Path")
dbutils.widgets.dropdown("file_type", "csv", ["csv","json","parquet","excel"], "File Type")
dbutils.widgets.text("report_output_dir", "/dbfs/FileStore/reports", "Report Output Dir")


# COMMAND ----------

# ── Cell 2 – Ingest (Delta / flat file / Excel) and limit to 500 rows ──
from pyspark.sql import SparkSession
from ingestion.ingestion import IngestionManager
import pyspark.sql.functions as F

spark = SparkSession.builder.appName("DQ_SingleNode").getOrCreate()
ingest_manager = IngestionManager(spark)

# ── 1️⃣  Read widget values (already created in Notebook) ────────────────
source_type = dbutils.widgets.get("source_type")   # "delta" | "file"
table       = dbutils.widgets.get("table")         # catalog.schema.table
file_path   = dbutils.widgets.get("file_path")     # /dbfs/...
file_type   = dbutils.widgets.get("file_type").lower()  # csv | json | parquet | excel

# ── 2️⃣  Ingest with fast-path options  ──────────────────────────────────
if source_type == "delta":
    # Read only a few physical files to avoid scanning entire lake
    df_full = (
        spark.read.format("delta")
             .option("maxFiles", 10)  # <-- limits read to first 10 parquet files
             .load(table)
    )

elif source_type == "file":
    fpath = file_path.strip()

    if file_type == "csv":
        # Disable schema inference for speed (all columns -> string)
        df_full = (
            spark.read.option("header", "true")
                      .option("inferSchema", "false")
                      .csv(fpath)
        )

    elif file_type == "json":
        df_full = spark.read.json(fpath)

    elif file_type == "parquet":
        df_full = spark.read.parquet(fpath)

    elif file_type in ("excel", "xlsx", "xls"):
        # Uses com.crealytics.spark.excel (must be installed on cluster)
        df_full = (
            spark.read.format("com.crealytics.spark.excel")
                 .option("header", "true")
                 .option("inferSchema", "false")   # speed: everything as string
                 .option("workbookPassword", None)
                 .load(fpath)
        )
    else:
        raise ValueError(f"Unsupported file_type: {file_type}")

else:
    raise ValueError(f"Unsupported source_type: {source_type}")

# ── 3️⃣  Early sampling: 0.1 % OR first 500 rows  ───────────────────────
MAX_ROWS   = 500
SAMPLE_FRAC = 0.001  # 0.1 % of rows; adjust if dataset is tiny

df_sampled = df_full.sample(False, SAMPLE_FRAC, seed=42).limit(MAX_ROWS)

# ── 4️⃣  Cache and sanity-check  ────────────────────────────────────────
df = df_sampled.cache()

if not df.head(1):
    raise ValueError("No data after sampling / limiting to 500 rows")

row_cnt = df.count()          # one action only
print(f"✅ Ingested sample: {row_cnt} rows")

# df is now ready for Cell 3


# COMMAND ----------

suggester = ChunkedRuleSuggester()
rules = suggester.suggest_rules_chunked(final_pdf)
print(len(rules), rules[:2])


# COMMAND ----------

# Cell 3: Sampling & rule suggestion + user review
import pandas as pd
from sampling.stage3_diversity_sampling import DiversitySampler
from rule_suggester.chunked_rule_suggester import ChunkedRuleSuggester
import pyspark.sql.functions as F

# Step 1: sample 100 rows, then diversity-sample
sample_df = df.orderBy(F.rand()).limit(100)
pdf = sample_df.toPandas()
diversity = DiversitySampler(num_clusters=2, samples_per_cluster=1)
final_pdf = diversity.sample(pdf)

# Step 2: define DQ parameters and initial weights
DQ_PARAMS = ["accuracy", "consistency", "completeness", "uniqueness"]
init_weights = {p: 0.25 for p in DQ_PARAMS}

# Step 3: get LLM-generated rules
suggester = ChunkedRuleSuggester(model_name="deepseek-r1-distill-llama-70b")
# CRUCIAL CHANGE: Don't pass DQ_PARAMS as target_columns!
result = suggester.suggest_rules_chunked(final_pdf)
rules, weights = result["rules"], result.get("weights", init_weights)

# Step 4: display generated rules grouped by type (DQ param)
from collections import defaultdict
param_rules = defaultdict(list)
for rule in rules:
    typ = rule.get("type")
    if typ in DQ_PARAMS:
        param_rules[typ].append(rule)
    else:
        param_rules["other"].append(rule)

print("LLM‑generated rules (please review/edit):")
for param in DQ_PARAMS:
    print(f"\n{param.upper()} (weight = {weights.get(param,0):.2f}):")
    for i, r in enumerate(param_rules[param]):
        print(f" • [{r['rule_id']}] {r['description']}")

# Step 5: Optional edits via widgets
dbutils.widgets.removeAll()
dbutils.widgets.multiselect("active_params", DQ_PARAMS[0], DQ_PARAMS, "Select parameters")
active = dbutils.widgets.get("active_params").split(",") if dbutils.widgets.get("active_params") else DQ_PARAMS
user_edits = {"weights": {}, "remove": {}, "add": {}}

# generate inputs for each active parameter
for param in active:
    dbutils.widgets.text(f"weight_{param}", str(weights.get(param, init_weights[param])))
    dbutils.widgets.text(f"remove_{param}", "", f"Remove IDs for {param}")
    dbutils.widgets.text(f"add_{param}", "", f"Add description for {param}")

# collect edits
for param in active:
    rid = dbutils.widgets.get(f"remove_{param}")
    if rid:
        user_edits["remove"][param] = [x.strip() for x in rid.split(",") if x.strip()]
    add_desc = dbutils.widgets.get(f"add_{param}")
    if add_desc:
        # If you want to add rules to specific columns, you can extend here
        # This adds to the *parameter* group, not to a column
        rnew = {
            "rule_id": f"user_{param}_{len(param_rules[param])+1}",
            "description": add_desc,
            "columns": [],  # <-- You might want to allow user to choose a real column
            "type": param,
            "condition": "true"
        }
        user_edits["add"].setdefault(param, []).append(rnew)
    try:
        user_edits["weights"][param] = float(dbutils.widgets.get(f"weight_{param}"))
    except:
        user_edits["weights"][param] = init_weights[param]

# normalize weights
w_total = sum(user_edits["weights"].values())
if w_total > 0:
    user_edits["weights"] = {p: w / w_total for p, w in user_edits["weights"].items()}

# Step 6: Apply edits: remove/add rules
final_rules = []
for param in active:
    # start with LLM
    final_rules += [r for r in param_rules[param] if r["rule_id"] not in user_edits["remove"].get(param,[])]
    final_rules += user_edits["add"].get(param, [])

# Save final rules and weights
import json
with open("/dbfs/FileStore/reports/final_rules.json", "w") as f:
    json.dump(final_rules, f)
with open("/dbfs/FileStore/reports/final_weights.json", "w") as f:
    json.dump(user_edits["weights"], f)

print("✔ Final rules and weights ready for assessment.")
if final_rules:
    display(pd.DataFrame(final_rules))
else:
    print("⚠ No rules to display after edits.")
    display(pd.DataFrame([{
        "rule_id": "",
        "description": "No rules (all were removed)",
        "columns": [],
        "type": "",
        "condition": ""
    }]))
print("Weights:", user_edits["weights"])


# COMMAND ----------

# Cell 4: Assessment, Fail Flag, and Parameter Scoring

from assessment.dq_assessment import DQAssessment
import pyspark.sql.functions as F
import json
import re

DQ_PARAMS = ["accuracy", "consistency", "completeness", "uniqueness"]

# Step 1: Ensure you have df (your main Spark DataFrame)
# (if you have re-run kernel or this cell alone, make sure df is available)
try:
    df
except NameError:
    raise ValueError("Please make sure your main Spark DataFrame 'df' is loaded and available before running this cell.")

# Step 2: Load final rules and weights (from Cell 3 output)
with open("/dbfs/FileStore/reports/final_rules.json", "r") as f:
    final_rules = json.load(f)
with open("/dbfs/FileStore/reports/final_weights.json", "r") as f:
    weights = json.load(f)

def translate_condition(cond: str, default_col: str) -> str:
    cond = re.sub(r"\s+", " ", cond).strip()
    cond = re.sub(r"(?i)\bIS_NUMBER\s*\(\s*([\w\.]+)\s*\)", r"NOT isnan(CAST(\1 AS double))", cond)
    cond = re.sub(r"(?i)\bMATCHES_REGEX\s*\(\s*([\w\.]+)\s*,\s*['\"]([^'\"]+)['\"]\s*\)", r"\1 RLIKE '\2'", cond)
    m = re.match(r"^NOT \(BETWEEN\s+(.+)\s+AND\s+(.+)\)$", cond, re.IGNORECASE)
    if m:
        lo, hi = m.groups()
        cond = f"NOT ({default_col} BETWEEN {lo} AND {hi})"
    return cond

# Step 3: Translate conditions for Spark SQL
for r in final_rules:
    col = r["columns"][0] if r.get("columns") and len(r["columns"]) else None
    if col is None or col not in df.columns:
        r["condition"] = "true"
        continue
    try:
        cond = translate_condition(r.get("condition", ""), col)
        r["condition"] = cond
    except Exception:
        r["condition"] = "true"

# Step 4: Run assessment
assessor = DQAssessment(spark)
results_df = assessor.run_assessment(df, final_rules)

# Step 5: Add Fail_Flag
results_df = results_df.withColumn(
    "Fail_Flag",
    (F.col("score") < 1.0).cast("int")
)
results_df.cache()
display(results_df.limit(10))

# Step 6: Collect results to pandas for summary scoring
results_pd = results_df.toPandas()

# Step 7: Calculate scores per parameter
param_scores = {}
param_counts = {p: 0 for p in DQ_PARAMS}
param_passed = {p: 0 for p in DQ_PARAMS}
param_failed = {p: 0 for p in DQ_PARAMS}
param_error = {p: 0 for p in DQ_PARAMS}
param_obs = {}

for r in results_pd.itertuples():
    typ = getattr(r, 'type', None)
    if typ in DQ_PARAMS:
        param_counts[typ] += 1
        if getattr(r, "score", 0.0) == 1.0:
            param_passed[typ] += 1
        elif getattr(r, "score", 0.0) is None:
            param_error[typ] += 1
        else:
            param_failed[typ] += 1

for p in DQ_PARAMS:
    if param_counts[p] > 0:
        score = param_passed[p] / param_counts[p] * 10
        param_scores[p] = round(score, 1)
    else:
        param_scores[p] = None

    # Basic LLM-like observation logic (replace with LLM call for richer obs if desired)
    if param_scores[p] is None:
        param_obs[p] = "No rules evaluated for this dimension."
    elif param_scores[p] >= 9:
        param_obs[p] = f"Data quality for {p} is very good."
    elif param_scores[p] >= 7:
        param_obs[p] = f"The data mostly meets {p} criteria, with minor issues."
    elif param_scores[p] >= 5:
        param_obs[p] = f"Partial {p} compliance, but improvement is needed."
    else:
        param_obs[p] = f"Significant {p} issues detected, action recommended."

# Step 8: Compute overall weighted DQ score
overall_score = 0
total_weight = sum([weights.get(p, 0) for p in DQ_PARAMS])
for p in DQ_PARAMS:
    w = weights.get(p, 0)
    s = param_scores.get(p, 0) or 0
    overall_score += w * s
if total_weight > 0:
    overall_score = round(overall_score / total_weight, 1)
else:
    overall_score = 0.0

if overall_score >= 9:
    overall_assessment = "Excellent data quality."
elif overall_score >= 7:
    overall_assessment = "Good overall data quality, with minor improvements suggested."
elif overall_score >= 5:
    overall_assessment = "Fair. Specific dimensions require improvement."
else:
    overall_assessment = "Poor. Immediate attention required for most dimensions."

# Step 9: Save summary for report generator
summary_stats = {
    "overall_score": overall_score,
    "overall_assessment": overall_assessment,
    "total_rules": int(results_pd.shape[0]),
    "rules_passed": int((results_pd["score"] == 1.0).sum()),
    "rules_failed": int((results_pd["score"] != 1.0).sum()),
    "rules_with_error": int(results_pd["score"].isnull().sum()),
    "param_scores": param_scores,
    "param_obs": param_obs,
    "param_counts": param_counts,
    "param_passed": param_passed,
    "param_failed": param_failed,
    "param_error": param_error,
    "weights": weights
}

import pickle
with open("/dbfs/FileStore/reports/summary_stats.pkl", "wb") as f:
    pickle.dump(summary_stats, f)


# COMMAND ----------

# Cell 5 – Display Results and PDF Report with Dimension Breakdown

import pickle,os
from reporting.report_generator import ReportGenerator

# Load stats prepared in cell 4
with open("/dbfs/FileStore/reports/summary_stats.pkl", "rb") as f:
    summary_stats = pickle.load(f)

# Load rule-level summary DataFrame (produced in Cell 4 and saved as parquet/csv/pkl)
import pandas as pd
rule_summary_path = "/dbfs/FileStore/reports/summary_df.pkl"
if os.path.exists(rule_summary_path):
    summary_df = pd.read_pickle(rule_summary_path)
else:
    # fallback: create dummy
    summary_df = pd.DataFrame(columns=["Rule Description", "Columns", "Type", "Score", "Fail Count"])

# Show summary in notebook
print(f"\nOverall DQ Score: {summary_stats['overall_score']}/10")
print("Overall Assessment:", summary_stats["overall_assessment"])
print("Summary of Checks:")
print(f"  Total Rules Assessed: {summary_stats['total_rules']}")
print(f"  Rules Passed: {summary_stats['rules_passed']}")
print(f"  Rules Failed: {summary_stats['rules_failed']}")
print(f"  Rules with Errors: {summary_stats['rules_with_error']}")

print("\nDimension Analysis:")
dim_data = []
for p in summary_stats["param_scores"]:
    dim_data.append({
        "Dimension": p.capitalize(),
        "Weight (%)": f"{int(summary_stats['weights'][p]*100)}%",
        "Score (/10)": f"{summary_stats['param_scores'][p]}/10" if summary_stats['param_scores'][p] is not None else "-",
        "Observation": summary_stats["param_obs"][p]
    })
dim_df = pd.DataFrame(dim_data)
display(dim_df)

# Show all rule results in notebook for completeness
if summary_df is not None and not summary_df.empty:
    display(summary_df)
else:
    print("No rule summary data to display.")


# Create PDF report (fpdf in ReportGenerator)
output_dir = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_reports"
report_gen = ReportGenerator(output_dir=output_dir)
pdf_path   = report_gen.generate_dimension_summary(summary_stats, dim_df, summary_df)
print(f"Report saved at: {pdf_path}")


# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# MAGIC %pip install reportlab

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/FileStore/reports"))


# COMMAND ----------

# Cell – make a local copy of the PDF
src  = "/dbfs/FileStore/reports/DQ_Report_20250610_201939.pdf"   # source in DBFS
dest_dir = "/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com/dq_pipeline_project/dq_reports"
dest = f"{dest_dir}/DQ_Report_20250610_201939.pdf"

import os, shutil
os.makedirs(dest_dir, exist_ok=True)
shutil.copy(src, dest)

print(f"Copied to {dest}")


# COMMAND ----------

# MAGIC %pip install -U threadpoolctl

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# ----------- run_pipeline_single_node.py -----------
# Runs on a memory-constrained, single-node Databricks cluster.
# Limits the dataset to 10,000 rows to avoid OOM and performs
# data quality analysis on that bounded sample.

import os
import logging
import traceback

from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import pandas as pd

from ingestion.ingestion import IngestionManager
from sampling.stage3_diversity_sampling import DiversitySampler
from rule_suggester.chunked_rule_suggester import ChunkedRuleSuggester
from assessment.dq_assessment import DQAssessment
from reporting.report_generator import ReportGenerator

# ─── 1. SparkSession ────────────────────────────────────────────────────────────
spark = (
    SparkSession.builder
        .appName("DQ_Pipeline_SingleNode")
        .master("local[*]")
        .config("spark.driver.memory", "40g")
        .config("spark.sql.execution.arrow.maxRecordsPerBatch", "50000")
        .config("spark.checkpoint.dir", "/dbfs/checkpoints")
        .getOrCreate()
)
spark.sparkContext.setCheckpointDir("/dbfs/checkpoints")
spark.conf.set("spark.sql.shuffle.partitions", "200")
spark.conf.set("spark.default.parallelism", "200")

# ─── 2. Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s - %(message)s"
)
logger = logging.getLogger("dq_pipeline_single_node")

def get_widget(name: str, default: str = "") -> str:
    """Fetch from dbutils.widgets if available, else return default."""
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return default

def run_pipeline():
    # ─── 3. Read Inputs ─────────────────────────────────────────────────────────
    try:
        dbutils.widgets.removeAll()
        dbutils.widgets.dropdown('source_type','delta',['delta','file'],'Source Type')
        dbutils.widgets.text('table','samples.nyctaxi.trips','Delta Table')
        dbutils.widgets.text('file_path','','File Path')
        dbutils.widgets.dropdown('file_type','csv',['csv','json','parquet','excel'],'File Type')
        dbutils.widgets.text('report_output_dir','/dbfs/FileStore/reports','Report Output Dir')
    except NameError:
        pass  # not in Databricks notebook

    source_type       = get_widget('source_type', 'delta')
    table             = get_widget('table', 'samples.nyctaxi.trips')
    file_path         = get_widget('file_path', '')
    file_type         = get_widget('file_type', 'csv')
    report_output_dir = get_widget('report_output_dir', '/dbfs/FileStore/reports')

    # ─── 4. Ingest LIMITED SAMPLE ─────────────────────────────────────────────────
    MAX_ROWS = 10000
    ingest_manager = IngestionManager(spark)

    try:
        logger.info(f"Ingesting from: {source_type}")
        if source_type == 'delta':
            if not table:
                raise ValueError("Delta table name must be provided")
            temp_df = ingest_manager.ingest_delta(table)

        elif source_type == 'file':
            if not (file_path and file_type):
                raise ValueError("File path and type required")
            temp_df = ingest_manager.ingest_file(file_path, file_type.lower())

        else:
            raise NotImplementedError(f"Ingestion for '{source_type}' not implemented")

        logger.warning(f"Limiting to {MAX_ROWS} rows to prevent OOM")
        df = temp_df.limit(MAX_ROWS)
        df.cache()
        if df.count() == 0:
            raise ValueError("No data after limiting rows")

    except Exception:
        logger.error("Ingestion error", exc_info=True)
        spark.stop()
        raise

    # ─── 5. Sampling & Rule Suggestion ────────────────────────────────────────────
    try:
        logger.info("Sampling 10% of limited data (up to 500 rows)")
        sample_df = df.sample(False, 0.1, seed=42).limit(500)
        pdf = sample_df.toPandas()
        if pdf.empty:
            raise ValueError("Empty sample for LLM")

        # Diversity sampling on driver
        diversity_sampler = DiversitySampler(num_clusters=1, samples_per_cluster=1)
        final_pdf = diversity_sampler.sample(pdf)

        # Generate rules
        logger.info("Invoking ChunkedRuleSuggester")
        suggester = ChunkedRuleSuggester(model_name="deepseek-r1-distill-llama-70b")
        rules = suggester.suggest_rules_chunked(final_pdf)
        if not rules:
            logger.warning("No DQ rules suggested; exiting.")
            return

    except Exception:
        logger.error("Sampling/rule suggestion error", exc_info=True)
        spark.stop()
        raise

    # ─── 6. Data Quality Assessment ───────────────────────────────────────────────
    try:
        logger.info(f"Running DQ assessment on {MAX_ROWS}-row sample")
        assessor = DQAssessment(spark)
        results_df = assessor.run_assessment(df, rules)

    except Exception:
        logger.error("DQ assessment error", exc_info=True)
        spark.stop()
        raise

    # ─── 7. Save Results & Generate Report ────────────────────────────────────────
    try:
        results_table = "dq_results_sample"
        results_df.write.mode("overwrite").format("delta").saveAsTable(results_table)
        logger.info(f"Results saved to Delta table: {results_table}")

        agg_df = (
            results_df
            .groupBy("Dimension","Rule","Column","Status")
            .agg(F.count("*").alias("Affected_Records"))
            .orderBy("Dimension","Rule")
        )
        report_pd = agg_df.limit(1000).toPandas()

        report_gen = ReportGenerator(output_dir=report_output_dir)
        pdf_path = report_gen.generate(report_pd)
        logger.info(f"Report generated at: {pdf_path}")

    except Exception:
        logger.error("Save/report generation error", exc_info=True)

if __name__ == "__main__":
    try:
        run_pipeline()
    except Exception:
        logger.error("Pipeline failed:\n" + traceback.format_exc())
        raise
    finally:
        spark.stop()
        logger.info("Spark session stopped. Pipeline complete.")


# COMMAND ----------

# ----------- run_pipeline.py -----------

import os
import logging
from pyspark.sql import SparkSession
from ingestion.ingestion import IngestionManager
from sampling.stage1_reservoir_sampling import ReservoirSampler
from sampling.stage2_random_downsample import RandomDownSampler
from sampling.stage3_diversity_sampling import DiversitySampler

try:
    from rule_suggester.chunked_rule_suggester import ChunkedRuleSuggester
except ModuleNotFoundError:
    raise ImportError(
        "The module 'langchain_groq' is required but not installed. "
        "Please install it via 'pip install langchain-groq'."
    )

from assessment.dq_assessment import DQAssessment
from reporting.report_generator import ReportGenerator
import pandas as pd

# -----------------------------------
# 1. Create SparkSession with checkpoint directory
# -----------------------------------
# BEFORE running, ensure the folder exists:
#   dbutils.fs.mkdirs("dbfs:/checkpoints")
spark = (
    SparkSession.builder
        .appName("DQ_Pipeline_Fixed_Checkpoint")
        .config("spark.sql.execution.arrow.maxRecordsPerBatch", "50000")
        .config("spark.checkpoint.dir", "/dbfs/checkpoints")  # builder-time set
        .enableHiveSupport()
        .getOrCreate()
)

# Explicitly set SparkContext checkpoint dir (ensures driver sees it)
spark.sparkContext.setCheckpointDir("/dbfs/checkpoints")  # :contentReference[oaicite:14]{index=14}

# Tweak shuffle partitions & parallelism to prevent oversized partitions
spark.conf.set("spark.sql.shuffle.partitions", "200")         # :contentReference[oaicite:15]{index=15}
spark.conf.set("spark.default.parallelism", "200")            # :contentReference[oaicite:16]{index=16}

# -----------------------------------
# 2. Configure logging
# -----------------------------------
env_logging_conf = os.getenv('LOGGING_CONF', 'configs/logging.conf')
if os.path.exists(env_logging_conf):
    import logging.config
    logging.config.fileConfig(env_logging_conf, disable_existing_loggers=False)
logger = logging.getLogger('dq_pipeline.mitigated')

# Instantiate ingestion manager
ingest_manager = IngestionManager(spark)

# -----------------------------------
# 3. Create widgets for user input (Databricks only)
# -----------------------------------
try:
    dbutils.widgets.removeAll()
    source_options = ['delta', 'kafka', 'mongodb', 'relational', 'cassandra', 'file', 's3', 'fivetran']
    dbutils.widgets.dropdown('source_type', 'delta', source_options, 'Source Type')
    dbutils.widgets.text('table', '', 'Delta Table (catalog.schema.table)')
    dbutils.widgets.text('topic', '', 'Kafka Topic')
    dbutils.widgets.text('kafka_servers', '', 'Kafka Bootstrap Servers')
    dbutils.widgets.text('uri', '', 'MongoDB URI')
    dbutils.widgets.text('database', '', 'MongoDB Database')
    dbutils.widgets.text('collection', '', 'MongoDB Collection')
    dbutils.widgets.text('jdbc_url', '', 'JDBC URL')
    dbutils.widgets.text('rel_table', '', 'Relational Table')
    dbutils.widgets.text('rel_user', '', 'Relational User')
    dbutils.widgets.text('rel_pass', '', 'Relational Password')
    dbutils.widgets.text('rel_driver', '', 'JDBC Driver Class')
    dbutils.widgets.text('cass_keyspace', '', 'Cassandra Keyspace')
    dbutils.widgets.text('cass_table', '', 'Cassandra Table')
    dbutils.widgets.text('cass_hosts', '', 'Cassandra Hosts')
    dbutils.widgets.text('cass_port', '', 'Cassandra Port')
    dbutils.widgets.text('file_path', '', 'File Path')
    dbutils.widgets.dropdown('file_type', 'csv', ['csv', 'json', 'parquet', 'excel'], 'File Type')
    dbutils.widgets.text('s3_path', '', 'S3 Path')
    dbutils.widgets.dropdown('s3_format', 'csv', ['csv', 'json', 'parquet'], 'S3 Format')
    dbutils.widgets.text('fivetran_table', '', 'FiveTran Table')
    dbutils.widgets.text('report_output_dir', '/dbfs/FileStore/acharjeerishab/reports', 'Report Output Dir')
except NameError:
    # Not running in Databricks; skip widgets
    pass

# Helper to fetch widget values
def get_widget(name: str):
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return None

# -----------------------------------
# 4. Read widget values
# -----------------------------------
source_type       = get_widget('source_type')
table             = get_widget('table')
topic             = get_widget('topic')
kafka_servers     = get_widget('kafka_servers')
uri               = get_widget('uri')
database          = get_widget('database')
collection        = get_widget('collection')
jdbc_url          = get_widget('jdbc_url')
rel_table         = get_widget('rel_table')
rel_user          = get_widget('rel_user')
rel_pass          = get_widget('rel_pass')
rel_driver        = get_widget('rel_driver')
cass_keyspace     = get_widget('cass_keyspace')
cass_table        = get_widget('cass_table')
cass_hosts        = get_widget('cass_hosts')
cass_port         = get_widget('cass_port')
file_path         = get_widget('file_path')
file_type         = get_widget('file_type')
s3_path           = get_widget('s3_path')
s3_format         = get_widget('s3_format')
fivetran_table    = get_widget('fivetran_table')
report_output_dir = get_widget('report_output_dir') or '/dbfs/FileStore/acharjeerishab/reports'

# -----------------------------------
# 5. Ingest data based on chosen source
# -----------------------------------
try:
    logger.info(f"Ingestion source: {source_type}")
    if source_type == 'delta':
        if not table:
            raise ValueError("Delta table must be provided")
        df = ingest_manager.ingest_delta(table)

    elif source_type == 'kafka':
        if not topic or not kafka_servers:
            raise ValueError("Kafka topic and bootstrap servers required")
        df = ingest_manager.ingest_kafka(topic, kafka_servers)
        raise ValueError("Streaming ingestion not supported in interactive batch mode")

    elif source_type == 'mongodb':
        if not (uri and database and collection):
            raise ValueError("MongoDB URI, database, and collection required")
        df = ingest_manager.ingest_mongodb(uri, database, collection)

    elif source_type == 'relational':
        if not (jdbc_url and rel_table and rel_user and rel_pass):
            raise ValueError("JDBC URL, table, user, and password required")
        df = ingest_manager.ingest_relational(jdbc_url, rel_table, rel_user, rel_pass, driver=rel_driver)

    elif source_type == 'cassandra':
        if not (cass_keyspace and cass_table and cass_hosts and cass_port):
            raise ValueError("Cassandra keyspace, table, hosts, and port required")
        df = ingest_manager.ingest_cassandra(
            cass_keyspace,
            cass_table,
            contact_points=cass_hosts,
            port=int(cass_port)
        )

    elif source_type == 'file':
        if not (file_path and file_type):
            raise ValueError("File path and file type required")

        # Normalize the file path
        if file_path.startswith("/Workspace/"):
            norm_path = "dbfs:" + file_path
        elif file_path.startswith("/dbfs/"):
            norm_path = file_path.replace("/dbfs/", "dbfs:/")
        elif file_path.startswith("dbfs:/"):
            norm_path = file_path
        else:
            norm_path = file_path

        logger.info(f"Normalized file path: {norm_path}")
        if file_type.lower() == 'excel' and file_path.endswith(('xlsx', 'xls')):
            # Read Excel via Spark Excel connector
            df = spark.read.format("com.crealytics.spark.excel") \
                         .option("header", "true") \
                         .option("inferSchema", "true") \
                         .load(norm_path)
        else:
            # Delegate other formats to ingestion manager
            df = ingest_manager.ingest_file(norm_path, file_type)

    elif source_type == 's3':
        if not (s3_path and s3_format):
            raise ValueError("S3 path and format required")
        df = ingest_manager.ingest_s3(s3_path, file_format=s3_format)

    elif source_type == 'fivetran':
        if not fivetran_table:
            raise ValueError("FiveTran table required")
        df = ingest_manager.ingest_fivetran(fivetran_table)

    else:
        raise ValueError(f"Unsupported source: {source_type}")

except Exception as e:
    logger.error(f"Error during ingestion: {e}")
    spark.stop()
    raise

# -----------------------------------
# 6. Validate non‐empty DataFrame
#    (Use head(1) rather than count() to avoid full scan.)
# -----------------------------------
if df is None or len(df.head(1)) == 0:
    logger.error("DataFrame is empty after ingestion.")
    spark.stop()
    raise ValueError("Empty DataFrame")

# -----------------------------------
# 7. Break lineage early via checkpoint
# -----------------------------------
df = df.checkpoint(eager=True)  # :contentReference[oaicite:17]{index=17}

# … (all code up through checkpointing) …

# -----------------------------------
# 8. Sampling & rule suggestion
# -----------------------------------
logger.info("Starting sampling & rule suggestion")

# Stage 1: Reservoir Sampling (fraction-based)
resampler = ReservoirSampler(spark, sample_size=900)
sample_stage1 = resampler.sample(df)

# Stage 2: Random Downsample
downsampler = RandomDownSampler(spark, target_count=50)
sample_stage2 = downsampler.sample(sample_stage1)

# === Convert a small subset (or all) of columns to Pandas ===
# OPTION A: all columns
pdf = sample_stage2.limit(100).toPandas()

# OPTION B: only specific columns (uncomment & adjust):
# sample_cols = ["Date", "Discom", "Time", "RTC"]  # replace with actual names
# selected = sample_stage2.select(*sample_cols)
# pdf = selected.limit(1000).toPandas()

# Stage 3: Diversity Sampling (on driver, on the small PDF)
diversity_sampler = DiversitySampler(num_clusters=1, samples_per_cluster=1)
final_pdf = diversity_sampler.sample(pdf)

# Continue with rule suggestion…
try:
    chunked_suggester = ChunkedRuleSuggester(model_name='deepseek-r1-distill-llama-70b')
    rules = chunked_suggester.suggest_rules_chunked(final_pdf)
except Exception as e:
    logger.error(f"Error during rule suggestion: {e}")
    spark.stop()
    raise

if not rules:
    logger.warning("No rules generated; skipping DQ assessment")
    spark.stop()
    exit(0)


# -----------------------------------
# 9. Run DQ Assessment (distributed)
# -----------------------------------
logger.info("Running DQ Assessment")
assessor = DQAssessment(spark)
try:
    results_df = assessor.run_assessment(df, rules)
except Exception as e:
    logger.error(f"Assessment failed: {e}")
    spark.stop()
    raise

# Save results as a Delta table
results_table = os.getenv('DQ_RESULTS_TABLE', 'dq_results.default')
try:
    results_df.write.mode('overwrite').format('delta').saveAsTable(results_table)
    logger.info(f"Results saved to {results_table}")
except Exception as e:
    logger.error(f"Writing results failed: {e}")
    spark.stop()
    raise

# -----------------------------------
# 10. Generate PDF report
# -----------------------------------
logger.info("Generating PDF report")
report_gen = ReportGenerator(output_dir=report_output_dir)
try:
    pdf_path = report_gen.generate(results_df)
    logger.info(f"Report saved at {pdf_path}")
except Exception as e:
    logger.error(f"Report generation failed: {e}")
    spark.stop()
    raise

spark.stop()
logger.info("Pipeline run complete.")


# COMMAND ----------

