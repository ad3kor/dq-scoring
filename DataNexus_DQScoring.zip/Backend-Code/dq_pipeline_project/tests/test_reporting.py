import unittest
from pyspark.sql import SparkSession
from reporting.report_generator import ReportGenerator
import os

class TestReportGenerator(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spark = SparkSession.builder.master("local[2]").appName("TestReport").getOrCreate()
        data = [('r1', 'Rule 1', 'accuracy', 10, 0, 1.0)]
        cls.df = cls.spark.createDataFrame(data, ['rule_id', 'description', 'type', 'pass_count', 'fail_count', 'score'])

    def test_generate(self):
        gen = ReportGenerator(output_dir="./test_reports")
        path = gen.generate(self.df)
        self.assertTrue(os.path.exists(path))
        os.remove(path)

if __name__ == '__main__':
    unittest.main()