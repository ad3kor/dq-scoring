# tests/test_rag.py
import unittest
from pyspark.sql import SparkSession
from rag.rag_utils import chunk_dataframe
from rag.vector_search_query import VectorSearchQuery
from rag.weaviate_query import WeaviateQuery

class TestRAGComponents(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spark = SparkSession.builder.master("local[2]").appName("TestRAG").getOrCreate()
        data = ["This is a test.", "Another sentence."]
        cls.pdf = pd.DataFrame({'text': data, 'metadata': ["m1", "m2"]})

    def test_chunking(self):
        chunks = chunk_dataframe(self.pdf, chunk_size=1, overlap=0)
        self.assertEqual(len(chunks), 2)

    def test_vector_search_query(self):
        # Requires a real index and credentials; skip or mock
        pass

    def test_weaviate_query(self):
        # Requires running Weaviate; skip or mock
        pass

if __name__ == '__main__':
    unittest.main()