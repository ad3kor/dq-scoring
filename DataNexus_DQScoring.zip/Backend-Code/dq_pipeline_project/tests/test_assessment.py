# tests/test_assessment.py
import unittest
from pyspark.sql import SparkSession
from assessment.dq_assessment import DQAssessment

class TestDQAssessment(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spark = SparkSession.builder.master("local[2]").appName("TestDQ").getOrCreate()
        data = [(1, 'a'), (None, 'b'), (3, None)]
        cls.df = cls.spark.createDataFrame(data, ['id', 'value'])

    def test_run_assessment(self):
        rules = [
            {'rule_id': 'r1', 'description': 'ID not null', 'columns': ['id'], 'type': 'completeness', 'condition': 'id IS NOT NULL'},
            {'rule_id': 'r2', 'description': 'Value not null', 'columns': ['value'], 'type': 'completeness', 'condition': 'value IS NOT NULL'}
        ]
        assessor = DQAssessment(self.spark)
        results = assessor.run_assessment(self.df, rules).toPandas()
        self.assertEqual(len(results), 2)
        self.assertEqual(results.iloc[0]['fail_count'], 1)
        self.assertEqual(results.iloc[1]['fail_count'], 1)

if __name__ == '__main__':
    unittest.main()