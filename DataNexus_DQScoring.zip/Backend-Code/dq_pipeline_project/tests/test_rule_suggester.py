# tests/test_rule_suggester.py
import unittest
from rule_suggester.rule_suggester import RuleSuggester

class TestRuleSuggester(unittest.TestCase):
    def test_build_prompt(self):
        rs = RuleSuggester()
        sample = [{'col1': 1, 'col2': 'a'}]
        stats = {'col1': {'null_count': 0, 'unique_count': 1}, 'col2': {'null_count': 0, 'unique_count': 1}}
        prompt = rs.build_prompt(sample, stats)
        self.assertIn('col1', prompt)
        self.assertIn('col2', prompt)

if __name__ == '__main__':
    unittest.main()