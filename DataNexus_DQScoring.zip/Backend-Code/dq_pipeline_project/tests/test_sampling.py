# tests/test_sampling.py
import unittest
import pandas as pd
from sampling.stage3_diversity_sampling import DiversitySampler

class TestDiversitySampler(unittest.TestCase):
    def test_sample_shape(self):
        df = pd.DataFrame({'a': range(100), 'b': range(100, 200)})
        sampler = DiversitySampler(num_clusters=10, samples_per_cluster=2)
        sampled_df = sampler.sample(df)
        # Expect 10 clusters * 2 samples = 20
        self.assertEqual(len(sampled_df), 20)

if __name__ == '__main__':
    unittest.main()