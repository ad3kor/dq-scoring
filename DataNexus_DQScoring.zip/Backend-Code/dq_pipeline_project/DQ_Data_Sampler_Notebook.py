# Databricks notebook source
# MAGIC %pip install -r requirements.txt
# MAGIC

# COMMAND ----------

# # Notebook: DQ_Data_Sampler_Notebook
# # Purpose: Load cleaned data from Delta table, extract a small sample, and return it as JSON for frontend.

# import json
# import pandas as pd
# import logging
# import numpy as np # Import numpy for NaT handling
# import datetime # Import datetime module to check for date types

# # --- Spark and Logging Setup ---
# from pyspark.sql import SparkSession
# spark = SparkSession.builder.appName("DQ_Data_Sampler_Job").getOrCreate()
# logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
# logger = logging.getLogger('dq_data_sampler_notebook')
# print("✅ Spark Session and Logger initialized.")

# # --- Configuration ---
# # Define the Delta table where the cleaned data is read from
# CLEANED_DATA_DELTA_TABLE_FQDN = "hive_metastore.default.dq_ingested_clean_sample" # Must match Notebook 1
# MAX_ROWS_FOR_SAMPLE_OUTPUT = 50 # Max rows to return to frontend (keep this small!)

# # ==============================================================================
# # 1. Load Cleaned Data
# # ==============================================================================
# print(f"--- Step 1: Loading cleaned data from Delta table: {CLEANED_DATA_DELTA_TABLE_FQDN} ---")
# df_cleaned = None
# try:
#     df_cleaned = spark.read.format("delta").table(CLEANED_DATA_DELTA_TABLE_FQDN)
#     total_records = df_cleaned.count()
#     print(f"✅ Loaded cleaned data (df_cleaned) with {total_records} rows.")
# except Exception as e:
#     print(f"❌ Error loading cleaned data from Delta table: {e}")
#     dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Failed to load cleaned data for sampling: {str(e)}"}))

# # ==============================================================================
# # 2. Extract and Prepare Data Sample for Frontend
# # ==============================================================================
# print(f"\n--- Step 2: Extracting a sample of {MAX_ROWS_FOR_SAMPLE_OUTPUT} rows for frontend... ---")

# data_sample_for_frontend = []
# if df_cleaned and df_cleaned.count() > 0:
#     try:
#         # Take a small sample and convert to Pandas
#         pandas_sample = df_cleaned.limit(MAX_ROWS_FOR_SAMPLE_OUTPUT).toPandas()

#         # --- FIX: UNIVERSAL DATE/DATETIME/NAN/NAT HANDLING FOR JSON SERIALIZATION ---
#         # Iterate through columns and apply a lambda that handles various types.
#         # This is more robust as it checks each element's type directly.
#         for col_name in pandas_sample.columns:
#             pandas_sample[col_name] = pandas_sample[col_name].apply(
#                 lambda x: x.isoformat() 
#                 if isinstance(x, (datetime.date, datetime.datetime)) # Check for date or datetime objects (including pandas.Timestamp)
#                 else (None if pd.isna(x) else x) # Handle np.nan, pd.NaT, and other None-like values
#             )
            
#         # At this point, all recognized date/datetime objects should be strings or None.
#         # Any remaining NaNs in numeric columns will be caught by to_dict(orient='records')
#         # if they are actual floating point NaNs, or should have been covered by previous step.
#         # This explicit replace ensures no NaNs slip through for numeric columns:
#         for col_name in pandas_sample.columns:
#             if pd.api.types.is_numeric_dtype(pandas_sample[col_name]):
#                  pandas_sample[col_name] = pandas_sample[col_name].replace({np.nan: None})


#         # Convert the cleaned Pandas DataFrame to a list of dictionaries
#         data_sample_for_frontend = pandas_sample.to_dict(orient='records')
        
#         print(f"✅ Successfully extracted {len(data_sample_for_frontend)} rows as sample.")
#     except Exception as e:
#         print(f"❌ Error extracting sample for frontend: {e}")
#         dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Failed to extract sample for frontend: {str(e)}"}))
# else:
#     print("⚠️ No data in df_cleaned, returning empty sample.")

# # ==============================================================================
# # 3. Exit Notebook with JSON Sample
# # ==============================================================================
# final_output = {
#     "status": "SUCCEEDED",
#     "message": f"Data sample of {len(data_sample_for_frontend)} rows generated.",
#     "data_sample": data_sample_for_frontend
# }

# print("\n--- Exiting notebook with data sample JSON ---")
# dbutils.notebook.exit(json.dumps(final_output))

# COMMAND ----------

# # Notebook: DQ_Data_Sampler_Notebook (Dynamic Input Version)
# # Purpose: Load a specific data file passed at runtime, extract a diverse sample, 
# #          and return it as a single, valid JSON string.

# # --- Dependency Installation ---
# %pip install scikit-learn sentence-transformers pandas numpy

# import json
# import pandas as pd
# import logging
# import numpy as np
# import datetime

# # --- Library Imports ---
# from pyspark.sql import SparkSession
# from sentence_transformers import SentenceTransformer
# from sklearn.cluster import KMeans
# from sklearn.metrics import pairwise_distances_argmin_min

# # --- Spark and Logging Setup ---
# spark = SparkSession.builder.appName("DQ_Advanced_Sampler_Job").getOrCreate()
# logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
# logger = logging.getLogger('dq_advanced_sampler_notebook')
# logger.info("✅ Spark Session and Logger initialized.")

# # --- Configuration ---
# # Sampling strategy parameters
# STAGE_1_SAMPLE_SIZE = 1000000 
# STAGE_2_SAMPLE_SIZE = 50000   
# FINAL_SAMPLE_SIZE = 50        

# # ==============================================================================
# # 1. Get Input File Path from Job Parameters
# # ==============================================================================
# logger.info("--- Step 1: Retrieving source file path from job parameters... ---")

# # Define the widget to accept the file path from the frontend
# dbutils.widgets.text("source_file_path", "", "The full cloud storage path to the source data file to be sampled")
# source_file_path = dbutils.widgets.get("source_file_path")

# if not source_file_path:
#     dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": "Job parameter 'source_file_path' was empty. No file specified for sampling."}))

# logger.info(f"✅ Received request to sample file: {source_file_path}")


# # ==============================================================================
# # 2. Load Data from the Provided Path
# # ==============================================================================
# logger.info(f"--- Step 2: Loading data from source file... ---")
# try:
#     # Infer the format from the file extension
#     if source_file_path.endswith(".csv"):
#         df_cleaned = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(source_file_path)
#     elif source_file_path.endswith(".parquet"):
#         df_cleaned = spark.read.parquet(source_file_path)
#     elif source_file_path.endswith((".xlsx", ".xls")):
#         # Note: This requires the com.crealytics.spark.excel library to be installed on your cluster
#         df_cleaned = spark.read.format("com.crealytics.spark.excel").option("header", "true").option("inferSchema", "true").load(source_file_path)
#     else:
#         raise ValueError(f"Unsupported file format for path: {source_file_path}")

#     total_records = df_cleaned.count()
#     if total_records == 0:
#         dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": "Source file is empty."}))
    
#     logger.info(f"✅ Loaded {total_records} rows from the source file.")
# except Exception as e:
#     error_payload = json.dumps({"status": "FAILED", "message": f"Failed to load data from path '{source_file_path}'. Error: {str(e)}"})
#     dbutils.notebook.exit(error_payload)


# # ==============================================================================
# # 3. Multi-Stage Sampling and Refinement
# # ==============================================================================
# logger.info("\n--- Step 3: Beginning Multi-Stage Sampling Process ---")
# # The logic for stages 1, 2, and 3 remains the same as it operates on the dynamically loaded DataFrame.

# # --- Stage 1: Initial, Massive-Scale Reduction (Spark) ---
# logger.info(f"  > Stage 1: Performing initial reduction to approx. {STAGE_1_SAMPLE_SIZE} records...")
# fraction_stage1 = min(1.5 * STAGE_1_SAMPLE_SIZE / total_records, 1.0)
# stage1_df = df_cleaned.sample(withReplacement=False, fraction=fraction_stage1, seed=42).limit(STAGE_1_SAMPLE_SIZE)
# stage1_count = stage1_df.count()
# logger.info(f"  > Stage 1 complete. Sample size: {stage1_count} records.")

# # --- Stage 2: Intermediate Refinement for Manageability (Spark -> Pandas) ---
# logger.info(f"  > Stage 2: Refining sample to {STAGE_2_SAMPLE_SIZE} records for driver processing...")
# if stage1_count > STAGE_2_SAMPLE_SIZE:
#     fraction_stage2 = min(1.5 * STAGE_2_SAMPLE_SIZE / stage1_count, 1.0)
#     stage2_df = stage1_df.sample(withReplacement=False, fraction=fraction_stage2, seed=42).limit(STAGE_2_SAMPLE_SIZE)
# else:
#     stage2_df = stage1_df

# try:
#     pandas_sample_df = stage2_df.toPandas()
#     logger.info(f"  > Stage 2 complete. Collected {len(pandas_sample_df)} records to driver as Pandas DataFrame.")
# except Exception as e:
#     error_payload = json.dumps({"status": "FAILED", "message": f"Failed to collect sample to Pandas. Error: {str(e)}"})
#     dbutils.notebook.exit(error_payload)

# # ==============================================================================
# # 4. Stage 3: Diversity-Focused Final Sample Selection
# # ==============================================================================
# logger.info("\n--- Step 4: Performing Diversity Sampling using Clustering ---")
# logger.info("  > Step 4a: Converting rows to JSON strings for text embedding...")
# pandas_sample_df_for_embedding = pandas_sample_df.replace({np.nan: None})
# json_strings = pandas_sample_df_for_embedding.to_json(orient='records', lines=True).strip().split('\n')
# logger.info(f"  > Converted {len(json_strings)} rows.")

# logger.info("  > Step 4b: Embedding text into vectors using SentenceTransformer...")
# model = SentenceTransformer('all-MiniLM-L6-v2')
# embeddings = model.encode(json_strings, show_progress_bar=False)
# logger.info(f"  > Created {embeddings.shape[0]} embeddings.")

# logger.info(f"  > Step 4c: Applying K-Means clustering with k={FINAL_SAMPLE_SIZE}...")
# kmeans = KMeans(n_clusters=FINAL_SAMPLE_SIZE, random_state=42, n_init='auto')
# kmeans.fit(embeddings)
# logger.info("  > Clustering complete.")

# logger.info("  > Step 4d: Selecting the most representative sample from each cluster...")
# closest, _ = pairwise_distances_argmin_min(kmeans.cluster_centers_, embeddings)
# final_diverse_sample_df = pandas_sample_df.iloc[closest]
# logger.info(f"✅ Diversity sampling complete. Final sample size: {len(final_diverse_sample_df)} records.")


# # ==============================================================================
# # 5. Prepare and Exit with Final JSON Sample
# # ==============================================================================
# logger.info("\n--- Step 5: Preparing final JSON output ---")
# list_of_records = final_diverse_sample_df.to_dict(orient='records')
# cleaned_data_sample = []
# for row in list_of_records:
#     cleaned_row = {}
#     for key, value in row.items():
#         if isinstance(value, (datetime.datetime, datetime.date, pd.Timestamp)):
#             cleaned_row[key] = value.isoformat()
#         elif pd.isna(value):
#             cleaned_row[key] = None
#         else:
#             cleaned_row[key] = value
#     cleaned_data_sample.append(cleaned_row)

# final_output = {
#     "status": "SUCCEEDED",
#     "message": f"Advanced data sample of {len(cleaned_data_sample)} diverse rows generated.",
#     "data_sample": cleaned_data_sample
# }

# final_json_string = json.dumps(final_output, indent=2)

# logger.info("\n--- Exiting notebook with data sample JSON ---")
# dbutils.notebook.exit(final_json_string)

# COMMAND ----------

# Notebook: DQ_Data_Sampler_Notebook (Multi-File Dynamic Input Version)
# Purpose: Load one or more data files passed at runtime, merge them, extract a diverse sample, 
#          and return it as a single, valid JSON string.

# --- Dependency Installation ---
%pip install scikit-learn sentence-transformers pandas numpy

import json
import pandas as pd
import logging
import numpy as np
import datetime

# --- Library Imports ---
from pyspark.sql import SparkSession
from sentence_transformers import SentenceTransformer
from sklearn.cluster import KMeans
from sklearn.metrics import pairwise_distances_argmin_min

# --- Spark and Logging Setup ---
spark = SparkSession.builder.appName("DQ_Advanced_Sampler_Job").getOrCreate()
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('dq_advanced_sampler_notebook')
logger.info("✅ Spark Session and Logger initialized.")

# --- Configuration ---
# Sampling strategy parameters
STAGE_1_SAMPLE_SIZE = 1000000 
STAGE_2_SAMPLE_SIZE = 50000   
FINAL_SAMPLE_SIZE = 50        

# ==============================================================================
# 1. Get Input File Paths from Job Parameters
# ==============================================================================
logger.info("--- Step 1: Retrieving source file paths from job parameters... ---")

# *** MODIFICATION: Define a widget to accept a JSON list of file paths ***
dbutils.widgets.text("source_file_paths_json", "", "A JSON array of full cloud storage paths to the source data files")
source_file_paths_json_str = dbutils.widgets.get("source_file_paths_json")

if not source_file_paths_json_str:
    dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": "Job parameter 'source_file_paths_json' was empty. No files specified."}))

try:
    # Parse the JSON string into a Python list of paths
    source_file_paths = json.loads(source_file_paths_json_str)
    if not isinstance(source_file_paths, list) or len(source_file_paths) == 0:
        raise ValueError("Parameter must be a non-empty list of file paths.")
    logger.info(f"✅ Received request to sample {len(source_file_paths)} file(s).")
except Exception as e:
    dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": f"Could not parse 'source_file_paths_json'. Error: {e}"}))


# ==============================================================================
# 2. Load and Merge Data from the Provided Paths
# ==============================================================================
logger.info(f"--- Step 2: Loading and merging data from source files... ---")
try:
    # Determine the file format from the first file in the list
    first_file_path = source_file_paths[0]
    
    # *** MODIFICATION: The spark.read.load() method can accept a list of paths directly. ***
    # Spark will automatically merge (union) the files as long as they have the same schema.
    if first_file_path.endswith(".csv"):
        df_cleaned = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(source_file_paths)
    elif first_file_path.endswith(".parquet"):
        df_cleaned = spark.read.parquet(source_file_paths)
    elif first_file_path.endswith((".xlsx", ".xls")):
        # Note: This requires the com.crealytics.spark.excel library to be installed on your cluster
        df_cleaned = spark.read.format("com.crealytics.spark.excel").option("header", "true").option("inferSchema", "true").load(source_file_paths)
    else:
        raise ValueError(f"Unsupported file format for path: {first_file_path}")

    total_records = df_cleaned.count()
    if total_records == 0:
        dbutils.notebook.exit(json.dumps({"status": "FAILED", "message": "Source files are empty."}))
    
    logger.info(f"✅ Successfully loaded and merged {len(source_file_paths)} file(s) into a single DataFrame with {total_records} total rows.")
except Exception as e:
    error_payload = json.dumps({"status": "FAILED", "message": f"Failed to load data from paths. Error: {str(e)}"})
    dbutils.notebook.exit(error_payload)


# ==============================================================================
# 3. Multi-Stage Sampling and Refinement
# ==============================================================================
# (This entire section remains unchanged, as it now operates on the merged DataFrame)
logger.info("\n--- Step 3: Beginning Multi-Stage Sampling Process ---")
# --- Stage 1: Initial, Massive-Scale Reduction (Spark) ---
logger.info(f"  > Stage 1: Performing initial reduction to approx. {STAGE_1_SAMPLE_SIZE} records...")
fraction_stage1 = min(1.5 * STAGE_1_SAMPLE_SIZE / total_records, 1.0)
stage1_df = df_cleaned.sample(withReplacement=False, fraction=fraction_stage1, seed=42).limit(STAGE_1_SAMPLE_SIZE)
stage1_count = stage1_df.count()
logger.info(f"  > Stage 1 complete. Sample size: {stage1_count} records.")

# --- Stage 2: Intermediate Refinement for Manageability (Spark -> Pandas) ---
logger.info(f"  > Stage 2: Refining sample to {STAGE_2_SAMPLE_SIZE} records for driver processing...")
if stage1_count > STAGE_2_SAMPLE_SIZE:
    fraction_stage2 = min(1.5 * STAGE_2_SAMPLE_SIZE / stage1_count, 1.0)
    stage2_df = stage1_df.sample(withReplacement=False, fraction=fraction_stage2, seed=42).limit(STAGE_2_SAMPLE_SIZE)
else:
    stage2_df = stage1_df

try:
    pandas_sample_df = stage2_df.toPandas()
    logger.info(f"  > Stage 2 complete. Collected {len(pandas_sample_df)} records to driver as Pandas DataFrame.")
except Exception as e:
    error_payload = json.dumps({"status": "FAILED", "message": f"Failed to collect sample to Pandas. Error: {str(e)}"})
    dbutils.notebook.exit(error_payload)

# ==============================================================================
# 4. Stage 3: Diversity-Focused Final Sample Selection
# ==============================================================================
# (This entire section remains unchanged)
logger.info("\n--- Step 4: Performing Diversity Sampling using Clustering ---")
logger.info("  > Step 4a: Converting rows to JSON strings for text embedding...")
pandas_sample_df_for_embedding = pandas_sample_df.replace({np.nan: None})
json_strings = pandas_sample_df_for_embedding.to_json(orient='records', lines=True).strip().split('\n')
logger.info(f"  > Converted {len(json_strings)} rows.")

logger.info("  > Step 4b: Embedding text into vectors using SentenceTransformer...")
model = SentenceTransformer('all-MiniLM-L6-v2')
embeddings = model.encode(json_strings, show_progress_bar=False)
logger.info(f"  > Created {embeddings.shape[0]} embeddings.")

logger.info(f"  > Step 4c: Applying K-Means clustering with k={FINAL_SAMPLE_SIZE}...")
kmeans = KMeans(n_clusters=FINAL_SAMPLE_SIZE, random_state=42, n_init='auto')
kmeans.fit(embeddings)
logger.info("  > Clustering complete.")

logger.info("  > Step 4d: Selecting the most representative sample from each cluster...")
closest, _ = pairwise_distances_argmin_min(kmeans.cluster_centers_, embeddings)
final_diverse_sample_df = pandas_sample_df.iloc[closest]
logger.info(f"✅ Diversity sampling complete. Final sample size: {len(final_diverse_sample_df)} records.")


# ==============================================================================
# 5. Prepare and Exit with Final JSON Sample
# ==============================================================================
# (This entire section remains unchanged)
logger.info("\n--- Step 5: Preparing final JSON output ---")
list_of_records = final_diverse_sample_df.to_dict(orient='records')
cleaned_data_sample = []
for row in list_of_records:
    cleaned_row = {}
    for key, value in row.items():
        if isinstance(value, (datetime.datetime, datetime.date, pd.Timestamp)):
            cleaned_row[key] = value.isoformat()
        elif pd.isna(value):
            cleaned_row[key] = None
        else:
            cleaned_row[key] = value
    cleaned_data_sample.append(cleaned_row)

final_output = {
    "status": "SUCCEEDED",
    "message": f"Advanced data sample of {len(cleaned_data_sample)} diverse rows generated from {len(source_file_paths)} file(s).",
    "data_sample": cleaned_data_sample
}

final_json_string = json.dumps(final_output, indent=2)

logger.info("\n--- Exiting notebook with data sample JSON ---")
dbutils.notebook.exit(final_json_string)

# COMMAND ----------

