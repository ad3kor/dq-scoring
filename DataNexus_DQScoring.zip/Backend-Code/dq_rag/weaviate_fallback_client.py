# dq_rag/weaviate_fallback_client.py
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import weaviate
from dq_utils.config_manager import ConfigManager
from .embedding_generators import EmbeddingGenerator

logger = logging.getLogger(__name__)


class WeaviateClientRAG:
    """
    Client for Weaviate fallback for RAG.
    """

    def __init__(
        self,
        config_manager_instance: "ConfigManager",
        embedding_generator_instance: EmbeddingGenerator
    ):
        self.config_mgr = config_manager_instance
        self.embed_gen = embedding_generator_instance
        url = self.config_mgr.get_config("WEAVIATE_URL")
        api_key = self.config_mgr.get_config(
            "WEAVIATE_API_KEY", is_secret=True, secret_scope="weaviate_credentials"
        )
        auth = weaviate.AuthApiKey(api_key=api_key) if api_key else None
        self.client = weaviate.connect(url=url, auth_client_secret=auth)
        self.collection = self.config_mgr.get_config("WEAVIATE_COLLECTION_NAME", default="DataQualityEmbeddings")

    def ensure_collection_exists(self, vector_dimensionality: int = 384) -> None:
        if not self.client.schema.exists(self.collection):
            self.client.schema.create_class({
                "class": self.collection,
                "properties": [{"name": "text_content", "dataType": ["text"]}]
            })

    def add_documents_batch(self, documents: List[Dict[str, Any]], embeddings: List[List[float]]) -> None:
        with self.client.batch as batch:
            for doc, emb in zip(documents, embeddings):
                batch.add_data_object(properties=doc, class_name=self.collection, vector=emb)

    def query_collection(
        self, query_text: str, num_results: int = 5, certainty_threshold: Optional[float] = None
    ) -> Any:
        emb = self.embed_gen.generate_embedding_local(query_text)
        res = self.client.query.get(self.collection, ["text_content"]) \
                 .with_near_vector({"vector": emb, "certainty": certainty_threshold}) \
                 .with_limit(num_results).do()
        return res
