# dq_rag/vector_search_interface.py
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from databricks.vector_search.client import VectorSearchClient

logger = logging.getLogger(__name__)


class DatabricksVectorSearchInterface:
    """
    Interface for Databricks Vector Search.
    """

    def __init__(self, db_workspace_client=None):
        try:
            self.vsc = VectorSearchClient()
        except Exception:
            logger.error("Failed to init VectorSearchClient.", exc_info=True)
            self.vsc = None

    def query_index(
        self,
        query_text: str,
        vs_endpoint_name: str,
        vs_index_fqn: str,
        num_results: int = 5,
        columns_to_return: Optional[List[str]] = None
    ) -> Optional[List[Dict[str, Any]]]:
        if not self.vsc:
            return None
        columns = columns_to_return or ["text_content_column", "source_document_id"]
        idx = self.vsc.get_index(endpoint_name=vs_endpoint_name, index_name=vs_index_fqn)
        resp = idx.similarity_search(query_text=query_text, columns=columns, num_results=num_results)
        docs: List[Dict[str, Any]] = []
        for row in resp["result"]["data_array"]:
            docs.append({columns[i]: row[i] for i in range(len(columns))})
        return docs
