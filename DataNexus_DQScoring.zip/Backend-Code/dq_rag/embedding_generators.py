# dq_rag/embedding_generators.py
from __future__ import annotations

import asyncio
import logging
from typing import Any, List, Optional, Union

import ray
from sentence_transformers import SentenceTransformer

from dq_utils.config_manager import ConfigManager

logger = logging.getLogger(__name__)


class EmbeddingGenerator:
    """
    Generates embeddings via Hugging Face Sentence Transformers.
    """

    def __init__(
        self,
        config_manager_instance: "ConfigManager",
        model_name: str = "all-MiniLM-L6-v2"
    ):
        self.config_mgr = config_manager_instance
        self.model_name = model_name
        self._local_model: Optional[SentenceTransformer] = None

    def get_local_model(self) -> SentenceTransformer:
        if not self._local_model:
            self._local_model = SentenceTransformer(self.model_name)
        return self._local_model

    def generate_embedding_local(
        self, text_to_embed: Union[str, List[str]]
    ) -> Optional[Union[List[float], List[List[float]]]]:
        try:
            model = self.get_local_model()
            emb = model.encode(text_to_embed, show_progress_bar=False)
            return emb.tolist() if hasattr(emb, "tolist") else emb
        except Exception:
            logger.error("Error generating local embedding.", exc_info=True)
            return None

    @ray.remote(num_cpus=1)
    class EmbeddingGeneratorActor:
        def __init__(self, model_name: str):
            self.model = SentenceTransformer(model_name)

        def generate_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
            return self.model.encode(texts, show_progress_bar=False).tolist()

    async def generate_embeddings_with_ray(
        self, texts: List[str], batch_size: int = 32
    ) -> Optional[List[List[float]]]:
        if not ray.is_initialized():
            ray.init(ignore_reinit_error=True)
        actors = [
            self.EmbeddingGeneratorActor.remote(self.model_name)
            for _ in range(max(1, int(ray.available_resources().get("CPU", 1) // 2)))
        ]
        parts = []
        for i in range(0, len(texts), batch_size):
            actor = actors[(i // batch_size) % len(actors)]
            parts.append(actor.generate_embeddings_batch.remote(texts[i : i + batch_size]))
        results = await asyncio.gather(*parts)
        return [item for sub in results for item in sub]
