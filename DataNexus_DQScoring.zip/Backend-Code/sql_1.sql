-- Databricks notebook source
-- Create a new catalog if it does not exist
CREATE CATALOG IF NOT EXISTS governance_catalog;

-- COMMAND ----------

SHOW CATALOGS;

-- COMMAND ----------

-- 1️⃣ Create a new Unity Catalog catalog named "my_catalog"
--    (The actual name can be anything that isn’t already in use.)
CREATE CATALOG IF NOT EXISTS my_catalog;


-- COMMAND ----------

-- 2️⃣ Create a schema (namespace) called "audit_db" inside "my_catalog"
CREATE SCHEMA IF NOT EXISTS my_catalog.audit_db;


-- COMMAND ----------

SHOW SCHEMAS FROM my_catalog;


-- COMMAND ----------

-- 3️⃣ Create an empty Delta table for audit events
CREATE TABLE IF NOT EXISTS my_catalog.audit_db.application_events_log (
  event_timestamp_utc TIMESTAMP NOT NULL,
  user_id             STRING,
  action              STRING,
  details_json        STRING
)
USING DELTA;


-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS my_catalog.dq_db;

CREATE TABLE IF NOT EXISTS my_catalog.dq_db.dq_rules (
  rule_id           STRING    NOT NULL,
  rule_name         STRING,
  rule_type         STRING,
  column_name       STRING,
  description       STRING,
  parameters_json   STRING,
  spark_sql_condition STRING,
  is_active         BOOLEAN,
  severity          STRING,
  dimension         STRING,
  weight            DOUBLE,
  created_at        TIMESTAMP,
  updated_at        TIMESTAMP,
  version           BIGINT
)
USING DELTA;


-- COMMAND ----------

CREATE TABLE IF NOT EXISTS my_catalog.dq_db.dq_all_failures (
  -- define columns to match your data or use a wide schema (e.g. map string->string)
  dq_rule_id     STRING,
  dq_rule_name   STRING
)
USING DELTA;


-- COMMAND ----------

SHOW SCHEMAS IN my_catalog;

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS my_catalog.dq_db.dq_rules (
  rule_id STRING,
  rule_name STRING,
  rule_type STRING,
  column_name STRING,
  description STRING,
  parameters_json STRING,
  spark_sql_condition STRING,
  is_active BOOLEAN,
  severity STRING,
  dimension STRING,
  weight DOUBLE,
  created_at TIMESTAMP,
  updated_at TIMESTAMP,
  version BIGINT
) 
USING DELTA;

-- 2) DQ Failures table  (schema can be extended to include original row fields plus dq_rule_id)
CREATE TABLE IF NOT EXISTS my_catalog.dq_db.dq_failures (
  dq_rule_id STRING,
  dq_rule_name STRING,
  failure_timestamp TIMESTAMP
) 
USING DELTA;

-- 3) Audit Log table
CREATE TABLE IF NOT EXISTS my_catalog.dq_db.audit_log (
  event_timestamp_utc TIMESTAMP,
  user_id STRING,
  action STRING,
  details_json STRING
) 
USING DELTA;

-- COMMAND ----------

