# Databricks notebook source
# MAGIC %pip install openpyxl langchain langchain-groq langchain-core requests python-dotenv pyspark pandas pydantic==1.10.2

# COMMAND ----------

# MAGIC %pip install --upgrade -U pydantic

# COMMAND ----------

# Phase 4 (Integrated): Data Ingestion, Profiling, Sampling, LangChain LLM Rules, Interactive Refinement & Weighted Scoring

import logging
import re
from datetime import datetime
import os
import json 
import uuid 

# PySpark imports
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import (
    col, when, lit, count, isnull, monotonically_increasing_id, expr, 
    regexp_extract, from_json, 
    min as spark_min, max as spark_max, avg as spark_avg, stddev as spark_stddev,
    approx_count_distinct, first 
)
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType, LongType, ArrayType, MapType, BooleanType, DataType, NumericType, DateType

# For Web API simulation & potential Pandas use for small samples
import requests
import pandas as pd

# LangChain and Groq imports
# Ensure these are installed: pip install langchain langchain-core langchain-groq python-dotenv
from langchain_groq import ChatGroq; import pydantic
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.pydantic_v1 import BaseModel, Field # For defining output structure
from typing import List, Dict, Any, Optional

# For API Key Management
from dotenv import load_dotenv

# --- Configuration ---
LOG_FORMAT = '%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)
logger = logging.getLogger(__name__)

# Load environment variables from .env file (optional, for local development)
load_dotenv()

# --- Spark Session Initialization ---
def get_spark_session(app_name="PySparkDQApp_Phase4_LangChain"):
    builder = SparkSession.builder.appName(app_name) \
        .config("spark.sql.legacy.timeParserPolicy", "LEGACY")
    
    # For Spark 3.5.0 / Scala 2.12 (e.g., Databricks Runtime 15.4 LTS)
    excel_package = "com.crealytics:spark-excel_2.12:3.5.0_0.20.3" 
    # This version of spark-excel (0.20.3) is specifically built for Spark 3.5.0.
    # In Databricks, it's often more reliable to install this library directly onto your cluster
    # via Cluster UI -> Libraries -> Install New -> Maven.
    # If installed on the cluster, this line might be redundant but should work if versions match.
    builder = builder.config("spark.jars.packages", excel_package)
    # You can add other connector JARs here, e.g., for MongoDB or Cassandra if making live connections:
    # mongo_package = "org.mongodb.spark:mongo-spark-connector_2.12:4.3.4" # Check for latest compatible with Spark 3.5
    # cassandra_package = "com.datastax.spark:spark-cassandra-connector_2.12:3.4.1" # Check for latest compatible
    # builder = builder.config("spark.jars.packages", f"{excel_package},{mongo_package},{cassandra_package}")
    
    spark = builder.getOrCreate()
    spark.sparkContext.setLogLevel("WARN") 
    logger.info(f"Spark session '{app_name}' created. Configured packages: {spark.conf.get('spark.jars.packages', 'None specified or cluster libraries used')}")
    return spark

# --- DATA INGESTION FUNCTIONS ---
# (Includes fixes for absolute paths and robustness from previous interactions)
def ingest_csv_spark(spark: SparkSession, file_path: str, header: bool = True, infer_schema: bool = True, custom_schema: StructType = None) -> DataFrame:
    logger.info(f"Attempting to ingest CSV from: {file_path}")
    is_cloud_path = any(file_path.startswith(prefix) for prefix in ["s3a://", "gs://", "abfss://", "dbfs:/"])
    load_path = file_path
    if not is_cloud_path:
        if not os.path.exists(file_path):
            logger.error(f"CSV file not found at local path: {file_path}")
            return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"File not found: {file_path}"))
        if not file_path.lower().startswith("file:/"): # Prepend file:// if it's a local path not already URI
             load_path = "file://" + os.path.abspath(file_path)
             logger.info(f"Using absolute path for local CSV: {load_path}")

    try:
        reader = spark.read.format("csv").option("header", str(header).lower()) # Ensure boolean as string for option
        if custom_schema:
            reader = reader.schema(custom_schema)
        else:
            reader = reader.option("inferSchema", str(infer_schema).lower())
        
        df = reader.load(load_path)
        logger.info(f"Successfully ingested CSV from '{file_path}'. Rows: {df.count()}")
        return df.withColumn("row_id_ingest", monotonically_increasing_id())
    except Exception as e:
        logger.error(f"Error ingesting CSV from '{file_path}' (load path '{load_path}'): {e}", exc_info=True)
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"CSV Ingestion Error: {str(e)}"))

def ingest_parquet_spark(spark: SparkSession, dir_path: str, custom_schema: StructType = None) -> DataFrame:
    logger.info(f"Attempting to ingest Parquet from directory: {dir_path}")
    is_cloud_path = any(dir_path.startswith(prefix) for prefix in ["s3a://", "gs://", "abfss://", "dbfs:/"])
    load_path = dir_path
    if not is_cloud_path:
        if not (os.path.exists(dir_path) and os.path.isdir(dir_path)):
            logger.error(f"Parquet directory not found or is not a directory: {dir_path}")
            return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"Directory not found: {dir_path}"))
        if not dir_path.lower().startswith("file:/"):
            load_path = "file://" + os.path.abspath(dir_path)
            logger.info(f"Using absolute path for local Parquet directory: {load_path}")
    try:
        reader = spark.read.format("parquet")
        if custom_schema: reader = reader.schema(custom_schema)
        df = reader.load(load_path)
        logger.info(f"Successfully ingested Parquet from '{dir_path}'. Rows: {df.count()}")
        return df.withColumn("row_id_ingest", monotonically_increasing_id())
    except Exception as e:
        logger.error(f"Error ingesting Parquet from '{dir_path}' (load path '{load_path}'): {e}", exc_info=True)
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"Parquet Ingestion Error: {str(e)}"))

def ingest_json_spark(spark: SparkSession, file_path: str, multi_line: bool = False, custom_schema: StructType = None) -> DataFrame:
    logger.info(f"Attempting to ingest JSON from: {file_path}")
    is_cloud_path = any(file_path.startswith(prefix) for prefix in ["s3a://", "gs://", "abfss://", "dbfs:/"])
    load_path = file_path
    if not is_cloud_path:
        if not os.path.exists(file_path): # JSON can be a directory of files for Spark too
            logger.error(f"JSON file/directory not found at path: {file_path}")
            return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"File/directory not found: {file_path}"))
        if not file_path.lower().startswith("file:/"):
            load_path = "file://" + os.path.abspath(file_path)
            logger.info(f"Using absolute path for local JSON: {load_path}")
    try:
        reader = spark.read.format("json").option("multiLine", str(multi_line).lower())
        if custom_schema: reader = reader.schema(custom_schema)
        else: logger.info("Inferring schema for JSON.")
        df = reader.load(load_path)
        logger.info(f"Successfully ingested JSON from '{file_path}'. Rows: {df.count()}")
        return df.withColumn("row_id_ingest", monotonically_increasing_id())
    except Exception as e:
        logger.error(f"Error ingesting JSON from '{file_path}' (load path '{load_path}'): {e}", exc_info=True)
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"JSON Ingestion Error: {str(e)}"))

def ingest_excel_spark(spark: SparkSession, file_path: str, sheet_name: str = None, header: bool = True, infer_schema: bool = True, custom_schema: StructType = None) -> DataFrame:
    logger.info(f"Attempting to ingest Excel from: {file_path}")
    is_dbfs_path = file_path.lower().startswith("dbfs:/")
    load_path = file_path
    if not is_dbfs_path and not file_path.lower().startswith("file:/"):
        if os.path.exists(file_path):
            load_path = "file://" + os.path.abspath(file_path)
            logger.info(f"Using absolute path for local Excel: {load_path}")
        else:
             logger.error(f"Excel file not found at local path: {file_path} (and not a dbfs path)")
             return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"File not found: {file_path}"))
    try:
        reader = spark.read.format("com.crealytics.spark.excel") \
            .option("header", str(header).lower()) \
            .option("inferSchema", str(infer_schema).lower()) \
            .option("treatEmptyValuesAsNulls", "true") 
        if sheet_name: reader = reader.option("dataAddress", f"'{sheet_name}'!A1") 
        df_loaded = reader.load(load_path)
        if custom_schema:
            logger.info("Applying custom schema to Excel data.")
            select_exprs = []
            df_cols_lower_map_excel = {c.lower(): c for c in df_loaded.columns}
            for field in custom_schema.fields:
                actual_col_name = df_cols_lower_map_excel.get(field.name.lower())
                if actual_col_name:
                    select_exprs.append(col(actual_col_name).cast(field.dataType).alias(field.name))
                else:
                    logger.warning(f"Column '{field.name}' from custom schema not found in Excel. Added as null.")
                    select_exprs.append(lit(None).cast(field.dataType).alias(field.name))
            df = df_loaded.select(*select_exprs) if select_exprs else spark.createDataFrame([], custom_schema)
        else:
            df = df_loaded
        logger.info(f"Successfully ingested Excel from '{file_path}'. Rows: {df.count()}.")
        return df.withColumn("row_id_ingest", monotonically_increasing_id())
    except Exception as e: 
        if "SparkClassNotFoundException" in str(e) and "com.crealytics.spark.excel" in str(e):
            msg = ("Error ingesting Excel: spark-excel data source not found. "
                   "1. Ensure the spark-excel JAR (e.g., com.crealytics:spark-excel_2.12:3.5.0_0.20.3 for Spark 3.5.0) "
                   "is installed on your Databricks cluster OR "
                   "2. Correctly configured via `spark.jars.packages` in `get_spark_session`. "
                  f"Current error details: {e}")
            logger.error(msg, exc_info=False)
            return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(msg))
        else:
            logger.error(f"Error ingesting Excel from '{file_path}' (load_path '{load_path}'): {e}", exc_info=True)
            return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"Excel Ingestion Error: {str(e)}"))

def ingest_delta_lake_table(spark: SparkSession, table_path_or_name: str) -> DataFrame:
    logger.info(f"Attempting to ingest from Delta Lake table/path: {table_path_or_name}")
    load_path = table_path_or_name
    if "/" in table_path_or_name and not any(table_path_or_name.lower().startswith(p) for p in ["s3a:", "gs:", "abfss:", "dbfs:", "file:"]):
        if os.path.exists(table_path_or_name): 
            load_path = "file://" + os.path.abspath(table_path_or_name)
            logger.info(f"Using absolute path for local Delta Lake: {load_path}")
    try:
        if load_path.lower().startswith("file:") or any(load_path.lower().startswith(p) for p in ["s3a:", "gs:", "abfss:", "dbfs:"]) or os.path.isdir(table_path_or_name): # Check isdir for local path based tables
            df = spark.read.format("delta").load(load_path)
        else: 
            df = spark.read.table(load_path) 
        logger.info(f"Successfully ingested from Delta Lake '{table_path_or_name}'. Rows: {df.count()}")
        return df.withColumn("row_id_ingest", monotonically_increasing_id())
    except Exception as e:
        logger.error(f"Error ingesting from Delta Lake '{table_path_or_name}' (load path '{load_path}'): {e}", exc_info=True)
        return spark.createDataFrame([], StructType([StructField("error", StringType(), True), StructField("message", StringType(), True)])).withColumn("message", lit(f"Delta Lake Ingestion Error: {str(e)}"))

# ... (Conceptual ingest_jdbc_database, ingest_cassandra_table, ingest_mongodb_collection, ingest_kafka_topic_batch, ingest_web_api_spark functions from previous turn) ...
# These will remain conceptual as they require live external systems & specific JARS not configured here.
def ingest_jdbc_database(spark: SparkSession, jdbc_url: str, table_name: str, driver: str, user: str, password_value: str) -> DataFrame:
    logger.warning(f"JDBC Ingestion for {table_name} is conceptual. Requires live DB, driver JAR, and correct credentials.")
    return spark.createDataFrame([], StructType([StructField("conceptual_message", StringType(), True)])).withColumn("conceptual_message", lit(f"Conceptual JDBC read for {table_name}"))
def ingest_cassandra_table(spark: SparkSession, keyspace: str, table: str, host: str, port: str = "9042") -> DataFrame:
    logger.warning(f"Cassandra Ingestion for {keyspace}.{table} is conceptual. Requires live DB, Cassandra connector JAR.")
    return spark.createDataFrame([], StructType([StructField("conceptual_message", StringType(), True)])).withColumn("conceptual_message", lit(f"Conceptual Cassandra read for {keyspace}.{table}"))
def ingest_mongodb_collection(spark: SparkSession, connection_uri: str, database: str, collection: str) -> DataFrame:
    logger.warning(f"MongoDB Ingestion for {database}.{collection} is conceptual. Requires live DB, MongoDB connector JAR.")
    return spark.createDataFrame([], StructType([StructField("conceptual_message", StringType(), True)])).withColumn("conceptual_message", lit(f"Conceptual MongoDB read for {database}.{collection}"))
def ingest_kafka_topic_batch(spark: SparkSession, kafka_bootstrap_servers: str, topic: str, starting_offsets: str = "earliest") -> DataFrame:
    logger.warning(f"Kafka batch read for topic {topic} is conceptual. Requires live Kafka and spark-sql-kafka connector.")
    # Return a schema that might be parsable by the downstream Kafka logic if it proceeds
    kafka_schema = StructType([
        StructField("key", StringType(), True), StructField("value", StringType(), True), # Assume value will be string for parsing
        StructField("topic", StringType(), True), StructField("partition", IntegerType(), True),
        StructField("offset", LongType(), True), StructField("timestamp", TimestampType(), True),
        StructField("timestampType", IntegerType(), True),
        StructField("row_id_ingest", LongType(), True) 
    ])
    return spark.createDataFrame([], kafka_schema).withColumn("conceptual_message", lit(f"Conceptual Kafka batch read for {topic}"))
def ingest_web_api_spark(spark: SparkSession, api_url: str, params: dict = None, headers: dict = None) -> DataFrame:
    logger.info(f"Attempting to ingest from Web API: {api_url}")
    try:
        response = requests.get(api_url, params=params, headers=headers, timeout=10); response.raise_for_status(); api_data = response.json()
        if not api_data: return spark.createDataFrame([], StructType([StructField("nodata_marker", StringType(), True)]))
        if isinstance(api_data, dict): api_data = [api_data]
        if not isinstance(api_data, list) or not api_data: return spark.createDataFrame([], StructType([StructField("error", StringType(), True)])).withColumn("error", lit("API data not list or empty"))
        df = spark.createDataFrame(pd.DataFrame(api_data)) # Pandas helps with varied JSON structures
        logger.info(f"Successfully ingested from Web API '{api_url}'. Rows: {df.count()}")
        return df.withColumn("row_id_ingest", monotonically_increasing_id())
    except Exception as e: logger.error(f"Web API error '{api_url}': {e}"); return spark.createDataFrame([], StructType([StructField("error", StringType(), True)])).withColumn("error", lit(f"API Error: {e}"))


# --- DATA PROFILING AND SAMPLING (Implementations from previous turns) ---
def perform_multi_stage_sampling(df: DataFrame, stage1_fraction: float = 0.001, stage2_max_rows_for_pandas: int = 1000, stage3_llm_sample_size: int = 50):
    logger.info("Starting multi-stage sampling.")
    try: original_count = df.count()
    except Exception : return pd.DataFrame(), None 
    if original_count == 0: return pd.DataFrame(), df 
    stage1_fraction = max(0.0000001, min(stage1_fraction, 1.0)) 
    stage1_sampled_df = df.sample(withReplacement=False, fraction=stage1_fraction, seed=42) 
    try: stage1_count = stage1_sampled_df.count()
    except Exception: return pd.DataFrame(), None
    if stage1_count == 0: 
        if original_count <= stage2_max_rows_for_pandas * 2: stage1_sampled_df = df; stage1_count = original_count
        else: return pd.DataFrame(), stage1_sampled_df 
    df_for_pandas = stage1_sampled_df
    if stage1_count > stage2_max_rows_for_pandas:
        stage2_fraction = stage2_max_rows_for_pandas / stage1_count if stage1_count > 0 else 0.0
        if stage2_fraction > 0 : df_for_pandas = stage1_sampled_df.sample(withReplacement=False, fraction=stage2_fraction, seed=42)
        else: df_for_pandas = stage1_sampled_df.limit(stage2_max_rows_for_pandas) 
    pandas_df_stage2 = df_for_pandas.limit(stage2_max_rows_for_pandas).toPandas()
    if pandas_df_stage2.empty: return pd.DataFrame(), stage1_sampled_df
    if len(pandas_df_stage2) <= stage3_llm_sample_size: final_llm_sample_pd = pandas_df_stage2
    else: final_llm_sample_pd = pandas_df_stage2.sample(n=stage3_llm_sample_size, random_state=42, replace=False) 
    return final_llm_sample_pd, stage1_sampled_df

def simulate_data_profiling(df_for_profiling: DataFrame, spark: SparkSession, sample_rows_for_llm: pd.DataFrame = None):
    logger.info("Simulating Data Profiling...")
    default_profile = {"schema": {}, "column_stats": {}, "data_sample_for_llm": [], "data_source_type_inferred": "unknown"}
    if df_for_profiling is None: return default_profile
    try:
        if df_for_profiling.rdd.isEmpty(): return default_profile # More robust check for empty
    except Exception: return default_profile
    profile = {"schema": {}, "column_stats": {}, "data_sample_for_llm": [], "data_source_type_inferred": "unknown"}
    profile["schema"] = {field.name: str(field.dataType) for field in df_for_profiling.schema.fields}
    cols_lower = {c.lower() for c in profile["schema"].keys()}
    if {'order_id', 'product_id', 'customer_id'}.issubset(cols_lower): profile["data_source_type_inferred"] = "ecommerce_transactional"
    elif {'event_id', 'timestamp', 'user_id'}.issubset(cols_lower): profile["data_source_type_inferred"] = "event_log_data"
    for field in df_for_profiling.schema.fields:
        col_name = field.name; col_type = field.dataType; stats = {}
        try:
            stats["null_count"] = df_for_profiling.filter(col(col_name).isNull()).count()
            stats["non_null_count"] = df_for_profiling.filter(col(col_name).isNotNull()).count()
            if stats["non_null_count"] > 0 : stats["distinct_approx_count"] = df_for_profiling.select(approx_count_distinct(col(col_name))).first()[0]
            else: stats["distinct_approx_count"] = 0
            if isinstance(col_type, (NumericType, DateType, TimestampType)) and stats["non_null_count"] > 0 :
                agg_exprs = [spark_min(col(col_name)).alias("min"), spark_max(col(col_name)).alias("max")]
                if isinstance(col_type, NumericType): agg_exprs.extend([spark_avg(col(col_name)).alias("mean"), spark_stddev(col(col_name)).alias("stddev")])
                col_summary = df_for_profiling.filter(col(col_name).isNotNull()).agg(*agg_exprs).first()
                if col_summary:
                    stats["min"] = str(col_summary["min"]) if col_summary["min"] is not None else None
                    stats["max"] = str(col_summary["max"]) if col_summary["max"] is not None else None
                    if isinstance(col_type, NumericType): stats["mean"] = col_summary["mean"]; stats["stddev"] = col_summary["stddev"]
        except Exception: pass # ignore stat errors for individual columns
        profile["column_stats"][col_name] = stats
    if sample_rows_for_llm is not None and not sample_rows_for_llm.empty:
        profile["data_sample_for_llm"] = sample_rows_for_llm.astype(str).to_dict(orient='records')
    return profile

# --- LANGCHAIN LLM RULE SUGGESTION ---
class RuleParams(BaseModel):
    min_value: Optional[float] = None; max_value: Optional[float] = None
    format: Optional[str] = None; pattern: Optional[str] = None
    condition_col: Optional[str] = None; condition_val: Optional[Any] = None
    dependent_col: Optional[str] = None
class DQRuleSuggestion(BaseModel):
    rule_id: str = Field(default_factory=lambda: f"llm_rule_{str(uuid.uuid4())[:8]}")
    dimension: str; column_name: Optional[str] = None; rule_type: str
    params: Optional[RuleParams] = Field(default_factory=RuleParams)
    description: str
class DQRuleSuggestionsList(BaseModel):
    suggestions: List[DQRuleSuggestion]

def get_llm_rule_suggestions_langchain_groq(data_profile: dict, for_new_dimension_name: str = None, groq_api_key: str = None):
    logger.info(f"Requesting LLM rule suggestions via LangChain/Groq. Dimension focus: {for_new_dimension_name or 'Standard'}")
    if not groq_api_key: logger.error("GROQ_API_KEY not found."); return []
    try:
        llm = ChatGroq(temperature=0.1, groq_api_key=groq_api_key, model_name="llama3-8b-8192") # Or mixtral-8x7b-32768
    except Exception as e: logger.error(f"Failed to initialize ChatGroq: {e}"); return []

    schema_info = json.dumps(data_profile.get("schema", {}), indent=2)
    column_stats_info = json.dumps(data_profile.get("column_stats", {}), indent=2, default=str)
    sample_data_info = json.dumps(data_profile.get("data_sample_for_llm", [])[:3], indent=2) # Only first 3 samples
    inferred_source_type = data_profile.get("data_source_type_inferred", "unknown")
    dim_focus = f"Focus on suggesting rules for dimension: '{for_new_dimension_name.capitalize()}'." if for_new_dimension_name else "Suggest rules for standard dimensions: Accuracy, Completeness, Consistency, Uniqueness."

    system_prompt = (
        "You are a Data Quality expert. Based on the provided data profile (schema, column stats, sample data), "
        f"suggest relevant DQ rules. Inferred data source type: {inferred_source_type}. {dim_focus} "
        "Output a JSON list of rule objects. Each object must have: 'rule_id' (unique string), 'dimension' (string), "
        "'column_name' (string, or null if not applicable), 'rule_type' (string from allowed types: "
        "'not_null', 'range_check', 'date_format', 'regex_match', 'is_unique', 'conditional_not_null'), "
        "'params' (a dictionary, e.g., {{'min_value': 0.01}} or {{}} if no params), and 'description' (string). "
        "Ensure params match the rule_type, e.g. range_check needs min_value, max_value. "
        "date_format needs 'format'. regex_match needs 'pattern'. conditional_not_null needs 'condition_col', 'condition_val', 'dependent_col'. "
        "Make rule_ids unique and descriptive like 'llm_accuracy_price_range_check_abc1'. Be concise with descriptions."
    )
    human_prompt = (
        "Data Profile:\nSchema: {schema_info}\nColumn Stats: {column_stats_info}\nSample Data: {sample_data_info}\n"
        "Please provide DQ rule suggestions in the specified JSON list format."
    )
    prompt = ChatPromptTemplate.from_messages([("system", system_prompt), ("human", human_prompt)])
    parser = JsonOutputParser(pydantic_object=DQRuleSuggestionsList)
    chain = prompt | llm | parser
    try:
        logger.info("Sending request to LLM...")
        response_model = chain.invoke({"schema_info": schema_info, "column_stats_info": column_stats_info, "sample_data_info": sample_data_info})
        suggestions_list = [s.dict() for s in response_model.suggestions]
        logger.info(f"LLM generated {len(suggestions_list)} rule suggestions.")
        return suggestions_list
    except Exception as e: logger.error(f"LLM rule suggestion error: {e}", exc_info=True); return []

# --- INTERACTIVE RULE REFINEMENT ---
def refine_rules_weights_dimensions_interactively(data_profile: dict, groq_api_key: str, initial_dimensions:list = None):
    if initial_dimensions is None: active_dimensions = ["Accuracy", "Completeness", "Consistency", "Uniqueness"]
    else: active_dimensions = list(initial_dimensions) 
    all_rules = [] 
    logger.info("\n--- Initial LLM Rule Suggestions for Standard Dimensions (via LangChain/Groq) ---")
    if groq_api_key: standard_suggestions = get_llm_rule_suggestions_langchain_groq(data_profile, groq_api_key=groq_api_key)
    else: logger.warning("No Groq API key, skipping LLM suggestions."); standard_suggestions = []
    if standard_suggestions: all_rules.extend(standard_suggestions)
    else: logger.warning("No initial rule suggestions. Please add manually or check LLM call.")

    current_weights = {dim.lower(): 1.0/len(active_dimensions) if active_dimensions else 0.25 for dim in active_dimensions}
    current_weights = get_dimension_weights_interactively_v2(active_dimensions, current_weights)

    while True:
        print("\n--- Current DQ Setup ---")
        print("Active Dimensions and Weights:")
        for dim_idx, dim_name_display in enumerate(active_dimensions):
            print(f"  {dim_idx+1}. {dim_name_display} (Weight: {current_weights.get(dim_name_display.lower(), 0.0)*100:.1f}%)")
        
        print("\nCurrent Rules:")
        if not all_rules: print("  No rules defined yet.")
        for i, rule in enumerate(all_rules):
            print(f"  {i+1}. ID: {rule.get('rule_id', 'N/A')}, Dim: {rule.get('dimension', 'N/A')}, Col: {rule.get('column_name', 'N/A')}, Type: {rule.get('rule_type', 'N/A')}, Params: {rule.get('params', {})}, Desc: {rule.get('description', '')[:60]}...")

        action = input("\nChoose action: [a]dd rule, [r]emove rule, [m]odify rule, [p]add dimension, [w]edit weights, [d]one: ").lower()
        if action == 'd': break
        elif action == 'a': 
            print("\n--- Add New Manual Rule ---")
            new_rule_dim = input(f"Enter dimension for new rule (from {active_dimensions} or a new one): ").capitalize()
            if new_rule_dim and new_rule_dim not in active_dimensions: active_dimensions.append(new_rule_dim)
            new_rule_col = input("Enter column name for the rule (or leave blank if not column-specific): ") or None
            new_rule_type = input("Enter rule type (e.g., not_null, range_check, is_unique): ")
            new_rule_params_str = input("Enter parameters as JSON string (e.g., {\"min_value\": 0} or {} if none): ")
            new_rule_desc = input("Enter a brief description for this manual rule: ")
            try:
                new_rule_params = json.loads(new_rule_params_str) if new_rule_params_str else {}
                new_rule_id = f"manual_{new_rule_dim[:3].lower()}_{new_rule_col if new_rule_col else 'global'}_{new_rule_type[:5]}_{str(uuid.uuid4())[:4]}"
                all_rules.append({"rule_id": new_rule_id, "dimension": new_rule_dim, "column_name": new_rule_col, "rule_type": new_rule_type, "params": new_rule_params, "description": new_rule_desc})
                logger.info(f"Manual rule '{new_rule_id}' added for dimension '{new_rule_dim}'.")
                if new_rule_dim.lower() not in current_weights: 
                    logger.info(f"New dimension '{new_rule_dim}' added. Please re-evaluate weights.")
                    current_weights = get_dimension_weights_interactively_v2(active_dimensions, current_weights)
            except json.JSONDecodeError: logger.warning("Invalid JSON for parameters. Rule not added.")
        
        elif action == 'r': 
            if not all_rules: print("No rules to remove."); continue
            try:
                rule_num_to_remove = int(input("Enter rule number to remove (from list above): "))
                if 1 <= rule_num_to_remove <= len(all_rules):
                    removed_rule = all_rules.pop(rule_num_to_remove - 1)
                    logger.info(f"Rule '{removed_rule['rule_id']}' removed.")
                else: logger.warning("Invalid rule number.")
            except ValueError: logger.warning("Invalid input for rule number.")

        elif action == 'm': 
            if not all_rules: print("No rules to modify."); continue
            try:
                rule_num_to_modify = int(input("Enter rule number to modify: "))
                if 1 <= rule_num_to_modify <= len(all_rules):
                    rule_to_mod = all_rules[rule_num_to_modify - 1]
                    logger.info(f"Modifying rule: {rule_to_mod}")
                    new_params_str = input(f"Enter new JSON parameters for rule type '{rule_to_mod['rule_type']}' (current: {rule_to_mod.get('params', {})}): ")
                    try:
                        new_params = json.loads(new_params_str)
                        rule_to_mod['params'] = new_params
                        logger.info(f"Rule '{rule_to_mod['rule_id']}' parameters updated.")
                    except json.JSONDecodeError: logger.warning("Invalid JSON for parameters. Modification failed.")
                else: logger.warning("Invalid rule number.")
            except ValueError: logger.warning("Invalid input for rule number.")

        elif action == 'p': 
            new_dim_name = input("Enter name for the new DQ dimension: ").capitalize()
            if new_dim_name and new_dim_name not in active_dimensions:
                active_dimensions.append(new_dim_name)
                logger.info(f"New dimension '{new_dim_name}' added. Requesting LLM suggestions for it...")
                if groq_api_key: new_dim_suggestions = get_llm_rule_suggestions_langchain_groq(data_profile, for_new_dimension_name=new_dim_name, groq_api_key=groq_api_key)
                else: logger.warning("No Groq API key, skipping LLM suggestions for new dimension."); new_dim_suggestions = []
                if new_dim_suggestions:
                    print(f"--- LLM Suggestions for new dimension '{new_dim_name}' ---")
                    for sug_idx, sug_rule in enumerate(new_dim_suggestions): print(f"  {sug_idx+1}. Col: {sug_rule.get('column_name')}, Type: {sug_rule['rule_type']}, Params: {sug_rule.get('params')}, Desc: {sug_rule['description']}")
                    if input("Accept these suggestions for the new dimension? (yes/no, default: yes): ").lower() != 'no':
                        all_rules.extend(new_dim_suggestions)
                        logger.info(f"Added {len(new_dim_suggestions)} rules for dimension '{new_dim_name}'.")
                else: logger.info(f"LLM had no specific suggestions for dimension '{new_dim_name}'. You can add rules manually.")
                current_weights = get_dimension_weights_interactively_v2(active_dimensions, current_weights) 
            elif new_dim_name in active_dimensions: logger.info(f"Dimension '{new_dim_name}' already exists.")
            else: logger.warning("Invalid dimension name.")
        
        elif action == 'w': current_weights = get_dimension_weights_interactively_v2(active_dimensions, current_weights)
        else: logger.warning("Invalid action selected.")

    final_dq_config = {dim.lower(): [] for dim in active_dimensions}; final_dq_config["accuracy"] = {}
    for rule in all_rules:
        dim_lower = rule['dimension'].lower(); col_name = rule.get("column_name")
        if dim_lower not in final_dq_config: final_dq_config[dim_lower] = [] if rule['dimension'] != "Accuracy" else {}
        if rule['dimension'] == "Accuracy" and col_name: final_dq_config["accuracy"].setdefault(col_name, {}).update({rule['rule_type']: rule.get('params', {})})
        elif rule['dimension'] == "Completeness" and col_name: 
            if col_name not in final_dq_config.get("completeness", []): final_dq_config.setdefault("completeness", []).append(col_name)
        elif rule['dimension'] == "Uniqueness" and col_name: 
            if col_name not in final_dq_config.get("uniqueness", []): final_dq_config.setdefault("uniqueness", []).append(col_name)
        elif rule['dimension'] == "Consistency": final_dq_config.setdefault("consistency", []).append(rule.get('params', {})) 
        else: final_dq_config.setdefault(dim_lower, []).append(rule) 
    return final_dq_config, current_weights, active_dimensions

def get_dimension_weights_interactively_v2(active_dimensions: list, current_weights: dict = None):
    logger.info("\n--- DQ Dimension Weighting ---")
    if current_weights is None: current_weights = {}
    new_weights = {} 
    num_dims = len(active_dimensions)
    default_weight_each = 1.0 / num_dims if num_dims > 0 else 0.0
    for dim_name_iter_init in active_dimensions:
        dim_key_init = dim_name_iter_init.lower()
        new_weights[dim_key_init] = current_weights.get(dim_key_init, default_weight_each)
    while True:
        print("Current weights (should sum to 100%):")
        current_total_percentage = sum(new_weights.get(d.lower(),0) for d in active_dimensions) * 100
        for dim_name_display_iter in active_dimensions: print(f"  - {dim_name_display_iter}: {new_weights.get(dim_name_display_iter.lower(), default_weight_each) * 100:.1f}%")
        print(f"  Current Total Weight: {current_total_percentage:.1f}%")
        if abs(current_total_percentage - 100.0) < 0.1: print("Weights sum to approx 100%.")
        else: print(f"WARNING: Weights sum to {current_total_percentage:.1f}%, not 100%. Please adjust.")
        for dim_name_input_iter in active_dimensions:
            dim_key_input_iter = dim_name_input_iter.lower()
            while True:
                try:
                    prompt_default_percent = new_weights.get(dim_key_input_iter, default_weight_each) * 100
                    weight_input_str = input(f"Enter weight for {dim_name_input_iter} (current: {prompt_default_percent:.1f}%, 0-100, or blank to keep): ")
                    if not weight_input_str: break 
                    weight_percent_val = float(weight_input_str)
                    if 0.0 <= weight_percent_val <= 100.0: new_weights[dim_key_input_iter] = weight_percent_val / 100.0; break
                    else: print("Weight must be between 0 and 100.")
                except ValueError: print("Invalid input.")
        total_new_weight_val = sum(new_weights.get(d.lower(),0) for d in active_dimensions) 
        if abs(total_new_weight_val - 1.0) < 0.001: logger.info(f"Final Dimension Weights: {new_weights}"); return new_weights
        else: print(f"Weights sum to {total_new_weight_val*100:.1f}%, NOT 100%. Please re-enter all weights.")


# --- DQ CHECK FUNCTIONS (Full Implementations) ---
def check_accuracy_spark(df: DataFrame, column_rules: dict, spark: SparkSession):
    logger.info(f"ACCURACY CHECK: Rules for columns: {list(column_rules.keys()) if column_rules else 'None'}")
    if not column_rules or df.rdd.isEmpty(): 
        return {'passed': df.count() if df and not df.rdd.isEmpty() else 0, 'failed': 0, 'total_checks': df.count() if df and not df.rdd.isEmpty() else 0, 'issues_sample': []}
    
    original_count = df.count()
    issues_sample_list = []
    df_validated = df 
    temp_validation_cols = []
    applied_rules_count = 0 

    df_cols_lower_map = {df_c.lower(): df_c for df_c in df_validated.columns}

    for col_name_rule, rules_for_col in column_rules.items(): # rules_for_col is {'rule_type': params}
        actual_col_name_in_df = df_cols_lower_map.get(col_name_rule.lower())
        
        if not actual_col_name_in_df:
            logger.warning(f"Accuracy check: Rule target column '{col_name_rule}' not found in DataFrame. Skipping rules for this column.")
            continue
        
        base_col_obj = col(actual_col_name_in_df)

        for rule_type, params in rules_for_col.items():
            applied_rules_count +=1
            rule_col_name_ok = f"acc_{actual_col_name_in_df}_{rule_type}_ok"
            temp_validation_cols.append(rule_col_name_ok)

            if rule_type == "range_check":
                min_val = params.get("min_value")
                max_val = params.get("max_value")
                condition = lit(True) # Default to true if params missing
                if min_val is not None:
                    condition = condition & (base_col_obj.isNotNull() & (base_col_obj.cast(DoubleType()) >= float(min_val)))
                if max_val is not None:
                    condition = condition & (base_col_obj.isNotNull() & (base_col_obj.cast(DoubleType()) <= float(max_val)))
                # If only one bound is given, nulls for the value itself should not automatically pass unless explicitly allowed.
                # Current logic: if a bound is present, value must be notNull AND meet bound.
                # If value is null, it won't meet >= or <=.
                df_validated = df_validated.withColumn(rule_col_name_ok, when(base_col_obj.isNull(), True).otherwise(condition)) # Nulls pass range check by default, fail completeness

            elif rule_type == "date_format":
                fmt = params.get("format")
                if fmt:
                    cast_col_name = f"acc_{actual_col_name_in_df}_casted_date" 
                    temp_validation_cols.append(cast_col_name)
                    df_validated = df_validated.withColumn(cast_col_name, expr(f"to_timestamp(CAST(COALESCE(`{actual_col_name_in_df}`, '') AS STRING), '{fmt}')"))
                    # Passes if original is null/empty OR if it parses correctly
                    condition = base_col_obj.isNull() | \
                                (expr(f"CAST(COALESCE(`{actual_col_name_in_df}`, '') AS STRING) == ''")) | \
                                col(cast_col_name).isNotNull()
                    df_validated = df_validated.withColumn(rule_col_name_ok, condition)
                else: df_validated = df_validated.withColumn(rule_col_name_ok, lit(True)) # No format, pass

            elif rule_type == "regex_match":
                pattern = params.get("pattern")
                if pattern:
                    condition = base_col_obj.isNull() | (expr(f"CAST(COALESCE(`{actual_col_name_in_df}`, '') AS STRING)") == "") | base_col_obj.rlike(pattern)
                    df_validated = df_validated.withColumn(rule_col_name_ok, condition)
                else: df_validated = df_validated.withColumn(rule_col_name_ok, lit(True)) # No pattern, pass
            else:
                logger.warning(f"Unsupported accuracy rule_type '{rule_type}' for column '{actual_col_name_in_df}'. Assuming pass.")
                df_validated = df_validated.withColumn(rule_col_name_ok, lit(True))
                applied_rules_count -=1 # Don't count unsupported rule
            
    if applied_rules_count == 0 : 
        logger.info("No accuracy rules were effectively applied.")
        return {'passed': original_count, 'failed': 0, 'total_checks': original_count, 'issues_sample': []}

    overall_accuracy_condition = lit(True)
    actual_validation_rule_cols = [c for c in temp_validation_cols if c.endswith("_ok")] 
    if not actual_validation_rule_cols: 
        return {'passed': original_count, 'failed': 0, 'total_checks': original_count, 'issues_sample': []}

    for rule_c in actual_validation_rule_cols:
        overall_accuracy_condition = overall_accuracy_condition & col(rule_c)
    
    df_validated = df_validated.withColumn("is_accurate_row_overall", overall_accuracy_condition)
    failed_df = df_validated.filter(col("is_accurate_row_overall") == False)
    failed_count_rows = failed_df.count()
    passed_count_rows = original_count - failed_count_rows

    if failed_count_rows > 0:
        row_id_col_name = "row_id_ingest" if "row_id_ingest" in failed_df.columns else None
        cols_to_select_for_issues = [row_id_col_name] if row_id_col_name else []
        
        involved_original_cols_from_rules = list(column_rules.keys())
        actual_involved_cols_in_df = [df_cols_lower_map.get(rule_c.lower()) for rule_c in involved_original_cols_from_rules if df_cols_lower_map.get(rule_c.lower())]
        
        cols_to_select_for_issues.extend(actual_involved_cols_in_df)
        cols_to_select_for_issues.extend(actual_validation_rule_cols) 
        cols_to_select_for_issues = list(dict.fromkeys(c for c in cols_to_select_for_issues if c is not None and c in df_validated.columns))

        if cols_to_select_for_issues: 
            sample_failed_collected = failed_df.select(*cols_to_select_for_issues).limit(10).collect()
            for row_spark in sample_failed_collected:
                row_dict = row_spark.asDict()
                current_row_id = row_dict.get(row_id_col_name, 'N/A')
                for rule_col_key, rules_for_col_detail in column_rules.items(): 
                    actual_col_name_for_issue = df_cols_lower_map.get(rule_col_key.lower())
                    if not actual_col_name_for_issue: continue 
                    for rule_type_detail, params_detail in rules_for_col_detail.items():
                        status_col_name = f"acc_{actual_col_name_for_issue}_{rule_type_detail}_ok"
                        if status_col_name in row_dict and not row_dict[status_col_name]:
                            rule_desc = f"{rule_type_detail.replace('_',' ')} failed. Params: {params_detail}"
                            issues_sample_list.append({'row_id': current_row_id, 'column': actual_col_name_for_issue, 'value': str(row_dict.get(actual_col_name_for_issue)), 'rule_violated': 'Accuracy', 'detail': rule_desc})
                            if len(issues_sample_list) >= 10: break
                if len(issues_sample_list) >= 10: break
        else: logger.warning("Could not collect accuracy issue samples as no relevant columns were found to select from failed_df.")
            
    logger.info(f"Accuracy checks (Spark) completed. Passed (rows): {passed_count_rows}, Failed (rows): {failed_count_rows}")
    return {'passed': passed_count_rows, 'failed': failed_count_rows, 'total_checks': original_count, 'issues_sample': issues_sample_list[:10]}

# Completeness
def check_completeness_spark(df: DataFrame, required_columns_from_rules: list, spark: SparkSession):
    logger.info(f"COMPLETENESS CHECK: Required columns from rules: {required_columns_from_rules}")
    if df.rdd.isEmpty(): return {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues_sample': []}
    original_count = df.count()
    if not required_columns_from_rules : # No completeness rules
        return {'passed': original_count * 0, 'failed': 0, 'total_checks': original_count * 0, 'issues_sample': []} # Or total_checks = original_count if interpreting "checked against no rules"

    total_individual_checks = 0 
    passed_individual_checks = 0
    issues_sample_list = []
    row_id_col_name = "row_id_ingest" if "row_id_ingest" in df.columns else None
    df_cols_lower_map = {df_c.lower(): df_c for df_c in df.columns}

    for req_col_name_rule in required_columns_from_rules: 
        total_individual_checks += original_count
        actual_col_name_in_df = df_cols_lower_map.get(req_col_name_rule.lower())

        if not actual_col_name_in_df:
            logger.warning(f"Completeness check: Column '{req_col_name_rule}' (from rules) not found in DataFrame columns: {df.columns}.")
            # All rows fail for this missing column, passed_individual_checks is not incremented
            if row_id_col_name: sample_row_ids = [r[row_id_col_name] for r in df.select(row_id_col_name).limit(3).collect()]
            else: sample_row_ids = [f"index_{i}" for i in range(min(3, original_count))]
            for r_id in sample_row_ids:
                 issues_sample_list.append({'row_id': r_id, 'column': req_col_name_rule, 'value': 'COLUMN_MISSING', 'rule_violated': 'Completeness', 'detail': f"Required column '{req_col_name_rule}' is missing."})
            continue 
            
        condition = col(actual_col_name_in_df).isNotNull() & (expr(f"trim(CAST(COALESCE(`{actual_col_name_in_df}`, '') AS STRING))") != "")
        current_passed = df.filter(condition).count()
        passed_individual_checks += current_passed
        
        if current_passed < original_count: 
            current_failed_df = df.filter(~condition)
            select_cols_for_issue = ([row_id_col_name] if row_id_col_name else []) + [actual_col_name_in_df]
            sample_failed_rows = current_failed_df.select(*[c for c in select_cols_for_issue if c in current_failed_df.columns]).limit(3).collect()
            for row in sample_failed_rows:
                issues_sample_list.append({'row_id': row[row_id_col_name] if row_id_col_name and row_id_col_name in row else 'N/A', 'column': actual_col_name_in_df, 'value': str(row[actual_col_name_in_df] if actual_col_name_in_df in row else 'N/A'), 'rule_violated': 'Completeness', 'detail': f"Value is null or empty in '{actual_col_name_in_df}'."})
                if len(issues_sample_list) >= 10: break
        if len(issues_sample_list) >= 10: break
        
    failed_individual_checks = total_individual_checks - passed_individual_checks
    logger.info(f"Completeness: Passed Indiv Checks: {passed_individual_checks}, Failed Indiv Checks: {failed_individual_checks}, Total Indiv Checks: {total_individual_checks}")
    return {'passed': passed_individual_checks, 'failed': failed_individual_checks, 'total_checks': total_individual_checks, 'issues_sample': issues_sample_list[:10]}

# Consistency
def check_consistency_spark(df: DataFrame, consistency_rules_params_list: list, spark: SparkSession):
    logger.info(f"CONSISTENCY CHECK: {len(consistency_rules_params_list)} rule sets.")
    if df.rdd.isEmpty(): return {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues_sample': []}
    original_count = df.count()
    if not consistency_rules_params_list: return {'passed': original_count, 'failed': 0, 'total_checks': original_count, 'issues_sample': []}
    
    df_with_checks = df
    temp_cols_added_for_rules = []
    issues_sample_list = []
    applied_rules_count = 0
    row_id_col_name = "row_id_ingest" if "row_id_ingest" in df.columns else None
    df_cols_lower_map = {df_c.lower(): df_c for df_c in df.columns}

    for rule_idx, rule_params_dict in enumerate(consistency_rules_params_list): 
        rule_ok_col_name = f"cons_rule_{rule_idx}_ok"
        temp_cols_added_for_rules.append(rule_ok_col_name)
        
        cond_col_rule_key = rule_params_dict.get('condition_col')
        cond_val = rule_params_dict.get('condition_val')
        dep_col_rule_key = rule_params_dict.get('dependent_col')
        check_type = rule_params_dict.get('check', 'not_null') 

        if not (cond_col_rule_key and dep_col_rule_key and cond_val is not None): # cond_val can be empty string, but must be present
            logger.warning(f"Consistency Rule {rule_idx}: Missing essential params (condition_col, condition_val, dependent_col) in: {rule_params_dict}")
            df_with_checks = df_with_checks.withColumn(rule_ok_col_name, lit(False))
            applied_rules_count +=1
            continue

        actual_cond_col_df = df_cols_lower_map.get(cond_col_rule_key.lower())
        actual_dep_col_df = df_cols_lower_map.get(dep_col_rule_key.lower())

        if not actual_cond_col_df or not actual_dep_col_df:
            logger.warning(f"Consistency Rule {rule_idx} for '{cond_col_rule_key}' -> '{dep_col_rule_key}': One or both columns not found in DataFrame.")
            df_with_checks = df_with_checks.withColumn(rule_ok_col_name, lit(False)) 
            applied_rules_count +=1 
            if row_id_col_name: sample_r_ids = [r[row_id_col_name] for r in df.select(row_id_col_name).limit(2).collect()]
            else: sample_r_ids = [f"index_{i}" for i in range(min(2, original_count))]
            for r_id_val in sample_r_ids: issues_sample_list.append({'row_id': r_id_val, 'column': f"{cond_col_rule_key}, {dep_col_rule_key}", 'value': 'COLUMN_MISSING','rule_violated': 'Consistency', 'detail': f"Rule params {rule_params_dict} involves missing column(s)." })
            continue
            
        applied_rules_count +=1
        if check_type == 'not_null':
            dep_populated = col(actual_dep_col_df).isNotNull() & (expr(f"trim(CAST(COALESCE(`{actual_dep_col_df}`, '') AS STRING))") != "")
            # Rule passes if condition_col != val OR (condition_col == val AND dependent is populated)
            # Need to handle type of cond_val appropriately if it's not string
            rule_logic = (col(actual_cond_col_df).cast(StringType()) != str(cond_val)) | dep_populated 
            df_with_checks = df_with_checks.withColumn(rule_ok_col_name, rule_logic)
        else:
            logger.warning(f"Unsupported consistency check_type: {check_type} for rule {rule_idx}. Assuming pass.")
            df_with_checks = df_with_checks.withColumn(rule_ok_col_name, lit(True)) 
        
        rule_failed_df_snapshot = df_with_checks.filter(col(rule_ok_col_name) == False) 
        if rule_failed_df_snapshot.count() > 0 and len(issues_sample_list) < 10:
            select_cols_for_issue = ([row_id_col_name] if row_id_col_name else []) + [actual_cond_col_df, actual_dep_col_df]
            sample_failed_this_rule = rule_failed_df_snapshot.select(*[c for c in select_cols_for_issue if c in rule_failed_df_snapshot.columns]).limit(2).collect()
            for row_spark_cons in sample_failed_this_rule:
                 issues_sample_list.append({'row_id': row_spark_cons[row_id_col_name] if row_id_col_name and row_id_col_name in row_spark_cons else 'N/A', 'column': f"Cond: {actual_cond_col_df} ({row_spark_cons[actual_cond_col_df] if actual_cond_col_df in row_spark_cons else 'N/A'}), Dep: {actual_dep_col_df} ({row_spark_cons[actual_dep_col_df] if actual_dep_col_df in row_spark_cons else 'N/A'})",'value': f"Condition met but dependent check failed",'rule_violated': 'Consistency', 'detail': f"Rule: If '{cond_col_rule_key}' is '{cond_val}', '{dep_col_rule_key}' should be {check_type}. Params: {rule_params_dict}"})
                 if len(issues_sample_list) >= 10: break
        if len(issues_sample_list) >= 10: break

    if applied_rules_count == 0: 
        logger.info("No consistency rules were effectively applied.")
        return {'passed': original_count, 'failed': 0, 'total_checks': original_count, 'issues_sample': []}
        
    overall_ok_cond = lit(True)
    for c_col_name_consistency in temp_cols_added_for_rules: overall_ok_cond = overall_ok_cond & col(c_col_name_consistency)
    df_with_checks = df_with_checks.withColumn("is_consistent_row_overall", overall_ok_cond)
    failed_rows = df_with_checks.filter(col("is_consistent_row_overall") == False).count()
    passed_rows = original_count - failed_rows
    logger.info(f"Consistency: Passed (rows): {passed_rows}, Failed (rows): {failed_rows}")
    return {'passed': passed_rows, 'failed': failed_rows, 'total_checks': original_count, 'issues_sample': issues_sample_list[:10]}

# Uniqueness
def check_uniqueness_spark(df: DataFrame, unique_columns_from_rules: list, spark: SparkSession):
    logger.info(f"UNIQUENESS CHECK: Unique columns from rules: {unique_columns_from_rules}")
    if df.rdd.isEmpty(): return {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues_sample': []}
    original_count = df.count()
    if not unique_columns_from_rules: return {'passed': original_count * 0, 'failed': 0, 'total_checks': original_count * 0, 'issues_sample': []}
    
    total_row_checks_across_all_unique_cols = 0 
    passed_row_checks_across_all_unique_cols = 0
    issues_sample_list = []
    row_id_col_name = "row_id_ingest" if "row_id_ingest" in df.columns else None
    df_cols_lower_map = {df_c.lower(): df_c for df_c in df.columns}

    for unique_col_rule_key in unique_columns_from_rules: 
        total_row_checks_across_all_unique_cols += original_count
        actual_col_name_in_df = df_cols_lower_map.get(unique_col_rule_key.lower())

        if not actual_col_name_in_df:
            logger.warning(f"Uniqueness check: Column '{unique_col_rule_key}' not found in DataFrame columns: {df.columns}.")
            if row_id_col_name: sample_r_ids = [r[row_id_col_name] for r in df.select(row_id_col_name).limit(3).collect()]
            else: sample_r_ids = [f"index_{i}" for i in range(min(3, original_count))]
            for r_id_val in sample_r_ids: issues_sample_list.append({'row_id': r_id_val, 'column': unique_col_rule_key, 'value': 'COLUMN_MISSING','rule_violated': 'Uniqueness', 'detail': f"Unique column '{unique_col_rule_key}' is missing."})
            continue
            
        non_null_df_for_col = df.filter(col(actual_col_name_in_df).isNotNull())
        non_null_count_for_col = non_null_df_for_col.count()
        
        if non_null_count_for_col == 0: 
            passed_row_checks_across_all_unique_cols += original_count
            continue

        distinct_count_for_col = non_null_df_for_col.select(actual_col_name_in_df).distinct().count()

        if distinct_count_for_col == non_null_count_for_col: 
            passed_row_checks_across_all_unique_cols += original_count 
        else:
            duplicates_values_df = non_null_df_for_col.groupBy(actual_col_name_in_df).agg(count("*").alias("cnt")).filter(col("cnt") > 1)
            failing_rows_df = non_null_df_for_col.join(duplicates_values_df.select(actual_col_name_in_df), on=actual_col_name_in_df, how="inner")
            num_failing_rows_with_duplicates = failing_rows_df.count()
            passed_row_checks_across_all_unique_cols += (original_count - num_failing_rows_with_duplicates)

            if len(issues_sample_list) < 10:
                select_cols_for_issue = ([row_id_col_name] if row_id_col_name else []) + [actual_col_name_in_df]
                sample_failed_rows = failing_rows_df.select(*[c for c in select_cols_for_issue if c in failing_rows_df.columns]).limit(3).collect()
                for row_uniqueness in sample_failed_rows:
                     issues_sample_list.append({'row_id': row_uniqueness[row_id_col_name] if row_id_col_name and row_id_col_name in row_uniqueness else "N/A", 'column': actual_col_name_in_df, 'value': str(row_uniqueness[actual_col_name_in_df] if actual_col_name_in_df in row_uniqueness else "N/A"),'rule_violated': 'Uniqueness', 'detail': f"Value in column '{actual_col_name_in_df}' is not unique among non-nulls."})
                     if len(issues_sample_list) >= 10: break
        if len(issues_sample_list) >= 10: break
                
    failed_row_checks_across_all_unique_cols = total_row_checks_across_all_unique_cols - passed_row_checks_across_all_unique_cols
    logger.info(f"Uniqueness: Passed Row Checks: {passed_row_checks_across_all_unique_cols}, Failed: {failed_row_checks_across_all_unique_cols}, Total: {total_row_checks_across_all_unique_cols}")
    return {'passed': passed_row_checks_across_all_unique_cols, 'failed': failed_row_checks_across_all_unique_cols, 'total_checks': total_row_checks_across_all_unique_cols, 'issues_sample': issues_sample_list[:10]}
# --- END OF DQ CHECK FUNCTIONS ---


# --- Main DQ Pipeline Runner (V2 for dynamic dimensions) ---
def run_dq_pipeline_spark_v2(df: DataFrame, final_rules_config: dict, dimension_weights: dict, active_dimensions: list, spark: SparkSession):
    logger.info("Starting Data Quality Pipeline (V2) with refined rules and weights.")
    if df is None: logger.error("DQ V2: Input DF is None."); return {"error": "Input DataFrame is None.", "overall_summary": {}}
    if "error" in df.columns and df.filter(col("error").isNotNull()).count() > 0:
        # Attempt to get a more specific error message if available
        error_messages = df.filter(col("error").isNotNull()).select("message").rdd.flatMap(lambda x: x).collect()
        err_msg = error_messages[0] if error_messages and error_messages[0] else "Ingestion error detected."
        logger.error(f"DQ V2: Ingestion errors: '{err_msg}'."); return {"error": f"Ingestion errors: {err_msg}", "overall_summary": {}}
    try: current_df_count = df.count()
    except Exception as e: logger.error(f"DQ V2: Could not count rows: {e}"); return {"error": f"Could not count rows: {e}", "overall_summary": {}}
    if current_df_count == 0: logger.warning("DQ V2: Input DF empty."); return {"info": "Input DataFrame empty.", "overall_summary": {}}
    if "conceptual_message" in df.columns: message = df.select("conceptual_message").first()["conceptual_message"]; logger.info(f"DQ V2: Input conceptual: '{message}'."); return {"info": message, "overall_summary": {}}

    all_dq_results = {"dimension_scores": {}, "dimension_details": {}}
    summary = {'total_raw_passed': 0, 'total_raw_failed': 0, 'total_raw_checks': 0, 'all_issues_sample': [], 'weighted_overall_dq_score': 0.0}
    if "row_id_ingest" not in df.columns: df = df.withColumn("row_id_ingest", monotonically_increasing_id())

    for dim_name in active_dimensions:
        dim_key = dim_name.lower(); rules = final_rules_config.get(dim_key); details = {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues_sample': []}
        score = 100.0 
        if dim_key == "accuracy" and isinstance(rules, dict) and rules: details = check_accuracy_spark(df, rules, spark)
        elif dim_key == "completeness" and isinstance(rules, list) and rules: details = check_completeness_spark(df, rules, spark)
        elif dim_key == "consistency" and isinstance(rules, list) and rules: details = check_consistency_spark(df, rules, spark)
        elif dim_key == "uniqueness" and isinstance(rules, list) and rules: details = check_uniqueness_spark(df, rules, spark)
        elif isinstance(rules, list) and rules: # Custom dimension with list of rule dicts
            logger.info(f"Processing custom dimension '{dim_name}' with {len(rules)} rules.")
            passed_c, failed_c, checks_c, issues_c = 0,0,0,[]
            for r_item in rules:
                r_type, r_col, r_params = r_item.get('rule_type'), r_item.get('column_name'), r_item.get('params',{})
                temp_res = {'passed': 0, 'failed': 0, 'total_checks': 0, 'issues_sample': []}
                if r_type in ['range_check', 'date_format', 'regex_match'] and r_col: temp_res = check_accuracy_spark(df, {r_col: {r_type: r_params}}, spark)
                elif r_type == 'not_null' and r_col: temp_res = check_completeness_spark(df, [r_col], spark)
                elif r_type == 'is_unique' and r_col: temp_res = check_uniqueness_spark(df, [r_col], spark)
                elif r_type == 'conditional_not_null': temp_res = check_consistency_spark(df, [r_params], spark)
                else: logger.warning(f"Unsupported rule '{r_type}' for custom dim '{dim_name}'."); temp_res['total_checks'] = current_df_count; temp_res['passed'] = current_df_count
                passed_c += temp_res.get('passed',0); failed_c += temp_res.get('failed',0); checks_c += temp_res.get('total_checks',0); issues_c.extend(temp_res.get('issues_sample',[]))
            details = {'passed': passed_c, 'failed': failed_c, 'total_checks': checks_c, 'issues_sample': issues_c}
        
        if details['total_checks'] > 0: score = (details['passed'] / details['total_checks']) * 100
        elif not rules or (isinstance(rules,(list,dict)) and not rules) : 
            details['total_checks'] = current_df_count; details['passed'] = current_df_count 
        all_dq_results["dimension_scores"][dim_key] = round(score, 2); all_dq_results["dimension_details"][dim_key] = details
        summary['total_raw_passed'] += details.get('passed',0); summary['total_raw_failed'] += details.get('failed',0); summary['total_raw_checks'] += details.get('total_checks',0); summary['all_issues_sample'].extend(details.get('issues_sample',[]))

    weighted_score_sum, total_weight = 0,0
    for dim_n_calc in active_dimensions:
        dim_k_calc = dim_n_calc.lower(); score_calc = all_dq_results["dimension_scores"].get(dim_k_calc, 100.0); weight_calc = dimension_weights.get(dim_k_calc, 0)
        weighted_score_sum += score_calc * weight_calc; total_weight += weight_calc
    if total_weight > 0: summary['weighted_overall_dq_score'] = round(weighted_score_sum / total_weight, 2)
    elif all_dq_results['dimension_scores']: summary['weighted_overall_dq_score'] = round(sum(all_dq_results['dimension_scores'].values()) / len(all_dq_results['dimension_scores']), 2)
    else: summary['weighted_overall_dq_score'] = 100.0 if current_df_count > 0 else None
    all_dq_results['overall_summary'] = summary
    if summary['all_issues_sample']:
        unique_issues = []
        seen_tuples = set()
        for issue in summary['all_issues_sample']:
            issue_tuple = (issue.get('row_id', 'N/A'), issue.get('column', 'N/A'), issue.get('rule_violated', 'N/A'), issue.get('detail', 'N/A'))
            if issue_tuple not in seen_tuples: seen_tuples.add(issue_tuple); unique_issues.append(issue)
        all_dq_results['overall_summary']['all_issues_sample'] = unique_issues[:20]
    else: all_dq_results['overall_summary']['all_issues_sample'] = []
    logger.info(f"DQ V2 Finished. Overall Score: {summary.get('weighted_overall_dq_score', 'N/A')}%")
    return all_dq_results


# --- Main Execution Block ---
if __name__ == "__main__":
    groq_api_key_env = os.getenv("GROQ_API_KEY")
    if not groq_api_key_env:
        logger.error("GROQ_API_KEY environment variable not set.")
        groq_api_key_input = input("Enter your GROQ_API_KEY to use LLM features (or press Enter to skip LLM and use only manual rules): ")
        if not groq_api_key_input: logger.warning("Proceeding without LLM rule suggestions.")
        else: groq_api_key_env = groq_api_key_input 
    
    spark_main_session = get_spark_session() 
    SAMPLE_DATA_DIR_MAIN = "sample_data_files_etl_v2" 
    os.makedirs(SAMPLE_DATA_DIR_MAIN, exist_ok=True)
    csv_file_main = os.path.abspath(os.path.join(SAMPLE_DATA_DIR_MAIN, "orders_sample.csv"))
    if not os.path.exists(csv_file_main): 
        with open(csv_file_main, "w") as f:
            f.write("order_id,customer_id,order_date_str,product_price,email,order_status,shipping_date_str,category\n")
            f.write("701,CUST701,2024-07-01,10.99,alpha@example.com,shipped,2024-07-03,books\n")
            f.write("702,CUST702,2024-07-01,5.50,beta@example.com,pending,,electronics\n")
        logger.info(f"Created sample CSV for Phase 4: {csv_file_main}")

    logger.info("--- Phase 4: Ingesting Data ---")
    ingestion_schema = StructType([ 
        StructField("order_id", StringType(), True), StructField("customer_id", StringType(), True),
        StructField("order_date_str", StringType(), True), StructField("product_price", StringType(), True),
        StructField("email", StringType(), True), StructField("order_status", StringType(), True),
        StructField("shipping_date_str", StringType(), True), StructField("category", StringType(), True)
    ])
    main_ingested_df = ingest_csv_spark(spark_main_session, csv_file_main, custom_schema=ingestion_schema, infer_schema=False)
    
    if main_ingested_df is None or "error" in main_ingested_df.columns or main_ingested_df.rdd.isEmpty(): 
        logger.error("Halting Phase 4 due to ingestion failure or empty DataFrame.")
        if main_ingested_df is not None and "error" in main_ingested_df.columns: main_ingested_df.show(truncate=False)
        spark_main_session.stop(); exit()
    
    logger.info("\n--- Phase 4: Performing Multi-Stage Sampling ---")
    llm_sample_pd, stage1_sample_spark_df = perform_multi_stage_sampling(main_ingested_df, stage1_fraction=0.9, stage2_max_rows_for_pandas=100, stage3_llm_sample_size=10) 
    
    logger.info("\n--- Phase 4: Simulating Data Profiling ---")
    profiling_df_source = stage1_sample_spark_df if stage1_sample_spark_df is not None and not stage1_sample_spark_df.rdd.isEmpty() else main_ingested_df
    data_profile_output = simulate_data_profiling(profiling_df_source, spark_main_session, llm_sample_pd)
    
    logger.info("\n--- Phase 4: Interactive Rule, Weight, and Dimension Setup ---")
    final_rules_config, final_dimension_weights, final_active_dimensions = refine_rules_weights_dimensions_interactively(data_profile_output, groq_api_key=groq_api_key_env)
    
    df_for_dq_run = main_ingested_df 
    if "accuracy" in final_rules_config: 
        for col_name_acc, acc_rules in final_rules_config["accuracy"].items():
            # Find actual column name in df (case-insensitive)
            actual_col_for_cast = next((df_col for df_col in df_for_dq_run.columns if df_col.lower() == col_name_acc.lower()), None)
            if actual_col_for_cast:
                if "range_check" in acc_rules: 
                    df_for_dq_run = df_for_dq_run.withColumn(actual_col_for_cast, col(actual_col_for_cast).cast(DoubleType()))
                # Add other type casts if rule_types imply them (e.g. date_format -> TimestampType)
                # For date_format, the check function itself handles casting from string.
    logger.info("Schema of DataFrame being sent to DQ engine after potential casting:")
    df_for_dq_run.printSchema()

    logger.info("\n--- Phase 4: Running DQ Pipeline with Final Setup ---")
    if not df_for_dq_run.rdd.isEmpty():
        dq_results_final = run_dq_pipeline_spark_v2(df_for_dq_run, final_rules_config, final_dimension_weights, final_active_dimensions, spark_main_session)
        
        logger.info("\n--- Final Detailed DQ Results (Phase 4) ---")
        for dim_name_report in final_active_dimensions: 
            dim_key_report = dim_name_report.lower()
            dim_details_report = dq_results_final.get("dimension_details", {}).get(dim_key_report, {})
            logger.info(f"\nCategory: {dim_name_report.upper()}")
            logger.info(f"  Dimension Score: {dq_results_final.get('dimension_scores', {}).get(dim_key_report, 'N/A')}% (Weight: {final_dimension_weights.get(dim_key_report, 0)*100:.1f}%)")
            if dim_details_report:
                logger.info(f"  Passed Checks: {dim_details_report.get('passed', 'N/A')}")
                logger.info(f"  Failed Checks: {dim_details_report.get('failed', 'N/A')}")
                logger.info(f"  Total Element Checks: {dim_details_report.get('total_checks', 'N/A')}")
                if dim_details_report.get('issues_sample'):
                    logger.info(f"  Sample Issues for {dim_name_report} (up to 5):")
                    for issue in dim_details_report['issues_sample'][:5]: logger.info(f"    - RowID: {issue.get('row_id', 'N/A')}, Col: {issue.get('column','N/A')}, Val: '{str(issue.get('value', 'N/A'))[:50]}', Detail: {issue.get('detail', 'N/A')}")
            else: logger.info("  No specific details or rules run for this dimension.")
        final_summary_report = dq_results_final.get('overall_summary', {})
        if final_summary_report:
            logger.info("\n--- Final Overall DQ Summary (Phase 4) ---")
            logger.info(f"  Weighted Overall DQ Score: {final_summary_report.get('weighted_overall_dq_score', 'N/A')}%")
            if final_summary_report.get('all_issues_sample'):
                logger.info(f"  Overall Sample Issues (first 10 of combined samples):")
                for issue in final_summary_report['all_issues_sample'][:10]: logger.info(f"    - RowID: {issue.get('row_id', 'N/A')}, Col: {issue.get('column','N/A')}, Val: '{str(issue.get('value', 'N/A'))[:50]}', Rule: {issue.get('rule_violated', 'N/A')}, Detail: {issue.get('detail', 'N/A')}")
        elif dq_results_final.get("error"): logger.error(f"DQ Pipeline Error: {dq_results_final.get('error')}")
        elif dq_results_final.get("info"): logger.info(f"DQ Pipeline Info: {dq_results_final.get('info')}")
    else: logger.error("DataFrame for DQ is empty. Cannot run DQ pipeline.")
    spark_main_session.stop()
    logger.info("Spark session stopped.")



# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

