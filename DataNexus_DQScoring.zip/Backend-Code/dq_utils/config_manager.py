# dq_utils/config_manager.py
from __future__ import annotations

import os
from dotenv import load_dotenv
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


class ConfigManager:
    """
    Manages configuration loading, prioritizing Databricks widgets/secrets and falling back
    to environment variables or a .env file.
    """

    def __init__(self, dbutils_instance=None, dotenv_path: Optional[str] = None):
        self.dbutils = dbutils_instance
        if dotenv_path and os.path.exists(dotenv_path):
            load_dotenv(dotenv_path)
            logger.info(f"Loaded configurations from .env: {dotenv_path}")
        elif os.path.exists(".env"):
            load_dotenv()
            logger.info("Loaded configurations from .env file in working directory.")
        else:
            logger.info("No .env file found; using Databricks widgets/secrets or environment variables.")

    def get_config(
        self,
        key: str,
        default: Optional[Any] = None,
        is_secret: bool = False,
        secret_scope: Optional[str] = None
    ) -> Optional[Any]:
        # 1️⃣ Try Widgets (non‐secret)
        if self.dbutils and not is_secret and hasattr(self.dbutils, "widgets"):
            try:
                val = self.dbutils.widgets.get(key)
                if val is not None:
                    logger.debug(f"Config '{key}' from widgets: {val}")
                    return val
            except Exception:
                logger.debug(f"Widget '{key}' not defined.")

        # 2️⃣ Try Secrets
        if self.dbutils and is_secret and secret_scope:
            try:
                val = self.dbutils.secrets.get(scope=secret_scope, key=key)
                if val:
                    logger.debug(f"Secret '{key}' from scope '{secret_scope}' retrieved.")
                    return val
            except Exception:
                logger.warning(f"Cannot retrieve secret '{key}' from scope '{secret_scope}'.")

        # 3️⃣ Try environment variable
        env_val = os.getenv(key)
        if env_val is not None:
            logger.debug(f"Config '{key}' from environment: {env_val}")
            return env_val

        # 4️⃣ Fallback to default
        logger.debug(f"Config '{key}' not found; using default: {default}")
        return default
