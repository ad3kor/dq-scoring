# dq_utils/audit.py
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from pyspark.sql import SparkSession, Row
from pyspark.sql.types import (
    StructType, StructField, StringType, TimestampType, LongType
)

logger = logging.getLogger(__name__)


class AuditLogger:
    """
    Handles application‐level audit logging to a Delta table.
    """

    def __init__(
        self,
        spark: SparkSession,
        audit_table_fqn: str = "governance_catalog.audit_db.application_events_log"
    ):
        self.spark = spark
        self.audit_table_fqn = audit_table_fqn
        self._ensure_table()

    def _ensure_table(self) -> None:
        try:
            catalog, schema, tbl = self.audit_table_fqn.split(".")
            self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
            if not self.spark.catalog.tableExists(self.audit_table_fqn):
                logger.info(f"Creating audit table {self.audit_table_fqn}...")
                schema_df = StructType([
                    StructField("event_timestamp_utc", TimestampType(), False),
                    StructField("user_id", StringType(), True),
                    StructField("action", StringType(), True),
                    StructField("details_json", StringType(), True),
                ])
                self.spark.createDataFrame([], schema_df) \
                    .write.format("delta") \
                    .saveAsTable(self.audit_table_fqn)
                logger.info("Audit table created.")
        except Exception as e:
            logger.error(f"Failed to ensure audit table: {e}", exc_info=True)

    def log_event(self, user_id: str, action: str, details: Dict[str, Any]) -> None:
        try:
            ts = datetime.now(timezone.utc)
            record = Row(
                event_timestamp_utc=ts,
                user_id=str(user_id),
                action=str(action),
                details_json=json.dumps(details, default=str)
            )
            df = self.spark.createDataFrame([record])
            df.write.format("delta").mode("append").saveAsTable(self.audit_table_fqn)
        except Exception as e:
            logger.error(f"Failed to log audit event: {e}", exc_info=True)
