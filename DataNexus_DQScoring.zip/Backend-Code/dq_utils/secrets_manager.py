# dq_utils/secrets_manager.py
from __future__ import annotations

from typing import Optional
from .config_manager import ConfigManager


class SecretsManager:
    """
    Utility class for securely retrieving secrets via ConfigManager.
    """

    def __init__(
        self,
        config_manager_instance: ConfigManager,
        default_secret_scope: str = "dq_app_secrets"
    ):
        self.config_mgr = config_manager_instance
        self.default_secret_scope = default_secret_scope

    def get_secret(self, key: str, scope: Optional[str] = None) -> Optional[str]:
        secret_scope_to_use = scope if scope else self.default_secret_scope
        return self.config_mgr.get_config(key, is_secret=True, secret_scope=secret_scope_to_use)
