# dq_utils/spark_utils.py
from __future__ import annotations

import logging
from typing import List, Optional

from pyspark.sql import SparkSession

logger = logging.getLogger(__name__)


class SparkUtils:
    """
    Common PySpark helper functions.
    """

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def optimize_delta_table(self, table_fqn: str, zorder_cols: Optional[List[str]] = None) -> None:
        try:
            if zorder_cols:
                self.spark.sql(f"OPTIMIZE {table_fqn} ZORDER BY ({', '.join(zorder_cols)})")
            else:
                self.spark.sql(f"OPTIMIZE {table_fqn}")
        except Exception as e:
            logger.error(f"Failed to optimize table {table_fqn}: {e}", exc_info=True)

    def set_liquid_clustering(self, table_fqn: str, cluster_by_cols: List[str]) -> None:
        try:
            alter_query = f"ALTER TABLE {table_fqn} CLUSTER BY ({', '.join(cluster_by_cols)})"
            self.spark.sql(alter_query)
            self.spark.sql(f"OPTIMIZE {table_fqn}")
        except Exception as e:
            logger.error(f"Failed to set Liquid Clustering for {table_fqn}: {e}", exc_info=True)

    def get_table_row_count(self, table_fqn: str) -> Optional[int]:
        try:
            return self.spark.table(table_fqn).count()
        except Exception as e:
            logger.error(f"Could not get row count for {table_fqn}: {e}", exc_info=True)
            return None
