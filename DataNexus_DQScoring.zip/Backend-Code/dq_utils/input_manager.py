# dq_utils/input_manager.py
"""
Responsible for reading input source based on configuration or widgets.
Supports: Delta table, Parquet, CSV, Excel, JDBC, Kafka.
"""
from __future__ import annotations

import json
from typing import Any, Dict

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructType
from pyspark.sql import functions as F

import pandas as pd

from .config_manager import ConfigManager

# Default parameters for reading an input source
EXPECTED_INPUT_PARAMS: Dict[str, Any] = {
    "source_type": "delta_table",             # delta_table | parquet | csv | excel | jdbc | kafka
    "input_table_fqn": "",                    # for delta_table
    "input_path": "",                         # for file-based (parquet, csv, excel)
    "file_format": "parquet",                 # parquet | csv | excel
    "jdbc_table_or_query": "",                # for JDBC
    "kafka_topic": "",                        # for Kafka
    "kafka_starting_offsets": "earliest",
    "kafka_value_schema_struct_json": "{}",   # JSON string of StructType for Kafka
}


def create_input_widgets(dbutils) -> None:
    """
    Create Databricks text widgets for each expected input parameter.
    """
    for param, default in EXPECTED_INPUT_PARAMS.items():
        dbutils.widgets.text(param, default, param)


def load_input_dataframe(
    spark: SparkSession,
    dbutils,
    config_mgr: ConfigManager
) -> DataFrame:
    """
    Load an input DataFrame based on source_type and related parameters.
    """
    # 1️⃣ Gather all parameters from widgets or environment
    params: Dict[str, Any] = {}
    for key, default in EXPECTED_INPUT_PARAMS.items():
        raw = config_mgr.get_config(key, default=default)
        if key.endswith("_json") and isinstance(raw, str):
            try:
                params[key] = json.loads(raw)
            except json.JSONDecodeError:
                params[key] = default
        else:
            params[key] = raw

    source = params.get("source_type", "delta_table").lower()

    if source == "delta_table":
        table = params.get("input_table_fqn")
        if not table:
            raise ValueError("'input_table_fqn' must be provided for source_type='delta_table'.")
        return spark.table(table)

    elif source in ("parquet", "csv", "excel"):  # file-based
        path = params.get("input_path")
        fmt = params.get("file_format", source).lower()
        if not path:
            raise ValueError("'input_path' must be provided for file-based sources.")
        if fmt == "excel":
            # Read via Pandas, then convert to Spark
            try:
                pdf = pd.read_excel(path, engine="openpyxl")
                return spark.createDataFrame(pdf)
            except Exception as e:
                raise ValueError(f"Error reading Excel file at {path}: {e}")
        reader = spark.read.format(fmt)
        if fmt == "csv":
            reader = reader.option("header", True).option("inferSchema", True)
        return reader.load(path)

    elif source == "jdbc":
        table_or_query = params.get("jdbc_table_or_query")
        if not table_or_query:
            raise ValueError("'jdbc_table_or_query' must be provided for source_type='jdbc'.")
        # Delegate to a connector client
        from .connector_clients import ConnectorClients
        conn = ConnectorClients(spark, config_mgr)
        return conn.read_from_jdbc(table_or_query)

    elif source == "kafka":
        topic = params.get("kafka_topic")
        if not topic:
            raise ValueError("'kafka_topic' must be provided for source_type='kafka'.")
        schema_json = params.get("kafka_value_schema_struct_json", "{}")
        struct = None
        if isinstance(schema_json, dict):
            struct = StructType.fromJson(schema_json)
        from .connector_clients import ConnectorClients
        conn = ConnectorClients(spark, config_mgr)
        df = conn.read_from_kafka(topic, is_streaming=False)
        if struct:
            df = (
                df.selectExpr("CAST(value AS STRING)")
                  .select(F.from_json("value", struct).alias("data"))
                  .select("data.*")
            )
        return df

    else:
        raise ValueError(f"Unsupported source_type: {source}")
