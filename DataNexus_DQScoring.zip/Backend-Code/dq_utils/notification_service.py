# dq_utils/notification_service.py
from __future__ import annotations

import os
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from typing import List, Optional

from .config_manager import ConfigManager

logger = logging.getLogger(__name__)


class NotificationService:
    """
    Handles sending email notifications (HTML + optional attachments).
    """

    def __init__(self, config_manager_instance: ConfigManager):
        self.config_mgr = config_manager_instance
        self.smtp_server = self.config_mgr.get_config("SMTP_SERVER")
        smtp_port_str = self.config_mgr.get_config("SMTP_PORT", default="587")
        try:
            self.smtp_port = int(smtp_port_str)
        except ValueError:
            logger.error(f"Invalid SMTP_PORT: '{smtp_port_str}'. Using default 587.")
            self.smtp_port = 587

        self.sender_email = self.config_mgr.get_config("SENDER_EMAIL")
        self.sender_password = self.config_mgr.get_config(
            "SENDER_PASSWORD", is_secret=True, secret_scope="smtp_credentials"
        )
        self.default_recipient_email = self.config_mgr.get_config("RECIPIENT_EMAIL")

    def send_email(
        self,
        subject: str,
        body_html: str,
        recipient_email: Optional[str] = None,
        attachments: Optional[List[str]] = None
    ) -> bool:
        if not all([self.smtp_server, self.smtp_port, self.sender_email, self.sender_password]):
            logger.error("SMTP configuration is incomplete. Cannot send email.")
            return False

        to_email = recipient_email if recipient_email else self.default_recipient_email
        if not to_email:
            logger.error("Recipient email not specified and no default is set. Cannot send email.")
            return False

        msg = MIMEMultipart()
        msg["From"] = self.sender_email
        msg["To"] = to_email
        msg["Subject"] = subject
        msg.attach(MIMEText(body_html, "html"))

        if attachments:
            for file_path in attachments:
                if not os.path.exists(file_path):
                    logger.warning(f"Attachment file not found: {file_path}. Skipping.")
                    continue
                try:
                    with open(file_path, "rb") as attachment_file:
                        part = MIMEBase("application", "octet-stream")
                        part.set_payload(attachment_file.read())
                    encoders.encode_base64(part)
                    part.add_header("Content-Disposition", f"attachment; filename={os.path.basename(file_path)}")
                    msg.attach(part)
                    logger.debug(f"Attached file: {file_path}")
                except Exception as e:
                    logger.error(f"Failed to attach file {file_path}: {e}", exc_info=True)

        try:
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.sendmail(self.sender_email, to_email, msg.as_string())
            logger.info(f"Email sent successfully to {to_email} with subject: '{subject}'")
            return True
        except Exception as e:
            logger.error(
                f"Failed to send email to {to_email} with subject '{subject}'. Error: {e}", exc_info=True
            )
            return False
