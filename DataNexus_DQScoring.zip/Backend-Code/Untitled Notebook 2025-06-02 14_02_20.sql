-- Databricks notebook source
OPTIMIZE dq_catalog.dq_schema.dq_issues
ZORDER BY (issue_text, rule_id, metadata)


-- COMMAND ----------

-- Replace <your_catalog_name> with a unique name (e.g., dq_catalog)
CREATE CATALOG IF NOT EXISTS dq_catalog;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS dq_catalog.dq_schema;

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS dq_catalog.dq_schema.dq_issues (
  issue_id STRING,
  table_name STRING,
  rule_id STRING,
  issue_text STRING,
  timestamp TIMESTAMP,
  metadata STRING
)
USING DELTA;

-- COMMAND ----------

GRANT USAGE ON CATALOG dq_catalog TO `acharjeerishab@fofdlm.onmicrosoft.com`;
GRANT USAGE ON SCHEMA dq_catalog.dq_schema TO `acharjeerishab@fofdlm.onmicrosoft.com`;
GRANT SELECT ON TABLE dq_catalog.dq_schema.dq_issues TO `acharjeerishab@fofdlm.onmicrosoft.com`;
GRANT MODIFY ON TABLE dq_catalog.dq_schema.dq_issues TO `acharjeerishab@fofdlm.onmicrosoft.com`;

-- COMMAND ----------

-- Preferred syntax (Databricks SQL, Unity Catalog-enabled):
CREATE OR REPLACE VECTOR INDEX dq_catalog.dq_schema.dq_issues_index
  ON dq_catalog.dq_schema.dq_issues (issue_text, rule_id, metadata)
  USING VECTOR SEARCH OPTIONS ('endpoint' = 'dq-vector-endpoint');

ALTER VECTOR INDEX dq_catalog.dq_schema.dq_issues_index
  SET TBLPROPERTIES (
    'deltaSync.sourceTable' = 'dq_catalog.dq_schema.dq_issues',
    'deltaSync.mode' = 'Continuous'
  );

-- COMMAND ----------

-- Create a Delta table with the required columns
CREATE OR REPLACE TABLE dq_catalog.dq_schema.dq_issues (
  issue_text STRING,
  rule_id STRING,
  metadata STRING
);

-- Optimize the Delta table using Z-Ordering
OPTIMIZE dq_catalog.dq_schema.dq_issues
  ZORDER BY (issue_text, rule_id, metadata);

-- Set table properties for continuous sync
ALTER TABLE dq_catalog.dq_schema.dq_issues
  SET TBLPROPERTIES (
    'deltaSync.sourceTable' = 'dq_catalog.dq_schema.dq_issues',
    'deltaSync.mode' = 'Continuous'
  );

-- COMMAND ----------

CREATE OR REPLACE VECTOR INDEX dq_catalog.dq_schema.dq_issues_index
  ON dq_catalog.dq_schema.dq_issues (issue_text, rule_id, metadata)
  USING VECTOR SEARCH OPTIONS ('endpoint' = 'dq-vector-endpoint');


-- COMMAND ----------

