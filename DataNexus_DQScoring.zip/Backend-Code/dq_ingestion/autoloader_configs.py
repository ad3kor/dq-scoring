# dq_ingestion/autoloader_configs.py
from __future__ import annotations

import logging
from typing import Optional, Dict, Any

from pyspark.sql import SparkSession, DataFrame

logger = logging.getLogger(__name__)


class AutoLoaderManager:
    """
    Manages Auto Loader stream configurations for various file types.
    """

    def __init__(self, spark_session: SparkSession, dbutils_instance=None):
        self.spark = spark_session
        self.dbutils = dbutils_instance

    def _get_base_autoloader_reader(
        self,
        schema_location: str,
        bad_records_path: Optional[str] = None,
        extra_options: Optional[Dict[str, str]] = None
    ) -> Optional[Any]:
        reader = self.spark.readStream.format("cloudFiles") \
            .option("cloudFiles.schemaLocation", schema_location) \
            .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        if bad_records_path:
            reader = reader.option("badRecordsPath", bad_records_path)
        if extra_options:
            for k, v in extra_options.items():
                reader = reader.option(k, v)
        return reader

    def get_autoloader_stream(
        self,
        input_path: str,
        file_format: str,
        schema_location: str,
        bad_records_path: Optional[str] = None,
        extra_options: Optional[Dict[str, str]] = None
    ) -> Optional[DataFrame]:
        base_reader = self._get_base_autoloader_reader(schema_location, bad_records_path, extra_options)
        if not base_reader:
            return None
        specific_options = {"cloudFiles.format": file_format.lower()}
        if file_format.lower() == "csv":
            specific_options.setdefault("header", "true")
            specific_options.setdefault("inferSchema", "false")
        for k, v in specific_options.items():
            base_reader = base_reader.option(k, v)
        try:
            return base_reader.load(input_path)
        except Exception as e:
            logger.error(
                f"Failed to configure Auto Loader for {file_format.upper()} from path {input_path}. Error: {e}",
                exc_info=True
            )
            return None

    def start_autoloader_to_delta(
        self,
        stream_df: DataFrame,
        target_table_fqn: str,
        checkpoint_location: str,
        output_mode: str = "append",
        trigger_type: str = "processingTime",
        trigger_interval: str = "1 minute"
    ) -> Any:
        writer = stream_df.writeStream \
            .format("delta") \
            .outputMode(output_mode) \
            .option("checkpointLocation", checkpoint_location) \
            .option("mergeSchema", "true")
        if trigger_type.lower() == "processingtime":
            writer = writer.trigger(processingTime=trigger_interval)
        return writer.toTable(target_table_fqn)
