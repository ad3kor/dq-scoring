# dq_ingestion/custom_ingestors.py
from __future__ import annotations

import json
import logging
import os
from typing import Any, Dict, Optional

import pandas as pd
import requests
from pyspark.sql import SparkSession, DataFrame

from dq_utils.config_manager import ConfigManager

logger = logging.getLogger(__name__)


class CustomIngestors:
    """
    Custom ingestion scripts for Web APIs and processing local/DBFS file uploads.
    """

    def __init__(
        self,
        spark_session: SparkSession,
        config_manager_instance: "ConfigManager",
        dbutils_instance=None
    ):
        self.spark = spark_session
        self.config_mgr = config_manager_instance
        self.dbutils = dbutils_instance

    def fetch_api_data_and_stage(
        self,
        api_url: str,
        output_path: str,
        api_key_name: Optional[str] = None,
        api_key_scope: Optional[str] = "api_credentials",
        is_spark_env: bool = True
    ) -> None:
        headers = {}
        if api_key_name:
            api_key = self.config_mgr.get_config(api_key_name, is_secret=True, secret_scope=api_key_scope)
            if api_key:
                headers["Authorization"] = f"Bearer {api_key}"
        try:
            response = requests.get(api_url, headers=headers, timeout=30)
            response.raise_for_status()
            data = response.json()
            if is_spark_env and self.spark:
                if isinstance(data, list) and data:
                    df = self.spark.createDataFrame(data)
                elif isinstance(data, dict):
                    df = self.spark.createDataFrame([data])
                else:
                    return
                df.write.mode("overwrite").parquet(output_path)
            else:
                os.makedirs(output_path, exist_ok=True)
                with open(os.path.join(output_path, "api_data.json"), "w") as f:
                    json.dump(data, f, indent=2)
        except Exception:
            logger.error(f"Error fetching/staging API data from {api_url}", exc_info=True)

    def process_uploaded_file(
        self,
        file_path: str,
        file_format: str,
        read_options: Optional[Dict[str, str]] = None
    ) -> Optional[DataFrame]:
        reader = self.spark.read
        opts = read_options.copy() if read_options else {}
        fmt = file_format.lower()
        try:
            if fmt == "csv":
                reader = reader.format("csv")
                opts.setdefault("header", "true")
                opts.setdefault("inferSchema", "true")
            elif fmt == "json":
                reader = reader.format("json")
                opts.setdefault("multiLine", "true")
            elif fmt == "parquet":
                reader = reader.format("parquet")
            elif fmt == "excel":
                local_path = file_path if file_path.startswith("/dbfs") else f"/dbfs{file_path}"
                df_pd = pd.read_excel(local_path, engine="openpyxl", **opts)
                return self.spark.createDataFrame(df_pd)
            else:
                logger.error(f"Unsupported file format '{fmt}' for processing.")
                return None
            for k, v in opts.items():
                reader = reader.option(k, v)
            return reader.load(file_path)
        except Exception:
            logger.error(f"Error processing uploaded file '{file_path}'", exc_info=True)
            return None
