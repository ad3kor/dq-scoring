# dq_ingestion/connector_clients.py
from __future__ import annotations

import logging
from typing import Optional, Dict

from pyspark.sql import SparkSession, DataFrame
from dq_utils.config_manager import ConfigManager

logger = logging.getLogger(__name__)


class ConnectorClients:
    """
    Clients for reading from various data sources (Cassandra, MongoDB, Kafka, JDBC).
    """

    def __init__(self, spark_session: SparkSession, config_manager_instance: "ConfigManager"):
        self.spark = spark_session
        self.config_mgr = config_manager_instance

    def read_from_cassandra(
        self,
        host: str,
        keyspace: str,
        table: str,
        username_secret_key: Optional[str] = "CASSANDRA_USER",
        password_secret_key: Optional[str] = "CASSANDRA_PASS",
        secret_scope: Optional[str] = "cassandra_credentials"
    ) -> Optional[DataFrame]:
        options = {
            "spark.cassandra.connection.host": host,
            "keyspace": keyspace,
            "table": table
        }
        username = self.config_mgr.get_config(username_secret_key, is_secret=True, secret_scope=secret_scope)
        password = self.config_mgr.get_config(password_secret_key, is_secret=True, secret_scope=secret_scope)
        if username and password:
            options.update({
                "spark.cassandra.auth.username": username,
                "spark.cassandra.auth.password": password
            })
        try:
            return self.spark.read.format("org.apache.spark.sql.cassandra") \
                .options(**options).load()
        except Exception:
            logger.error(f"Error reading from Cassandra {keyspace}.{table}", exc_info=True)
            return None

    def read_from_mongodb(
        self,
        database: str,
        collection: str,
        connection_uri_secret_key: str = "MONGO_CONNECTION_URI",
        secret_scope: str = "mongo_credentials"
    ) -> Optional[DataFrame]:
        connection_uri = self.config_mgr.get_config(connection_uri_secret_key, is_secret=True, secret_scope=secret_scope)
        if not connection_uri:
            logger.error(f"MongoDB URI secret '{connection_uri_secret_key}' not found.")
            return None
        try:
            return self.spark.read.format("mongodb") \
                .option("spark.mongodb.input.uri", connection_uri) \
                .option("database", database) \
                .option("collection", collection) \
                .load()
        except Exception:
            logger.error(f"Error reading from MongoDB {database}.{collection}", exc_info=True)
            return None

    def read_from_kafka(
        self,
        topic: str,
        kafka_bootstrap_servers_key: str = "KAFKA_BOOTSTRAP_SERVERS",
        starting_offsets: str = "earliest",
        kafka_options: Optional[Dict[str, str]] = None,
        secret_scope: Optional[str] = "kafka_credentials",
        is_streaming: bool = False
    ) -> Optional[DataFrame]:
        bootstrap_servers = self.config_mgr.get_config(
            kafka_bootstrap_servers_key, is_secret=True, secret_scope=secret_scope
        )
        if not bootstrap_servers:
            logger.error(f"Kafka bootstrap servers key '{kafka_bootstrap_servers_key}' not found.")
            return None
        reader = self.spark.readStream if is_streaming else self.spark.read
        options = {
            "kafka.bootstrap.servers": bootstrap_servers,
            "subscribe": topic
        }
        if is_streaming:
            options["startingOffsets"] = starting_offsets
        if kafka_options:
            options.update(kafka_options)
        try:
            return reader.format("kafka").options(**options).load()
        except Exception:
            logger.error(f"Error configuring Kafka reader for topic '{topic}'", exc_info=True)
            return None

    def read_from_jdbc(
        self,
        table_or_query: str,
        jdbc_url_key: str = "JDBC_URL",
        user_secret_key: Optional[str] = "JDBC_USER",
        password_secret_key: Optional[str] = "JDBC_PASSWORD",
        driver: Optional[str] = None,
        jdbc_options: Optional[Dict[str, str]] = None,
        secret_scope: Optional[str] = "jdbc_credentials"
    ) -> Optional[DataFrame]:
        jdbc_url = self.config_mgr.get_config(jdbc_url_key, is_secret=True, secret_scope=secret_scope)
        if not jdbc_url:
            logger.error(f"JDBC URL '{jdbc_url_key}' not found.")
            return None
        options = {"url": jdbc_url}
        if table_or_query.strip().upper().startswith("SELECT "):
            options["query"] = table_or_query
        else:
            options["dbtable"] = table_or_query
        user = self.config_mgr.get_config(user_secret_key, is_secret=True, secret_scope=secret_scope)
        password = self.config_mgr.get_config(password_secret_key, is_secret=True, secret_scope=secret_scope)
        if user is not None and password is not None:
            options["user"] = user
            options["password"] = password
        if driver:
            options["driver"] = driver
        if jdbc_options:
            options.update(jdbc_options)
        try:
            return self.spark.read.format("jdbc").options(**options).load()
        except Exception:
            logger.error(f"Error reading from JDBC source '{table_or_query}'", exc_info=True)
            return None
