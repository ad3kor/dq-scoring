import json
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional

from pyspark.sql import SparkSession, DataFrame, Row
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, LongType, BooleanType,
    TimestampType
)
import logging

logger = logging.getLogger(__name__)

class DQRuleManager:
    """
    Manages DQ rule storage and retrieval in Delta.
    """
    def __init__(self, spark_session: SparkSession, rules_table_fqn: str = "my_schema.dq_rules"):
        self.spark = spark_session
        self.rules_table_fqn = rules_table_fqn
        self._ensure_rules_table_exists()

    def _ensure_rules_table_exists(self):
        # Support both catalog.schema.table and schema.table
        parts = self.rules_table_fqn.split('.')
        if len(parts) == 3:
            catalog, schema, tbl = parts
        elif len(parts) == 2:
            catalog = None
            schema, tbl = parts
        else:
            raise ValueError(f"Invalid table identifier '{self.rules_table_fqn}'. "
                             "Expected 'schema.table' or 'catalog.schema.table'.")

        # Create schema if not exists
        if catalog:
            self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
        else:
            self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema}")

        # Create table if not exists
        if not self.spark.catalog.tableExists(self.rules_table_fqn):
            logger.info(f"Creating DQ rules table {self.rules_table_fqn}...")
            dq_schema = StructType([
                StructField("rule_id", StringType(), False),
                StructField("rule_name", StringType(), True),
                StructField("rule_type", StringType(), True),
                StructField("column_name", StringType(), True),
                StructField("description", StringType(), True),
                StructField("parameters_json", StringType(), True),
                StructField("spark_sql_condition", StringType(), True),
                StructField("is_active", BooleanType(), True),
                StructField("severity", StringType(), True),
                StructField("dimension", StringType(), True),
                StructField("weight", DoubleType(), True),
                StructField("created_at", TimestampType(), True),
                StructField("updated_at", TimestampType(), True),
                StructField("version", LongType(), True)
            ])
            self.spark.createDataFrame([], dq_schema) \
                      .write.format("delta") \
                      .saveAsTable(self.rules_table_fqn)
            logger.info("DQ rules table created.")

    def save_rules(self, rules_config_list: List[Dict[str, Any]], mode: str = "append"):
        rows = []
        for r in rules_config_list:
            rcopy = r.copy()
            rcopy["parameters_json"] = json.dumps(rcopy.pop("parameters", {}))
            rcopy.setdefault("is_active", True)
            rcopy.setdefault("severity", "MEDIUM")
            rcopy.setdefault("dimension", "N/A")
            rcopy.setdefault("weight", 1.0)
            now = datetime.now(timezone.utc)
            rcopy.setdefault("created_at", now)
            rcopy.setdefault("updated_at", now)
            rows.append(Row(**rcopy))
        df = self.spark.createDataFrame(rows)
        df.write.format("delta") \
          .mode(mode) \
          .option("mergeSchema", "true") \
          .saveAsTable(self.rules_table_fqn)

    def load_active_rules(self, dimension_filter: Optional[str] = None) -> DataFrame:
        df = self.spark.read.format("delta").table(self.rules_table_fqn)
        active = df.filter(F.col("is_active") == True)
        if dimension_filter:
            active = active.filter(F.col("dimension") == dimension_filter)
        return active
