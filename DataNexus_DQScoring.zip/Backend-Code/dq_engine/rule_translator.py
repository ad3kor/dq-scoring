# dq_engine/rule_translator.py
from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window

logger = logging.getLogger(__name__)


class DQRuleTranslator:
    """
    Translates structured rule definitions into executable PySpark/Spark SQL operations.
    """

    def __init__(self, spark_session: SparkSession):
        self.spark = spark_session

    def translate_rule_to_spark_df_operation(
        self, df_to_validate: DataFrame, rule_config: Dict[str, Any]
    ) -> Optional[DataFrame]:
        rule_type = rule_config.get("rule_type")
        column = rule_config.get("column_name")
        params = json.loads(rule_config.get("parameters_json", "{}"))
        sql_cond = rule_config.get("spark_sql_condition")

        try:
            if sql_cond:
                failing = df_to_validate.where(sql_cond)

            elif rule_type == "completeness":
                failing = df_to_validate.filter(
                    F.col(column).isNull() | F.isnan(F.col(column))
                )

            elif rule_type == "uniqueness":
                window = Window.partitionBy(F.col(column))
                failing = df_to_validate.withColumn("_cnt", F.count("*").over(window)) \
                                        .filter(F.col("_cnt") > 1) \
                                        .drop("_cnt")

            elif rule_type == "range_check":
                minv, maxv = params.get("min_value"), params.get("max_value")
                failing = df_to_validate.filter(
                    (F.col(column) < minv) | (F.col(column) > maxv)
                )

            elif rule_type == "format_check":
                pattern = params.get("regex_pattern")
                failing = df_to_validate.filter(~F.col(column).rlike(pattern))

            else:
                return None

            return failing \
                .withColumn("dq_rule_id", F.lit(rule_config.get("rule_id"))) \
                .withColumn("dq_rule_name", F.lit(rule_config.get("rule_name")))

        except Exception:
            logger.error(f"Error applying rule {rule_config.get('rule_name')}", exc_info=True)
            return None
