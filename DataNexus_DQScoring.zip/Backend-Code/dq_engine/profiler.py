# dq_engine/profiler.py
from __future__ import annotations

from typing import Any, Dict

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, LongType, DoubleType

class DataProfiler:
    """
    Profiles data to generate statistics for Data Quality workflows.
    """

    def __init__(self, spark_session: SparkSession):
        self.spark = spark_session

    def profile_dataframe(self, df: DataFrame, table_name_for_report: str) -> Dict[str, Any]:
        total_rows = df.count()
        profile_summary: Dict[str, Any] = {
            "table_name": table_name_for_report,
            "total_rows": total_rows,
            "column_profiles": []
        }

        for field in df.schema.fields:
            col = field.name
            distinct_count = df.select(F.approx_count_distinct(col)).first()[0]
            null_count = df.filter(F.col(col).isNull() | F.isnan(F.col(col))).count()
            null_pct = round((null_count / total_rows) * 100, 2) if total_rows > 0 else 0
            col_profile = {
                "column_name": col,
                "data_type": str(field.dataType),
                "distinct_count": distinct_count,
                "null_count": null_count,
                "null_percentage": null_pct
            }
            if isinstance(field.dataType, (IntegerType, LongType, DoubleType)):
                stats = df.select(
                    F.min(col).alias("min"),
                    F.max(col).alias("max"),
                    F.mean(col).alias("mean"),
                    F.stddev(col).alias("stddev")
                ).first().asDict()
                col_profile["numeric_stats"] = {k: round(v, 2) if v is not None else None for k, v in stats.items()}

            profile_summary["column_profiles"].append(col_profile)

        return profile_summary
