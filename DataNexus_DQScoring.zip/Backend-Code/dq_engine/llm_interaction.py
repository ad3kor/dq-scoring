# dq_engine/llm_interaction.py
from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Union
import httpx
import tiktoken
from dq_utils.config_manager import ConfigManager

logger = logging.getLogger(__name__)


class GroqLLMInteraction:
    """
    Interact with Groq LLM for Data Quality rule suggestion.
    """

    DEFAULT_GROQ_MODEL = "deepseek-r1-distill-llama-70b"
    MAX_TOKENS_DEFAULT = 8192

    def __init__(
        self,
        config_manager_instance: "ConfigManager",
        llm_model_name: Optional[str] = None,
        max_prompt_tokens: Optional[int] = None
    ):
        self.config_mgr = config_manager_instance
        self.api_key = self.config_mgr.get_config(
            "GROQ_API_KEY", is_secret=True, secret_scope="groq_credentials"
        )
        self.api_url = self.config_mgr.get_config(
            "GROQ_API_URL",
            default="https://api.groq.com/openai/v1/chat/completions"
        )
        self.model_name = llm_model_name or self.DEFAULT_GROQ_MODEL
        self.model_max_total_tokens = self._get_max_tokens_for_model(self.model_name)
        self.max_prompt_tokens = max_prompt_tokens or int(self.model_max_total_tokens * 0.75)

        try:
            self.tokenizer = tiktoken.encoding_for_model("gpt-3.5-turbo")
        except Exception:
            self.tokenizer = tiktoken.get_encoding("cl100k_base")

    def _get_max_tokens_for_model(self, model_name: str) -> int:
        for part in reversed(model_name.split("-")):
            if part.isdigit():
                return int(part)
        return self.MAX_TOKENS_DEFAULT

    def _truncate_prompt(self, prompt: str) -> str:
        tokens = self.tokenizer.encode(prompt)
        if len(tokens) > self.max_prompt_tokens:
            return self.tokenizer.decode(tokens[: self.max_prompt_tokens])
        return prompt

    async def _call_groq_api(
        self,
        prompt: str,
        is_json_response: bool = False,
        json_schema_obj: Optional[Dict[str, Any]] = None
    ) -> Optional[Union[Dict[str, Any], str]]:
        if not self.api_key:
            logger.error("Groq API key not configured.")
            return None

        content = self._truncate_prompt(prompt)
        payload: Dict[str, Any] = {
            "model": self.model_name,
            "messages": [{"role": "user", "content": content}]
        }
        if is_json_response and json_schema_obj:
            payload["response_format"] = {"type": "json_object"}

        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        async with httpx.AsyncClient(timeout=60) as client:
            try:
                response = await client.post(self.api_url, headers=headers, json=payload)
                response.raise_for_status()
                result = response.json()
                msg = result["choices"][0]["message"]["content"]
                if is_json_response:
                    return json.loads(msg)
                return msg
            except Exception:
                logger.error("Groq API call failed.", exc_info=True)
                return None

    async def suggest_dq_rules(
        self, data_profile: Dict[str, Any], num_suggestions: int = 5
    ) -> Optional[List[Dict[str, Any]]]:
        if "error" in data_profile:
            return None
        prompt = f"Profile: {json.dumps(data_profile)}\nSuggest {num_suggestions} rules."
        return await self._call_groq_api(prompt, is_json_response=True, json_schema_obj={})
