# dq_engine/metrics_calculator.py
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType
)

logger = logging.getLogger(__name__)


class DQMetricsCalculator:
    """
    Calculates Data Quality metrics based on rule execution outcomes.
    """

    def __init__(self, spark_session: SparkSession):
        self.spark = spark_session

    def calculate_rule_and_dimension_scores(
        self,
        total_records_in_table: int,
        all_failing_records_df: Optional[DataFrame],
        rules_config_df: DataFrame
    ) -> Dict[str, Any]:
        results: Dict[str, Any] = {
            "overall_dq_score": 100.0,
            "dimensions": {},
            "rules": {}
        }

        if rules_config_df.rdd.isEmpty():
            return results

        if total_records_in_table == 0:
            for row in rules_config_df.collect():
                results["rules"][row.rule_id] = {
                    **row.asDict(),
                    "fail_count": 0,
                    "pass_count": 0,
                    "total_applicable_records": 0,
                    "pass_percentage": 100.0
                }
            for dim in rules_config_df.select("dimension").distinct().rdd.flatMap(lambda x: x).collect():
                results["dimensions"][dim] = {"score": 100.0, "weight_sum_rules": 0.0}
            return results

        if all_failing_records_df and not all_failing_records_df.rdd.isEmpty():
            fail_counts = all_failing_records_df.groupBy("dq_rule_id") \
                .agg(F.count("*").alias("fail_count"))
        else:
            schema = StructType([
                StructField("dq_rule_id", StringType()),
                StructField("fail_count", LongType())
            ])
            fail_counts = self.spark.createDataFrame([], schema)

        stats = rules_config_df.alias("r").join(
            fail_counts.alias("f"),
            F.col("r.rule_id") == F.col("f.dq_rule_id"),
            "left"
        ).select(
            F.col("r.rule_id"),
            F.col("r.rule_name"),
            F.col("r.dimension"),
            F.col("r.weight"),
            F.coalesce(F.col("f.fail_count"), F.lit(0)).alias("fail_count")
        )

        stats = stats.withColumn("total_applicable_records", F.lit(total_records_in_table)) \
                     .withColumn("pass_count", F.col("total_applicable_records") - F.col("fail_count")) \
                     .withColumn("pass_percentage", (F.col("pass_count") / F.col("total_applicable_records")) * 100)

        for row in stats.collect():
            results["rules"][row.rule_id] = row.asDict()

        weighted = stats.filter(F.col("weight") > 0)
        if weighted.rdd.isEmpty():
            avg_pass = stats.agg(F.avg("pass_percentage")).first()[0] or 100.0
            results["overall_dq_score"] = round(avg_pass, 2)
            for row in stats.groupBy("dimension").agg(F.avg("pass_percentage").alias("score")).collect():
                results["dimensions"][row.dimension] = {"score": round(row.score, 2), "weight_sum_rules": 0.0}
            return results

        dim_scores = weighted.groupBy("dimension").agg(
            (F.sum(F.col("pass_percentage") * F.col("weight")) / F.sum("weight")).alias("dimension_score"),
            F.sum("weight").alias("weight_sum")
        )
        overall = dim_scores.agg(
            (F.sum(F.col("dimension_score") * F.col("weight_sum")) / F.sum("weight_sum")).alias("overall_score")
        ).first().overall_score

        results["overall_dq_score"] = round(overall, 2)
        for row in dim_scores.collect():
            results["dimensions"][row.dimension] = {
                "score": round(row.dimension_score, 2),
                "weight_sum_rules": row.weight_sum
            }

        return results
