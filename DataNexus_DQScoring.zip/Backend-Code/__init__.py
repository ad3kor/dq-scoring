import streamlit as st
import pandas as pd
import time
import re # Added for regex in Accuracy
import json # Added for params in Accuracy (Range Check)

# --- Page Configuration ---
st.set_page_config(
    page_title="DQ App - Phase 1",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- Helper Functions & Mock Data ---
def mock_dq_processing(data_source_name, rules, data_sample):
    """Simulates a DQ processing engine (like a Spark job)."""
    st.info(f"🚀 Starting DQ processing for '{data_source_name}'...")
    log_messages = [
        f"[INFO] Connecting to data source: {data_source_name}",
        f"[INFO] Applying {len(rules)} DQ rules...",
    ]

    results = {"overall_dq_score": 0, "dimension_scores": {}, "rule_results": []}
    num_rules = len(rules)
    if num_rules == 0:
        log_messages.append("[WARNING] No DQ rules defined. Skipping processing.")
        st.warning("No DQ rules defined to process.")
        results["overall_dq_score"] = None # Or some other indicator for no rules
        return results, log_messages

    passed_rules_count = 0

    if data_sample is not None and not data_sample.empty:
        log_messages.append(f"[INFO] Analyzing {len(data_sample)} sample records.")
        for i, rule in enumerate(rules):
            progress = (i + 1) / num_rules
            log_messages.append(f"[PROGRESS] Processing rule {i+1}/{num_rules}: '{rule['name']}' on column '{rule['column']}' ({rule['dimension']}/{rule['type']})")
            time.sleep(0.5) # Simulate processing time

            rule_passed = True # Assume rule passes by default
            log_detail = "Default pass"

            if rule['column'] not in data_sample.columns:
                log_messages.append(f"  [WARNING] Column '{rule['column']}' not found in data sample for rule '{rule['name']}'. Skipping specific check.")
                rule_passed = False # Or treat as a failure, or skip scoring for this rule
                log_detail = f"Column '{rule['column']}' not found."
            else:
                # --- Completeness Check ---
                if rule['dimension'] == "Completeness" and rule['type'] == "Completeness":
                    null_count = data_sample[rule['column']].isnull().sum()
                    if null_count == 0:
                        rule_passed = True
                        log_detail = f"All records are non-null in '{rule['column']}'."
                    else:
                        rule_passed = False
                        log_detail = f"Found {null_count} nulls in '{rule['column']}'."
                    log_messages.append(f"  [DETAIL] Completeness check on '{rule['column']}': {log_detail}")

                # --- Uniqueness Check ---
                elif rule['dimension'] == "Uniqueness" and rule['type'] == "Uniqueness":
                    duplicate_count = data_sample[rule['column']].duplicated().sum()
                    if duplicate_count == 0:
                        rule_passed = True
                        log_detail = f"All records are unique in '{rule['column']}'."
                    else:
                        rule_passed = False
                        log_detail = f"Found {duplicate_count} duplicates in '{rule['column']}'."
                    log_messages.append(f"  [DETAIL] Uniqueness check on '{rule['column']}': {log_detail}")

                # --- Accuracy Checks ---
                elif rule['dimension'] == "Accuracy":
                    if rule['type'] == "Format (Regex)":
                        # Mock: Check if email column contains '@'
                        # A real implementation would use rule['params'] for the regex pattern
                        if 'email' in rule['column'].lower(): # Simple check for email-like column
                            valid_formats = data_sample[rule['column']].astype(str).str.contains('@', na=False)
                            num_valid = valid_formats.sum()
                            num_total_non_na = data_sample[rule['column']].notna().sum()
                            if num_total_non_na > 0:
                                rule_passed = (num_valid == num_total_non_na)
                                log_detail = f"{num_valid}/{num_total_non_na} non-null records in '{rule['column']}' contain '@'."
                            else:
                                rule_passed = True # No non-null data to check
                                log_detail = f"No non-null data in '{rule['column']}' to check format."
                        else: # Fallback for other columns
                            rule_passed = (i % 2 == 0) # Random pass/fail for non-email columns
                            log_detail = f"Mock format check: {'Passed' if rule_passed else 'Failed'}."
                        log_messages.append(f"  [DETAIL] Accuracy (Format) on '{rule['column']}': {log_detail}")

                    elif rule['type'] == "Range Check":
                        # Mock: Check if quantity > 0
                        # A real implementation would parse min/max from rule['params']
                        if 'quantity' in rule['column'].lower() or 'age' in rule['column'].lower(): # Simple check for quantity-like column
                            try:
                                numeric_column = pd.to_numeric(data_sample[rule['column']], errors='coerce')
                                valid_range = numeric_column[numeric_column.notna()] > 0
                                num_valid = valid_range.sum()
                                num_total_numeric_non_na = numeric_column.notna().sum()
                                if num_total_numeric_non_na > 0:
                                    rule_passed = (num_valid == num_total_numeric_non_na)
                                    log_detail = f"{num_valid}/{num_total_numeric_non_na} numeric non-null records in '{rule['column']}' are > 0."
                                else:
                                    rule_passed = True # No numeric non-null data
                                    log_detail = f"No numeric non-null data in '{rule['column']}' for range check."
                            except Exception as e:
                                rule_passed = False
                                log_detail = f"Error during range check on '{rule['column']}': {e}"
                        else: # Fallback for other columns
                            rule_passed = (i % 2 != 0) # Random pass/fail
                            log_detail = f"Mock range check: {'Passed' if rule_passed else 'Failed'}."
                        log_messages.append(f"  [DETAIL] Accuracy (Range) on '{rule['column']}': {log_detail}")
                    else: # Fallback for other accuracy types
                        rule_passed = (i % 2 == 0)
                        log_detail = f"Generic accuracy check: {'Passed' if rule_passed else 'Failed'}."
                        log_messages.append(f"  [DETAIL] Accuracy (Other) on '{rule['column']}': {log_detail}")


                # --- Consistency Check ---
                elif rule['dimension'] == "Consistency":
                    # Mock: If 'email' (rule['column']) is present, 'signup_date' (related_column) must be present.
                    # This is a highly specific mock for the "ProductionDB_Customers_Table" data.
                    # A real system would parse rule['params'] for related columns and conditions.
                    related_column = 'signup_date' # Example related column
                    if rule['column'] == 'email' and related_column in data_sample.columns:
                        consistent_count = 0
                        relevant_rows = 0
                        for _, row_data in data_sample.iterrows():
                            if pd.notna(row_data[rule['column']]): # If primary column is not null
                                relevant_rows +=1
                                if pd.notna(row_data[related_column]): # Check if related column is also not null
                                    consistent_count += 1
                        if relevant_rows > 0:
                            rule_passed = (consistent_count == relevant_rows) # All relevant rows must be consistent
                            log_detail = f"{consistent_count}/{relevant_rows} records consistent between '{rule['column']}' and '{related_column}'."
                        else:
                            rule_passed = True # No relevant data to check for inconsistency
                            log_detail = f"No relevant data to check consistency between '{rule['column']}' and '{related_column}'."
                    else: # Fallback for other consistency rules or different datasets
                        rule_passed = (i % 3 == 0) # Different random pattern
                        log_detail = f"Mock consistency check: {'Passed' if rule_passed else 'Failed'}."
                    log_messages.append(f"  [DETAIL] Consistency check on '{rule['column']}': {log_detail}")
                else: # Fallback for unhandled dimension/type combinations
                    rule_passed = (i % 2 == 0) # Original random pass/fail
                    log_detail = f"Generic mock rule execution: {'Passed' if rule_passed else 'Failed'}."
                    log_messages.append(f"  [DETAIL] Generic check for '{rule['column']}': {log_detail}")


            results["rule_results"].append({
                "name": rule['name'],
                "dimension": rule['dimension'],
                "type": rule['type'],
                "column": rule['column'],
                "status": "PASS" if rule_passed else "FAIL",
                "details": log_detail
            })
            if rule_passed:
                passed_rules_count +=1
    else:
        log_messages.append("[WARNING] No data sample provided or data sample is empty. Mocking rule outcomes.")
        for i, rule in enumerate(rules): # Simplified mocking if no data
            rule_passed = (i % 2 == 0)
            results["rule_results"].append({
                "name": rule['name'],
                "dimension": rule['dimension'],
                "type": rule['type'],
                "column": rule['column'],
                "status": "PASS" if rule_passed else "FAIL",
                "details": f"Mocked due to no data sample"
            })
            if rule_passed:
                passed_rules_count +=1

    results["overall_dq_score"] = (passed_rules_count / num_rules) * 100 if num_rules > 0 else 0

    dimensions = ["Accuracy", "Completeness", "Consistency", "Uniqueness"]
    for dim in dimensions:
        dim_rules = [r for r in results["rule_results"] if r["dimension"] == dim]
        if dim_rules:
            passed_dim_rules = sum(1 for r in dim_rules if r["status"] == "PASS")
            results["dimension_scores"][dim] = (passed_dim_rules / len(dim_rules)) * 100
        else:
            results["dimension_scores"][dim] = None

    log_messages.append(f"[INFO] DQ Processing completed. Overall Score: {results['overall_dq_score']:.2f}%")
    st.success(f"✅ DQ Processing completed for '{data_source_name}'!")
    return results, log_messages

# --- Initialize Session State ---
if 'dq_rules_phase1' not in st.session_state:
    st.session_state.dq_rules_phase1 = []
if 'logs_phase1' not in st.session_state:
    st.session_state.logs_phase1 = ["[INFO] Application started. Ready for DQ configuration."]
if 'dq_results_phase1' not in st.session_state:
    st.session_state.dq_results_phase1 = None
if 'uploaded_file_data_phase1' not in st.session_state:
    st.session_state.uploaded_file_data_phase1 = None
if 'uploaded_file_name_phase1' not in st.session_state: # To store the name of the uploaded file
    st.session_state.uploaded_file_name_phase1 = None


# --- Sidebar for Configuration ---
with st.sidebar:
    st.header("⚙️ Phase 1 Configuration")
    st.markdown("""
    **Core Infrastructure & Foundational DQ Engine**

    This phase focuses on:
    1.  Establishing core environment concepts.
    2.  Developing initial ingestion pipelines (mocked).
    3.  Implementing the DQ processing engine with manual rules.
    """)

    st.subheader("🌍 Environment Setup (Conceptual)")
    st.info("""
    -   **Databricks Workspaces**: Dev, Stg, Prod (Conceptual)
    -   **Unity Catalog**: Central governance (Conceptual)
    -   **Secret Management**: Secure credentials (Conceptual)
    """)

    st.subheader("📊 Data Source Selection")
    data_source_options = ["Upload CSV/Parquet", "Mock Database A (Customers)", "Mock Cloud Storage (Orders)"]
    selected_data_source_type = st.selectbox("Select Data Source Type", data_source_options, key="ph1_dst_select")

    current_data_source_name = "N/A"
    if selected_data_source_type == "Upload CSV/Parquet":
        uploaded_file = st.file_uploader("Upload your data file (CSV or Parquet)", type=["csv", "parquet"], key="ph1_uploader")
        if uploaded_file:
            st.session_state.uploaded_file_name_phase1 = uploaded_file.name
            current_data_source_name = uploaded_file.name
            try:
                if uploaded_file.name.endswith('.csv'):
                    st.session_state.uploaded_file_data_phase1 = pd.read_csv(uploaded_file)
                elif uploaded_file.name.endswith('.parquet'):
                    st.session_state.uploaded_file_data_phase1 = pd.read_parquet(uploaded_file)
                st.success(f"Uploaded '{uploaded_file.name}' successfully!")
            except Exception as e:
                st.error(f"Error reading file: {e}")
                st.session_state.uploaded_file_data_phase1 = None
                st.session_state.uploaded_file_name_phase1 = None
        elif st.session_state.uploaded_file_name_phase1: # If a file was previously uploaded
            current_data_source_name = st.session_state.uploaded_file_name_phase1
            # Data is already in st.session_state.uploaded_file_data_phase1
        else:
            current_data_source_name = "No file uploaded"
            st.session_state.uploaded_file_data_phase1 = None


    elif selected_data_source_type == "Mock Database A (Customers)":
        current_data_source_name = "ProductionDB_Customers_Table"
        st.session_state.uploaded_file_data_phase1 = pd.DataFrame({
            'customer_id': [1, 2, 3, 4, 2, 6],
            'email': ['a@test.com', 'b@test.com', None, 'd_test.com', 'b@test.com', 'f@test.com'], # Added an invalid email
            'age': [25, 30, -5, 40, 30, 28], # Added a negative age
            'signup_date': ['2023-01-01', '2023-01-15', '2023-02-01', '2023-02-10', '2023-01-15', None] # Added a None for consistency check
        })
        st.caption(f"Using mock data for {current_data_source_name}")
    else: # Mock Cloud Storage (Orders)
        current_data_source_name = "S3_Orders_Bucket_DailyFeed"
        st.session_state.uploaded_file_data_phase1 = pd.DataFrame({
            'order_id': [101, 102, 103, 103, 105, 106],
            'product_id': ['P10', 'P11', 'P12', 'P12', 'P13', 'P14'],
            'quantity': [1, None, 2, 2, 3, 0], # Added a zero quantity
            'order_date': ['2023-03-01', '2023-03-01', '2023-03-02', '2023-03-02', '2023-03-03', '2023-03-04']
        })
        st.caption(f"Using mock data for {current_data_source_name}")

    st.markdown("---")
    st.subheader("📜 Manual DQ Rule Definition")
    # Ensure rule types are comprehensive enough for dimensions
    rule_type_options = ["Completeness", "Uniqueness", "Format (Regex)", "Range Check", "Cross-Column Consistency"]

    with st.form("dq_rule_form_phase1", clear_on_submit=True):
        rule_name = st.text_input("Rule Name (e.g., 'Email Format Check')")
        rule_dimension = st.selectbox("DQ Dimension", ["Accuracy", "Completeness", "Consistency", "Uniqueness"])
        rule_column = st.text_input("Target Column Name (e.g., 'email')")
        # Filter rule types based on dimension for better UX, or keep all and let logic handle
        rule_type = st.selectbox("Rule Type", rule_type_options)
        rule_params = st.text_area("Rule Parameters (e.g., regex for Format, JSON for Range {'min':0,'max':100}, JSON for Consistency {'related_column':'col_b'})")

        submitted = st.form_submit_button("Add DQ Rule")
        if submitted and rule_name and rule_dimension and rule_column and rule_type:
            st.session_state.dq_rules_phase1.append({
                "name": rule_name,
                "dimension": rule_dimension,
                "column": rule_column,
                "type": rule_type,
                "params": rule_params
            })
            st.success(f"Rule '{rule_name}' added!")
            st.session_state.logs_phase1.append(f"[CONFIG] DQ Rule '{rule_name}' ({rule_dimension}/{rule_type}) added for column '{rule_column}'.")
        elif submitted:
            st.error("Please fill in all rule fields.")


# --- Main Page Layout ---
st.title("📊 Data Quality Application - Phase 1")
st.markdown("Foundational DQ Engine with Manual Rule Definition")

# Display Data Sample if available
if st.session_state.uploaded_file_data_phase1 is not None:
    with st.expander("View Data Sample (First 10 rows)", expanded=False):
        st.dataframe(st.session_state.uploaded_file_data_phase1.head(10))

col1, col2 = st.columns(2)

with col1:
    st.subheader("📋 Defined DQ Rules")
    if not st.session_state.dq_rules_phase1:
        st.info("No DQ rules defined yet. Add rules using the sidebar form.")
    else:
        rules_to_remove = []
        for i, rule in enumerate(st.session_state.dq_rules_phase1):
            with st.expander(f"{rule['name']} ({rule['dimension']}/{rule['type']} on '{rule['column']}')"):
                st.json(rule)
                if st.button(f"Remove Rule '{rule['name']}'", key=f"remove_rule_{i}_phase1"):
                    rules_to_remove.append(i) # Mark for removal

        if rules_to_remove:
            for index in sorted(rules_to_remove, reverse=True): # Remove from end to avoid index shifts
                removed_rule = st.session_state.dq_rules_phase1.pop(index)
                st.session_state.logs_phase1.append(f"[CONFIG] DQ Rule '{removed_rule['name']}' removed.")
            st.rerun()


with col2:
    st.subheader("🚀 Trigger DQ Assessment")
    st.markdown(f"**Target Data Source:** `{current_data_source_name}`")

    if not st.session_state.dq_rules_phase1:
        st.warning("Add at least one DQ rule to run an assessment.")
    elif st.session_state.uploaded_file_data_phase1 is None and "Mock" not in selected_data_source_type :
        st.warning(f"Please upload a data file for '{current_data_source_name}' or select a mock data source.")
    else:
        if st.button("▶️ Run DQ Assessment", type="primary", use_container_width=True):
            st.session_state.logs_phase1.append(f"[ACTION] DQ Assessment triggered for '{current_data_source_name}'.")
            with st.spinner(f"Running DQ assessment on '{current_data_source_name}'... This is a simulation."):
                results, new_logs = mock_dq_processing(current_data_source_name, st.session_state.dq_rules_phase1, st.session_state.uploaded_file_data_phase1)
                st.session_state.dq_results_phase1 = results
                st.session_state.logs_phase1.extend(new_logs)


# --- Display DQ Results ---
if st.session_state.dq_results_phase1:
    st.subheader("📈 DQ Assessment Results")
    results = st.session_state.dq_results_phase1

    if results["overall_dq_score"] is not None:
        st.metric("Overall DQ Score", f"{results['overall_dq_score']:.2f}%")

        st.markdown("**Dimension Scores:**")
        # Ensure all dimensions are present in the scores dictionary for consistent display
        all_dims = ["Accuracy", "Completeness", "Consistency", "Uniqueness"]
        display_scores = {dim: results['dimension_scores'].get(dim) for dim in all_dims}

        dim_cols = st.columns(len(all_dims))
        for idx, (dim, score) in enumerate(display_scores.items()):
            with dim_cols[idx]:
                st.metric(dim, f"{score:.2f}%" if score is not None else "N/A")

        st.markdown("**Rule Details:**")
        if results['rule_results']:
            results_df = pd.DataFrame(results['rule_results'])
            st.dataframe(results_df[['name', 'dimension', 'type', 'column', 'status', 'details']])
        else:
            st.info("No rules were processed to show details.")
    else:
        st.info("DQ Assessment was run, but no rules were defined or applicable to produce a score.")


# --- Logging Area ---
st.subheader("📝 Application Logs")
log_container = st.container(height=300)
with log_container:
    for log_entry in reversed(st.session_state.logs_phase1): # Show newest logs first
        if "[INFO]" in log_entry:
            st.text(log_entry)
        elif "[WARNING]" in log_entry:
            st.warning(log_entry)
        elif "[ERROR]" in log_entry:
            st.error(log_entry)
        elif "[CONFIG]" in log_entry:
            st.caption(log_entry)
        elif "[ACTION]" in log_entry:
            st.caption(f"➡️ {log_entry}")
        elif "[PROGRESS]" in log_entry:
            st.caption(f"⏳ {log_entry}")
        else:
            st.text(log_entry)

st.caption("End of Phase 1 Application.")
