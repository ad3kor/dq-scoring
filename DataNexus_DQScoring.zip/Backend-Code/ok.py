# Databricks notebook source
# MAGIC %pip install python-dotenv langchain-groq langchain langchain-community langchain-core weaviate-client pyspark langchain-weaviate asyncio playwright Jinja2 ray databricks-vectorsearch requests delta-spark httpx sentence-transformers
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %pip install tiktoken databricks-sdk

# COMMAND ----------

# ① Clean out any partial installs (optional but tidy)
%pip uninstall -y weaviate          # gets rid of the 0.1.2 stub
%pip uninstall -y weaviate-client   # in case an old v3 is still around
%pip uninstall -y protobuf google-api-core proto-plus

# modern client + modern protobuf + Google stack that accepts protobuf 5.x
%pip install --upgrade \
"weaviate-client>=4.14.0" \
"protobuf>=5.29,<6" \
"google-api-core>=2.24.2" \
"googleapis-common-protos>=1.63.0" \
"proto-plus>=1.25.0"



# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# Notebook: Optimized DQ Pipeline Launcher with Excel/JSON support and Reduced Spark Jobs
%python
# 1️⃣ Setup Python path, env, and logging
import sys, os, json, asyncio, logging
from datetime import datetime
import nest_asyncio
from dotenv import load_dotenv

# 2️⃣ Spark imports
from pyspark.sql import SparkSession, DataFrame, Row
from pyspark.sql.types import StructType
from pyspark.sql.functions import from_json, col, broadcast
from typing import Any, Dict
import pandas as pd

# 3️⃣ Load .env and add user workspace to Python path
load_dotenv()
sys.path.insert(0, '/Workspace/Users/acharjeerishab@fofdlm.onmicrosoft.com')

# 4️⃣ Initialize logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 5️⃣ Import ConfigManager + helpers + pipeline entrypoint
from dq_utils.config_manager import ConfigManager
from dq_utils.input_manager import load_input_dataframe as original_load_input
from dq_utils.input_manager import create_input_widgets
from dq_application_backend_main import main_dq_pipeline_async

# 6️⃣ Define expected parameters (with three-part FQNs for DQ tables)
EXPECTED_PARAMS: Dict[str, Any] = {
    'source_type': 'delta_table',                  # delta_table | parquet | csv | excel | json | jdbc | kafka
    'input_table_fqn': '',                         # e.g. my_catalog.raw_data.sales
    'input_path': '',                              # for file-based sources
    'file_format': 'parquet',                      # parquet | csv | excel | json
    'jdbc_table_or_query': '',                     # for JDBC
    'kafka_topic': '',                             # for Kafka
    'kafka_starting_offsets': 'earliest',
    'kafka_value_schema_struct_json': '{}',        # JSON string of StructType for Kafka

    # IMPORTANT: use valid three-part FQNs here (catalog.schema.table):
    'dq_rules_table_fqn': 'my_catalog.dq_db.dq_rules',
    'dq_all_failures_table_fqn': 'my_catalog.dq_db.dq_failures',
    'audit_log_table_fqn': 'my_catalog.dq_db.audit_log',

    'output_report_uc_path_prefix': '/tmp/dq_reports',
    'report_template_dir': 'templates',
    'report_html_template_name': 'dq_report.html',
    'run_llm_rule_suggestion': 'false',
    'num_llm_rule_suggestions': '5',
    'alert_threshold': '75'
}

# 7️⃣ Initialize Spark and dbutils
spark = SparkSession.builder.appName('DQApplicationJob').getOrCreate()
dbutils = globals().get('dbutils', None)

# 8️⃣ Create widgets for all EXPECTED_PARAMS if interactive
if dbutils:
    for param, default in EXPECTED_PARAMS.items():
        dbutils.widgets.text(param, str(default), param)

    # Also add convenience widgets for file format, input path, etc.
    dbutils.widgets.text('file_format', 'parquet', 'file_format')
    dbutils.widgets.text('input_path', '', 'input_path')
    dbutils.widgets.text('input_table_fqn', '', 'input_table_fqn')
    dbutils.widgets.text('jdbc_table_or_query', '', 'jdbc_table_or_query')
    dbutils.widgets.text('kafka_topic', '', 'kafka_topic')
    dbutils.widgets.text('kafka_starting_offsets', 'earliest', 'kafka_starting_offsets')
    dbutils.widgets.text('kafka_value_schema_struct_json', '{}', 'kafka_value_schema_struct_json')
    dbutils.widgets.text('dq_rules_table_fqn', 'my_catalog.dq_db.dq_rules', 'dq_rules_table_fqn')
    dbutils.widgets.text('dq_all_failures_table_fqn', 'my_catalog.dq_db.dq_failures', 'dq_all_failures_table_fqn')
    dbutils.widgets.text('audit_log_table_fqn', 'my_catalog.dq_db.audit_log', 'audit_log_table_fqn')
    dbutils.widgets.text('output_report_uc_path_prefix', '/tmp/dq_reports', 'output_report_uc_path_prefix')
    dbutils.widgets.text('report_template_dir', 'templates', 'report_template_dir')
    dbutils.widgets.text('report_html_template_name', 'dq_report.html', 'report_html_template_name')
    dbutils.widgets.text('run_llm_rule_suggestion', 'false', 'run_llm_rule_suggestion')
    dbutils.widgets.text('num_llm_rule_suggestions', '5', 'num_llm_rule_suggestions')
    dbutils.widgets.text('alert_threshold', '75', 'alert_threshold')

# 9️⃣ Define a custom load_input_dataframe that wraps the original + adds Excel/JSON support

def load_input_dataframe(
    spark: SparkSession,
    dbutils,
    config_mgr: ConfigManager
) -> DataFrame:
    """
    Load an input DataFrame based on source_type, with support for:
     - Delta tables (three-part FQNs)
     - Parquet/CSV/JSON files
     - Excel (via pandas)
     - JDBC
     - Kafka
    """
    # Gather parameters
    params: Dict[str, Any] = {}
    for key, default in EXPECTED_PARAMS.items():
        raw = config_mgr.get_config(key, default=default)
        if key.endswith('_json') and isinstance(raw, str):
            try:
                params[key] = json.loads(raw)
            except json.JSONDecodeError:
                params[key] = default
        else:
            params[key] = raw

    source            = params.get('source_type', 'delta_table').lower()
    input_table       = params.get('input_table_fqn', '')
    input_path        = params.get('input_path', '')
    file_fmt          = params.get('file_format', 'parquet').lower()
    jdbc_query        = params.get('jdbc_table_or_query', '')
    kafka_topic       = params.get('kafka_topic', '')
    kafka_offsets     = params.get('kafka_starting_offsets', 'earliest')
    kafka_schema_json = params.get('kafka_value_schema_struct_json', '{}')

    if source == 'delta_table':
        if not input_table:
            raise ValueError("'input_table_fqn' must be provided for source_type='delta_table'.")
        # Validate three-part FQN
        parts = input_table.split('.')
        if len(parts) != 3:
            raise ValueError(f"'input_table_fqn' must be 'catalog.schema.table' (got: {input_table})")
        df = spark.table(input_table)
        df.cache()  # Cache once
        df.count()  # Materialize cache
        return df

    elif source in ('parquet', 'csv', 'json', 'excel'):
        if not input_path:
            raise ValueError("'input_path' must be provided for file-based sources.")
        fmt = source

        if fmt == 'excel':
            local_path = input_path if input_path.startswith('/Workspace/') else f'/Workspace{input_path}'
            try:
                pdf = pd.read_excel(local_path, engine='openpyxl')
            except Exception as e:
                raise ValueError(f"Failed to read Excel file at {local_path}: {e}")
            df = spark.createDataFrame(pdf)
            df.cache()
            df.count()
            return df
        else:
            reader = spark.read.format(fmt)
            if fmt == 'csv':
                reader = reader.option('header', True).option('inferSchema', True)
            if fmt == 'json':
                reader = reader.option('multiLine', True)
            df = reader.load(input_path)
            df.cache()
            df.count()
            return df

    elif source == 'jdbc':
        if not jdbc_query:
            raise ValueError("'jdbc_table_or_query' must be provided for source_type='jdbc'.")
        from dq_utils.connector_clients import ConnectorClients
        conn = ConnectorClients(spark, config_mgr)
        df = conn.read_from_jdbc(jdbc_query)
        if df is not None:
            df.cache()
            df.count()
        return df

    elif source == 'kafka':
        if not kafka_topic:
            raise ValueError("'kafka_topic' must be provided for source_type='kafka'.")
        struct = None
        if isinstance(kafka_schema_json, dict):
            struct = StructType.fromJson(kafka_schema_json)
        from dq_utils.connector_clients import ConnectorClients
        conn = ConnectorClients(spark, config_mgr)
        df = conn.read_from_kafka(kafka_topic, is_streaming=False)
        if struct is not None:
            df = (
                df.selectExpr('CAST(value AS STRING)')
                  .select(from_json(col('value'), struct).alias('data'))
                  .select('data.*')
            )
        df.cache()
        df.count()
        return df

    else:
        raise ValueError(f"Unsupported source_type: {source}")

# 🔟 Load the input DataFrame
try:
    config_mgr = ConfigManager(dbutils_instance=dbutils)
    input_df = load_input_dataframe(spark, dbutils, config_mgr)
    total_records = input_df.count() if input_df is not None else 0
    logger.info(f"Loaded input with {total_records} records.")
except Exception as e:
    logger.error(f"Failed to load input DataFrame: {e}")
    raise

# 1️⃣1️⃣ Build job_config dict from EXPECTED_PARAMS
job_config: Dict[str, Any] = {}
for key, default in EXPECTED_PARAMS.items():
    job_config[key] = config_mgr.get_config(key, default)

# 1️⃣2️⃣ Validate critical parameters
if job_config['source_type'] == 'delta_table':
    if not job_config['input_table_fqn']:
        raise ValueError("Missing required parameter 'input_table_fqn' for delta_table source.")
    # Validate three-part FQNs for DQ tables as well
    for table_key in ['dq_rules_table_fqn', 'dq_all_failures_table_fqn', 'audit_log_table_fqn']:
        fqn = job_config.get(table_key, '')
        if fqn and len(fqn.split('.')) != 3:
            raise ValueError(f"'{table_key}' must be 'catalog.schema.table' (got: {fqn})")

elif job_config['source_type'] == 'jdbc':
    if not job_config['jdbc_table_or_query']:
        raise ValueError("Missing required parameter 'jdbc_table_or_query' for jdbc source.")

elif job_config['source_type'] == 'kafka':
    if not job_config['kafka_topic']:
        raise ValueError("Missing required parameter 'kafka_topic' for kafka source.")

# 1️⃣3️⃣ Parse JSON options
for j in ['kafka_value_schema_struct_json']:
    raw = job_config.get(j, '{}')
    try:
        job_config[j] = json.loads(raw)
    except:
        logger.warning(f"Invalid JSON for {j}: {raw}. Defaulting to {{}}.")
        job_config[j] = {}

# 1️⃣4️⃣ Cast booleans and ints
job_config['run_llm_rule_suggestion'] = str(job_config.get('run_llm_rule_suggestion','false')).lower() == 'true'
try:
    job_config['num_llm_rule_suggestions'] = int(job_config.get('num_llm_rule_suggestions', 5))
except:
    job_config['num_llm_rule_suggestions'] = 5
job_config['alert_threshold'] = float(job_config.get('alert_threshold', 75))

# 1️⃣5️⃣ Add runtime context
job_config['total_records'] = total_records

# 1️⃣6️⃣ Launch the async pipeline (only once!)
nest_asyncio.apply()
asyncio.run(
    main_dq_pipeline_async(
        spark_session = spark,
        dbutils_instance = dbutils,
        job_config_dict = job_config
    )
)

# 1️⃣7️⃣ Stop Spark
spark.stop()


# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

