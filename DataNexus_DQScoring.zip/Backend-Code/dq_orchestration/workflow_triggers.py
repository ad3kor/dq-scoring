# dq_orchestration/workflow_triggers.py
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from databricks.sdk import WorkspaceClient
from dq_utils.config_manager import ConfigManager

logger = logging.getLogger(__name__)


class DatabricksWorkflowManager:
    """
    Manages Databricks Jobs programmatically using Databricks SDK.
    """

    def __init__(self, config_manager_instance: "ConfigManager"):
        self.config_mgr = config_manager_instance
        host = self.config_mgr.get_config("DATABRICKS_HOST")
        token = self.config_mgr.get_config("DATABRICKS_TOKEN", is_secret=True, secret_scope="databricks_sdk_creds")
        try:
            self.workspace_client = WorkspaceClient(host=host, token=token)
            logger.info("Databricks WorkspaceClient initialized.")
        except Exception as e:
            logger.error(f"Failed to init WorkspaceClient: {e}", exc_info=True)
            self.workspace_client = None

    def trigger_job_run(self, job_id: int, notebook_params: Optional[Dict[str, str]] = None) -> Optional[int]:
        if not self.workspace_client:
            logger.error("WorkspaceClient not initialized.")
            return None
        try:
            resp = self.workspace_client.jobs.run_now(job_id=job_id, notebook_params=notebook_params)
            logger.info(f"Triggered job {job_id}, run_id={resp.run_id}")
            return resp.run_id
        except Exception as e:
            logger.error(f"Error triggering job {job_id}: {e}", exc_info=True)
            return None

    def get_run_status(self, run_id: int) -> Optional[str]:
        if not self.workspace_client:
            logger.error("WorkspaceClient not initialized.")
            return None
        try:
            details = self.workspace_client.jobs.get_run(run_id=run_id)
            return details.state.life_cycle_state.value
        except Exception as e:
            logger.error(f"Error fetching run status for {run_id}: {e}", exc_info=True)
            return None
