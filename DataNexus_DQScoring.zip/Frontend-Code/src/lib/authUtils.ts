
"use client";

const MOCK_USER_KEY = 'DataQualityApp_currentMockUser';

// Base keys for different data types, to be suffixed with user ID
export const BASE_DS_KEY = 'dataQualityApp_dataSources';
export const BASE_RULES_KEY = 'dataQualityApp_rules'; // Used by old assessment and rules editor
export const BASE_ASSESSMENT_HISTORY_KEY = 'dataQualityApp_assessmentHistory'; // For the "Reports" page, stores multiple runs
export const BASE_REPORTS_KEY = 'dataQualityApp_reports';
export const BASE_AUDIT_LOGS_KEY = 'dataQualityApp_auditLogs';
export const BASE_DATABRICKS_SUGGESTER_CONFIG_KEY = 'dataQualityApp_databricksSuggesterConfig'; // For rules & weights from suggester
export const BASE_DATABRICKS_SUGGESTER_HISTORY_KEY = 'dataQualityApp_databricksSuggesterHistory'; // For history of suggester configs
export const BASE_DATANEXUS_ASSESSMENT_RESULTS_KEY = 'dataQualityApp_dataNexusAssessmentResults'; // Stores latest result per data source for Data Nexus Assessment page
export const BASE_DATANEXUS_ANALYSIS_HISTORY_KEY = 'dataQualityApp_dataNexusAnalysisHistory'; // Stores history of sampling jobs on Data Nexus page


export function setCurrentMockUser(username: string): void {
  if (typeof window !== 'undefined') {
    window.localStorage.setItem(MOCK_USER_KEY, username);
  }
}

export function getCurrentMockUser(): string | null {
  if (typeof window !== 'undefined') {
    return window.localStorage.getItem(MOCK_USER_KEY);
  }
  return null;
}

export function clearCurrentMockUser(): void {
  if (typeof window !== 'undefined') {
    window.localStorage.removeItem(MOCK_USER_KEY);
  }
}

export function getUserSpecificKey(baseKey: string, usernameOverride?: string | null): string {
  const user = usernameOverride || getCurrentMockUser();
  if (!user) {
    console.warn(`No current user for key: ${baseKey}. Using a generic key or this might fail.`);
    return `${baseKey}_guest`; 
  }
  return `${baseKey}_${user}`;
}

export interface AuditLog {
  id: string;
  timestamp: Date;
  user: string; 
  action: string;
  details: string;
  entityType?: string;
  entityId?: string;
}

export function addAuditLog(
  action: string,
  details: string,
  entityType?: string,
  entityId?: string
): void {
  if (typeof window === 'undefined') {
    return;
  }
  
  const currentUser = getCurrentMockUser();
  if (!currentUser) {
    console.warn("Audit log skipped: No current user session.");
    return; 
  }

  try {
    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date(),
      user: currentUser, 
      action,
      details,
      entityType,
      entityId,
    };

    const storageKey = getUserSpecificKey(BASE_AUDIT_LOGS_KEY, currentUser);
    const existingLogsItem = window.localStorage.getItem(storageKey);
    let logs: AuditLog[] = [];

    if (existingLogsItem) {
      try {
        logs = JSON.parse(existingLogsItem).map((log: any) => ({
          ...log,
          timestamp: new Date(log.timestamp)
        }));
      } catch (e) {
        console.error("Error parsing existing audit logs, resetting.", e);
        logs = [];
      }
    }

    const updatedLogs = [newLog, ...logs].slice(0, 200); // Keep max 200 logs
    window.localStorage.setItem(storageKey, JSON.stringify(updatedLogs));
  } catch (error) {
    console.error("Failed to add audit log:", error);
  }
}

