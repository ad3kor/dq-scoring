
"use client";

// This file might become redundant if addAuditLog is fully managed within authUtils.ts
// For now, keeping it separate in case of future divergence.
// If addAuditLog is exclusively in authUtils.ts, this file could be removed or repurposed.

import { getCurrentMockUser, getUserSpecificKey, BASE_AUDIT_LOGS_KEY } from '@/lib/authUtils';

export interface AuditLog {
  id: string;
  timestamp: Date;
  user: string; 
  action: string;
  details: string;
  entityType?: string;
  entityId?: string;
}

// If you want to keep addAuditLog here, ensure authUtils.ts doesn't also define it,
// or one should call the other to avoid duplication.
// The current setup in the prompt moves addAuditLog to authUtils.ts.
// If sticking to that, this file might only export the AuditLog interface,
// or authUtils.ts can export it too.

// Example: If authUtils.ts is the source of truth for addAuditLog:
/*
export function addAuditLog(
  action: string,
  details: string,
  entityType?: string,
  entityId?: string
): void {
  // This would call the one from authUtils or be removed.
  // For now, assuming the primary implementation is in authUtils as per the other file change.
  console.warn("auditUtils.ts addAuditLog called - ensure this is intended if also defined in authUtils.ts");
}
*/

// To maintain separation and use the version from authUtils.ts, 
// other files should import addAuditLog from authUtils.ts.
// This file can simply export the interface if needed elsewhere independently.
// However, to avoid circular dependencies or confusion, it's often cleaner
// to have utilities and their associated types in the same place.

// Given the prompt aims to consolidate `addAuditLog` in `authUtils.ts`,
// this file could be deprecated or just export the type. For safety,
// let's assume `authUtils.ts` is now the primary provider of `addAuditLog`.
// This file might be removed in a later refactor if `AuditLog` type is also moved.
// For now, let's leave the type definition here.
// If `addAuditLog` is also present here, ensure it's not conflicting with authUtils.

// If the addAuditLog from authUtils is the canonical one, this file
// should not re-declare it, or this version should be removed.
// The user's context implies it was moved to authUtils.
// So, this file may become just for the type if not also moved.
// Let's comment out the function here to avoid conflict, assuming authUtils has it.
/*
export function addAuditLog(
  action: string,
  details: string,
  entityType?: string,
  entityId?: string
): void {
  if (typeof window === 'undefined') {
    return;
  }
  
  const currentUser = getCurrentMockUser();
  if (!currentUser) {
    console.warn("Audit log skipped: No current user session.");
    return;
  }

  try {
    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date(),
      user: currentUser,
      action,
      details,
      entityType,
      entityId,
    };

    const storageKey = getUserSpecificKey(BASE_AUDIT_LOGS_KEY, currentUser);
    const existingLogsItem = window.localStorage.getItem(storageKey);
    let logs: AuditLog[] = [];

    if (existingLogsItem) {
      try {
        logs = JSON.parse(existingLogsItem).map((log: any) => ({
          ...log,
          timestamp: new Date(log.timestamp)
        }));
      } catch (e) {
        console.error("Error parsing existing audit logs, resetting.", e);
        logs = [];
      }
    }

    const updatedLogs = [newLog, ...logs];
    window.localStorage.setItem(storageKey, JSON.stringify(updatedLogs));
  } catch (error) {
    console.error("Failed to add audit log:", error);
  }
}
*/
