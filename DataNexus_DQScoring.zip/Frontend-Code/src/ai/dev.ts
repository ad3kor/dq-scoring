import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-data-quality-issues.ts';
import '@/ai/flows/suggest-dq-rules.ts';