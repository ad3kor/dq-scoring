
// src/ai/flows/suggest-dq-rules.ts
'use server';

/**
 * @fileOverview This file defines a Genkit flow for suggesting data quality rules
 * based on a sample of a dataset and specified dimension weights.
 *
 * - suggestDQRules - A function that takes a data sample and weights, then suggests data quality rules.
 * - SuggestDQRulesInput - The input type for the suggestDQRules function.
 * - SuggestDQRulesOutput - The output type for the suggestDQRules function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestDQRulesInputSchema = z.object({
  dataSample: z
    .string()
    .describe(
      'A sample of the dataset in JSON format. Include column names and representative data.'
    ),
  completenessWeight: z.number().describe('Weight of completeness as a percentage (0-100).'),
  accuracyWeight: z.number().describe('Weight of accuracy as a percentage (0-100).'),
  consistencyWeight: z.number().describe('Weight of consistency as a percentage (0-100).'),
  uniquenessWeight: z.number().describe('Weight of uniqueness as a percentage (0-100).'),
});
export type SuggestDQRulesInput = z.infer<typeof SuggestDQRulesInputSchema>;

interface SuggestedRuleInternal {
  description: string;
  column: string;
  type: string; // Added type field
  rationale: string;
  reasonForColumnChoice: string;
  impactOnDimension: string;
  weight: number;
  dimension: "Accuracy" | "Completeness" | "Consistency" | "Uniqueness" | "Other";
}

const SuggestDQRulesOutputSchema = z.object({
  suggestedRules: z
    .string()
    .describe(
      'A JSON array string of suggested data quality rules. Each rule object MUST include: "description" (string), "column" (string, the column it applies to - MUST BE A COLUMN FROM THE INPUT dataSample), "type" (string, e.g., "IS_NOT_NULL", "IS_UNIQUE", "REGEX_MATCH", "RANGE_CHECK", "SQL_EXPRESSION", "CUSTOM_LOGIC", "FORMAT_VALIDATION", "TYPE_CHECK"), "rationale" (string, for the rule suggestion), "reasonForColumnChoice" (string, explaining why this column was chosen for this rule based on observed data or best practices for its data type), "impactOnDimension" (string, explaining how this rule helps improve the specified data quality dimension), "weight" (number, 0-100, rule-specific importance), and "dimension" (string, one of "Accuracy", "Completeness", "Consistency", "Uniqueness", "Other") indicating the primary data quality dimension this rule addresses.'
    ),
});
export type SuggestDQRulesOutput = z.infer<typeof SuggestDQRulesOutputSchema>;

export async function suggestDQRules(input: SuggestDQRulesInput): Promise<SuggestDQRulesOutput> {
  return suggestDQRulesFlow(input);
}

const suggestDQRulesPrompt = ai.definePrompt({
  name: 'suggestDQRulesPrompt',
  input: {
    schema: SuggestDQRulesInputSchema,
  },
  output: {
    schema: SuggestDQRulesOutputSchema,
  },
  prompt: `You are an expert data quality engineer. Your SOLE AND PRIMARY task is to suggest practical and actionable data quality rules based **EXCLUSIVELY on the specific content, structure, anomalies, patterns, data types, and formats observed in the provided 'Dataset Sample' JSON.** Your rules MUST be tailored to this sample. Do NOT generate generic rules.
You MUST return a well-formed JSON array string in the 'suggestedRules' field of your output.
If the 'dataSample' input JSON array is not empty and contains objects with columns, your returned 'suggestedRules' JSON array MUST NOT BE EMPTY.

**CRITICAL INSTRUCTION 1: Your suggestions MUST ONLY target columns that are explicitly present as keys in the objects within the 'Dataset Sample' JSON. DO NOT invent columns or refer to columns not found in the sample. The 'column' field in each rule you generate MUST be one of these existing column names from the sample.**

**CRITICAL INSTRUCTION 2: For EACH AND EVERY column name present as a key in the objects within the 'Dataset Sample' JSON array, you MUST generate AT LEAST ONE data quality rule object.** Systematically analyze each column.

**CRITICAL INSTRUCTION 3: You MUST generate rules that cover ALL FOUR of the primary Data Quality dimensions: Accuracy, Completeness, Consistency, and Uniqueness. Ensure your output contains rules assigned to each of these dimensions based on your analysis of the sample. Do not focus on only one dimension.**

Dataset Sample:
\`\`\`json
{{{dataSample}}}
\`\`\`

Consider these Data Quality dimensions and their user-defined importance weights (these weights should influence rule-specific weights you assign, and help you decide which dimension a rule primarily targets if it could apply to multiple):
Completeness Weight: {{{completenessWeight}}}%
Accuracy Weight: {{{accuracyWeight}}}%
Consistency Weight: {{{consistencyWeight}}}%
Uniqueness Weight: {{{uniquenessWeight}}}%

For each column found in the sample, analyze its data in the sample and suggest relevant rule(s) targeting one of the four dimensions.
Each suggested rule object in the JSON array string MUST have the following fields:
1.  'description': (String) A clear, concise, and actionable description of the rule (e.g., "Ensure 'email' column contains valid email addresses formatted as user@domain.com.", "Verify 'voltage' is non-negative.", "Check for high null counts in 'current_ir' column.").
2.  'column': (String) The specific column name from the 'Dataset Sample' this rule applies to. This MUST be one of the columns from the dataset sample. For rules involving multiple columns (e.g. consistency checks), list them comma-separated (e.g., "receivedTime, RTC").
3.  'type': (String) The category or method of the rule. Choose the most appropriate type based on the rule's nature. Examples: "IS_NOT_NULL", "IS_UNIQUE", "REGEX_MATCH", "RANGE_CHECK", "SQL_EXPRESSION", "CUSTOM_LOGIC", "FORMAT_VALIDATION", "TYPE_CHECK", "VALUE_IN_SET", "TEMPORAL_ORDER".
4.  'rationale': (String) A brief explanation of why this rule is generally important or what specific data quality aspect it checks (e.g., "Valid email formats are crucial for communication.", "Negative voltage readings are physically impossible.", "High null counts indicate missing data.").
5.  'reasonForColumnChoice': (String) Explain *why this specific column (or columns)* was chosen for *this specific rule*. **Your explanation MUST be primarily based on specific observations from the data sample provided for that column (e.g., 'The sample for column X shows values like Y, Z, indicating a need for this rule', or 'Column Y exhibits N% null values in the sample', or 'Observed data in column Z suggests it should be a positive integer').** If the sample for a column appears clean, reference the observed data type and common expectations for such data (e.g., 'Column A contains numeric values in the sample; this rule checks for outliers typical for [domain] data based on its observed numeric type'). Avoid purely generic reasons not tied to the sample's characteristics.
6.  'impactOnDimension': (String) Describe how this rule specifically contributes to the chosen data quality 'dimension'. For example: "This rule improves 'Accuracy' by ensuring that email addresses conform to standard, verifiable formats." or "This rule enhances 'Completeness' by flagging the observed high percentage of missing 'user_id' values." or "This rule improves 'Consistency' by checking that 'receivedTime' and 'RTC' are coherent."
7.  'weight': (Number, 0-100) A rule-specific importance score, influenced by its potential impact, observed issues in the sample, and the input dimension weights. A critical rule for an important dimension should have a higher weight.
8.  'dimension': (String) The primary data quality dimension this rule addresses. Choose one of: "Accuracy", "Completeness", "Consistency", "Uniqueness". Assign rules thoughtfully to ensure coverage across these four dimensions. If none fit perfectly after careful consideration, use "Other".

Guidance for Generating Practical, Sample-Driven Rules Across Dimensions:
- **Completeness:**
    - Look for missing values (nulls, empty strings). If a column has many, suggest "IS_NOT_NULL". Justify with observed null counts.
    - Check for placeholder values like "N/A", "Unknown", "NaN", "None", "NaT" in text or numeric fields. Suggest "PLACEHOLDER_CHECK".
- **Accuracy:**
    - For text fields that look like emails, phone numbers, zip codes, suggest "REGEX_MATCH" or "FORMAT_VALIDATION" with an example format.
    - For numeric fields, if values seem to be within a certain range (e.g., percentages 0-100, age > 0), suggest "RANGE_CHECK".
    - For date/time fields, check for consistent formatting and suggest "DATE_FORMAT_VALIDATION".
    - If a column seems to be categorical (e.g., 'status', 'type'), and the sample shows a few distinct values, suggest "VALUE_IN_SET" with the observed values as examples.
    - If numbers are expected to be positive (e.g., 'quantity', 'amount', 'voltage' if context implies), suggest a "RANGE_CHECK" (e.g., >=0).
- **Consistency:**
    - If there are multiple date/timestamp columns (e.g., 'order_date', 'ship_date'), suggest a "TEMPORAL_ORDER" check (e.g., 'ship_date' >= 'order_date').
    - If 'city', 'state', 'zip_code' are present, suggest a "CROSS_COLUMN_CONSISTENCY" check (though full validation is complex, flag the need).
    - If units or formats are mixed within a column (e.g., "USD 100", "$50.00"), suggest "FORMAT_UNIFORMITY".
- **Uniqueness:**
    - For columns that look like identifiers (e.g., 'id', 'transaction_id', 'user_id', 'deviceId', 'sessionId'), suggest "IS_UNIQUE" or "IS_UNIQUE_NOT_NULL".
    - Justify based on the apparent role of the column from its name and sample values.

- **ULTRA IMPORTANT FALLBACK (FOR COLUMNS PRESENT IN SAMPLE ONLY)**: If, after thorough analysis of the sample for a specific column *that exists in the dataSample*, you determine it has absolutely no discernible quality issues and none of the example basic checks seem highly relevant to its observed data type/nature, you MUST STILL provide a very generic but complete rule object for it, such as: \`{'description': 'Verify data type and general integrity of [column_name_from_sample].', 'column': '[column_name_from_sample]', 'type': 'BASIC_TYPE_CHECK', 'rationale': 'Basic check for all columns to ensure data conforms to expected type based on sample observation.', 'reasonForColumnChoice': '[column_name_from_sample] is part of the dataset; basic type (e.g., text/numeric as observed in sample) and presence validation is a foundational check.', 'impactOnDimension': 'Contributes to overall data Completeness and Accuracy by ensuring values are present and of the correct general type.', 'weight': 10, 'dimension': 'Completeness'}\`. DO NOT omit any column *from the sample* from having at least one rule.

Your entire output MUST be a JSON object with a single key "suggestedRules" which holds a JSON array string. Ensure the JSON is well-formed.
Example of a single rule object in the array string: {"description":"Ensure 'customer_id' is not null and unique","column":"customer_id", "type":"IS_UNIQUE_NOT_NULL", "rationale":"Customer ID is essential for record identification and linking.","reasonForColumnChoice":"The 'customer_id' column sample values appear to be primary keys; sample shows some 'CUST_NULL' values and duplicate 'CUST001' which would break data integrity.","impactOnDimension":"Improves Completeness by ensuring IDs are present, and Uniqueness by preventing duplicate IDs.","weight":95,"dimension":"Uniqueness"}
`,
});

const suggestDQRulesFlow = ai.defineFlow(
  {
    name: 'suggestDQRulesFlow',
    inputSchema: SuggestDQRulesInputSchema,
    outputSchema: SuggestDQRulesOutputSchema,
  },
  async (input: SuggestDQRulesInput): Promise<SuggestDQRulesOutput> => {
    let llmOutput: { suggestedRules: string } | null = null;
    try {
      const {output} = await suggestDQRulesPrompt(input);
      llmOutput = output;
    } catch (e) {
      console.error("SuggestDQRulesFlow: Error calling suggestDQRulesPrompt LLM model:", e);
      // If LLM call fails, proceed to programmatic fallback
    }

    // Log the raw output from the LLM for suggestedRules
    console.log('SuggestDQRulesFlow: Raw LLM output string for suggestedRules:', JSON.stringify(llmOutput?.suggestedRules));

    let suggestedRulesArray: SuggestedRuleInternal[] = [];

    if (llmOutput && typeof llmOutput.suggestedRules === 'string' && llmOutput.suggestedRules.trim() !== "") {
      try {
        suggestedRulesArray = JSON.parse(llmOutput.suggestedRules);
        if (!Array.isArray(suggestedRulesArray)) {
            console.warn("SuggestDQRulesFlow: LLM output for suggestedRules was a string but not a valid JSON array. Will fallback. Raw:", llmOutput.suggestedRules);
            suggestedRulesArray = []; // Reset if not an array
        } else if (suggestedRulesArray.length === 0) {
            console.warn("SuggestDQRulesFlow: LLM output for suggestedRules was a valid JSON array, but it was empty. Will attempt fallback if sample has columns.");
        }
      } catch (e: any) {
        console.error("SuggestDQRulesFlow: Failed to parse LLM suggestedRules string. Error:", e.message, "Raw LLM string:", llmOutput.suggestedRules);
        suggestedRulesArray = []; // Reset on parse error
      }
    } else {
        console.warn('SuggestDQRulesFlow: LLM output was null, not a string, or an empty string for suggestedRules. Will attempt fallback.');
    }

    // If LLM provided no valid rules (empty array after parse or parse failed), attempt programmatic fallback
    if (suggestedRulesArray.length === 0) {
      console.log("SuggestDQRulesFlow: LLM provided no usable rules. Attempting programmatic fallback using input data sample's columns.");
      try {
        const sampleData = JSON.parse(input.dataSample);
        if (Array.isArray(sampleData) && sampleData.length > 0) {
          const firstRecord = sampleData[0];
          if (typeof firstRecord === 'object' && firstRecord !== null) {
            const columnNames = Object.keys(firstRecord);
            const dimensionsCycle: Array<"Accuracy" | "Completeness" | "Consistency" | "Uniqueness"> = ["Accuracy", "Completeness", "Consistency", "Uniqueness"];
            
            if (columnNames.length > 0) {
                columnNames.forEach((colName, index) => {
                const dimensionForThisRule = dimensionsCycle[index % dimensionsCycle.length];
                suggestedRulesArray.push({
                    description: `Ensure column '${colName}' has valid data and meets basic quality standards. (Programmatic Fallback Rule)`,
                    column: colName,
                    type: "BASIC_VALIDATION", 
                    rationale: `This is a programmatically generated fallback rule for '${colName}' as the AI model did not provide specific rules for this column or the overall suggestion was not usable. This rule suggests basic validation.`,
                    reasonForColumnChoice: "Programmatic fallback: applied to ensure all columns found in the sample have at least one basic rule defined when AI suggestions are unavailable.",
                    impactOnDimension: `This basic validation rule contributes to overall data ${dimensionForThisRule} by encouraging checks for presence, correct data type, or general integrity.`,
                    weight: 15, 
                    dimension: dimensionForThisRule,
                });
                });
                console.log(`SuggestDQRulesFlow: Programmatically generated ${suggestedRulesArray.length} basic rules, distributed across dimensions.`);
            } else {
                 console.warn("SuggestDQRulesFlow: Programmatic fallback - data sample's first record has no columns (empty object). No fallback rules generated.");
            }
          } else {
            console.warn("SuggestDQRulesFlow: Fallback failed. First record in sample data is not an object or is null.");
          }
        } else {
          console.warn("SuggestDQRulesFlow: Fallback failed. Input dataSample is not an array or is empty. No fallback rules can be generated.");
        }
      } catch (e) {
        console.error("SuggestDQRulesFlow: Error during programmatic rule generation fallback:", e);
      }
    }
    
    const validatedRulesArray = suggestedRulesArray.map(rule => ({
        description: rule.description || "No description provided by AI.",
        column: rule.column || "Unknown column from AI.",
        type: rule.type || "UNKNOWN_TYPE",
        rationale: rule.rationale || "No rationale provided by AI.",
        reasonForColumnChoice: rule.reasonForColumnChoice || "No specific reason for column choice provided by AI.",
        impactOnDimension: rule.impactOnDimension || "No specific impact on dimension provided by AI.",
        weight: typeof rule.weight === 'number' ? Math.min(100, Math.max(0, rule.weight)) : 30,
        dimension: rule.dimension || "Other",
    }));


    if (validatedRulesArray.length === 0) {
        console.log("SuggestDQRulesFlow: No rules generated by LLM or programmatic fallback. Returning empty array string for suggestedRules.");
        return { suggestedRules: "[]" };
    }

    return { suggestedRules: JSON.stringify(validatedRulesArray) };
  }
);

