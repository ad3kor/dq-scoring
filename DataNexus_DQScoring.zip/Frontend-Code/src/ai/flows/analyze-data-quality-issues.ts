'use server';

/**
 * @fileOverview An AI agent for analyzing data quality issues using a chatbot.
 *
 * - analyzeDataQualityIssues - A function that allows users to ask questions about data quality issues.
 * - AnalyzeDataQualityIssuesInput - The input type for the analyzeDataQualityIssues function.
 * - AnalyzeDataQualityIssuesOutput - The return type for the analyzeDataQualityIssues function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeDataQualityIssuesInputSchema = z.object({
  userQuery: z.string().describe('The question about data quality issues.'),
  dataQualityReport: z
    .string()
    .describe('The data quality report to provide context for the chatbot.'),
});
export type AnalyzeDataQualityIssuesInput = z.infer<typeof AnalyzeDataQualityIssuesInputSchema>;

const AnalyzeDataQualityIssuesOutputSchema = z.object({
  answer: z.string().describe('The answer to the user question about data quality issues.'),
});
export type AnalyzeDataQualityIssuesOutput = z.infer<typeof AnalyzeDataQualityIssuesOutputSchema>;

export async function analyzeDataQualityIssues(input: AnalyzeDataQualityIssuesInput): Promise<AnalyzeDataQualityIssuesOutput> {
  return analyzeDataQualityIssuesFlow(input);
}

const analyzeDataQualityIssuesPrompt = ai.definePrompt({
  name: 'analyzeDataQualityIssuesPrompt',
  input: {schema: AnalyzeDataQualityIssuesInputSchema},
  output: {schema: AnalyzeDataQualityIssuesOutputSchema},
  prompt: `You are a data quality analysis chatbot. Use the following data quality report to answer the user\'s question about data quality issues.\n\nData Quality Report:\n{{{dataQualityReport}}}\n\nUser Question: {{{userQuery}}}`,
});

const analyzeDataQualityIssuesFlow = ai.defineFlow(
  {
    name: 'analyzeDataQualityIssuesFlow',
    inputSchema: AnalyzeDataQualityIssuesInputSchema,
    outputSchema: AnalyzeDataQualityIssuesOutputSchema,
  },
  async input => {
    const {output} = await analyzeDataQualityIssuesPrompt(input);
    return output!;
  }
);
