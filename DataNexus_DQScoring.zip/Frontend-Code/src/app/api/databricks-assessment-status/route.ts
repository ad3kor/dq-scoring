
import { NextResponse, type NextRequest } from 'next/server';

// Helper to interact with Databricks API (ensure it's consistent or share from a common util)
async function databricksApiRequest(
  endpoint: string,
  method: 'GET' | 'POST' = 'GET',
  body?: Record<string, any>,
  hostOverride?: string,
  tokenOverride?: string
) {
  const host = hostOverride || process.env.DATABRICKS_HOST;
  const token = tokenOverride || process.env.DATABRICKS_PAT;

  if (!host || !token || host.includes("<your-workspace-id>") || token.includes("<your-personal-access-token>")) {
    console.error("Databricks host or token not configured correctly for assessment status. Host:", host, "Token Valid:", !!token && !token.includes("<your-personal-access-token>"));
    throw new Error('Databricks host or token not configured correctly in .env for assessment status check.');
  }

  const response = await fetch(`${host}${endpoint}`, {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: response.statusText }));
    const errorMessage = errorData.error_message || errorData.message || response.statusText;
    console.error(`Databricks API Error (${endpoint}): ${errorMessage}`, errorData);
    throw new Error(`Databricks API request to ${endpoint} failed: ${errorMessage}`);
  }
  return response.json();
}

// In-memory store for assessment job statuses (should be the same instance as in run-databricks-assessment)
declare global {
  var databricksAssessmentJobStore_singleton: Record<string, {
    status: 'PENDING' | 'RUNNING' | 'SUCCEEDED' | 'FAILED' | 'TIMED_OUT' | 'CANCELED';
    startTime: number;
    error?: string;
    results?: any; 
    databricksRunId?: string; // Main Databricks Job Run ID
    databricksTaskKey?: string; // Task Key for the notebook within the job
    databricksTaskRunId?: string; // Actual Run ID of the notebook task
    dataSourceName?: string;
  }> | undefined;
}

const assessmentJobStore = global.databricksAssessmentJobStore_singleton || (global.databricksAssessmentJobStore_singleton = {});


function getNotebookTaskRunIdForAssessment(jobRunDetails: any, specifiedTaskKey?: string): string | null {
    if (!jobRunDetails.tasks || jobRunDetails.tasks.length === 0) {
        console.warn(`Assessment: No tasks found in job run details for main run_id ${jobRunDetails.run_id}. Will attempt to use main run_id for output, but this may fail if it's a multi-task job run ID.`);
        return jobRunDetails.run_id.toString(); 
    }

    let targetTaskRun;
    // 1. Try to find by specified task key
    if (specifiedTaskKey && specifiedTaskKey !== "<your-task-key>" && !specifiedTaskKey.includes("your-task-key")) { // Check for placeholder
        targetTaskRun = jobRunDetails.tasks.find((task: any) => task.task_key === specifiedTaskKey);
        if (targetTaskRun && targetTaskRun.run_id) {
            console.log(`Assessment: Found task by key '${specifiedTaskKey}' with run_id: ${targetTaskRun.run_id}`);
            return targetTaskRun.run_id.toString();
        }
        console.warn(`Assessment: Specified task_key '${specifiedTaskKey}' not found in job tasks for run ${jobRunDetails.run_id}.`);
    } else {
         console.log(`Assessment: DATABRICKS_ASSESSMENT_TASK_KEY not specified or is a placeholder. Attempting fallback logic.`);
    }
    
    // 2. Fallback: Find the first successfully completed notebook task
    targetTaskRun = jobRunDetails.tasks.find((task: any) =>
        task.notebook_task && 
        task.state?.life_cycle_state === 'TERMINATED' &&
        task.state?.result_state === 'SUCCESS' &&
        task.run_id
    );
    if (targetTaskRun) {
        console.log(`Assessment: Fallback - Found a successfully completed notebook task with run_id: ${targetTaskRun.run_id}.`);
        return targetTaskRun.run_id.toString();
    }
    
    // 3. Fallback: Find any notebook task if none were successful or key didn't match
     targetTaskRun = jobRunDetails.tasks.find((task: any) => task.notebook_task && task.run_id);
     if (targetTaskRun) {
        console.warn(`Assessment: Fallback - Could not find specific notebook task by key or success state for job run ${jobRunDetails.run_id}. Using first available notebook task with run_id ${targetTaskRun.run_id}. Output might be from an incomplete or non-target task.`);
        return targetTaskRun.run_id.toString();
     }

    console.error(`Assessment: Could not determine a specific notebook task run_id for job run ${jobRunDetails.run_id}. Cannot fetch notebook output reliably for multi-task jobs without a valid task_key or a clear notebook task.`);
    return null;
}


export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const internalTrackingId = searchParams.get('run_id'); // This is the internal tracking ID from run-databricks-assessment

  if (!internalTrackingId || !assessmentJobStore[internalTrackingId]) {
    return NextResponse.json({ error: 'Invalid or unknown internal_run_id for polling assessment status.', status: 'FAILED' }, { status: 404 });
  }

  const jobState = assessmentJobStore[internalTrackingId];
  const mainDatabricksRunId = jobState.databricksRunId; 
  const databricksHost = process.env.DATABRICKS_HOST;
  const databricksPat = process.env.DATABRICKS_PAT;

  if (!mainDatabricksRunId) {
     return NextResponse.json({ error: 'Databricks main run_id missing in job state for polling.', status: 'FAILED' }, { status: 500 });
  }
  
  if (jobState.status === 'SUCCEEDED' || jobState.status === 'FAILED') {
    return NextResponse.json(jobState); // Return full state including results or error
  }

  try {
    const jobRunDetails = await databricksApiRequest(`/api/2.1/jobs/runs/get?run_id=${mainDatabricksRunId}`, 'GET', undefined, databricksHost, databricksPat);
    const lifeCycleState = jobRunDetails.state?.life_cycle_state;
    const resultState = jobRunDetails.state?.result_state;

    if (lifeCycleState === 'TERMINATED') {
      if (resultState === 'SUCCESS') {
        const notebookTaskRunId = getNotebookTaskRunIdForAssessment(jobRunDetails, jobState.databricksTaskKey);

        if (!notebookTaskRunId) {
             const noTaskRunIdMsg =`Assessment job ${mainDatabricksRunId} succeeded, but could not identify the notebook task run ID to fetch output. Ensure DATABRICKS_ASSESSMENT_TASK_KEY is correct or notebook is findable.`;
             console.error(noTaskRunIdMsg);
             assessmentJobStore[internalTrackingId] = { ...jobState, status: 'FAILED', error: noTaskRunIdMsg, databricksTaskRunId: null };
             return NextResponse.json({ status: 'FAILED', error: noTaskRunIdMsg, dataSourceName: jobState.dataSourceName, databricksTaskRunId: null });
        }
        
        const output = await databricksApiRequest(`/api/2.1/jobs/runs/get-output?run_id=${notebookTaskRunId}`, 'GET', undefined, databricksHost, databricksPat);
        
        if (output.notebook_output && output.notebook_output.result) {
            try {
                let resultString = output.notebook_output.result;
                const prefix = "Notebook exited: ";
                if (typeof resultString === 'string' && resultString.startsWith(prefix)) {
                    resultString = resultString.substring(prefix.length);
                }

                const parsedResults = JSON.parse(resultString);
                assessmentJobStore[internalTrackingId] = { ...jobState, status: 'SUCCEEDED', results: parsedResults, databricksTaskRunId: notebookTaskRunId };
                return NextResponse.json({ status: 'SUCCEEDED', results: parsedResults, dataSourceName: jobState.dataSourceName, databricksTaskRunId: notebookTaskRunId });
            } catch (e: any) {
                console.error("Failed to parse notebook output JSON for assessment (task " + notebookTaskRunId + "):", e, "Raw output:", output.notebook_output.result);
                const parseErrorMsg = `Job SUCCEEDED, but its output (from task ${notebookTaskRunId}) was not valid JSON: ${e.message}. Raw output was: ${output.notebook_output.result.substring(0,200)}...`;
                assessmentJobStore[internalTrackingId] = { ...jobState, status: 'FAILED', error: parseErrorMsg, databricksTaskRunId: notebookTaskRunId };
                return NextResponse.json({ status: 'FAILED', error: parseErrorMsg, dataSourceName: jobState.dataSourceName, databricksTaskRunId: notebookTaskRunId });
            }
        } else if (output.error) {
             console.error(`Error fetching output for assessment task ${notebookTaskRunId}:`, output.error);
             const fetchErrorMsg = `Job SUCCEEDED, but encountered error when fetching output from task ${notebookTaskRunId}: ${output.error}`;
             assessmentJobStore[internalTrackingId] = { ...jobState, status: 'FAILED', error: fetchErrorMsg, databricksTaskRunId: notebookTaskRunId };
             return NextResponse.json({ status: 'FAILED', error: fetchErrorMsg, dataSourceName: jobState.dataSourceName, databricksTaskRunId: notebookTaskRunId });
        }
        else {
            console.warn(`Job ${mainDatabricksRunId} (task ${notebookTaskRunId}) SUCCEEDED, but no notebook_output.result found. Output:`, JSON.stringify(output).substring(0,500));
            const noOutputMsg = `Job SUCCEEDED, but no parsable output found from notebook task ${notebookTaskRunId}. Check Databricks logs.`;
            assessmentJobStore[internalTrackingId] = { ...jobState, status: 'FAILED', error: noOutputMsg, databricksTaskRunId: notebookTaskRunId };
            return NextResponse.json({ status: 'FAILED', error: noOutputMsg, dataSourceName: jobState.dataSourceName, databricksTaskRunId: notebookTaskRunId });
        }

      } else { 
        const errorMessage = jobRunDetails.state?.state_message || `Job ${mainDatabricksRunId} terminated with state: ${resultState || lifeCycleState || 'Unknown Error'}.`;
        assessmentJobStore[internalTrackingId] = { ...jobState, status: 'FAILED', error: errorMessage, databricksTaskRunId: jobState.databricksTaskRunId || null };
        return NextResponse.json({ status: 'FAILED', error: errorMessage, dataSourceName: jobState.dataSourceName, databricksTaskRunId: jobState.databricksTaskRunId || null });
      }
    } else if (['SKIPPED', 'INTERNAL_ERROR', 'TIMED_OUT', 'CANCELED', 'MAXIMUM_CONCURRENT_RUNS_REACHED', 'BLOCKED'].includes(lifeCycleState)) {
      const errorMessage = jobRunDetails.state?.state_message || `Job ${mainDatabricksRunId} ended with unrecoverable state: ${lifeCycleState}.`;
      assessmentJobStore[internalTrackingId] = { ...jobState, status: 'FAILED', error: errorMessage, databricksTaskRunId: jobState.databricksTaskRunId || null };
      return NextResponse.json({ status: 'FAILED', error: errorMessage, dataSourceName: jobState.dataSourceName, databricksTaskRunId: jobState.databricksTaskRunId || null });
    } else { 
      assessmentJobStore[internalTrackingId] = { ...jobState, status: lifeCycleState as 'PENDING' | 'RUNNING' };
      return NextResponse.json({ status: lifeCycleState, dataSourceName: jobState.dataSourceName, databricksTaskRunId: jobState.databricksTaskRunId });
    }

  } catch (error: any) {
    console.error(`Error polling assessment job status for Databricks run ${mainDatabricksRunId} (Internal ID ${internalTrackingId}):`, error);
    assessmentJobStore[internalTrackingId] = { ...jobState, status: 'FAILED', error: error.message, databricksTaskRunId: jobState.databricksTaskRunId || null };
    return NextResponse.json({ status: 'FAILED', error: error.message, dataSourceName: jobState.dataSourceName, databricksTaskRunId: jobState.databricksTaskRunId || null });
  }
}

    
