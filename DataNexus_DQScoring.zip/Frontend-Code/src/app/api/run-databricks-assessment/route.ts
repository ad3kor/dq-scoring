import { NextResponse, type NextRequest } from 'next/server';
import { v4 as uuidv4 } from 'uuid';

// Helper to interact with Databricks API
async function databricksApiRequest(
  endpoint: string,
  method: 'GET' | 'POST' = 'GET',
  body?: Record<string, any>,
  hostOverride?: string,
  tokenOverride?: string
) {
  const host = hostOverride || process.env.DATABRICKS_HOST;
  const token = tokenOverride || process.env.DATABRICKS_PAT;

  if (!host || !token || host.includes("<your-workspace-id>") || token.includes("<your-personal-access-token>")) {
    console.error("Databricks host or token not configured correctly. Host:", host, "Token Valid:", !!token && !token.includes("<your-personal-access-token>"));
    throw new Error('Databricks host or token not configured correctly in .env for assessment job.');
  }

  const response = await fetch(`${host}${endpoint}`, {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: response.statusText }));
    const errorMessage = errorData.error_message || errorData.message || response.statusText;
    console.error(`Databricks API Error (${endpoint}): ${errorMessage}`, errorData);
    throw new Error(`Databricks API request to ${endpoint} failed: ${errorMessage}`);
  }
  return response.json();
}

// In-memory store for assessment job statuses
declare global {
  var databricksAssessmentJobStore_singleton: Record<string, {
    status: 'PENDING' | 'RUNNING' | 'SUCCEEDED' | 'FAILED' | 'TIMED_OUT' | 'CANCELED';
    startTime: number;
    error?: string;
    results?: any; // This will hold the parsed JSON output from the notebook
    databricksRunId?: string; // Databricks actual run_id
    databricksTaskKey?: string; // Task key for the assessment notebook
    dataSourceName?: string;
  }> | undefined;
}

const assessmentJobStore = global.databricksAssessmentJobStore_singleton || (global.databricksAssessmentJobStore_singleton = {});

export async function POST(request: NextRequest) {
  try {
    const { 
        dataSourceId, 
        dataSourceName,
        rules, // Array of Rule objects
        dimensionWeights, // Record<DimensionName, number>
        // Add any other parameters your DQ_Assessment_Generator_Notebook might need, e.g., related to the data source itself
        nexusJobId // Optional: if the data was prepared by a Data Nexus job
    } = await request.json();

    if (!dataSourceId || !rules || !dimensionWeights) {
        return NextResponse.json({ error: 'Missing required parameters: dataSourceId, rules, or dimensionWeights.' }, { status: 400 });
    }

    const databricksHost = process.env.DATABRICKS_HOST;
    const databricksPat = process.env.DATABRICKS_PAT;
    const assessmentJobId = process.env.DATABRICKS_ASSESSMENT_JOB_ID;
    const assessmentTaskKey = process.env.DATABRICKS_ASSESSMENT_TASK_KEY;

    if (!assessmentJobId || assessmentJobId.includes("<your-databricks-job-id>")) {
        return NextResponse.json({ error: 'DATABRICKS_ASSESSMENT_JOB_ID not configured.' }, { status: 500 });
    }
     if (!assessmentTaskKey || assessmentTaskKey.includes("<your-task-key>")) {
        console.warn('DATABRICKS_ASSESSMENT_TASK_KEY not configured. Job will be triggered without specifying a task key.');
    }


    // Prepare notebook parameters for DQ_Assessment_Generator_Notebook
    const notebookParams: Record<string, string> = {
      param_rules_json: JSON.stringify(rules),
      param_dimension_weights_json: JSON.stringify(dimensionWeights),
      param_data_source_id: dataSourceId, // To help notebook identify data context if needed
      // Add other params like param_source_table_fqdn if your notebook directly queries tables
      // For Data Nexus flow, the notebook might expect a path to the sampled data or read from a known Delta table
      // param_input_delta_table: "hive_metastore.default.dq_ingested_clean_sample", // Example
    };

    if (nexusJobId) {
        // Potentially pass info about the nexus job, e.g., a path derived from it if notebook uses that.
        // Or the notebook is expected to always read from `dq_ingested_clean_sample`
        notebookParams.param_nexus_job_id_context = nexusJobId;
    }
    
    const runNowPayload: { job_id: number, notebook_params?: Record<string, string>, task_key?: string } = {
        job_id: Number(assessmentJobId),
        notebook_params: notebookParams,
    };
    if (assessmentTaskKey && !assessmentTaskKey.includes("<your-task-key>")) {
        runNowPayload.task_key = assessmentTaskKey;
    }
    
    const runInfo = await databricksApiRequest('/api/2.1/jobs/run-now', 'POST', runNowPayload, databricksHost, databricksPat);
    const databricksRunId = runInfo.run_id.toString();

    const internalTrackingId = uuidv4(); // Internal ID for this request flow
    assessmentJobStore[internalTrackingId] = {
      status: 'PENDING',
      startTime: Date.now(),
      databricksRunId: databricksRunId,
      databricksTaskKey: assessmentTaskKey, // Store it if provided
      dataSourceName: dataSourceName || dataSourceId,
    };

    console.log(`Databricks Assessment Job triggered. Databricks Run ID: ${databricksRunId}. Internal Tracking ID: ${internalTrackingId}`);
    return NextResponse.json({ 
        message: `Databricks Assessment Job triggered. Internal Tracking ID: ${internalTrackingId}`, 
        runId: internalTrackingId 
    }, { status: 202 });

  } catch (error: any) {
    console.error('Error triggering Databricks assessment job:', error);
    return NextResponse.json({ error: error.message || 'Failed to trigger Databricks assessment job' }, { status: 500 });
  }
}