
import { NextResponse, type NextRequest } from 'next/server';
import { v4 as uuidv4 } from 'uuid';

// Helper to interact with Databricks API (consistent with other API routes)
async function databricksApiRequest(
  endpoint: string,
  method: 'GET' | 'POST' = 'GET',
  body?: Record<string, any>
) {
  const host = process.env.DATABRICKS_HOST;
  const token = process.env.DATABRICKS_PAT;

  if (!host || host.includes("<your-workspace-id>")) {
    throw new Error('Databricks API Error: DATABRICKS_HOST environment variable is not set or is a placeholder.');
  }
  if (!token || token.includes("<your-personal-access-token>")) {
    throw new Error('Databricks API Error: DATABRICKS_PAT environment variable is not set or is a placeholder.');
  }

  const response = await fetch(`${host}${endpoint}`, {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: response.statusText }));
    const errorMessage = errorData.error_message || errorData.message || response.statusText;
    console.error(`Databricks API Error (${endpoint}): ${errorMessage}`, errorData);
    throw new Error(`Databricks API request to ${endpoint} failed: ${errorMessage}`);
  }
  return response.json();
}

// In-memory store for job statuses for this file lister flow
declare global {
  var databricksFileListerJobStore_singleton: Record<string, {
    status: 'PENDING' | 'RUNNING' | 'SUCCEEDED' | 'FAILED' | 'TIMED_OUT' | 'CANCELED';
    startTime: number;
    error?: string;
    output?: { // Structure matches the "File Lister Backend" notebook's exit JSON
        status: string;
        message?: string;
        files?: any[];
    };
    jobRunId?: string; // Databricks actual run_id
    taskKey?: string; // Databricks task key for the notebook
  }> | undefined;
}

const fileListerJobStore = global.databricksFileListerJobStore_singleton || (global.databricksFileListerJobStore_singleton = {});

function getNotebookTaskRunIdForFileLister(jobRunDetails: any, specifiedTaskKey?: string): string | null {
    const logPrefix = "FileListerTaskID:";
    if (!jobRunDetails.tasks || jobRunDetails.tasks.length === 0) {
        console.warn(`${logPrefix} No tasks in job run ${jobRunDetails.run_id}. Using main run_id for output. Multi-task jobs may fail.`);
        return jobRunDetails.run_id.toString();
    }

    let targetTaskRun;
    if (specifiedTaskKey && specifiedTaskKey !== process.env.DATABRICKS_FILE_LISTER_TASK_KEY_PLACEHOLDER && !specifiedTaskKey.includes("your-task-key")) { // Use a placeholder const
        targetTaskRun = jobRunDetails.tasks.find((task: any) => task.task_key === specifiedTaskKey);
        if (targetTaskRun?.run_id) {
            console.log(`${logPrefix} Found task by key '${specifiedTaskKey}': ${targetTaskRun.run_id}`);
            return targetTaskRun.run_id.toString();
        }
        console.warn(`${logPrefix} Task key '${specifiedTaskKey}' not found for run ${jobRunDetails.run_id}.`);
    } else {
        console.log(`${logPrefix} DATABRICKS_FILE_LISTER_TASK_KEY not specified or is placeholder. Falling back.`);
    }
    
    targetTaskRun = jobRunDetails.tasks.find((task: any) => task.notebook_task && task.state?.life_cycle_state === 'TERMINATED' && task.state?.result_state === 'SUCCESS' && task.run_id);
    if (targetTaskRun?.run_id) {
        console.log(`${logPrefix} Fallback: Found successful notebook task: ${targetTaskRun.run_id}.`);
        return targetTaskRun.run_id.toString();
    }
    
    targetTaskRun = jobRunDetails.tasks.find((task: any) => task.notebook_task && task.run_id);
    if (targetTaskRun?.run_id) {
        console.warn(`${logPrefix} Fallback: Using first available notebook task: ${targetTaskRun.run_id}. Output might be non-target.`);
        return targetTaskRun.run_id.toString();
    }

    console.error(`${logPrefix} Cannot determine notebook task run_id for job run ${jobRunDetails.run_id}.`);
    return null;
}


// POST to trigger the Databricks job for listing files
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const age_in_days = body.age_in_days; // Can be null/undefined or a string number

    const databricksJobId = process.env.DATABRICKS_FILE_LISTER_JOB_ID;
    const taskKey = process.env.DATABRICKS_FILE_LISTER_TASK_KEY; // Task key for this specific notebook

    if (!databricksJobId || databricksJobId === "<your-file-lister-job-id>" || databricksJobId.includes("your-databricks-job-id")) {
        return NextResponse.json({ error: 'Config Error: DATABRICKS_FILE_LISTER_JOB_ID not set or is placeholder.' }, { status: 500 });
    }
    if (!taskKey || taskKey === "<your-file-lister-task-key>" || taskKey.includes("your-task-key")) {
        console.warn('Warning: DATABRICKS_FILE_LISTER_TASK_KEY not set or is placeholder. Output fetching for multi-task jobs might be unreliable.');
    }


    const notebookParams: Record<string, string> = {};
    if (age_in_days !== undefined && age_in_days !== null && age_in_days !== "") {
      notebookParams.age_in_days = String(age_in_days);
    }

    const runNowPayload: { job_id: number, notebook_params?: Record<string, string> } = {
        job_id: Number(databricksJobId),
    };
    if (Object.keys(notebookParams).length > 0) {
        runNowPayload.notebook_params = notebookParams;
    }
    
    const runInfo = await databricksApiRequest('/api/2.1/jobs/run-now', 'POST', runNowPayload);
    const jobRunId = runInfo.run_id.toString(); // This is the main Databricks job run ID

    const internalTrackingId = uuidv4();
    fileListerJobStore[internalTrackingId] = {
      status: 'PENDING',
      startTime: Date.now(),
      jobRunId: jobRunId,
      taskKey: taskKey // Store the task key for polling
    };

    console.log(`Databricks File Lister Job triggered. DB Run ID: ${jobRunId}, Internal ID: ${internalTrackingId}, Params:`, notebookParams);
    return NextResponse.json({
        message: `Databricks File Lister Job triggered. Databricks Run ID: ${jobRunId}. Internal Tracking ID: ${internalTrackingId}`,
        runId: internalTrackingId
    }, { status: 202 });

  } catch (error: any) {
    console.error('Error triggering Databricks File Lister job:', error);
    return NextResponse.json({ error: error.message || 'Failed to trigger Databricks job.' }, { status: 500 });
  }
}

// GET to poll the job status and fetch results
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const internalRunId = searchParams.get('run_id');

  if (!internalRunId || !fileListerJobStore[internalRunId]) {
    return NextResponse.json({ error: 'Invalid or unknown internal_run_id for polling file lister.', status: 'FAILED' }, { status: 404 });
  }

  const jobState = fileListerJobStore[internalRunId];
  const mainDatabricksRunId = jobState.jobRunId;

  if (!mainDatabricksRunId) {
     return NextResponse.json({ error: 'Databricks main run_id missing in job state for file lister polling.', status: 'FAILED' }, { status: 500 });
  }

  if (jobState.status === 'SUCCEEDED' || jobState.status === 'FAILED') {
    return NextResponse.json(jobState.output || { status: jobState.status, error: jobState.error, files: [] });
  }

  try {
    const jobRunDetails = await databricksApiRequest(`/api/2.1/jobs/runs/get?run_id=${mainDatabricksRunId}`);
    const lifeCycleState = jobRunDetails.state?.life_cycle_state;
    const resultState = jobRunDetails.state?.result_state;

    if (lifeCycleState === 'TERMINATED') {
      if (resultState === 'SUCCESS') {
        const notebookTaskRunId = getNotebookTaskRunIdForFileLister(jobRunDetails, jobState.taskKey);

        if (!notebookTaskRunId) {
            const noTaskError = `Job ${mainDatabricksRunId} SUCCEEDED, but could not find notebook task run ID. Check task key config.`;
            console.error(noTaskError);
            fileListerJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: noTaskError };
            return NextResponse.json({ status: 'FAILED', error: noTaskError, files: [] });
        }

        const outputResponse = await databricksApiRequest(`/api/2.1/jobs/runs/get-output?run_id=${notebookTaskRunId}`);
        let notebookResultJsonString = outputResponse.notebook_output?.result;

        if (notebookResultJsonString) {
            const prefix = "Notebook exited: "; // As per Databricks output format
            if (typeof notebookResultJsonString === 'string' && notebookResultJsonString.startsWith(prefix)) {
                notebookResultJsonString = notebookResultJsonString.substring(prefix.length);
            }
            try {
                const parsedOutput = JSON.parse(notebookResultJsonString); // This should be the JSON from dbutils.notebook.exit()
                fileListerJobStore[internalRunId] = { ...jobState, status: 'SUCCEEDED', output: parsedOutput };
                return NextResponse.json(parsedOutput); // Return the direct output from the notebook
            } catch (e: any) {
                const parseError = `Job SUCCEEDED, but notebook output (task ${notebookTaskRunId}) was not valid JSON: ${e.message}. Raw: ${notebookResultJsonString.substring(0,200)}...`;
                console.error("FileLister API: " + parseError);
                fileListerJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: parseError, output: { status: "FAILED", message: parseError, files: [] } };
                return NextResponse.json(fileListerJobStore[internalRunId].output);
            }
        } else {
            const noOutputError = `Job ${mainDatabricksRunId} (task ${notebookTaskRunId}) SUCCEEDED, but no notebook_output.result found.`;
            console.warn("FileLister API: " + noOutputError, "Full output response:", outputResponse);
            fileListerJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: noOutputError, output: { status: "FAILED", message: noOutputError, files: [] } };
            return NextResponse.json(fileListerJobStore[internalRunId].output);
        }
      } else {
        const termFailError = jobRunDetails.state?.state_message || `Job ${mainDatabricksRunId} terminated with non-SUCCESS state: ${resultState}.`;
        fileListerJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: termFailError, output: { status: "FAILED", message: termFailError, files: [] } };
        return NextResponse.json(fileListerJobStore[internalRunId].output);
      }
    } else if (['SKIPPED', 'INTERNAL_ERROR', 'TIMED_OUT', 'CANCELED'].includes(lifeCycleState)) {
      const unrecoverableError = jobRunDetails.state?.state_message || `Job ${mainDatabricksRunId} ended with unrecoverable state: ${lifeCycleState}.`;
      fileListerJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: unrecoverableError, output: { status: "FAILED", message: unrecoverableError, files: [] } };
      return NextResponse.json(fileListerJobStore[internalRunId].output);
    } else {
      // Still PENDING or RUNNING
      fileListerJobStore[internalRunId] = { ...jobState, status: lifeCycleState as 'PENDING' | 'RUNNING' };
      return NextResponse.json({ status: lifeCycleState, message: jobRunDetails.state?.state_message || "Job is ongoing..." });
    }
  } catch (error: any) {
    const pollError = `Error polling job status for Databricks File Lister run ${mainDatabricksRunId} (Internal ID ${internalRunId}): ${error.message}`;
    console.error("FileLister API: " + pollError);
    fileListerJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: pollError, output: { status: "FAILED", message: pollError, files: [] } };
    return NextResponse.json(fileListerJobStore[internalRunId].output);
  }
}

// Placeholder for DATABRICKS_FILE_LISTER_TASK_KEY if not set, to avoid undefined errors in string methods.
process.env.DATABRICKS_FILE_LISTER_TASK_KEY_PLACEHOLDER = "<your-file-lister-task-key>";
    
    