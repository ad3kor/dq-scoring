
import { NextResponse, type NextRequest } from 'next/server';
import { v4 as uuidv4 } from 'uuid';

// Helper to interact with Databricks API
async function databricksApiRequest(
  endpoint: string,
  method: 'GET' | 'POST' = 'GET',
  body?: Record<string, any>
) {
  const host = process.env.DATABRICKS_HOST;
  const token = process.env.DATABRICKS_PAT;

  if (!host) {
    throw new Error('Databricks API Error: DATABRICKS_HOST environment variable is not set.');
  }
  if (host.includes("<your-workspace-id>")) {
    throw new Error('Databricks API Error: DATABRICKS_HOST environment variable appears to be a placeholder value.');
  }
  if (!token) {
    throw new Error('Databricks API Error: DATABRICKS_PAT environment variable is not set.');
  }
  if (token.includes("<your-personal-access-token>")) {
    throw new Error('Databricks API Error: DATABRICKS_PAT environment variable appears to be a placeholder value.');
  }

  const response = await fetch(`${host}${endpoint}`, {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: response.statusText }));
    const errorMessage = errorData.error_message || errorData.message || response.statusText;
    console.error(`Databricks API Error (${endpoint}): ${errorMessage}`, errorData);
    throw new Error(`Databricks API request to ${endpoint} failed: ${errorMessage}`);
  }
  return response.json();
}

// In-memory store for job statuses for this specific rule suggester flow
declare global {
  var databricksRuleSuggesterJobStore_singleton: Record<string, {
    status: 'PENDING' | 'RUNNING' | 'SUCCEEDED' | 'FAILED' | 'TIMED_OUT' | 'CANCELED';
    startTime: number;
    error?: string;
    notebookOutput?: {
        status: string;
        message?: string;
        suggested_rules?: any[];
        default_weights?: Record<string, number>;
    };
    jobRunId?: string; // Databricks actual run_id
  }> | undefined;
}

const ruleSuggesterJobStore = global.databricksRuleSuggesterJobStore_singleton || (global.databricksRuleSuggesterJobStore_singleton = {});

// Helper function to get the specific notebook task run_id from a job run
function getNotebookTaskRunIdForRuleSuggester(jobRunDetails: any, specifiedTaskKey?: string): string | null {
    if (!jobRunDetails.tasks || jobRunDetails.tasks.length === 0) {
        console.warn(`No tasks found in job run details for main run_id ${jobRunDetails.run_id}. Will attempt to use main run_id for output, but this may fail if it's a multi-task job run ID.`);
        return jobRunDetails.run_id.toString(); 
    }

    let targetTaskRun;
    // 1. Try to find by specified task key
    if (specifiedTaskKey && specifiedTaskKey !== "<your-databricks-job-id>" && !specifiedTaskKey.includes("your-databricks-job-id")) { // Check for placeholder
        targetTaskRun = jobRunDetails.tasks.find((task: any) => task.task_key === specifiedTaskKey);
        if (targetTaskRun && targetTaskRun.run_id) {
            console.log(`RuleSuggester: Found task by key '${specifiedTaskKey}' with run_id: ${targetTaskRun.run_id}`);
            return targetTaskRun.run_id.toString();
        }
        console.warn(`RuleSuggester: Specified task_key '${specifiedTaskKey}' not found in job tasks for run ${jobRunDetails.run_id}.`);
    } else {
        console.log(`RuleSuggester: DATABRICKS_RULE_MGMT_TASK_KEY not specified or is a placeholder. Attempting fallback logic.`);
    }

    // 2. Fallback: Find the first successfully completed notebook task
    targetTaskRun = jobRunDetails.tasks.find((task: any) =>
        task.notebook_task && 
        task.state?.life_cycle_state === 'TERMINATED' &&
        task.state?.result_state === 'SUCCESS' &&
        task.run_id 
    );
    if (targetTaskRun) {
        console.log(`RuleSuggester: Fallback - Found a successfully completed notebook task with run_id: ${targetTaskRun.run_id}.`);
        return targetTaskRun.run_id.toString();
    }
    
    // 3. Fallback: Find any notebook task if none were successful or key didn't match
     targetTaskRun = jobRunDetails.tasks.find((task: any) => task.notebook_task && task.run_id);
     if (targetTaskRun) {
        console.warn(`RuleSuggester: Fallback - Could not find specific notebook task by key or success state for job run ${jobRunDetails.run_id}. Using first available notebook task with run_id ${targetTaskRun.run_id}. Output might be from an incomplete or non-target task.`);
        return targetTaskRun.run_id.toString();
     }

    console.error(`RuleSuggester: Could not determine a specific notebook task run_id for job run ${jobRunDetails.run_id}. Cannot fetch notebook output reliably for multi-task jobs without a valid task_key or a clear notebook task.`);
    return null;
}


// POST to trigger the Databricks job
export async function POST(request: NextRequest) {
  try {
    const { dataSampleJson, dataSourceName } = await request.json(); 
    const databricksJobId = process.env.DATABRICKS_RULE_MGMT_JOB_ID;

    if (!databricksJobId) {
        return NextResponse.json({ error: 'Databricks Config Error: DATABRICKS_RULE_MGMT_JOB_ID environment variable is not set.' }, { status: 500 });
    }
    if (databricksJobId.includes("<your-databricks-job-id>")) { 
        return NextResponse.json({ error: 'Databricks Config Error: DATABRICKS_RULE_MGMT_JOB_ID environment variable appears to be a placeholder value.' }, { status: 500 });
    }
    if (!dataSampleJson) {
        return NextResponse.json({ error: 'Databricks API Error: dataSampleJson is required in the request body.' }, { status: 400 });
    }

    const notebookParams: Record<string, string> = {
        data_sample_json: dataSampleJson
    };
    if (dataSourceName) { 
        notebookParams.param_data_source_name = dataSourceName;
    }
    
    const runNowPayload: { job_id: number, notebook_params?: Record<string, string> } = {
        job_id: Number(databricksJobId),
        notebook_params: notebookParams
    };
    
    const runInfo = await databricksApiRequest('/api/2.1/jobs/run-now', 'POST', runNowPayload);
    const jobRunId = runInfo.run_id.toString();

    const internalTrackingId = uuidv4(); 
    ruleSuggesterJobStore[internalTrackingId] = {
      status: 'PENDING',
      startTime: Date.now(),
      jobRunId: jobRunId,
    };

    return NextResponse.json({ 
        message: `Databricks Rule Management Job triggered. Databricks Run ID: ${jobRunId}. Internal Tracking ID: ${internalTrackingId}`, 
        runId: internalTrackingId 
    }, { status: 202 });

  } catch (error: any) {
    console.error('Error triggering Databricks rule suggester job:', error);
    return NextResponse.json({ error: error.message || 'Failed to trigger Databricks job due to an unknown error.' }, { status: 500 });
  }
}


// GET to poll the job status and fetch results
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const internalRunId = searchParams.get('run_id');

  if (!internalRunId || !ruleSuggesterJobStore[internalRunId]) {
    return NextResponse.json({ error: 'Invalid or unknown run_id for polling.', status: 'FAILED' }, { status: 404 });
  }

  const jobState = ruleSuggesterJobStore[internalRunId];
  const mainDatabricksRunId = jobState.jobRunId; // This is the main job run ID

  if (!mainDatabricksRunId) { 
     return NextResponse.json({ error: 'Databricks main run_id missing in job state for polling.', status: 'FAILED' }, { status: 500 });
  }
  
  if (jobState.status === 'SUCCEEDED' || jobState.status === 'FAILED') {
    return NextResponse.json(jobState.notebookOutput || { status: jobState.status, error: jobState.error });
  }

  try {
    const jobRunStatus = await databricksApiRequest(`/api/2.1/jobs/runs/get?run_id=${mainDatabricksRunId}`);
    const lifeCycleState = jobRunStatus.state?.life_cycle_state;
    const resultState = jobRunStatus.state?.result_state;

    if (lifeCycleState === 'TERMINATED') {
      if (resultState === 'SUCCESS') {
        const specifiedTaskKey = process.env.DATABRICKS_RULE_MGMT_TASK_KEY;
        const notebookTaskRunId = getNotebookTaskRunIdForRuleSuggester(jobRunStatus, specifiedTaskKey);

        if (!notebookTaskRunId) {
            const noTaskRunIdMsg = `Job ${mainDatabricksRunId} succeeded, but could not identify the specific notebook task run ID to fetch output. Ensure DATABRICKS_RULE_MGMT_TASK_KEY is correct or the job has a clearly identifiable notebook task.`;
            console.error(noTaskRunIdMsg);
            ruleSuggesterJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: noTaskRunIdMsg };
            return NextResponse.json({ status: 'FAILED', error: noTaskRunIdMsg });
        }
        
        const outputResponse = await databricksApiRequest(`/api/2.1/jobs/runs/get-output?run_id=${notebookTaskRunId}`);
        
        let notebookResultJsonString = outputResponse.notebook_output?.result;
        if (notebookResultJsonString) {
            const prefix = "Notebook exited: ";
            if (typeof notebookResultJsonString === 'string' && notebookResultJsonString.startsWith(prefix)) {
                notebookResultJsonString = notebookResultJsonString.substring(prefix.length);
            }
            try {
                const parsedOutput = JSON.parse(notebookResultJsonString);
                if (parsedOutput.status && parsedOutput.status.toUpperCase() === "SUCCEEDED") {
                     ruleSuggesterJobStore[internalRunId] = { 
                        ...jobState, 
                        status: 'SUCCEEDED', 
                        notebookOutput: parsedOutput 
                    };
                } else {
                    const notebookError = parsedOutput.message || "Notebook exited with a non-SUCCESS status or unexpected payload structure.";
                    ruleSuggesterJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: notebookError, notebookOutput: parsedOutput };
                }
                return NextResponse.json(ruleSuggesterJobStore[internalRunId].notebookOutput);

            } catch (e: any) {
                console.error("Failed to parse notebook output JSON for Databricks rule suggester (task run_id " + notebookTaskRunId +") :", e, "Raw output (after prefix strip):", notebookResultJsonString);
                const parseErrorMsg = `Job SUCCEEDED, but its output (from task ${notebookTaskRunId}) was not valid JSON: ${e.message}. Output (first 200 chars): ${notebookResultJsonString.substring(0,200)}...`;
                ruleSuggesterJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: parseErrorMsg };
                return NextResponse.json({ status: 'FAILED', error: parseErrorMsg });
            }
        } else {
            const noOutputMsg = `Job ${mainDatabricksRunId} (task ${notebookTaskRunId}) SUCCEEDED, but no notebook_output.result found. Check Databricks logs if notebook should have exited with JSON.`;
            console.warn(noOutputMsg, "Full output response from Databricks:", outputResponse);
            ruleSuggesterJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: noOutputMsg };
            return NextResponse.json({ status: 'FAILED', error: noOutputMsg });
        }
      } else { 
        const errorMessage = jobRunStatus.state?.state_message || `Job ${mainDatabricksRunId} terminated with non-SUCCESS state: ${resultState}.`;
        ruleSuggesterJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: errorMessage };
        return NextResponse.json({ status: 'FAILED', error: errorMessage });
      }
    } else if (['SKIPPED', 'INTERNAL_ERROR', 'TIMED_OUT', 'CANCELED', 'MAXIMUM_CONCURRENT_RUNS_REACHED', 'BLOCKED'].includes(lifeCycleState)) {
      const errorMessage = jobRunStatus.state?.state_message || `Job ${mainDatabricksRunId} ended with unrecoverable state: ${lifeCycleState}.`;
      ruleSuggesterJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: errorMessage };
      return NextResponse.json({ status: 'FAILED', error: errorMessage });
    } else { 
      ruleSuggesterJobStore[internalRunId] = { ...jobState, status: lifeCycleState as 'PENDING' | 'RUNNING' };
      return NextResponse.json({ status: lifeCycleState }); 
    }

  } catch (error: any) {
    console.error(`Error polling job status for Databricks rule suggester run ${mainDatabricksRunId} (Internal ID ${internalRunId}):`, error);
    const specificErrorMessage = error.message || 'Failed to poll Databricks job status due to an unknown error.';
    ruleSuggesterJobStore[internalRunId] = { ...jobState, status: 'FAILED', error: specificErrorMessage };
    return NextResponse.json({ status: 'FAILED', error: specificErrorMessage });
  }
}

