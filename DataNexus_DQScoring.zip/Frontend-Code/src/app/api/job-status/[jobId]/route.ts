
import { NextResponse, type NextRequest } from 'next/server';
import { getMockJobStore, type MockJob } from '@/app/api/data-nexus-proxy/route'; 

const SIMULATED_JOB_DURATION_MS = 12000; 
const FAIL_AFTER_MS = 9000; 

async function fetchJobOutputFromDatabricks(
    mainJobRunId: string, 
    host: string,
    pat: string,
    jobTasks?: any[] 
): Promise<any> {
    const headers = { 'Authorization': `Bearer ${pat}` };
    let notebookTaskRunIdToQuery = mainJobRunId; 

    if (jobTasks && jobTasks.length > 0) {
        const notebookTaskKey = process.env.DATABRICKS_NOTEBOOK_TASK_KEY; 
        let identifiedTask = null;

        if (notebookTaskKey && notebookTaskKey !== "<your-databricks-task-key-here>" && !notebookTaskKey.includes("your-databricks-task-key-here")) {
            identifiedTask = jobTasks.find(task => task.task_key === notebookTaskKey);
            if (identifiedTask && identifiedTask.run_id) {
                console.log(`DataNexusSampler Status: Found notebook task by key '${notebookTaskKey}' with run ID: ${identifiedTask.run_id}`);
            } else {
                 console.warn(`DataNexusSampler Status: Specified task_key '${notebookTaskKey}' not found for run ${mainJobRunId}.`);
            }
        } else {
            console.log(`DataNexusSampler Status: DATABRICKS_NOTEBOOK_TASK_KEY (for DQ_Data_Sampler_Job) not specified or is placeholder. Fallback.`);
        }

        if (!identifiedTask || !identifiedTask.run_id) {
            identifiedTask = jobTasks.find(task => 
                task.notebook_task && 
                task.state?.life_cycle_state === 'TERMINATED' && 
                task.state?.result_state === 'SUCCESS' &&
                task.run_id
            );
            if (identifiedTask && identifiedTask.run_id) {
                console.log(`DataNexusSampler Status: Fallback - Found successful notebook task with run ID: ${identifiedTask.run_id}.`);
            }
        }
        
        if (!identifiedTask || !identifiedTask.run_id) {
            identifiedTask = jobTasks.find(task => task.notebook_task && task.run_id);
            if (identifiedTask && identifiedTask.run_id) {
                console.warn(`DataNexusSampler Status: Fallback - Using first notebook task: ${identifiedTask.run_id}.`);
            }
        }
        
        if (identifiedTask && identifiedTask.run_id) {
            notebookTaskRunIdToQuery = identifiedTask.run_id.toString();
        } else {
            console.warn(`DataNexusSampler Status: Could not identify specific task for ${mainJobRunId}. Using main run ID ${mainJobRunId} for output.`);
        }
    } else {
        console.log(`DataNexusSampler Status: No tasks array for ${mainJobRunId}, querying output for this run ID.`);
    }
    
    console.log(`DataNexusSampler Status: Fetching output for Databricks run_id (task or job): ${notebookTaskRunIdToQuery}.`);
    try {
        const outputResponse = await fetch(`${host}/api/2.1/jobs/runs/get-output?run_id=${notebookTaskRunIdToQuery}`, {
            headers: headers,
        });

        if (!outputResponse.ok) {
            const errorData = await outputResponse.json().catch(() => ({ message: `API Error (runs/get-output for ${notebookTaskRunIdToQuery}): ${outputResponse.statusText}` }));
            console.error(`Databricks API Error (runs/get-output) for run_id ${notebookTaskRunIdToQuery}:`, errorData);
            throw new Error(errorData.error_message || errorData.message || `Failed to get job output for ${notebookTaskRunIdToQuery}, status: ${outputResponse.status}`);
        }

        const output = await outputResponse.json();
        let rawNotebookResult = output.notebook_output?.result;
        
        if (rawNotebookResult) {
            const prefix = "Notebook exited: ";
            if (typeof rawNotebookResult === 'string' && rawNotebookResult.startsWith(prefix)) {
                rawNotebookResult = rawNotebookResult.substring(prefix.length);
            }
            if (typeof rawNotebookResult === 'string') {
                let processedString = rawNotebookResult.replace(/:\s*NaN\b/g, ': null'); 
                rawNotebookResult = processedString;
            }
            try {
                return JSON.parse(rawNotebookResult);
            } catch (parseError: any) {
                console.error(`Error parsing notebook output JSON for run_id ${notebookTaskRunIdToQuery}:`, parseError.message, "Raw string was:", rawNotebookResult.substring(0,500));
                throw new Error(`Notebook output for ${notebookTaskRunIdToQuery} was not valid JSON: ${parseError.message}. Check Databricks logs.`);
            }
        } else {
            console.warn(`No 'notebook_output.result' found for run_id ${notebookTaskRunIdToQuery}. Full output (truncated):`, JSON.stringify(output).substring(0,500));
            throw new Error(`No structured JSON output from notebook for run_id ${notebookTaskRunIdToQuery}.`);
        }

    } catch (error: any) {
        console.error(`Error fetching or parsing job output from Databricks for run_id ${notebookTaskRunIdToQuery}:`, error);
        throw error; 
    }
}


export async function GET(
  request: NextRequest,
  { params }: { params: { jobId: string } }
) {
  const jobId = params.jobId; 
  const jobStatuses = getMockJobStore(); 
  let jobInfoFromStore: MockJob | undefined = jobStatuses[jobId];

  if (!jobId) {
    return NextResponse.json({ error: 'Job ID is required' }, { status: 400 });
  }
  
  if (!jobInfoFromStore) {
    return NextResponse.json({ 
        jobId: jobId, status: 'FAILED', 
        error: `Job with ID ${jobId} not found.`, 
        progress: 0, dataSourceName: 'Unknown', containerName: 'Unknown', blobName: 'Unknown', sourceFilePathsJson: '[]' 
    }, { status: 404 });
  }

  const databricksHost = process.env.DATABRICKS_HOST;
  const databricksPat = process.env.DATABRICKS_PAT;
  
  const shouldAttemptRealApiForPolling =
    jobInfoFromStore.isRealJob && 
    databricksHost && databricksHost !== "https://adb-<your-workspace-id>.<region>.azuredatabricks.net" &&
    databricksPat && databricksPat !== "<your-personal-access-token>";

  let currentJobData: MockJob = { ...jobInfoFromStore }; 

  if (shouldAttemptRealApiForPolling) {
    if (currentJobData.status !== 'SUCCEEDED' && currentJobData.status !== 'FAILED') {
      try {
        const statusResponse = await fetch(
            `${databricksHost}/api/2.1/jobs/runs/get?run_id=${jobId}`, 
            { headers: { 'Authorization': `Bearer ${databricksPat}` } }
        );

        if (!statusResponse.ok) {
            const errorData = await statusResponse.json().catch(() => ({ message: `Databricks API Error (runs/get for ${jobId}): ${statusResponse.statusText}` }));
            currentJobData.status = 'FAILED';
            currentJobData.error = errorData.error_message || errorData.message || `Failed to get job status from Databricks, status: ${statusResponse.status}.`;
        } else {
            const realJobStatus = await statusResponse.json();
            if (!realJobStatus.state) {
                currentJobData.status = 'FAILED';
                currentJobData.error = 'Invalid status response from Databricks (missing state).';
            } else {
                const lifeCycleState = realJobStatus.state.life_cycle_state;
                const resultState = realJobStatus.state.result_state;
                const jobTasks = realJobStatus.tasks; 

                if (lifeCycleState === 'TERMINATED') {
                    if (resultState === 'SUCCESS') {
                        currentJobData.status = 'SUCCEEDED';
                        currentJobData.progress = 100;
                        try {
                          const outputFromTask = await fetchJobOutputFromDatabricks(jobId, databricksHost!, databricksPat!, jobTasks);
                          currentJobData.dataSample = outputFromTask; 
                        } catch (fetchError: any) {
                          currentJobData.status = 'FAILED'; 
                          currentJobData.error = `Job SUCCEEDED but failed to retrieve/parse output: ${fetchError.message}`;
                        }
                    } else { 
                        currentJobData.status = 'FAILED';
                        currentJobData.error = realJobStatus.state.state_message || `Job terminated with state: ${resultState || lifeCycleState ||'Unknown Result'}`;
                    }
                } else if (['PENDING', 'RUNNING', 'TERMINATING'].includes(lifeCycleState)) {
                    currentJobData.status = lifeCycleState as 'PENDING' | 'RUNNING'; 
                    currentJobData.progress = Math.min(99, currentJobData.progress! + 10); 
                     if (currentJobData.status === 'RUNNING' && currentJobData.startTime) {
                        const executionDuration = realJobStatus.execution_duration || SIMULATED_JOB_DURATION_MS;
                        const elapsedTime = Date.now() - currentJobData.startTime;
                        currentJobData.progress = Math.min(99, Math.max(currentJobData.progress!, Math.floor((elapsedTime / executionDuration) * 100)));
                    }
                } else { 
                     currentJobData.status = 'FAILED';
                     currentJobData.error = realJobStatus.state.state_message || `Databricks job state: ${lifeCycleState} (${resultState || 'No result state'})`;
                }
            }
        }
        jobStatuses[jobId] = { ...currentJobData }; 
      } catch (apiError: any) {
          currentJobData.status = 'FAILED';
          currentJobData.error = `API call error during status check: ${apiError.message}.`;
          jobStatuses[jobId] = { ...currentJobData }; 
      }
    }
  } else if (jobInfoFromStore.isRealJob === false && (jobInfoFromStore.status === 'PENDING' || jobInfoFromStore.status === 'RUNNING')) {
    // Simulation Logic
    const currentTime = Date.now();
    const elapsedTime = currentTime - currentJobData.startTime!; 
    
    if (currentJobData.blobName && currentJobData.blobName.toLowerCase().includes("archived_sales_run_2023.parquet") && elapsedTime > FAIL_AFTER_MS && currentJobData.status === 'RUNNING') {
        currentJobData.status = 'FAILED';
        currentJobData.progress = Math.min(currentJobData.progress || 0, 75);
        currentJobData.error = currentJobData.error || 'Simulated failure: Processing archived data encountered an issue.';
    } else if (elapsedTime >= SIMULATED_JOB_DURATION_MS) {
      currentJobData.status = 'SUCCEEDED';
      currentJobData.progress = 100;
      if (!currentJobData.dataSample) { 
        currentJobData.dataSample = { 
            status: "SUCCEEDED", 
            message: `Simulated: DQ for ${currentJobData.blobName} is fair. Files: ${currentJobData.sourceFilePathsJson}`,
            data_sample: [ 
                {"id": 1, "sim_file_paths": currentJobData.sourceFilePathsJson, "name": "Mock Product A", "category": "Electronics", "price": 100.50},
                {"id": 2, "sim_file_paths": currentJobData.sourceFilePathsJson, "name": "Mock Service B", "category": "Services", "price": 75.20}
            ]
        };
      }
    } else if (currentJobData.status === 'PENDING' && elapsedTime > SIMULATED_JOB_DURATION_MS / 4) {
      currentJobData.status = 'RUNNING';
      currentJobData.progress = Math.min(99, Math.max(20, Math.floor((elapsedTime / SIMULATED_JOB_DURATION_MS) * 100)));
    } else if (currentJobData.status === 'RUNNING') {
      currentJobData.progress = Math.min(99, Math.max(currentJobData.progress || 20, Math.floor((elapsedTime / SIMULATED_JOB_DURATION_MS) * 100)));
    } else { 
      currentJobData.progress = Math.min(25, Math.floor((elapsedTime / SIMULATED_JOB_DURATION_MS) * 100));
    }
    jobStatuses[jobId] = currentJobData; 
  }

  return NextResponse.json({
    jobId: jobId,
    status: currentJobData.status,
    progress: currentJobData.progress,
    dataSample: currentJobData.status === 'SUCCEEDED' ? currentJobData.dataSample : undefined,
    error: currentJobData.error,
    dataSourceName: currentJobData.dataSourceName,
    containerName: currentJobData.containerName, // from first file
    blobName: currentJobData.blobName,           // from first file
    sourceFilePathsJson: currentJobData.sourceFilePathsJson, // The JSON string of all paths
  }, { status: 200 });
}
