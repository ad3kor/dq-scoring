
import { NextResponse, type NextRequest } from 'next/server';
import { v4 as uuidv4 } from 'uuid';

// Define and export the interface for MockJob
export interface MockJob {
  status: 'PENDING' | 'RUNNING' | 'SUCCEEDED' | 'FAILED';
  startTime: number;
  progress: number;
  dataSample?: any; 
  error?: string | null;
  dataSourceName: string; 
  containerName: string;  // Parsed from the *first* sourceFilePath
  blobName: string;       // Parsed from the *first* sourceFilePath (path part)
  sourceFilePathsJson: string; // JSON string array of paths
  isRealJob?: boolean; 
}

// In-memory store for job statuses - using global singleton pattern
declare global {
  var mockJobStore_singleton: Record<string, MockJob> | undefined;
}

const mockJobStore: Record<string, MockJob> = global.mockJobStore_singleton || (global.mockJobStore_singleton = {});

export const getMockJobStore = () => mockJobStore;

// Helper to parse container and blob name from abfss path
function parseAbfssPath(abfssPath: string): { containerName: string, blobName: string, storageAccountName: string } {
  const defaultResult = { containerName: 'unknown_container', blobName: 'unknown_blob', storageAccountName: 'unknown_account' };
  if (!abfssPath) return defaultResult;
  try {
    const url = new URL(abfssPath); 
    if (url.protocol === 'abfss:') {
      const container = url.username; 
      const storageAccount = url.hostname.split('.')[0];
      const blobPath = url.pathname.startsWith('/') ? url.pathname.substring(1) : url.pathname;
      return { containerName: container, blobName: blobPath, storageAccountName: storageAccount };
    }
  } catch (e) {
    const match = abfssPath.match(/^abfss:\/\/([^@]+)@([^\/]+)\/(.+)$/);
    if (match) {
      return { containerName: match[1], blobName: match[3], storageAccountName: match[2].split('.')[0] };
    }
    console.warn(`Could not parse abfss path: ${abfssPath}`);
  }
  return defaultResult;
}


export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
        source_file_paths_json, // New: JSON string array of paths
        user,                  
        dataSourceName,        
    } = body;

    if (!source_file_paths_json || !user || !dataSourceName) {
      return NextResponse.json({ message: 'Missing required parameters (source_file_paths_json, user, dataSourceName).' }, { status: 400 });
    }
    
    let firstFilePath = '';
    try {
        const pathsArray = JSON.parse(source_file_paths_json);
        if (Array.isArray(pathsArray) && pathsArray.length > 0 && typeof pathsArray[0] === 'string') {
            firstFilePath = pathsArray[0];
        } else {
            throw new Error('source_file_paths_json is not a valid JSON array of strings or is empty.');
        }
    } catch (e: any) {
        return NextResponse.json({ message: `Invalid source_file_paths_json format: ${e.message}` }, { status: 400 });
    }


    const databricksHost = process.env.DATABRICKS_HOST;
    const databricksPat = process.env.DATABRICKS_PAT;
    const databricksSamplerJobId = process.env.DATABRICKS_DQ_JOB_ID; 

    let currentJobIdToUse: string;
    let submissionMessage: string;
    let jobInitialStatus: 'PENDING' | 'FAILED' = 'PENDING';
    let jobError: string | null = null;
    let isRealJobAttempt = false;

    const { containerName: parsedContainer, blobName: parsedBlob } = parseAbfssPath(firstFilePath);

    const useRealDatabricksApi =
      databricksHost && databricksHost !== "https://adb-<your-workspace-id>.<region>.azuredatabricks.net" &&
      databricksPat && databricksPat !== "<your-personal-access-token>" &&
      databricksSamplerJobId && databricksSamplerJobId !== "<your-databricks-dq-job-id>";

    if (useRealDatabricksApi) {
      isRealJobAttempt = true;
      console.log(`Attempting to trigger real Databricks sampling job ${databricksSamplerJobId} for user ${user} on file(s): ${source_file_paths_json}`);
      try {
        // The dynamic sampler notebook now expects "source_file_paths_json"
        const notebookParams: Record<string, string> = {
            source_file_paths_json: source_file_paths_json,
        };
        
        const databricksResponse = await fetch(`${databricksHost}/api/2.1/jobs/run-now`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${databricksPat}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                job_id: Number(databricksSamplerJobId),
                notebook_params: notebookParams,
            }),
        });

        if (!databricksResponse.ok) {
            const errorData = await databricksResponse.json().catch(() => ({ message: databricksResponse.statusText }));
            const specificErrorMessage = errorData.error_message || errorData.message || databricksResponse.statusText;
            console.error('Databricks API Error (run-now for dynamic multi-file sampler):', errorData);
            
            isRealJobAttempt = false; 
            submissionMessage = `Failed to trigger Databricks sampling job: ${specificErrorMessage}. Falling back to simulation.`;
            currentJobIdToUse = uuidv4(); 
            jobInitialStatus = 'PENDING';
            jobError = null;

        } else {
            const databricksJobRunInfo = await databricksResponse.json();
            currentJobIdToUse = databricksJobRunInfo.run_id.toString();
            submissionMessage = `Data sampling job submitted to Databricks. Job Run ID: ${currentJobIdToUse}`;
            console.log(`Real Databricks sampling job ${currentJobIdToUse} triggered for paths ${source_file_paths_json}.`);
        }
      } catch (apiError: any) {
          console.error('Error in Databricks API call (run-now for dynamic multi-file sampler):', apiError);
          isRealJobAttempt = false; 
          submissionMessage = `Databricks API call error: ${apiError.message}. Falling back to simulation.`;
          currentJobIdToUse = uuidv4();
          jobInitialStatus = 'PENDING';
          jobError = null;
      }
    } else {
      isRealJobAttempt = false;
      currentJobIdToUse = uuidv4();
      submissionMessage = `Data sampling job submitted (simulation). Job ID: ${currentJobIdToUse} for file(s) ${source_file_paths_json}`;
      if (!databricksHost || databricksHost === "https://adb-<your-workspace-id>.<region>.azuredatabricks.net") {
        console.warn("Databricks ENV VARS not set or are placeholders for sampler job. Using simulation.");
      }
    }

    const jobDetails: MockJob = {
      status: jobInitialStatus,
      startTime: Date.now(),
      progress: 0,
      error: jobError, 
      dataSample: undefined,
      dataSourceName, 
      containerName: parsedContainer,  
      blobName: parsedBlob, // From first file path, for consistency in status
      sourceFilePathsJson: source_file_paths_json, // Store the full JSON string
      isRealJob: isRealJobAttempt,
    };
    mockJobStore[currentJobIdToUse] = jobDetails;

    return NextResponse.json({
      success: true,
      jobId: currentJobIdToUse,
      message: submissionMessage,
    }, { status: 202 });

  } catch (error: any) {
    console.error('API Error in data-nexus-proxy POST:', error);
    return NextResponse.json({ message: 'Internal Server Error', details: error.message }, { status: 500 });
  }
}
