
"use client";

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ShieldCheck, Filter, Calendar as CalendarIcon, UserCircle } from 'lucide-react';
import type { DateRange } from "react-day-picker";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format, addDays, subDays } from "date-fns";
import { FormattedDateTime } from '@/components/FormattedDateTime';
import type { AuditLog } from '@/lib/auditUtils';
import { getCurrentMockUser, getUserSpecificKey, BASE_AUDIT_LOGS_KEY } from '@/lib/authUtils'; // Correctly import BASE_AUDIT_LOGS_KEY

export default function AuditingPage() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<string | undefined>(undefined);
  const [selectedAction, setSelectedAction] = useState<string | undefined>(undefined);
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  useEffect(() => {
    const user = getCurrentMockUser();
    setCurrentUser(user);
    if (user) {
      try {
        const storageKey = getUserSpecificKey(BASE_AUDIT_LOGS_KEY, user);
        const item = window.localStorage.getItem(storageKey);
        if (item) {
          setLogs(JSON.parse(item).map((log: any) => ({
            ...log,
            timestamp: new Date(log.timestamp) 
          })));
        } else {
          setLogs([]); 
        }
      } catch (error) {
        console.error("Error reading audit logs from localStorage", error);
        setLogs([]);
      }
    } else {
        setLogs([]);
    }

    const to = new Date();
    const from = subDays(to, 7);
    setDateRange({ from, to });
  }, []); 

  const uniqueUsers = Array.from(new Set(logs.map(log => log.user))).sort();
  const uniqueActions = Array.from(new Set(logs.map(log => log.action))).sort();
  
  const filteredLogs = logs.filter(log => {
    const logTimestamp = new Date(log.timestamp); 
    const matchesSearch = 
        (log.user?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
        (log.action?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
        (log.details?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
        (log.entityType?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
        (log.entityId?.toLowerCase() || '').includes(searchTerm.toLowerCase());

    const matchesUser = selectedUser && selectedUser !== "all" ? log.user === selectedUser : true;
    const matchesAction = selectedAction && selectedAction !== "all" ? log.action === selectedAction : true;
    
    let currentMatchesDate = true;
    if (dateRange?.from && dateRange?.to) {
        currentMatchesDate = (logTimestamp >= dateRange.from && logTimestamp <= addDays(dateRange.to, 1)); 
    } else if (dateRange?.from) {
        currentMatchesDate = logTimestamp >= dateRange.from;
    } else if (dateRange?.to) {
        currentMatchesDate = logTimestamp <= addDays(dateRange.to, 1);
    }

    return matchesSearch && matchesUser && matchesAction && currentMatchesDate;
  }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()); 

  if (!currentUser) {
    return <div className="container mx-auto py-8 text-center">Please log in to view audit logs.</div>;
  }

  return (
    <div className="container mx-auto py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Audit Logs for {currentUser}</h1>
        <p className="text-muted-foreground">Track user actions, configuration changes, and system events.</p>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center"><Filter className="mr-2 h-5 w-5 text-primary" />Filter Logs</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Input 
            placeholder="Search logs (user, action, details...)" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Select onValueChange={(value) => setSelectedUser(value === "all" ? undefined : value)} value={selectedUser || "all"}>
            <SelectTrigger><SelectValue placeholder="Filter by User" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Users</SelectItem>
              {uniqueUsers.map(user => <SelectItem key={user} value={user}>{user}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select onValueChange={(value) => setSelectedAction(value === "all" ? undefined : value)} value={selectedAction || "all"}>
            <SelectTrigger><SelectValue placeholder="Filter by Action" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Actions</SelectItem>
              {uniqueActions.map(action => <SelectItem key={action} value={action}>{action}</SelectItem>)}
            </SelectContent>
          </Select>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant={"outline"}
                className={`w-full justify-start text-left font-normal ${!dateRange && "text-muted-foreground"}`}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dateRange?.from ? (
                  dateRange.to ? (
                     <>
                       <FormattedDateTime date={dateRange.from} formatter={(d) => format(d, "LLL dd, y")} placeholder="Pick a date" />
                       {' - '}
                       <FormattedDateTime date={dateRange.to} formatter={(d) => format(d, "LLL dd, y")} placeholder="Pick a date" />
                     </>
                  ) : (
                    <FormattedDateTime date={dateRange.from} formatter={(d) => format(d, "LLL dd, y")} placeholder="Pick a date" />
                  )
                ) : (
                  <span>Pick a date range</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={dateRange?.from}
                selected={dateRange}
                onSelect={setDateRange}
                numberOfMonths={2}
                disabled={{ after: new Date() }} 
              />
            </PopoverContent>
          </Popover>
        </CardContent>
      </Card>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Log Entries</CardTitle>
          <CardDescription>Detailed records of activities within DataQualityLens. Logs are sorted by newest first.</CardDescription>
        </CardHeader>
        <CardContent>
          {filteredLogs.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Entity</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>
                      <FormattedDateTime date={log.timestamp} formatter={(d) => d.toLocaleString()} placeholder="Loading date..." />
                    </TableCell>
                    <TableCell className="flex items-center">
                      <UserCircle className="h-4 w-4 mr-1 text-muted-foreground" />
                      {log.user}
                    </TableCell>
                    <TableCell><span className="px-2 py-0.5 text-xs bg-accent text-accent-foreground rounded-full">{log.action}</span></TableCell>
                    <TableCell>
                      {log.entityType && (
                        <span className="text-xs text-muted-foreground">
                          {log.entityType}: {log.entityId ? log.entityId.substring(0,15) + (log.entityId.length > 15 ? '...' : '') : 'N/A'}
                        </span>
                      )}
                    </TableCell>
                    <TableCell>{log.details}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
             <div className="text-center py-10">
              <ShieldCheck className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-2 text-sm font-medium text-foreground">No audit logs found</h3>
              <p className="mt-1 text-sm text-muted-foreground">No activities match your current filters, or no logs have been generated yet for {currentUser}.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
