
"use client";

import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { FileText, PlusCircle, Download, Eye, AlertTriangle, Database, History } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { FormattedDateTime } from '@/components/FormattedDateTime';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { addAuditLog, getCurrentMockUser, getUserSpecificKey, BASE_DS_KEY, BASE_ASSESSMENT_HISTORY_KEY, BASE_REPORTS_KEY } from '@/lib/authUtils';
import { useSearchParams, useRouter } from 'next/navigation'; 

const DIMENSION_NAMES_ORDERED = ["Accuracy", "Completeness", "Consistency", "Uniqueness"] as const;
type DimensionName = typeof DIMENSION_NAMES_ORDERED[number];

// Updated Interfaces for Databricks Job Output (matching new structure)
interface DatabricksDetailedRuleResultItem {
  "Rule Description": string;
  "Column": string;
  "Dimension": string;
  "Status": 'Pass' | 'Fail' | 'Error' | string;
  "Affected Records": number;
  "Details": string;
}
interface DatabricksDimensionAnalysisItem {
  "Dimension": string;
  "Weight (%)": string;
  "Score (/10)": string;
  "Observation": string;
}
interface DatabricksSummaryOfChecks {
  total_rules_assessed: number;
  pass: number; 
  fail: number; 
  error: number; 
}
interface DatabricksAssessmentJobOutput {
  overall_dq_score: number;
  overall_observation: string;
  summary_of_checks: DatabricksSummaryOfChecks;
  dimension_analysis: DatabricksDimensionAnalysisItem[];
  detailed_rule_results: DatabricksDetailedRuleResultItem[]; 
  timestamp?: string;
}

// --- Interfaces for Report Generation & Storage ---
interface ReportRuleResult {
  ruleDescription: string;
  column: string;
  status: 'Pass' | 'Fail' | 'Error' | string;
  details: string; 
  recordsAffected?: number | string; 
  dimension: DimensionName | 'Other' | string; 
}

interface DimensionReportDetail {
  name: DimensionName | "Other" | string; 
  weight: number; 
  score: number; 
  observation: string;
}

interface ReportSummary {
  totalRules: number;
  passed: number;
  failed: number;
  errors: number;
  dimensionDetails: DimensionReportDetail[];
  overallScore: number;
  overallAssessmentText: string;
  assessmentSourceType: 'legacy' | 'databricks';
}

interface Report {
  id: string;
  name: string;
  dataSourceName: string;
  assessmentTimestamp: Date;
  generatedAt: Date;
  status: 'Completed' | 'Generating' | 'Failed';
  format: 'PDF';
  assessmentResults?: ReportRuleResult[]; 
  summary?: ReportSummary; 
  assessmentRunId?: string; 
  assessmentType: 'legacy' | 'databricks'; 
}


// --- Interfaces for Data Selection (from localStorage) ---
interface LegacyAssessmentResult { 
  ruleDescription: string;
  column: string;
  status: 'Pass' | 'Fail' | 'Error';
  details: string;
  recordsAffected?: number;
  dimension: DimensionName | 'Other';
}
interface LegacyAssessmentSummary {
    totalRules: number;
    passed: number;
    failed: number;
    errors: number;
    dimensionScores: Record<DimensionName | "Other", number>;
    overallScore: number;
}
interface AssessmentRunFromStorage {
    id: string;
    dataSourceId: string;
    dataSourceName: string;
    timestamp: Date;
    status: 'Completed' | 'Failed'; 
    assessmentType: 'legacy' | 'databricks';
    
    results?: LegacyAssessmentResult[]; 
    summary?: LegacyAssessmentSummary;   

    databricksOutput?: DatabricksAssessmentJobOutput;
}

interface DataSourceForSelect {
  id: string;
  name: string;
}


export default function ReportsPage() {
  const { toast } = useToast();
  const searchParams = useSearchParams();
  const router = useRouter(); 

  const [reports, setReports] = useState<Report[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  const [dataSourcesForSelect, setDataSourcesForSelect] = useState<DataSourceForSelect[]>([]);
  const [selectedDataSourceId, setSelectedDataSourceId] = useState<string | undefined>(undefined);
  const [availableHistoricalRuns, setAvailableHistoricalRuns] = useState<AssessmentRunFromStorage[]>([]);
  const [selectedHistoricalRunId, setSelectedHistoricalRunId] = useState<string | undefined>(undefined);

  useEffect(() => {
    const user = getCurrentMockUser();
    setCurrentUser(user);
    if (user) {
      try {
        // Load reports
        const reportsStorageKey = getUserSpecificKey(BASE_REPORTS_KEY, user);
        const reportsItem = window.localStorage.getItem(reportsStorageKey);
        if (reportsItem) {
          setReports(JSON.parse(reportsItem).map((report: Report) => ({
            ...report,
            generatedAt: new Date(report.generatedAt),
            assessmentTimestamp: new Date(report.assessmentTimestamp),
          })));
        }

        // Load data sources for select dropdown (enhanced logic)
        const dsStorageKey = getUserSpecificKey(BASE_DS_KEY, user);
        const dsItem = window.localStorage.getItem(dsStorageKey);
        const mainDataSources: DataSourceForSelect[] = dsItem ? JSON.parse(dsItem) : [];
        
        const historyStorageKey = getUserSpecificKey(BASE_ASSESSMENT_HISTORY_KEY, user);
        const historyItem = window.localStorage.getItem(historyStorageKey);
        const allAssessmentHistory: AssessmentRunFromStorage[] = historyItem ? JSON.parse(historyItem).map((run:any) => ({...run, timestamp: new Date(run.timestamp)})) : [];

        const combinedDataSourcesMap = new Map<string, DataSourceForSelect>();
        mainDataSources.forEach(ds => combinedDataSourcesMap.set(ds.id, ds));
        
        allAssessmentHistory.forEach(run => {
          if (run.dataSourceId && run.dataSourceName && !combinedDataSourcesMap.has(run.dataSourceId)) {
            combinedDataSourcesMap.set(run.dataSourceId, { id: run.dataSourceId, name: run.dataSourceName });
          }
        });
        setDataSourcesForSelect(Array.from(combinedDataSourcesMap.values()));

      } catch (error) {
        console.error("Error reading data from localStorage for Reports Page", error);
        setReports([]);
        setDataSourcesForSelect([]);
      }
    } else {
      setReports([]);
      setDataSourcesForSelect([]);
    }
  }, [currentUser]); // Depend on currentUser to re-load if user changes

  useEffect(() => {
    if (currentUser && reports.length >= 0) { // Ensure reports is not negative (which it can't be but good practice)
      try {
        const storageKey = getUserSpecificKey(BASE_REPORTS_KEY, currentUser);
        window.localStorage.setItem(storageKey, JSON.stringify(reports));
      } catch (error) {
        console.error("Error saving reports to localStorage", error);
      }
    }
  }, [reports, currentUser]);

  // Effect to pre-select data source from query parameter
  useEffect(() => {
    const dsIdFromQuery = searchParams.get('dataSourceId');
    if (dsIdFromQuery && dataSourcesForSelect.some(ds => ds.id === dsIdFromQuery)) {
        setSelectedDataSourceId(dsIdFromQuery);
    } else if (dsIdFromQuery) {
      // If dsIdFromQuery exists but not in dataSourcesForSelect, it might be due to timing.
      // dataSourcesForSelect relies on localStorage reads which are async in effect.
      // This scenario should be less common with the combined loading logic above.
      console.warn(`ReportsPage: dataSourceId '${dsIdFromQuery}' from query param not found in initial dataSourcesForSelect. Waiting for full list.`);
    }
  }, [searchParams, dataSourcesForSelect]); // Re-run if dataSourcesForSelect updates


  useEffect(() => {
    if (selectedDataSourceId && currentUser) {
      try {
        const historyStorageKey = getUserSpecificKey(BASE_ASSESSMENT_HISTORY_KEY, currentUser);
        const historyItem = window.localStorage.getItem(historyStorageKey);
        let relevantRuns: AssessmentRunFromStorage[] = [];
        if (historyItem) {
          const allHistory: AssessmentRunFromStorage[] = JSON.parse(historyItem).map((run: any) => ({
            ...run, 
            timestamp: new Date(run.timestamp)
          }));
          
          relevantRuns = allHistory
            .filter(run => run.dataSourceId === selectedDataSourceId && run.status === 'Completed' && (run.summary || run.databricksOutput))
            .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
          
          setAvailableHistoricalRuns(relevantRuns);
        } else {
          setAvailableHistoricalRuns([]);
        }
        
        const runIdFromQuery = searchParams.get('assessmentRunId');
        if (runIdFromQuery && relevantRuns.some(run => run.id === runIdFromQuery)) {
            setSelectedHistoricalRunId(runIdFromQuery);
        } else if (relevantRuns.length > 0 && !runIdFromQuery) { 
            setSelectedHistoricalRunId(relevantRuns[0].id); 
        } else {
            setSelectedHistoricalRunId(undefined);
            if (relevantRuns.length === 0 && selectedDataSourceId) { 
                 toast({ 
                    title: "No Assessments Found", 
                    description: `No completed assessments available for this data source.`, 
                    variant: "default",
                    duration: 3000 
                });
            }
        }

      } catch (error) {
        console.error("Error reading assessment history for selected data source:", error);
        setAvailableHistoricalRuns([]);
        setSelectedHistoricalRunId(undefined);
      }
    } else {
      setAvailableHistoricalRuns([]);
      setSelectedHistoricalRunId(undefined);
    }
  }, [selectedDataSourceId, currentUser, toast, searchParams]);


const generateMockObservation = (dimension: string, score: number): string => {
  const dimLower = dimension.toLowerCase();
  if (score >= 8) return `The data generally meets ${dimLower} standards with minimal issues. Further monitoring advised.`;
  if (score >= 5) return `The data partially meets ${dimLower} criteria. Some areas require attention and targeted improvement.`;
  if (score > 0) return `The data exhibits significant ${dimLower} issues requiring review and immediate remediation actions.`;
  return `No ${dimLower} assessment performed or issues prevent reliable scoring for this dimension.`;
};

const generateOverallAssessmentText = (overallScore: number): string => {
  if (overallScore >= 8) return "Overall data quality is good. Continuous monitoring is recommended to maintain standards.";
  if (overallScore >= 5) return "Overall data quality is fair. Specific dimensions require improvement. Review detailed findings for action items.";
  if (overallScore > 0) return "Overall data quality is poor. Significant issues detected across multiple dimensions. Urgent attention and remediation are required.";
  return "Overall data quality could not be determined due to errors or lack of assessment data.";
};


const createReportSummaryAndResults = (
    assessmentRun: AssessmentRunFromStorage
  ): { summary: ReportSummary; results: ReportRuleResult[] } | null => {
  
  if (assessmentRun.assessmentType === 'databricks' && assessmentRun.databricksOutput) {
    const dbOutput = assessmentRun.databricksOutput;
    const reportSummary: ReportSummary = {
      totalRules: dbOutput.summary_of_checks.total_rules_assessed,
      passed: dbOutput.summary_of_checks.pass, 
      failed: dbOutput.summary_of_checks.fail, 
      errors: dbOutput.summary_of_checks.error, 
      dimensionDetails: dbOutput.dimension_analysis.map(da => ({
        name: da.Dimension,
        weight: parseFloat(da["Weight (%)"]),
        score: parseFloat(da["Score (/10)"]),
        observation: da.Observation,
      })),
      overallScore: parseFloat(dbOutput.overall_dq_score.toFixed(1)),
      overallAssessmentText: dbOutput.overall_observation,
      assessmentSourceType: 'databricks',
    };
    const reportResults: ReportRuleResult[] = dbOutput.detailed_rule_results.map(drr => ({ 
      ruleDescription: drr["Rule Description"],
      column: drr.Column,
      status: drr.Status,
      details: drr.Details, 
      recordsAffected: drr["Affected Records"],
      dimension: drr.Dimension,
    }));
    return { summary: reportSummary, results: reportResults };

  } else if (assessmentRun.assessmentType === 'legacy' && assessmentRun.summary && assessmentRun.results) {
    const legacySummary = assessmentRun.summary;
    const legacyResults = assessmentRun.results;
    
    const mockWeights: Record<DimensionName | "Other", number> = {
        Accuracy: 30, Completeness: 25, Consistency: 25, Uniqueness: 20, Other: 0,
    };
    const dimensionDetails: DimensionReportDetail[] = [];
    (DIMENSION_NAMES_ORDERED as readonly (DimensionName | "Other")[]).concat("Other").forEach(dimKey => {
        const key = dimKey as DimensionName | "Other";
        const score = legacySummary.dimensionScores[key] || 0;
        const weight = mockWeights[key] || 0;
        if (key !== "Other" || score > 0 || weight > 0) {
            dimensionDetails.push({
            name: key,
            weight: weight,
            score: parseFloat(score.toFixed(1)),
            observation: generateMockObservation(key, score),
            });
        }
    });

    const reportSummary: ReportSummary = {
      totalRules: legacySummary.totalRules,
      passed: legacySummary.passed,
      failed: legacySummary.failed,
      errors: legacySummary.errors,
      dimensionDetails: dimensionDetails,
      overallScore: parseFloat(legacySummary.overallScore.toFixed(1)),
      overallAssessmentText: generateOverallAssessmentText(legacySummary.overallScore),
      assessmentSourceType: 'legacy',
    };
    const reportResults: ReportRuleResult[] = legacyResults.map(lr => ({
      ruleDescription: lr.ruleDescription,
      column: lr.column,
      status: lr.status,
      details: lr.details,
      recordsAffected: lr.recordsAffected,
      dimension: lr.dimension,
    }));
    return { summary: reportSummary, results: reportResults };
  }
  return null;
};


  const handleGenerateReport = () => {
    if (!currentUser) {
        toast({ title: "Error", description: "No active user session.", variant: "destructive" });
        return;
    }
    if (!selectedDataSourceId || !selectedHistoricalRunId) {
      toast({ title: "Selection Required", description: "Please select a data source and an assessment run.", variant: "destructive"});
      return;
    }

    setIsGenerating(true);
    toast({ title: "Report Generation Initiated", description: "Attempting to generate report from selected assessment." });
    
    setTimeout(() => {
      let chosenAssessmentRun: AssessmentRunFromStorage | null = null;
      try {
        const historyStorageKey = getUserSpecificKey(BASE_ASSESSMENT_HISTORY_KEY, currentUser);
        const historyItem = window.localStorage.getItem(historyStorageKey);
        if (historyItem) {
          const assessmentHistory: AssessmentRunFromStorage[] = JSON.parse(historyItem).map((run: any) => ({
            ...run, 
            timestamp: new Date(run.timestamp),
            assessmentType: run.assessmentType || 'legacy' 
          }));
          chosenAssessmentRun = assessmentHistory.find(run => run.id === selectedHistoricalRunId && run.dataSourceId === selectedDataSourceId) || null;
        }
      } catch (error) {
        console.error("Error reading assessment history from localStorage for report generation", error);
        toast({ title: "Error", description: "Could not retrieve assessment history.", variant: "destructive" });
        setIsGenerating(false);
        return;
      }

      if (!chosenAssessmentRun || (chosenAssessmentRun.assessmentType === 'legacy' && !chosenAssessmentRun.summary) || (chosenAssessmentRun.assessmentType === 'databricks' && !chosenAssessmentRun.databricksOutput)) {
        toast({
          title: "Assessment Data Missing",
          description: "Selected assessment run data is incomplete or not found. Please try another run or re-assess.",
          variant: "destructive",
          duration: 5000,
        });
        setIsGenerating(false);
        return;
      }
      
      const transformedData = createReportSummaryAndResults(chosenAssessmentRun);
      if (!transformedData) {
        toast({ title: "Data Transformation Error", description: "Could not transform assessment data for reporting.", variant: "destructive" });
        setIsGenerating(false);
        return;
      }

      const { summary: reportSummary, results: reportResults } = transformedData;
      const reportId = `rep-${Date.now()}`;
      const newReport: Report = {
        id: reportId,
        name: `DQ Report for ${chosenAssessmentRun.dataSourceName} - ${new Date(chosenAssessmentRun.timestamp).toLocaleDateString()}`,
        dataSourceName: chosenAssessmentRun.dataSourceName, 
        assessmentTimestamp: chosenAssessmentRun.databricksOutput?.timestamp ? new Date(chosenAssessmentRun.databricksOutput.timestamp) : new Date(chosenAssessmentRun.timestamp),
        generatedAt: new Date(),
        status: 'Completed',
        format: 'PDF',
        assessmentResults: reportResults, 
        summary: reportSummary,
        assessmentRunId: chosenAssessmentRun.id,
        assessmentType: chosenAssessmentRun.assessmentType,
      };
      setReports(prev => [newReport, ...prev.slice(0,19)]); 
      addAuditLog(
        'GENERATE_REPORT',
        `Generated report '${newReport.name}' for DS '${chosenAssessmentRun.dataSourceName}' from assessment run ID ${chosenAssessmentRun.id} (type: ${chosenAssessmentRun.assessmentType}).`,
        'Report',
        reportId
      );
      setIsGenerating(false);
      toast({ title: "Report Generated Successfully", description: `"${newReport.name}" is now available.` });
    }, 1500);
  };

  const handleDownloadReport = (reportId: string) => {
    const report = reports.find(r => r.id === reportId);
    if (!report || report.status !== 'Completed' || !report.summary || !report.assessmentResults) {
      toast({ title: "Error", description: "Report not available or incomplete for download.", variant: "destructive" });
      return;
    }

    const doc = new jsPDF();
    const pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
    const pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth();
    let currentY = 20;
    const margin = 14;
    const contentWidth = pageWidth - 2 * margin;

    const deepTeal = '#008080'; 
    const darkGray = '#222831'; 
    const softYellow = '#FFD369'; 

    doc.setFontSize(18);
    doc.setTextColor(deepTeal);
    doc.text("Data Quality Report", pageWidth / 2, currentY, { align: 'center' });
    currentY += 10;

    doc.setFontSize(12);
    doc.setTextColor(darkGray);
    doc.text(`Report Name: ${report.name}`, margin, currentY);
    currentY += 7;
    doc.text(`Data Source: ${report.dataSourceName}`, margin, currentY);
    currentY += 7;
    doc.text(`Assessment Date: ${report.assessmentTimestamp.toLocaleString()}`, margin, currentY);
    currentY += 7;
    doc.text(`Report Generated: ${report.generatedAt.toLocaleString()}`, margin, currentY);
    currentY += 7;
    doc.text(`Assessment Type: ${report.assessmentType === 'databricks' ? 'Databricks Engine' : 'Legacy Simulator'}`, margin, currentY);
    currentY += 10;


    doc.setFontSize(14);
    doc.setTextColor(deepTeal);
    doc.text(`Overall DQ Score: ${report.summary.overallScore.toFixed(1)}/10`, margin, currentY);
    currentY += 8;

    doc.setFontSize(12);
    doc.setTextColor(darkGray);
    doc.setFillColor(230, 247, 247); 
    doc.rect(margin, currentY, contentWidth, (doc.splitTextToSize(report.summary.overallAssessmentText, contentWidth).length * 5) + 4, 'F');
    doc.text("OVERALL ASSESSMENT:", margin + 2, currentY + 5);
    currentY += 7;
    const overallAssessmentLines = doc.splitTextToSize(report.summary.overallAssessmentText, contentWidth -4);
    doc.text(overallAssessmentLines, margin + 2, currentY);
    currentY += overallAssessmentLines.length * 5 + 8; 

    if (currentY > pageHeight - 30) { doc.addPage(); currentY = 20; }

    doc.setFontSize(14);
    doc.setTextColor(deepTeal);
    doc.text("Summary of Checks", margin, currentY);
    currentY += 8;
    doc.setFontSize(10);
    doc.setTextColor(darkGray);
    doc.text(`Total Rules Assessed: ${report.summary.totalRules}`, margin, currentY);
    currentY += 5;
    doc.text(`Rules Passed: ${report.summary.passed}`, margin, currentY);
    currentY += 5;
    doc.text(`Rules Failed: ${report.summary.failed}`, margin, currentY);
    currentY += 5;
    doc.text(`Rules with Errors: ${report.summary.errors}`, margin, currentY);
    currentY += 10;

    if (currentY > pageHeight - 60) { doc.addPage(); currentY = 20; } 

    doc.setFontSize(14);
    doc.setTextColor(deepTeal);
    doc.text("Dimension Analysis", margin, currentY);
    currentY += 8; 

    const dimensionTableData = report.summary.dimensionDetails.map(detail => [
      detail.name,
      `${detail.weight}%`,
      `${typeof detail.score === 'number' ? detail.score.toFixed(1) : 'N/A'}/10`,
      detail.observation
    ]);

    autoTable(doc, {
      startY: currentY,
      head: [['Dimension', 'Weight (%)', 'Score (/10)', 'Observation']],
      body: dimensionTableData,
      theme: 'striped',
      headStyles: { fillColor: deepTeal, textColor: '#FFFFFF' }, 
      styles: { font: "helvetica", fontSize: 9, cellPadding: 2 },
      columnStyles: { 3: { cellWidth: 'auto' } },
      margin: { left: margin, right: margin },
      didDrawPage: (data) => { currentY = data.cursor?.y || currentY; }
    });
    currentY = (doc as any).lastAutoTable.finalY + 10;
    
    if (currentY > pageHeight - 80) { 
      doc.addPage();
      currentY = 20;
    }
    
    doc.setFontSize(14);
    doc.setTextColor(deepTeal);
    doc.text("Dimension Score Visualization", margin, currentY);
    currentY += 10;

    const chartX = margin + 5; 
    const chartStartY = currentY;
    const maxBarWidth = contentWidth - 60; 
    const barHeight = 8;
    const barSpacing = 6; 
    const labelColumnWidth = 40; 

    doc.setFontSize(10);
    doc.setTextColor(darkGray);

    report.summary.dimensionDetails.forEach(detail => {
      if (detail.name.toString().toLowerCase() === "other" && detail.score === 0 && detail.weight === 0) return; 

      if (currentY + barHeight + barSpacing > pageHeight - 20) {
        doc.addPage();
        currentY = 20;
        doc.setFontSize(14); 
        doc.setTextColor(deepTeal);
        doc.text("Dimension Score Visualization (Continued)", margin, currentY);
        currentY += 10;
        doc.setFontSize(10);
        doc.setTextColor(darkGray);
      }

      const barWidth = (detail.score / 10) * maxBarWidth;

      doc.text(detail.name.toString(), chartX, currentY + barHeight / 1.5); 
      doc.setFillColor(softYellow); 
      doc.rect(chartX + labelColumnWidth, currentY, barWidth > 0 ? barWidth : 1 , barHeight, 'F'); 
      doc.setTextColor(darkGray);
      doc.text(`${typeof detail.score === 'number' ? detail.score.toFixed(1): 'N/A'}/10`, chartX + labelColumnWidth + (barWidth > 0 ? barWidth : 1) + 5, currentY + barHeight / 1.5);
      currentY += barHeight + barSpacing;
    });
    currentY += 5; 

    if (currentY > pageHeight - 60) { 
      doc.addPage();
      currentY = 20;
    }
    doc.setFontSize(14);
    doc.setTextColor(deepTeal);
    doc.text("Detailed Rule Results", margin, currentY);
    currentY += 8;

    const ruleTableData = report.assessmentResults.map(result => [
      result.ruleDescription,
      result.column,
      result.dimension,
      result.status,
      result.details, 
      result.recordsAffected ?? 'N/A'
    ]);

    autoTable(doc, {
      startY: currentY,
      head: [['Rule Description', 'Column', 'Dimension', 'Status', 'Details', 'Affected Records']],
      body: ruleTableData,
      theme: 'grid',
      headStyles: { fillColor: deepTeal, textColor: '#FFFFFF' },
      styles: { font: "helvetica", fontSize: 8, cellPadding: 1.5 },
      columnStyles: {
        0: { cellWidth: 40 }, 
        4: { cellWidth: 'auto' }, 
      },
      margin: { left: margin, right: margin },
      didDrawPage: (data) => { currentY = data.cursor?.y || currentY; }
    });
    
    const filename = `${report.name.replace(/[^a-z0-9_.-]/gi, '_').substring(0, 50)}.pdf`;
    doc.save(filename);

    toast({ title: "Download Started", description: `Downloading report ${filename}` });
  };

  const handleViewReport = (reportId: string) => {
     const report = reports.find(r => r.id === reportId);
    if (!report || report.status !== 'Completed' || !report.summary || !report.summary.dimensionDetails) {
      toast({ title: "Error", description: "Report not available for viewing.", variant: "destructive" });
      return;
    }
    
    let reportContentPreview = `Report: ${report.name}\n`;
    reportContentPreview += `Data Source: ${report.dataSourceName}\n`;
    reportContentPreview += `Overall Score: ${report.summary.overallScore.toFixed(1)}/10\n`;
    reportContentPreview += `Overall Assessment: ${report.summary.overallAssessmentText}\n\n`;
    reportContentPreview += `Dimension Scores:\n`;
    report.summary.dimensionDetails.forEach(detail => {
        if (detail.name.toString().toLowerCase() !== "other" || detail.score > 0) { 
             reportContentPreview += `- ${detail.name}: ${typeof detail.score === 'number' ? detail.score.toFixed(1) : 'N/A'}/10 (Weight: ${detail.weight}%)\n  Observation: ${detail.observation}\n`;
        }
    });
    
    alert(reportContentPreview); 
    toast({ title: "Viewing Report Preview", description: `Displaying details for ${report.name}.` });
  };
  
  if (!currentUser) {
    return <div className="container mx-auto py-8 text-center">Please log in to manage reports.</div>;
  }

  return (
    <div className="container mx-auto py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Data Quality Reports for {currentUser}</h1>
        <p className="text-muted-foreground">Generate and manage DQ reports. Select a data source and a specific assessment run (from legacy or Databricks assessments) to generate a PDF report.</p>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
            <CardTitle>Configure New Report</CardTitle>
            <CardDescription>Select a data source and one of its historical assessment runs to generate a report.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                 <div>
                    <Label htmlFor="dataSourceSelectForReport" className="flex items-center mb-1">
                        <Database className="mr-2 h-4 w-4 text-muted-foreground" /> Data Source
                    </Label>
                    <Select onValueChange={setSelectedDataSourceId} value={selectedDataSourceId}>
                        <SelectTrigger id="dataSourceSelectForReport">
                        <SelectValue placeholder="Select data source" />
                        </SelectTrigger>
                        <SelectContent>
                        {dataSourcesForSelect.length > 0 ? (
                            dataSourcesForSelect.map(ds => (
                            <SelectItem key={ds.id} value={ds.id}>{ds.name}</SelectItem>
                            ))
                        ) : (
                            <SelectItem value="no-sources" disabled>No data sources. Add on Data Sources page.</SelectItem>
                        )}
                        </SelectContent>
                    </Select>
                </div>

                <div>
                    <Label htmlFor="historicalRunSelectForReport" className="flex items-center mb-1">
                        <History className="mr-2 h-4 w-4 text-muted-foreground" /> Assessment Run
                    </Label>
                    <Select 
                        onValueChange={setSelectedHistoricalRunId} 
                        value={selectedHistoricalRunId}
                        disabled={!selectedDataSourceId || availableHistoricalRuns.length === 0}
                    >
                        <SelectTrigger id="historicalRunSelectForReport">
                        <SelectValue placeholder={!selectedDataSourceId ? "Select data source first" : "Select assessment run"} />
                        </SelectTrigger>
                        <SelectContent>
                        {availableHistoricalRuns.length > 0 ? (
                            availableHistoricalRuns.map(run => (
                            <SelectItem key={run.id} value={run.id}>
                                <FormattedDateTime date={run.timestamp} formatter={(d) => d.toLocaleString()} placeholder="Loading date..." />
                                {run.assessmentType === 'databricks' && run.databricksOutput && ` (DB Score: ${run.databricksOutput.overall_dq_score.toFixed(1)}/10)`}
                                {run.assessmentType === 'legacy' && run.summary && ` (Sim Score: ${run.summary.overallScore.toFixed(1)}/10)`}
                                <span className="ml-2 text-xs text-muted-foreground">({run.assessmentType})</span>
                            </SelectItem>
                            ))
                        ) : (
                            <SelectItem value="no-runs" disabled>
                                {selectedDataSourceId ? "No completed assessments for this source." : "Select a data source." }
                            </SelectItem>
                        )}
                        </SelectContent>
                    </Select>
                </div>
            </div>
        </CardContent>
        <CardFooter className="flex justify-end">
             <AlertDialog>
                <AlertDialogTrigger asChild>
                    <Button disabled={isGenerating || !selectedDataSourceId || !selectedHistoricalRunId}>
                    <PlusCircle className="mr-2 h-4 w-4" /> {isGenerating ? 'Generating...' : 'Generate Report'}
                    </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                    <AlertDialogHeader>
                    <AlertDialogTitle>Confirm Report Generation</AlertDialogTitle>
                    <AlertDialogDescription>
                        This will generate a new PDF report based on the selected data source and assessment run.
                        Are you sure you want to proceed?
                    </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleGenerateReport}>Generate</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </CardFooter>
      </Card>


      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Available Reports</CardTitle>
          <CardDescription>List of generated data quality reports. Reports are stored locally for the current user.</CardDescription>
        </CardHeader>
        <CardContent>
          {reports.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Report Name</TableHead>
                  <TableHead>Data Source</TableHead>
                  <TableHead>Assessment Date</TableHead>
                  <TableHead>Overall Score</TableHead>
                  <TableHead>Source Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell className="font-medium">{report.name}</TableCell>
                    <TableCell>{report.dataSourceName}</TableCell>
                    <TableCell>
                      <FormattedDateTime date={report.assessmentTimestamp} formatter={(d) => d.toLocaleString()} placeholder="Loading date..." />
                    </TableCell>
                    <TableCell>{report.summary ? `${report.summary.overallScore.toFixed(1)}/10` : 'N/A'}</TableCell>
                    <TableCell>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${report.assessmentType === 'databricks' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' : 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300'}`}>
                        {report.assessmentType === 'databricks' ? 'Databricks' : 'Simulated'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        report.status === 'Completed' ? 'bg-green-500/20 text-green-700 dark:text-green-400' :
                        report.status === 'Generating' ? 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-400 animate-pulse' :
                        'bg-red-500/20 text-red-700 dark:text-red-400'
                      }`}>
                        {report.status}
                      </span>
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button variant="outline" size="sm" onClick={() => handleViewReport(report.id)} disabled={report.status !== 'Completed'}>
                        <Eye className="mr-1 h-4 w-4" /> View Preview
                      </Button>
                      <Button variant="default" size="sm" onClick={() => handleDownloadReport(report.id)} disabled={report.status !== 'Completed'}>
                        <Download className="mr-1 h-4 w-4" /> Download PDF
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-10">
              <AlertTriangle className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-2 text-sm font-medium text-foreground">No reports available</h3>
              <p className="mt-1 text-sm text-muted-foreground">Generate a new report to see it listed here.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

    
