
"use client";

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Lightbulb, Zap, AlertTriangle, Database, ListChecks, CloudCog, Briefcase } from "lucide-react"; // Added Briefcase
import { Skeleton } from "@/components/ui/skeleton";
import { getCurrentMockUser, getUserSpecificKey, BASE_DS_KEY, BASE_RULES_KEY, BASE_ASSESSMENT_HISTORY_KEY } from '@/lib/authUtils';

interface Rule {
  id: string;
  description: string;
}

interface AssessmentRunSummary {
  totalRules: number;
  passed: number;
  failed: number;
  errors: number;
}

interface AssessmentRun {
  id: string;
  dataSourceName: string;
  timestamp: string | Date;
  status: 'Pending' | 'Running' | 'Completed' | 'Failed';
  summary?: AssessmentRunSummary;
}

interface DataSource {
  id: string;
  name: string;
}


export default function DashboardPage() {
  const [activeDataSourcesCount, setActiveDataSourcesCount] = useState<number | null>(null);
  const [dqRulesCount, setDqRulesCount] = useState<number | null>(null);
  const [recentDQIssuesCount, setRecentDQIssuesCount] = useState<number | null>(null);
  const [recentDQIssuesSummary, setRecentDQIssuesSummary] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  useEffect(() => {
    const user = getCurrentMockUser();
    setCurrentUser(user);

    if (user) {
      let sourcesCount = 0;
      let rulesCount = 0;
      let issuesCount = 0;
      let issuesSummaryText = "No issues or assessments yet";

      // Fetch Data Sources
      try {
        const dsStorageKey = getUserSpecificKey(BASE_DS_KEY, user);
        const dsItem = window.localStorage.getItem(dsStorageKey);
        const dataSources: DataSource[] = dsItem ? JSON.parse(dsItem) : [];
        sourcesCount = dataSources.length;
      } catch (e) {
        console.error("Error reading data sources from localStorage for dashboard", e);
        sourcesCount = 0;
      }
      setActiveDataSourcesCount(sourcesCount);

      // Fetch DQ Rules (assuming this is the count from Genkit editor for now)
      try {
        const rulesStorageKey = getUserSpecificKey(BASE_RULES_KEY, user); // Genkit rules
        const rulesByDSItem = window.localStorage.getItem(rulesStorageKey);
        const rulesByDataSource: { [key: string]: {rules: Rule[], dimensionWeights: any} } = rulesByDSItem ? JSON.parse(rulesByDSItem) : {};
        let totalRules = 0;
        Object.values(rulesByDataSource).forEach(config => {
          if (config && Array.isArray(config.rules)) {
            totalRules += config.rules.length;
          }
        });
        rulesCount = totalRules;
      } catch (e) {
        console.error("Error reading DQ rules from localStorage for dashboard", e);
        rulesCount = 0;
      }
      setDqRulesCount(rulesCount);

      // Fetch Assessment History for Recent Issues
      try {
        const historyStorageKey = getUserSpecificKey(BASE_ASSESSMENT_HISTORY_KEY, user);
        const historyItem = window.localStorage.getItem(historyStorageKey);
        const assessmentHistoryRaw: AssessmentRun[] = historyItem ? JSON.parse(historyItem) : [];
        const assessmentHistory = assessmentHistoryRaw.map(run => ({
          ...run,
          timestamp: new Date(run.timestamp)
        })).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());


        const latestCompletedRun = assessmentHistory.find(run => run.status === 'Completed' && run.summary);

        if (latestCompletedRun && latestCompletedRun.summary) {
          issuesCount = (latestCompletedRun.summary.failed || 0) + (latestCompletedRun.summary.errors || 0);
          issuesSummaryText = `${latestCompletedRun.summary.failed || 0} failed, ${latestCompletedRun.summary.errors || 0} errors in last run`;
        }
      } catch (e) {
        console.error("Error reading assessment history from localStorage for dashboard", e);
        issuesCount = 0;
      }
      setRecentDQIssuesCount(issuesCount);
      setRecentDQIssuesSummary(issuesSummaryText);
    } else {
        // Handle case where there is no user
        setActiveDataSourcesCount(0);
        setDqRulesCount(0);
        setRecentDQIssuesCount(0);
        setRecentDQIssuesSummary("Log in to see your data");
    }
    setIsLoading(false);
  }, []);

  if (!currentUser && !isLoading) {
     return (
        <div className="container mx-auto py-8 text-center">
            <h1 className="text-2xl font-bold text-foreground mb-4">Welcome to DataQualityLens</h1>
            <p className="text-muted-foreground mb-6">Please log in to access your dashboard and data quality tools.</p>
            <Button asChild>
                <Link href="/login-mock">Go to Login</Link>
            </Button>
        </div>
    );
  }


  return (
    <div className="container mx-auto py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Welcome, {currentUser || 'User'}!</h1>
        <p className="text-muted-foreground">Your central hub for monitoring and improving data quality.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Data Sources</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-2xl font-bold">{activeDataSourcesCount ?? 0}</div>
            )}
            <p className="text-xs text-muted-foreground">Currently managed</p>
            <Button variant="outline" size="sm" className="mt-4" asChild>
              <Link href="/data-sources">Manage Sources</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">DQ Rules Defined (Genkit)</CardTitle>
            <ListChecks className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <div className="text-2xl font-bold">{dqRulesCount ?? 0}</div>
            )}
            <p className="text-xs text-muted-foreground">Across all sources</p>
            <Button variant="outline" size="sm" className="mt-4" asChild>
              <Link href="/rules-editor">View Genkit Rules</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recent DQ Issues (Sim)</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-12" />
            ) : (
              <div className={`text-2xl font-bold ${(recentDQIssuesCount ?? 0) > 0 ? 'text-destructive' : ''}`}>
                {recentDQIssuesCount ?? 0}
              </div>
            )}
            {isLoading ? (
                <Skeleton className="h-4 w-40 mt-1" />
            ) : (
                 <p className="text-xs text-muted-foreground">{recentDQIssuesSummary}</p>
            )}
            <Button variant={(recentDQIssuesCount ?? 0) > 0 ? "destructive" : "outline"} size="sm" className="mt-4" asChild>
              <Link href="/assessment">View Issues</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center"><Lightbulb className="mr-2 h-5 w-5 text-accent" />Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col space-y-3">
            <Button asChild><Link href="/data-sources">Add New Data Source</Link></Button>
            <Button variant="secondary" asChild><Link href="/rules-editor">Suggest DQ Rules with AI</Link></Button>
            <Button variant="secondary" asChild><Link href="/reports">Generate DQ Report</Link></Button>
             <Button variant="outline" asChild className="border-accent hover:bg-accent/10">
                <Link href="/data-nexus" className="flex items-center">
                    <Briefcase className="mr-2 h-4 w-4 text-accent" /> Connect to Data Nexus Storage
                </Link>
            </Button>
          </CardContent>
        </Card>
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center"><Zap className="mr-2 h-5 w-5 text-accent" />Explore Features</CardTitle>
            <CardDescription>Dive deeper into DataQualityLens capabilities.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Link href="/chatbot" className="block text-sm text-primary hover:underline">Analyze Issues with AI Chatbot</Link>
            <Link href="/assessment" className="block text-sm text-primary hover:underline">Run Old DQ Assessment (Sim)</Link>
            <Link href="/data-nexus-assessment" className="block text-sm text-primary hover:underline">Run Data Nexus Assessment</Link>
            <Link href="/auditing" className="block text-sm text-primary hover:underline">View Audit Logs</Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
    
    