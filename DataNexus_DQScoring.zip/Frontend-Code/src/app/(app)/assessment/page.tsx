
"use client";

import React, { useState, useEffect, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import { PlayCircle, CheckCircle2, XCircle, AlertTriangle, RefreshCw, BarChart3, Eye } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { FormattedDateTime } from '@/components/FormattedDateTime';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LabelList } from 'recharts';
import { addAuditLog, getCurrentMockUser, getUserSpecificKey, BASE_DS_KEY, BASE_RULES_KEY, BASE_ASSESSMENT_HISTORY_KEY } from '@/lib/authUtils';

const DIMENSION_NAMES = ["Accuracy", "Completeness", "Consistency", "Uniqueness"] as const;
type DimensionName = typeof DIMENSION_NAMES[number];

interface RuleFromStorage {
  id: string;
  description: string;
  column: string;
  dimension?: DimensionName | 'Other';
  weight?: number;
  type?: string;
  rationale?: string;
}

interface AssessmentResult {
  ruleDescription: string;
  column: string;
  status: 'Pass' | 'Fail' | 'Error';
  details: string;
  recordsAffected?: number;
  dimension: DimensionName | 'Other';
}

interface AssessmentRun {
  id: string;
  dataSourceId: string;
  dataSourceName: string;
  timestamp: Date;
  status: 'Pending' | 'Running' | 'Completed' | 'Failed';
  progress: number;
  results: AssessmentResult[];
  summary?: {
    totalRules: number;
    passed: number;
    failed: number;
    errors: number;
    dimensionScores: Record<DimensionName | "Other", number>;
    overallScore: number;
  };
}

interface DataSourceForSelect {
  id: string;
  name: string;
}

interface StoredRulesEditorConfig {
  rules: RuleFromStorage[];
  dimensionWeights: Record<DimensionName, number>;
}


export default function AssessmentPage() {
  const { toast } = useToast();
  const [dataSourcesForSelect, setDataSourcesForSelect] = useState<DataSourceForSelect[]>([]);
  const [selectedDataSourceId, setSelectedDataSourceId] = useState<string | undefined>(undefined);
  const [assessmentHistory, setAssessmentHistory] = useState<AssessmentRun[]>([]);
  const [currentRun, setCurrentRun] = useState<AssessmentRun | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  useEffect(() => {
    const user = getCurrentMockUser();
    setCurrentUser(user);
    if (user) {
      try {
        const dsStorageKey = getUserSpecificKey(BASE_DS_KEY, user);
        const dsItem = window.localStorage.getItem(dsStorageKey);
        setDataSourcesForSelect(dsItem ? JSON.parse(dsItem) : []);

        const historyStorageKey = getUserSpecificKey(BASE_ASSESSMENT_HISTORY_KEY, user);
        const historyItem = window.localStorage.getItem(historyStorageKey);
        setAssessmentHistory(historyItem ? JSON.parse(historyItem).map((run: AssessmentRun) => ({...run, timestamp: new Date(run.timestamp)})) : []);
      } catch (error) {
        console.error("Error reading from localStorage for Assessment Page", error);
        setDataSourcesForSelect([]);
        setAssessmentHistory([]);
      }
    } else {
        setDataSourcesForSelect([]);
        setAssessmentHistory([]);
    }
  }, []);

  useEffect(() => {
    if (currentUser && assessmentHistory.length >= 0) {
      try {
        const historyStorageKey = getUserSpecificKey(BASE_ASSESSMENT_HISTORY_KEY, currentUser);
        window.localStorage.setItem(historyStorageKey, JSON.stringify(assessmentHistory));
      } catch (error) {
        console.error("Error saving assessment history to localStorage", error);
      }
    }
  }, [assessmentHistory, currentUser]);

  const calculateScores = (results: AssessmentResult[]): AssessmentRun['summary'] => {
    const dimensionScoresRaw: Record<DimensionName | "Other", { totalScore: number; count: number }> = {
      Accuracy: { totalScore: 0, count: 0 },
      Completeness: { totalScore: 0, count: 0 },
      Consistency: { totalScore: 0, count: 0 },
      Uniqueness: { totalScore: 0, count: 0 },
      Other: { totalScore: 0, count: 0 },
    };

    results.forEach(result => {
      let score = 0;
      if (result.status === 'Pass') score = 10;
      else if (result.status === 'Fail') score = 3;
      else if (result.status === 'Error') score = 0;

      const dim = result.dimension || "Other";
      dimensionScoresRaw[dim].totalScore += score;
      dimensionScoresRaw[dim].count += 1;
    });

    const finalDimensionScores: Record<DimensionName | "Other", number> = {} as any;
    let totalOverallScore = 0;
    let numDimensionsForOverall = 0;

    for (const dim in dimensionScoresRaw) {
      const key = dim as DimensionName | "Other";
      if (dimensionScoresRaw[key].count > 0) {
        // Individual dimension scores should be between 0 and 10
        const individualDimScore = parseFloat((dimensionScoresRaw[key].totalScore / dimensionScoresRaw[key].count).toFixed(1));
        finalDimensionScores[key] = Math.min(10, Math.max(0, individualDimScore)); // Defensive cap

        if (DIMENSION_NAMES.includes(key as DimensionName)) {
             totalOverallScore += finalDimensionScores[key];
             numDimensionsForOverall++;
        }
      } else {
        finalDimensionScores[key] = 0;
        // If a main dimension has 0 rules, it does not contribute to numDimensionsForOverall or totalOverallScore here.
        // If we want it to count as a 0-scored dimension:
        // if (DIMENSION_NAMES.includes(key as DimensionName)) {
        //   numDimensionsForOverall++;
        // }
      }
    }
    
    // The overall score is an average of the main dimension scores.
    // This average itself should be between 0-10 if individual dimension scores are capped.
    // The Math.min(10, ...) provides the final definitive cap.
    const overallScore = numDimensionsForOverall > 0 ? Math.min(10, parseFloat((totalOverallScore / numDimensionsForOverall).toFixed(1))) : 0;

    return {
      totalRules: results.length,
      passed: results.filter(r => r.status === 'Pass').length,
      failed: results.filter(r => r.status === 'Fail').length,
      errors: results.filter(r => r.status === 'Error').length,
      dimensionScores: finalDimensionScores,
      overallScore: overallScore,
    };
  };

  const handleRunAssessment = () => {
    if (!currentUser) {
      toast({ title: "Error", description: "No active user session.", variant: "destructive" });
      return;
    }
    if (!selectedDataSourceId) {
      toast({ title: "Error", description: "Please select a data source.", variant: "destructive" });
      return;
    }
    setIsLoading(true);
    const selectedDS = dataSourcesForSelect.find(ds => ds.id === selectedDataSourceId);
    const dataSourceName = selectedDS?.name || "Unknown Source";

    let rulesForSource: RuleFromStorage[] = [];
    try {
      const rulesStorageKey = getUserSpecificKey(BASE_RULES_KEY, currentUser);
      const allConfigsItem = window.localStorage.getItem(rulesStorageKey);
      if (allConfigsItem) {
        const allStoredConfigs: Record<string, StoredRulesEditorConfig> = JSON.parse(allConfigsItem);
        const configForSelectedDS = allStoredConfigs[selectedDataSourceId];
        if (configForSelectedDS && Array.isArray(configForSelectedDS.rules)) {
          rulesForSource = configForSelectedDS.rules;
        }
      }
    } catch (error) {
      console.error("Error reading rules from localStorage for assessment", error);
      rulesForSource = [];
    }

    if (rulesForSource.length === 0) {
      toast({
        title: "No Rules Defined",
        description: `No data quality rules found for "${dataSourceName}". Please define rules in the Rules Editor.`,
        variant: "destructive",
        duration: 5000,
      });
      setIsLoading(false);
      return;
    }

    const runId = `run-${Date.now()}`;
    const newRun: AssessmentRun = {
      id: runId,
      dataSourceId: selectedDataSourceId,
      dataSourceName,
      timestamp: new Date(),
      status: 'Running',
      progress: 0,
      results: [],
    };
    setCurrentRun(newRun);
    addAuditLog(
      'INITIATE_ASSESSMENT',
      `Initiated assessment for data source '${dataSourceName}'. Using ${rulesForSource.length} rule(s).`,
      'Assessment',
      runId
    );

    let progress = 0;
    const interval = setInterval(() => {
      progress += 20;
      if (progress <= 100) {
        setCurrentRun(prev => prev ? { ...prev, progress } : null);
      } else {
        clearInterval(interval);

        const mockResults: AssessmentResult[] = rulesForSource.map((rule, index) => {
            const statuses: Array<'Pass' | 'Fail' | 'Error'> = ['Pass', 'Fail', 'Error', 'Pass', 'Pass', 'Fail'];
            const randomStatus = statuses[index % statuses.length];
            let details = "";
            let recordsAffected: number | undefined = undefined;

            switch (randomStatus) {
                case 'Pass':
                    details = `Rule '${rule.description}' on column '${rule.column}' passed.`;
                    recordsAffected = 0;
                    break;
                case 'Fail':
                    recordsAffected = Math.floor(Math.random() * 50) + 1;
                    details = `${recordsAffected} records failed for rule '${rule.description}' on column '${rule.column}'.`;
                    break;
                case 'Error':
                    details = `Error processing rule '${rule.description}' for column '${rule.column}'.`;
                    recordsAffected = undefined;
                    break;
            }
            return {
                ruleDescription: rule.description,
                column: rule.column,
                status: randomStatus,
                details: details,
                recordsAffected: recordsAffected,
                dimension: rule.dimension || "Other",
            };
        });

        const summary = calculateScores(mockResults);

        const completedRun: AssessmentRun = {
          ...newRun,
          status: 'Completed',
          progress: 100,
          results: mockResults,
          timestamp: new Date(),
          summary: summary
        };
        setCurrentRun(completedRun);
        setAssessmentHistory(prev => [completedRun, ...prev.slice(0, 19)]);
        addAuditLog(
          'COMPLETE_ASSESSMENT',
          `Completed assessment for data source '${completedRun.dataSourceName}'. Score: ${summary.overallScore.toFixed(1)}/10. ${summary.passed}/${summary.totalRules} rules passed.`,
          'Assessment',
          completedRun.id
        );
        toast({ title: "Success", description: `Assessment for ${dataSourceName} completed using ${rulesForSource.length} rule(s).` });
        setIsLoading(false);
      }
    }, 500);
  };

  const getStatusIcon = (status: AssessmentResult['status'] | AssessmentRun['status']) => {
    switch (status) {
      case 'Pass':
      case 'Completed':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'Fail':
      case 'Failed':
        return <XCircle className="h-4 w-4 text-destructive" />;
      case 'Error':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'Running':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'Pending':
        return <PlayCircle className="h-4 w-4 text-muted-foreground" />;
      default:
        return null;
    }
  };

  const chartData = useMemo(() => {
    if (currentRun?.summary?.dimensionScores) {
      return DIMENSION_NAMES.map(dimName => ({
        name: dimName,
        score: currentRun.summary!.dimensionScores[dimName] || 0,
      }));
    }
    return [];
  }, [currentRun?.summary?.dimensionScores]);

  const displayedHistory = useMemo(() => {
    if (selectedDataSourceId) {
      return assessmentHistory.filter(run => run.dataSourceId === selectedDataSourceId);
    }
    return assessmentHistory;
  }, [assessmentHistory, selectedDataSourceId]);

  if (!currentUser) {
    return <div className="container mx-auto py-8 text-center">Please log in to manage assessments.</div>;
  }

  return (
    <div className="container mx-auto py-8 space-y-8">
       <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Data Quality Assessment for {currentUser}</h1>
        <p className="text-muted-foreground">Execute DQ rules, monitor progress, and review assessment results. Rules are sourced from the Rules Editor (Genkit AI).</p>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Run New Assessment</CardTitle>
          <CardDescription>Select a data source to assess using its saved rules from the Rules Editor. History below will filter by this selection.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-end gap-4">
            <div className="flex-grow">
              <Label htmlFor="dataSourceSelect">Data Source</Label>
              <Select onValueChange={setSelectedDataSourceId} value={selectedDataSourceId}>
                <SelectTrigger id="dataSourceSelect">
                  <SelectValue placeholder="Select data source" />
                </SelectTrigger>
                <SelectContent>
                  {dataSourcesForSelect.length > 0 ? (
                    dataSourcesForSelect.map(ds => (
                      <SelectItem key={ds.id} value={ds.id}>{ds.name}</SelectItem>
                    ))
                  ) : (
                     <SelectItem value="no-sources" disabled>No data sources available. Add them on the Data Sources page.</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleRunAssessment} disabled={isLoading || !selectedDataSourceId}>
              <PlayCircle className="mr-2 h-4 w-4" /> {isLoading ? 'Running...' : 'Run Assessment'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {currentRun && (
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center">
              Current Run: {currentRun.dataSourceName}
              <span className="ml-2">{getStatusIcon(currentRun.status)}</span>
            </CardTitle>
            <CardDescription>
              Status: {currentRun.status} - Last updated: <FormattedDateTime date={currentRun.timestamp} formatter={(d) => d.toLocaleString()} placeholder="Loading date..." />
              {currentRun.summary && currentRun.status === 'Completed' && (
                <span className="block mt-1">Overall DQ Score: <strong className="text-lg">{currentRun.summary.overallScore.toFixed(1)}/10</strong></span>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={currentRun.progress} className="w-full mb-4" />
            {currentRun.status === 'Completed' && currentRun.summary && (
              <>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-center">
                  <div className="p-3 bg-secondary rounded-md">
                    <p className="text-xs text-muted-foreground">Total Rules</p>
                    <p className="text-xl font-bold">{currentRun.summary.totalRules}</p>
                  </div>
                  <div className="p-3 bg-secondary rounded-md">
                    <p className="text-xs text-muted-foreground">Passed</p>
                    <p className="text-xl font-bold text-green-500">{currentRun.summary.passed}</p>
                  </div>
                  <div className="p-3 bg-secondary rounded-md">
                    <p className="text-xs text-muted-foreground">Failed</p>
                    <p className="text-xl font-bold text-destructive">{currentRun.summary.failed}</p>
                  </div>
                  <div className="p-3 bg-secondary rounded-md">
                    <p className="text-xs text-muted-foreground">Errors</p>
                    <p className="text-xl font-bold text-yellow-500">{currentRun.summary.errors}</p>
                  </div>
                </div>

                {chartData.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-2 text-foreground flex items-center"><BarChart3 className="mr-2 h-5 w-5" />Dimension Scores</h3>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={chartData} margin={{ top: 20, right: 0, left: -20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="name" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
                        <YAxis domain={[0, 10]} tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
                        <Tooltip
                          contentStyle={{ backgroundColor: 'hsl(var(--background))', border: '1px solid hsl(var(--border))', borderRadius: 'var(--radius)' }}
                          labelStyle={{ color: 'hsl(var(--foreground))' }}
                          itemStyle={{ color: 'hsl(var(--primary))' }}
                        />
                        <Bar dataKey="score" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]}>
                          <LabelList dataKey="score" position="top" fill="hsl(var(--foreground))" fontSize={12} formatter={(value: number) => value.toFixed(1)} />
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </>
            )}
            {currentRun.results.length > 0 && (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rule Description</TableHead>
                    <TableHead>Column</TableHead>
                    <TableHead>Dimension</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Details</TableHead>
                    <TableHead>Records Affected</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {currentRun.results.map((result, index) => (
                    <TableRow key={index}>
                      <TableCell>{result.ruleDescription}</TableCell>
                      <TableCell>{result.column}</TableCell>
                      <TableCell>{result.dimension}</TableCell>
                      <TableCell className="flex items-center">{getStatusIcon(result.status)} <span className="ml-2">{result.status}</span></TableCell>
                      <TableCell>{result.details}</TableCell>
                      <TableCell>{result.recordsAffected ?? 'N/A'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      )}

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Assessment History {selectedDataSourceId ? `for ${dataSourcesForSelect.find(ds => ds.id === selectedDataSourceId)?.name || ''}` : '(All Sources)'}</CardTitle>
          <CardDescription>View past assessment runs. {selectedDataSourceId ? 'Filtered by the data source selected above.' : 'Select a data source above to filter.'}</CardDescription>
        </CardHeader>
        <CardContent>
          {displayedHistory.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data Source</TableHead>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Overall Score</TableHead>
                  <TableHead>Summary</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {displayedHistory.map((run) => (
                  <TableRow key={run.id}>
                    <TableCell>{run.dataSourceName}</TableCell>
                    <TableCell>
                       <FormattedDateTime date={run.timestamp} formatter={(d) => d.toLocaleString()} placeholder="Loading date..." />
                    </TableCell>
                    <TableCell className="flex items-center">{getStatusIcon(run.status)} <span className="ml-2">{run.status}</span></TableCell>
                    <TableCell>{run.summary ? `${run.summary.overallScore.toFixed(1)}/10` : 'N/A'}</TableCell>
                    <TableCell>
                      {run.summary ? `${run.summary.passed}/${run.summary.totalRules} Passed` : 'N/A'}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" onClick={() => setCurrentRun(run)}> <Eye className="mr-1 h-4 w-4" /> View Details</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
             <div className="text-center py-10">
                <PlayCircle className="mx-auto h-12 w-12 text-muted-foreground" />
                <h3 className="mt-2 text-sm font-medium text-foreground">No assessment history {selectedDataSourceId ? 'for this data source' : ''}</h3>
                <p className="mt-1 text-sm text-muted-foreground">Run an assessment to see results here.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

    