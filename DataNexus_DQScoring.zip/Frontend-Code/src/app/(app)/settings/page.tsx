
"use client";

import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from '@/components/ui/button';
import { getCurrentMockUser } from '@/lib/authUtils';
import { UserCircle, KeyRound, Mail, ShieldAlert } from 'lucide-react';

export default function SettingsPage() {
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  useEffect(() => {
    setCurrentUser(getCurrentMockUser());
  }, []);

  // For prototype, account ID can just be the username or a transformation
  const accountId = currentUser ? `dql-${currentUser.split('@')[0]}-${currentUser.length * 7}` : 'N/A';

  return (
    <div className="container mx-auto py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Account Settings</h1>
        <p className="text-muted-foreground">Manage your account details and preferences.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center"><UserCircle className="mr-2 h-5 w-5 text-primary" /> Profile Information</CardTitle>
              <CardDescription>View your current profile details. Updates are not supported in this prototype.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1">
                <Label htmlFor="email">Email / Username</Label>
                <Input id="email" type="email" value={currentUser || ''} readOnly disabled />
              </div>
              <div className="space-y-1">
                <Label htmlFor="accountId">Unique Account ID</Label>
                <Input id="accountId" type="text" value={accountId} readOnly disabled />
              </div>
               <div className="flex items-center p-3 bg-destructive/10 border border-destructive/30 rounded-md">
                 <ShieldAlert className="h-5 w-5 text-destructive mr-3 shrink-0" />
                 <p className="text-xs text-destructive-foreground">
                    For security reasons, password management is not available in this prototype environment.
                 </p>
               </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center"><KeyRound className="mr-2 h-5 w-5 text-primary" /> Security</CardTitle>
              <CardDescription>Security settings are not functional in this prototype.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <Button variant="outline" disabled>Change Password (Disabled)</Button>
                <Button variant="outline" disabled>Enable Two-Factor Auth (Disabled)</Button>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-1">
           <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center"><Mail className="mr-2 h-5 w-5 text-primary" /> Notifications</CardTitle>
              <CardDescription>Notification preferences are placeholders.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <p className="text-sm text-muted-foreground">Email Notifications: <span className="font-medium text-foreground">Enabled</span></p>
              <Button variant="link" className="p-0 h-auto text-xs" disabled>(Manage Preferences - Disabled)</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
