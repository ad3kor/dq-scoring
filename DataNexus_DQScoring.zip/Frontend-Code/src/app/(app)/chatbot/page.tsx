
"use client";

import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Send, Bot, User, MessageSquare, Database, History } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { analyzeDataQualityIssuesAction } from '@/app/actions';
import { cn } from '@/lib/utils';
import { FormattedDateTime } from '@/components/FormattedDateTime';
import { addAuditLog, getCurrentMockUser, getUserSpecificKey, BASE_DS_KEY, BASE_ASSESSMENT_HISTORY_KEY } from '@/lib/authUtils';


interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

interface DataSourceForSelect {
  id: string;
  name: string;
}

const DIMENSION_NAMES = ["Accuracy", "Completeness", "Consistency", "Uniqueness"] as const;
type DimensionName = typeof DIMENSION_NAMES[number];

interface AssessmentRunSummaryFromStorage {
    totalRules: number;
    passed: number;
    failed: number;
    errors: number;
    dimensionScores: Record<DimensionName | "Other", number>;
    overallScore: number;
}

interface AssessmentResultForChat {
  ruleDescription: string;
  column: string;
  status: 'Pass' | 'Fail' | 'Error';
  details: string;
  dimension: DimensionName | 'Other';
  recordsAffected?: number;
}

interface AssessmentRunFromStorage {
    id: string;
    dataSourceId: string;
    dataSourceName: string;
    timestamp: Date;
    status: 'Pending' | 'Running' | 'Completed' | 'Failed';
    results: AssessmentResultForChat[];
    summary?: AssessmentRunSummaryFromStorage;
}


function stringifyAssessmentSummaryForChatbot(
  run: AssessmentRunFromStorage | undefined, 
  dataSourceName: string
): string {
  if (!run || !run.summary) return `No assessment summary found for ${dataSourceName} for the selected period.`;

  const summary = run.summary;
  let reportContext = `Data Quality Report Summary for: ${dataSourceName} (Assessed at: ${new Date(run.timestamp).toLocaleString()})\n`;
  reportContext += `Overall DQ Score: ${summary.overallScore.toFixed(1)}/10\n`;
  reportContext += `Total Rules Assessed: ${summary.totalRules}, Passed: ${summary.passed}, Failed: ${summary.failed}, Errors: ${summary.errors}\n\n`;
  
  reportContext += "Dimension Scores:\n";
  for (const dim of DIMENSION_NAMES) {
    reportContext += `  - ${dim}: ${summary.dimensionScores[dim]?.toFixed(1) || 'N/A'}/10\n`;
  }
  if (summary.dimensionScores["Other"]) {
     reportContext += `  - Other: ${summary.dimensionScores["Other"]?.toFixed(1) || 'N/A'}/10\n`;
  }

  if (run.results && run.results.length > 0) {
    const failingRules = run.results.filter(r => r.status === 'Fail').slice(0, 3); 
    if (failingRules.length > 0) {
      reportContext += "\nKey Failing Rules:\n";
      failingRules.forEach(rule => {
        reportContext += `  - Rule: "${rule.ruleDescription}" on column "${rule.column}" (${rule.dimension}). Details: ${rule.details}\n`;
      });
    }
  }
  return reportContext;
}


export default function ChatbotPage() {
  const { toast } = useToast();
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [dataSourcesForSelect, setDataSourcesForSelect] = useState<DataSourceForSelect[]>([]);
  const [selectedDataSourceId, setSelectedDataSourceId] = useState<string | undefined>(undefined);
  
  const [availableHistoricalRuns, setAvailableHistoricalRuns] = useState<AssessmentRunFromStorage[]>([]);
  const [selectedHistoricalRunId, setSelectedHistoricalRunId] = useState<string | undefined>(undefined);

  const [userQuery, setUserQuery] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isSending, setIsSending] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const user = getCurrentMockUser();
    setCurrentUser(user);
    if (user) {
      try {
        const dsStorageKey = getUserSpecificKey(BASE_DS_KEY, user);
        const dsItem = window.localStorage.getItem(dsStorageKey);
        setDataSourcesForSelect(dsItem ? JSON.parse(dsItem) : []);
      } catch (error) {
        console.error("Error reading data sources from localStorage for Chatbot Page", error);
        setDataSourcesForSelect([]);
      }
    } else {
        setDataSourcesForSelect([]);
    }
  }, []);

  useEffect(() => {
    if (selectedDataSourceId && currentUser) {
      try {
        const historyStorageKey = getUserSpecificKey(BASE_ASSESSMENT_HISTORY_KEY, currentUser);
        const historyItem = window.localStorage.getItem(historyStorageKey);
        if (historyItem) {
          const allHistory: AssessmentRunFromStorage[] = JSON.parse(historyItem).map((run: any) => ({...run, timestamp: new Date(run.timestamp)}));
          const relevantRuns = allHistory
            .filter(run => run.dataSourceId === selectedDataSourceId && run.status === 'Completed' && run.summary)
            .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
          
          setAvailableHistoricalRuns(relevantRuns);
          if (relevantRuns.length > 0) {
            setSelectedHistoricalRunId(relevantRuns[0].id); 
          } else {
            setSelectedHistoricalRunId(undefined);
             toast({ 
                title: "No Assessments Found", 
                description: `No completed assessments available for the selected data source. AI context will be limited.`, 
                variant: "default",
                duration: 5000 
            });
          }
        } else {
          setAvailableHistoricalRuns([]);
          setSelectedHistoricalRunId(undefined);
        }
      } catch (error) {
        console.error("Error reading assessment history for selected data source:", error);
        setAvailableHistoricalRuns([]);
        setSelectedHistoricalRunId(undefined);
      }
    } else {
      setAvailableHistoricalRuns([]);
      setSelectedHistoricalRunId(undefined);
    }
  }, [selectedDataSourceId, currentUser, toast]);

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTo({ top: scrollAreaRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!currentUser) {
      toast({ title: "Error", description: "No active user session.", variant: "destructive" });
      return;
    }
    if (!userQuery.trim()) {
      toast({ title: "Error", description: "Please enter a query.", variant: "destructive" });
      return;
    }
    if (!selectedDataSourceId) {
      toast({ title: "Error", description: "Please select a Data Source.", variant: "destructive" });
      return;
    }

    const selectedDS = dataSourcesForSelect.find(ds => ds.id === selectedDataSourceId);
    if (!selectedDS) {
      toast({ title: "Error", description: "Selected data source not found.", variant: "destructive" });
      return;
    }
    
    setIsSending(true);
    const newUserMessage: Message = {
      id: `user-${Date.now()}`,
      text: userQuery,
      sender: 'user',
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, newUserMessage]);
    setUserQuery('');

    let reportContextString = `No assessment summary available for ${selectedDS.name}.`;
    let chosenRun: AssessmentRunFromStorage | undefined = undefined;

    if (selectedHistoricalRunId) {
      chosenRun = availableHistoricalRuns.find(run => run.id === selectedHistoricalRunId);
    }
    
    if (chosenRun) {
      reportContextString = stringifyAssessmentSummaryForChatbot(chosenRun, selectedDS.name);
    } else if (availableHistoricalRuns.length > 0 && !selectedHistoricalRunId) {
      chosenRun = availableHistoricalRuns[0]; 
      reportContextString = stringifyAssessmentSummaryForChatbot(chosenRun, selectedDS.name);
       toast({ 
            title: "Context Note", 
            description: `Using latest assessment for "${selectedDS.name}" as context.`, 
            variant: "default",
            duration: 3000 
        });
    } else {
         toast({ 
            title: "Context Missing", 
            description: `No completed assessment summary found for "${selectedDS.name}". The AI will have limited context.`, 
            variant: "default",
            duration: 7000 
        });
    }

    addAuditLog(
      'CHATBOT_QUERY',
      `User asked: "${newUserMessage.text.substring(0, 100)}${newUserMessage.text.length > 100 ? '...' : ''}" about data source '${selectedDS.name}'. Context: Assessment Run ID ${chosenRun?.id || 'N/A'}.`,
      'ChatInteraction',
      newUserMessage.id
    );

    try {
      const result = await analyzeDataQualityIssuesAction({
        userQuery: newUserMessage.text,
        dataQualityReport: reportContextString,
      });

      const aiResponse: Message = {
        id: `ai-${Date.now()}`,
        text: result.answer || "I'm sorry, I couldn't process that request.",
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error("Error analyzing issues:", error);
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        text: "An error occurred while trying to get an answer. Please try again.",
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
      toast({ title: "Error", description: "Failed to get response from AI.", variant: "destructive" });
    } finally {
      setIsSending(false);
    }
  };
  
  const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter' && !event.shiftKey && !isSending && selectedDataSourceId && userQuery.trim()) {
      event.preventDefault(); 
      handleSendMessage();
    }
  };

  if (!currentUser) {
    return <div className="container mx-auto py-8 text-center">Please log in to use the AI Chatbot.</div>;
  }

  return (
    <div className="container mx-auto py-8 h-full flex flex-col">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">AI Chatbot for {currentUser}</h1>
        <p className="text-muted-foreground">Select a data source and an assessment run to provide context for your questions.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 flex-1">
        <Card className="md:col-span-1 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center"><Database className="mr-2 h-5 w-5 text-primary" />Context Selection</CardTitle>
            <CardDescription>Choose a data source and then a specific assessment run for the AI context.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="dataSourceSelect">Data Source</Label>
              <Select onValueChange={setSelectedDataSourceId} value={selectedDataSourceId}>
                <SelectTrigger id="dataSourceSelect">
                  <SelectValue placeholder="Select data source" />
                </SelectTrigger>
                <SelectContent>
                  {dataSourcesForSelect.length > 0 ? (
                    dataSourcesForSelect.map(ds => (
                      <SelectItem key={ds.id} value={ds.id}>{ds.name}</SelectItem>
                    ))
                  ) : (
                     <SelectItem value="no-sources" disabled>No data sources. Add on Data Sources page.</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            {selectedDataSourceId && availableHistoricalRuns.length > 0 && (
              <div className="space-y-2">
                <Label htmlFor="historicalRunSelect" className="flex items-center">
                    <History className="mr-2 h-4 w-4 text-muted-foreground" /> Assessment Run
                </Label>
                <Select onValueChange={setSelectedHistoricalRunId} value={selectedHistoricalRunId}>
                  <SelectTrigger id="historicalRunSelect">
                    <SelectValue placeholder="Select assessment run" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableHistoricalRuns.map(run => (
                      <SelectItem key={run.id} value={run.id}>
                        <FormattedDateTime date={run.timestamp} formatter={(d) => d.toLocaleString()} placeholder="Loading date..." />
                        {run.summary && ` (Score: ${run.summary.overallScore.toFixed(1)}/10)`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            {selectedDataSourceId && availableHistoricalRuns.length === 0 && (
                <p className="text-xs text-muted-foreground">No completed assessment runs found for this data source.</p>
            )}
          </CardContent>
        </Card>

        <Card className="md:col-span-2 shadow-lg flex flex-col h-full">
          <CardHeader>
            <CardTitle className="flex items-center"><MessageSquare className="mr-2 h-5 w-5 text-primary" />Chat Interface</CardTitle>
            <CardDescription>Interact with the AI to understand your data quality based on the selected context.</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden p-0">
            <ScrollArea className="h-[calc(100vh-450px)] md:h-[calc(100vh-400px)] p-4" ref={scrollAreaRef}>
              {messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                  <Bot className="h-12 w-12 mb-2" />
                  <p>No messages yet. Select context and start asking!</p>
                </div>
              ) : (
                messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={cn(
                      "flex items-start gap-3 mb-4 p-3 rounded-lg max-w-[85%]",
                      msg.sender === 'user' ? "ml-auto bg-primary text-primary-foreground" : "mr-auto bg-secondary text-secondary-foreground"
                    )}
                  >
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={msg.sender === 'user' ? "https://placehold.co/40x40.png?text=U" : "https://placehold.co/40x40.png?text=AI"} data-ai-hint={msg.sender === 'user' ? "user avatar" : "robot avatar"} />
                      <AvatarFallback>{msg.sender === 'user' ? 'U' : 'AI'}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                      <p className="text-xs opacity-70 mt-1">
                        <FormattedDateTime date={msg.timestamp} formatter={(d) => d.toLocaleTimeString()} placeholder="..." />
                      </p>
                    </div>
                  </div>
                ))
              )}
            </ScrollArea>
          </CardContent>
          <CardFooter className="border-t pt-4">
            <div className="flex w-full items-center space-x-2">
              <Input
                id="userQuery"
                type="text"
                value={userQuery}
                onChange={(e) => setUserQuery(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask about data anomalies..."
                disabled={isSending || !selectedDataSourceId || (availableHistoricalRuns.length > 0 && !selectedHistoricalRunId) }
                className="flex-1"
              />
              <Button 
                onClick={handleSendMessage} 
                disabled={isSending || !selectedDataSourceId || !userQuery.trim() || (availableHistoricalRuns.length > 0 && !selectedHistoricalRunId) }
               >
                {isSending ? 'Sending...' : <Send className="h-4 w-4" />}
              </Button>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}

    