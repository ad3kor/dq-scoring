
"use client";

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { PlayCircle, CheckCircle2, XCircle, AlertTriangle, RefreshCw, BarChart3, Info, Loader2, Database, History, Save, FileText as ReportIcon, Eye } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { FormattedDateTime } from '@/components/FormattedDateTime';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LabelList } from 'recharts';
import { getCurrentMockUser, getUserSpecificKey, BASE_DS_KEY, BASE_DATABRICKS_SUGGESTER_CONFIG_KEY, BASE_ASSESSMENT_HISTORY_KEY, BASE_DATANEXUS_ASSESSMENT_RESULTS_KEY, addAuditLog } from '@/lib/authUtils';
import { useSearchParams, useRouter } from 'next/navigation';

const DIMENSION_NAMES_ORDERED = ["Accuracy", "Completeness", "Consistency", "Uniqueness"] as const;
type DimensionName = typeof DIMENSION_NAMES_ORDERED[number];

// --- Interfaces for Databricks Assessment Job Output ---
interface DatabricksDetailedRuleResultItem {
  "Rule Description": string;
  "Column": string;
  "Dimension": string;
  "Status": 'Pass' | 'Fail' | 'Error' | string;
  "Affected Records": number;
  "Details": string;
}
interface DatabricksDimensionAnalysisItem {
  "Dimension": string;
  "Weight (%)": string;
  "Score (/10)": string;
  "Observation": string;
}
interface DatabricksSummaryOfChecks {
  total_rules_assessed: number;
  pass: number;
  fail: number;
  error: number;
}
interface DatabricksAssessmentJobOutput {
  overall_dq_score: number;
  overall_observation: string;
  summary_of_checks: DatabricksSummaryOfChecks;
  dimension_analysis: DatabricksDimensionAnalysisItem[];
  detailed_rule_results: DatabricksDetailedRuleResultItem[];
  timestamp?: string; 
}

// Interface for storing/loading specific results for THIS page
interface StoredDataNexusAssessmentResult {
  assessmentRunId: string; 
  output: DatabricksAssessmentJobOutput;
  savedAt: string; 
}

// Interface for storing multiple assessment runs in the shared history (for Reports page)
interface AssessmentRunForHistory {
    id: string; 
    dataSourceId: string;
    dataSourceName: string;
    timestamp: Date; 
    status: 'Completed' | 'Failed';
    assessmentType: 'legacy' | 'databricks';
    databricksOutput?: DatabricksAssessmentJobOutput;
    results?: any[]; 
    summary?: any;   
}

interface AssessmentJobState {
  status: 'IDLE' | 'TRIGGERING' | 'POLLING' | 'SUCCEEDED' | 'FAILED' | 'LOADED_FROM_HISTORY';
  message: string;
  runId?: string; 
  output?: DatabricksAssessmentJobOutput;
  progress?: number;
  isFromHistory?: boolean; 
}

interface StoredSuggesterConfig { // Matches config saved by Databricks Suggester
  rules: any[]; 
  dimensionWeights: Record<DimensionName, number>;
  timestamp?: string; // Timestamp of when this config was saved
}

interface AllStoredSuggesterConfigs { // Matches structure in BASE_DATABRICKS_SUGGESTER_CONFIG_KEY
  [key: string]: StoredSuggesterConfig; // Key is dataSourceId
}

interface DataSourceForDisplay {
  id: string;
  name: string;
}

interface DisplayableHistoricalNexusResult extends StoredDataNexusAssessmentResult {
  dataSourceId: string;
  dataSourceName: string;
}


export default function DataNexusAssessmentPage() {
  const { toast } = useToast();
  const searchParams = useSearchParams();
  const router = useRouter();
  
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  
  const [allConfigurableDataSources, setAllConfigurableDataSources] = useState<DataSourceForDisplay[]>([]);
  const [selectedDataSourceIdForPage, setSelectedDataSourceIdForPage] = useState<string | undefined>(undefined);
  const [activeConfigForSelectedDS, setActiveConfigForSelectedDS] = useState<StoredSuggesterConfig | null>(null);

  const [assessmentJobState, setAssessmentJobState] = useState<AssessmentJobState>({ status: 'IDLE', message: 'Select a data source to view or run an assessment.'});
  const [isLoadingInitialData, setIsLoadingInitialData] = useState(true);
  const [lastCompletedAssessmentRunIdForReport, setLastCompletedAssessmentRunIdForReport] = useState<string | null>(null);
  const [allHistoricalNexusAssessments, setAllHistoricalNexusAssessments] = useState<DisplayableHistoricalNexusResult[]>([]);


  useEffect(() => {
    const user = getCurrentMockUser();
    setCurrentUser(user);
  }, []);

  // Effect to load all data sources that have a saved configuration from the suggester
  useEffect(() => {
    if (currentUser) {
      setIsLoadingInitialData(true);
      setAssessmentJobState({ status: 'IDLE', message: 'Select a data source to view or run an assessment.'});
      setActiveConfigForSelectedDS(null);
      setLastCompletedAssessmentRunIdForReport(null);
      setAllHistoricalNexusAssessments([]);
      
      let loadedConfigurableSources: DataSourceForDisplay[] = [];
      try {
        const mainDsStorageKey = getUserSpecificKey(BASE_DS_KEY, currentUser);
        const mainDsItem = window.localStorage.getItem(mainDsStorageKey);
        const allMainDataSources: { id: string; name: string }[] = mainDsItem ? JSON.parse(mainDsItem) : [];

        const suggesterConfigsStorageKey = getUserSpecificKey(BASE_DATABRICKS_SUGGESTER_CONFIG_KEY, currentUser);
        const suggesterConfigsItem = window.localStorage.getItem(suggesterConfigsStorageKey);
        const allStoredSuggesterConfigs: AllStoredSuggesterConfigs = suggesterConfigsItem ? JSON.parse(suggesterConfigsItem) : {};
        
        const displaySourcesMap = new Map<string, DataSourceForDisplay>();

        allMainDataSources.forEach(ds => {
          if (allStoredSuggesterConfigs[ds.id]) {
            displaySourcesMap.set(ds.id, { id: ds.id, name: ds.name });
          }
        });

        Object.keys(allStoredSuggesterConfigs).forEach(configId => {
          if (!displaySourcesMap.has(configId)) {
            const name = configId.startsWith('dn-job-') 
              ? `Data Nexus Analysis: ${configId.substring('dn-job-'.length)}` 
              : configId; 
            displaySourcesMap.set(configId, { id: configId, name: name });
          }
        });
        
        loadedConfigurableSources = Array.from(displaySourcesMap.values());
        setAllConfigurableDataSources(loadedConfigurableSources);

        const dsIdFromQuery = searchParams.get('dataSourceId');
        if (dsIdFromQuery && loadedConfigurableSources.some(cs => cs.id === dsIdFromQuery)) {
          setSelectedDataSourceIdForPage(dsIdFromQuery);
        } else if (loadedConfigurableSources.length > 0 && !dsIdFromQuery) {
          // No default selection
        } else {
          setSelectedDataSourceIdForPage(undefined);
        }

      } catch (error) {
        console.error("Error loading initial data sources for Data Nexus Assessment page:", error);
        toast({ title: "Loading Error", description: "Could not load data sources or configurations.", variant: "destructive" });
        setAllConfigurableDataSources([]);
        loadedConfigurableSources = [];
      }

      // Load all historical Data Nexus assessments for the new card
      try {
        const resultsStorageKey = getUserSpecificKey(BASE_DATANEXUS_ASSESSMENT_RESULTS_KEY, currentUser);
        const allResultsItem = window.localStorage.getItem(resultsStorageKey);
        const historicalAssessmentsForList: DisplayableHistoricalNexusResult[] = [];
        if (allResultsItem) {
            const allStoredResults: Record<string, StoredDataNexusAssessmentResult> = JSON.parse(allResultsItem);
            for (const dsId in allStoredResults) {
                const result = allStoredResults[dsId];
                const dsDisplayInfo = loadedConfigurableSources.find(ds => ds.id === dsId); // Use already loaded sources
                historicalAssessmentsForList.push({
                    ...result,
                    dataSourceId: dsId,
                    dataSourceName: dsDisplayInfo?.name || `Context: ${dsId.startsWith('dn-job-') ? dsId.substring('dn-job-'.length, 20) : dsId.substring(0,15)}...`
                });
            }
        }
        historicalAssessmentsForList.sort((a, b) => new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime());
        setAllHistoricalNexusAssessments(historicalAssessmentsForList);
      } catch (e) {
          console.error("Error loading all historical Data Nexus assessments for list display", e);
          setAllHistoricalNexusAssessments([]);
      }

      setIsLoadingInitialData(false);
    }
  }, [currentUser, searchParams, toast]);


  // Effect to load config for the selected data source and any previous assessment results for it
  useEffect(() => {
    if (currentUser && selectedDataSourceIdForPage) {
      setAssessmentJobState({ status: 'IDLE', message: `Loading configuration for ${allConfigurableDataSources.find(ds=>ds.id === selectedDataSourceIdForPage)?.name || 'selected source'}...` });
      setLastCompletedAssessmentRunIdForReport(null); 
      setActiveConfigForSelectedDS(null);

      try {
        const suggesterConfigsStorageKey = getUserSpecificKey(BASE_DATABRICKS_SUGGESTER_CONFIG_KEY, currentUser);
        const suggesterConfigsItem = window.localStorage.getItem(suggesterConfigsStorageKey);
        if (suggesterConfigsItem) {
          const allConfigs: AllStoredSuggesterConfigs = JSON.parse(suggesterConfigsItem);
          const configForDS = allConfigs[selectedDataSourceIdForPage];
          if (configForDS) {
            setActiveConfigForSelectedDS(configForDS); 
          } else {
            toast({ title: "Configuration Missing", description: "Rules/weights not found for this source. Please configure in Databricks Suggester.", variant: "destructive" });
          }
        }
      } catch (e) { 
        console.error("Error loading suggester config for selected DS", e);
        toast({ title: "Config Load Error", description: "Could not load rules/weights.", variant: "destructive" });
      }

      try {
        const resultsStorageKey = getUserSpecificKey(BASE_DATANEXUS_ASSESSMENT_RESULTS_KEY, currentUser);
        const allResultsItem = window.localStorage.getItem(resultsStorageKey);
        if (allResultsItem) {
          const allStoredResults = JSON.parse(allResultsItem);
          const resultForDS: StoredDataNexusAssessmentResult | undefined = allStoredResults[selectedDataSourceIdForPage];
          if (resultForDS && resultForDS.output) {
            setAssessmentJobState({
              status: 'LOADED_FROM_HISTORY',
              message: `Displaying previously saved assessment from ${new Date(resultForDS.savedAt).toLocaleString()}. Databricks Task Run ID: ${resultForDS.assessmentRunId.substring(0,15)}...`,
              output: resultForDS.output,
              runId: resultForDS.assessmentRunId, 
              progress: 100,
              isFromHistory: true,
            });
            setLastCompletedAssessmentRunIdForReport(`db-assess-${resultForDS.assessmentRunId}`); 
            // toast({title: "Loaded Previous Assessment", description: `Showing results saved on ${new Date(resultForDS.savedAt).toLocaleDateString()}`, duration: 4000});
          } else {
             setAssessmentJobState(prev => ({ ...prev, status: 'IDLE', message: 'No previous assessment results found for this source. Ready to run.' }));
          }
        } else {
           setAssessmentJobState(prev => ({ ...prev, status: 'IDLE', message: 'No previous assessment results found for this source. Ready to run.' }));
        }
      } catch (e) { 
        console.error("Error loading stored assessment results", e);
        setAssessmentJobState(prev => ({ ...prev, status: 'IDLE', message: 'Error loading previous results. Ready to run.' }));
      }
    } else if (!selectedDataSourceIdForPage) {
         setAssessmentJobState({ status: 'IDLE', message: 'Select a data source to view or run an assessment.'});
         setActiveConfigForSelectedDS(null);
         setLastCompletedAssessmentRunIdForReport(null);
    }
  }, [currentUser, selectedDataSourceIdForPage, toast, allConfigurableDataSources]);


  const saveCurrentDataNexusAssessmentResult = useCallback((databricksTaskRunId: string, output: DatabricksAssessmentJobOutput, dsId: string) => {
    if (!currentUser || !dsId) return;
    
    const resultToStore: StoredDataNexusAssessmentResult = {
      assessmentRunId: databricksTaskRunId,
      output: output,
      savedAt: new Date().toISOString(),
    };

    try {
      const storageKey = getUserSpecificKey(BASE_DATANEXUS_ASSESSMENT_RESULTS_KEY, currentUser);
      const allResultsItem = window.localStorage.getItem(storageKey);
      let allStoredResults = allResultsItem ? JSON.parse(allResultsItem) : {};
      
      allStoredResults[dsId] = resultToStore; 
      
      window.localStorage.setItem(storageKey, JSON.stringify(allStoredResults));
      console.log(`Data Nexus Assessment for DS ID ${dsId} (DB Task Run ID ${databricksTaskRunId}) saved to local storage for this page.`);
      
      // Refresh the list of all historical assessments
        const dsDisplayInfo = allConfigurableDataSources.find(ds => ds.id === dsId);
        const newHistoricalEntry: DisplayableHistoricalNexusResult = {
            ...resultToStore,
            dataSourceId: dsId,
            dataSourceName: dsDisplayInfo?.name || `Context: ${dsId.startsWith('dn-job-') ? dsId.substring('dn-job-'.length, 20) : dsId.substring(0,15)}...`
        };
        setAllHistoricalNexusAssessments(prev => {
            const filtered = prev.filter(item => item.assessmentRunId !== databricksTaskRunId && item.dataSourceId !== dsId); // Remove old entry for this dsId
            const updated = [newHistoricalEntry, ...filtered];
            return updated.sort((a, b) => new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime());
        });

    } catch (error) {
      console.error("Failed to save Data Nexus assessment result specifically for this page:", error);
      toast({title: "Save Error", description: "Could not save assessment result locally for this page.", variant: "destructive"});
    }
  }, [currentUser, toast, allConfigurableDataSources]);


  const saveDatabricksAssessmentToSharedHistory = useCallback((databricksTaskRunId: string, output: DatabricksAssessmentJobOutput, dsId: string, dsName: string): string => {
    if (!currentUser) return '';

    const sharedHistoryRunId = `db-assess-${databricksTaskRunId}`;
    const historyEntry: AssessmentRunForHistory = {
      id: sharedHistoryRunId, 
      dataSourceId: dsId,
      dataSourceName: dsName,
      timestamp: output.timestamp ? new Date(output.timestamp) : new Date(),
      status: 'Completed',
      assessmentType: 'databricks',
      databricksOutput: output,
    };

    try {
      const historyStorageKey = getUserSpecificKey(BASE_ASSESSMENT_HISTORY_KEY, currentUser);
      const historyItem = window.localStorage.getItem(historyStorageKey);
      let existingHistory: AssessmentRunForHistory[] = historyItem ? JSON.parse(historyItem).map((r:any) => ({...r, timestamp: new Date(r.timestamp)})) : [];
      
      existingHistory = existingHistory.filter(entry => entry.id !== historyEntry.id); 
      
      const updatedHistory = [historyEntry, ...existingHistory].slice(0, 20); 
      window.localStorage.setItem(historyStorageKey, JSON.stringify(updatedHistory));
      console.log("Saved Databricks assessment to shared history (for Reports page):", historyEntry.id);
      return sharedHistoryRunId;
    } catch (error) {
      console.error("Failed to save Databricks assessment to shared history:", error);
      return '';
    }
  }, [currentUser]);


  const handleRunAssessment = async () => {
    if (!currentUser || !selectedDataSourceIdForPage || !activeConfigForSelectedDS) {
      toast({ title: "Error", description: "User, data source, or configuration (rules/weights) is missing.", variant: "destructive" });
      return;
    }
    const currentSelectedDSDisplayInfo = allConfigurableDataSources.find(ds => ds.id === selectedDataSourceIdForPage);
    if (!currentSelectedDSDisplayInfo) {
        toast({ title: "Error", description: "Selected data source display details not found.", variant: "destructive" });
        return;
    }

    setAssessmentJobState({ status: 'TRIGGERING', message: 'Triggering Databricks assessment job...', progress: 0, isFromHistory: false });
    setLastCompletedAssessmentRunIdForReport(null);
    toast({title: "Assessment Job Triggered", description: "Contacting Databricks to start assessment job."});

    try {
      const payload = {
        dataSourceId: selectedDataSourceIdForPage, 
        dataSourceName: currentSelectedDSDisplayInfo.name, 
        rules: activeConfigForSelectedDS.rules,
        dimensionWeights: activeConfigForSelectedDS.dimensionWeights,
        nexusJobId: selectedDataSourceIdForPage.startsWith('dn-job-') ? selectedDataSourceIdForPage.substring('dn-job-'.length) : undefined
      };

      const response = await fetch('/api/run-databricks-assessment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const result = await response.json();

      if (!response.ok || !result.runId) { 
        throw new Error(result.error || `Failed to trigger assessment job (HTTP ${response.status})`);
      }
      
      addAuditLog(
        'DATABRICKS_ASSESSMENT_JOB_TRIGGERED',
        `Databricks assessment job triggered for source '${currentSelectedDSDisplayInfo.name}'. Internal Tracking ID: ${result.runId}`,
        'DatabricksAssessmentJob',
        result.runId 
      );
      setAssessmentJobState({ status: 'POLLING', message: `Job (tracking ID ${result.runId.substring(0,8)}...) is running. Polling for status...`, runId: result.runId, progress: 10, isFromHistory: false });
      pollJobStatus(result.runId, currentSelectedDSDisplayInfo);

    } catch (error: any) {
      console.error("Error triggering Databricks assessment job:", error);
      setAssessmentJobState({ status: 'FAILED', message: `Error triggering job: ${error.message}`, isFromHistory: false });
      toast({ title: "Job Trigger Failed", description: error.message, variant: "destructive" });
    }
  };

  const pollJobStatus = useCallback(async (internalTrackingId: string, currentDSForPolling: DataSourceForDisplay) => {
    const intervalId = setInterval(async () => {
      try {
        const response = await fetch(`/api/databricks-assessment-status?run_id=${internalTrackingId}`);
        const result = await response.json(); 
        
        setAssessmentJobState(prev => ({
            ...prev,
            message: prev.status === 'POLLING' ? `Job status: ${result.status || 'Polling...'}. Progress: ${prev.progress || 10}%` : prev.message,
            progress: prev.status === 'POLLING' ? Math.min(95, (prev.progress || 10) + 15) : prev.progress,
            isFromHistory: false, 
        }));

        if (!response.ok) {
            if (response.status === 404) {
                 setAssessmentJobState({ status: 'FAILED', message: `Job Tracking ID ${internalTrackingId} not found.`, isFromHistory: false });
            } else {
                 setAssessmentJobState(prev => ({ ...prev, status: 'FAILED', message: `Polling error... (${result.error || response.statusText})`, isFromHistory: false }));
            }
            clearInterval(intervalId); 
            return;
        }
        
        if (result.status === 'SUCCEEDED' && result.results && result.databricksTaskRunId) {
          clearInterval(intervalId);
          const jobOutputData = result.results as DatabricksAssessmentJobOutput;
          setAssessmentJobState({ status: 'SUCCEEDED', message: `Assessment for ${result.dataSourceName || currentDSForPolling.name} completed!`, output: jobOutputData, progress: 100, runId: result.databricksTaskRunId, isFromHistory: false });
          
          const sharedHistoryRunId = saveDatabricksAssessmentToSharedHistory(result.databricksTaskRunId, jobOutputData, currentDSForPolling.id, currentDSForPolling.name);
          saveCurrentDataNexusAssessmentResult(result.databricksTaskRunId, jobOutputData, currentDSForPolling.id); 
          setLastCompletedAssessmentRunIdForReport(sharedHistoryRunId); 

          const overallScoreText = typeof jobOutputData.overall_dq_score === 'number' 
            ? jobOutputData.overall_dq_score.toFixed(1) 
            : 'N/A';
          addAuditLog('DATABRICKS_ASSESSMENT_JOB_SUCCEEDED', `Databricks assessment for '${result.dataSourceName || currentDSForPolling.name}' completed. Databricks Task Run ID: ${result.databricksTaskRunId}. Overall Score: ${overallScoreText}`, 'DatabricksAssessmentJob', result.databricksTaskRunId);
          
          toast({ title: "Assessment Complete", description: "Results are now displayed and saved." });
        } else if (result.status === 'FAILED' || result.status === 'TIMED_OUT' || result.status === 'CANCELED') {
          clearInterval(intervalId);
          setAssessmentJobState({ status: 'FAILED', message: `Assessment Job ${result.status}: ${result.error || 'Unknown error'}`, progress: (assessmentJobState.progress && assessmentJobState.progress < 100) ? assessmentJobState.progress : 50, isFromHistory: false, runId: result.databricksTaskRunId });
          addAuditLog('DATABRICKS_ASSESSMENT_JOB_FAILED', `Databricks assessment for '${result.dataSourceName || currentDSForPolling.name}' failed. Error: ${result.error}. DB Task Run ID: ${result.databricksTaskRunId || 'N/A'}`, 'DatabricksAssessmentJob', internalTrackingId);
          toast({ title: "Assessment Job Failed", description: result.error || `Job ${result.status}`, variant: "destructive" });
        }
      } catch (error: any) {
        console.error(`Error polling assessment job status for Databricks internal tracking ID ${internalTrackingId}:`, error);
        setAssessmentJobState(prev => ({ ...prev, status: 'FAILED', message: `Polling error: ${error.message}`, isFromHistory: false }));
        clearInterval(intervalId); 
      }
    }, 7000); 

     return () => clearInterval(intervalId);
  }, [toast, saveDatabricksAssessmentToSharedHistory, saveCurrentDataNexusAssessmentResult, assessmentJobState.progress]);


  const getStatusIcon = (status: AssessmentJobState['status'] | DatabricksDetailedRuleResultItem['Status']) => {
    switch (status) {
      case 'SUCCEEDED':
      case 'LOADED_FROM_HISTORY':
      case 'Pass':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'FAILED':
      case 'Fail':
        return <XCircle className="h-4 w-4 text-destructive" />;
      case 'Error':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'TRIGGERING':
      case 'POLLING':
        return <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'IDLE':
        return <PlayCircle className="h-4 w-4 text-muted-foreground" />;
      default:
        return null;
    }
  };

  const chartData = useMemo(() => {
    if ((assessmentJobState.status === 'SUCCEEDED' || assessmentJobState.status === 'LOADED_FROM_HISTORY') && assessmentJobState.output?.dimension_analysis) {
      return assessmentJobState.output.dimension_analysis.map(item => ({
        name: item.Dimension,
        score: parseFloat(item["Score (/10)"]) || 0,
      })).filter(item => DIMENSION_NAMES_ORDERED.some(dn => dn.toLowerCase() === item.name.toLowerCase()) || item.name.toLowerCase() === "other"); 
    }
    return [];
  }, [assessmentJobState.status, assessmentJobState.output]);

  const handleDataSourceSelectionChange = (dsId: string) => {
    if (dsId) {
      setSelectedDataSourceIdForPage(dsId);
      router.replace(`/data-nexus-assessment?dataSourceId=${dsId}`, { scroll: false });
    }
  };

  const handlePreparePdfReport = () => {
    if (selectedDataSourceIdForPage && lastCompletedAssessmentRunIdForReport) {
      router.push(`/reports?dataSourceId=${selectedDataSourceIdForPage}&assessmentRunId=${lastCompletedAssessmentRunIdForReport}`);
    } else {
      toast({ title: "Error", description: "Cannot proceed to report. Data source or assessment run ID missing.", variant: "destructive" });
    }
  };

  if (!currentUser) {
    return <div className="container mx-auto py-8 text-center">Please log in to run assessments.</div>;
  }
  if (isLoadingInitialData) {
    return <div className="container mx-auto py-8 text-center"><Loader2 className="h-8 w-8 animate-spin mx-auto" /> Loading configurations...</div>;
  }
  
  const jobOutput = assessmentJobState.output;
  const displayTimestamp = jobOutput?.timestamp ? new Date(jobOutput.timestamp) : (assessmentJobState.status === 'LOADED_FROM_HISTORY' && assessmentJobState.output && assessmentJobState.output.timestamp ? new Date(assessmentJobState.output.timestamp) : new Date());
  const currentSelectedDSName = allConfigurableDataSources.find(ds => ds.id === selectedDataSourceIdForPage)?.name || "Selected Data Source";

  return (
    <div className="container mx-auto py-8 space-y-8">
       <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Data Nexus Assessment Engine</h1>
        <p className="text-muted-foreground">Select a configured data source to view its last assessment or run a new one using Databricks.</p>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Data Source Selection &amp; Assessment Trigger</CardTitle>
          <CardDescription>Choose a data source to view its latest assessment or to run/re-run the Databricks assessment job using its saved rules and weights.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div>
                <Label htmlFor="dataSourceSelectForAssessmentPage">Data Source</Label>
                <Select onValueChange={handleDataSourceSelectionChange} value={selectedDataSourceIdForPage}>
                    <SelectTrigger id="dataSourceSelectForAssessmentPage">
                        <SelectValue placeholder="Select a configured data source" />
                    </SelectTrigger>
                    <SelectContent>
                        {allConfigurableDataSources.length > 0 ? (
                            allConfigurableDataSources.map(ds => (
                            <SelectItem key={ds.id} value={ds.id}>{ds.name}</SelectItem>
                            ))
                        ) : (
                            <SelectItem value="no-configurable-ds" disabled>No data sources configured for Databricks assessment. Configure on Databricks Suggester page.</SelectItem>
                        )}
                    </SelectContent>
                </Select>
            </div>
            {selectedDataSourceIdForPage && !activeConfigForSelectedDS && !isLoadingInitialData && (
                 <p className="text-sm text-destructive">Warning: Configuration (rules/weights) not found for {currentSelectedDSName}. Please configure it on the Databricks Suggester page before running an assessment.</p>
            )}
        </CardContent>
        <CardFooter className="flex justify-between items-center">
            <Button 
                onClick={handleRunAssessment} 
                disabled={!selectedDataSourceIdForPage || !activeConfigForSelectedDS || assessmentJobState.status === 'TRIGGERING' || assessmentJobState.status === 'POLLING'}
            >
                {(assessmentJobState.status === 'TRIGGERING' || assessmentJobState.status === 'POLLING') ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                {assessmentJobState.status === 'TRIGGERING' ? 'Triggering...' : assessmentJobState.status === 'POLLING' ? `Polling... (Run ID: ${assessmentJobState.runId?.substring(0,8) || 'N/A'})` : `Run Assessment for ${currentSelectedDSName}`}
            </Button>
            {(assessmentJobState.status === 'SUCCEEDED' || assessmentJobState.status === 'LOADED_FROM_HISTORY') && selectedDataSourceIdForPage && lastCompletedAssessmentRunIdForReport && (
                <Button onClick={handlePreparePdfReport} variant="outline" className="ml-auto">
                    <ReportIcon className="mr-2 h-4 w-4" /> Prepare PDF Report
                </Button>
            )}
        </CardFooter>
      </Card>

      {selectedDataSourceIdForPage && (assessmentJobState.status !== 'IDLE' || assessmentJobState.isFromHistory) && (
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center">
              Assessment Status: {currentSelectedDSName}
              <span className="ml-2">{getStatusIcon(assessmentJobState.status)}</span>
            </CardTitle>
            <CardDescription>
              {assessmentJobState.message}
              {(assessmentJobState.status === 'SUCCEEDED' || assessmentJobState.status === 'LOADED_FROM_HISTORY') && jobOutput?.summary_of_checks && (
                <span className="block mt-1">Overall DQ Score: <strong className="text-lg">{typeof jobOutput.overall_dq_score === 'number' ? jobOutput.overall_dq_score.toFixed(1) : 'N/A'}/10</strong>
                 {jobOutput?.timestamp && (
                    <span className="text-xs text-muted-foreground ml-2">
                        (Assessed: <FormattedDateTime date={displayTimestamp} formatter={(d) => d.toLocaleString()} placeholder="..." />)
                    </span>
                  )}
                </span>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {(assessmentJobState.status === 'TRIGGERING' || assessmentJobState.status === 'POLLING') && assessmentJobState.progress !== undefined && (
                <Progress value={assessmentJobState.progress} className="w-full mb-4 h-3" />
            )}
            
            {(assessmentJobState.status === 'SUCCEEDED' || assessmentJobState.status === 'LOADED_FROM_HISTORY') && jobOutput && (
              <>
                {jobOutput.overall_observation && (
                    <Card className="mb-6 bg-secondary/30 shadow-inner">
                        <CardHeader><CardTitle className="text-lg flex items-center"><Info className="mr-2 h-5 w-5 text-primary"/>Overall Observation</CardTitle></CardHeader>
                        <CardContent><p className="text-sm text-secondary-foreground">{jobOutput.overall_observation}</p></CardContent>
                    </Card>
                )}
                {jobOutput.summary_of_checks && (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-center">
                        <div className="p-3 bg-secondary rounded-md shadow">
                        <p className="text-xs text-muted-foreground">Total Rules Assessed</p>
                        <p className="text-xl font-bold">{jobOutput.summary_of_checks.total_rules_assessed}</p>
                        </div>
                        <div className="p-3 bg-secondary rounded-md shadow">
                        <p className="text-xs text-muted-foreground">Passed</p>
                        <p className="text-xl font-bold text-green-500">{jobOutput.summary_of_checks.pass}</p>
                        </div>
                        <div className="p-3 bg-secondary rounded-md shadow">
                        <p className="text-xs text-muted-foreground">Failed</p>
                        <p className="text-xl font-bold text-destructive">{jobOutput.summary_of_checks.fail}</p>
                        </div>
                        <div className="p-3 bg-secondary rounded-md shadow">
                        <p className="text-xs text-muted-foreground">Errors</p>
                        <p className="text-xl font-bold text-yellow-500">{jobOutput.summary_of_checks.error}</p>
                        </div>
                    </div>
                )}

                {chartData.length > 0 && (
                  <div className="mb-6 p-4 border rounded-lg shadow-sm">
                    <h3 className="text-lg font-semibold mb-2 text-foreground flex items-center"><BarChart3 className="mr-2 h-5 w-5" />Dimension Scores</h3>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={chartData} margin={{ top: 20, right: 0, left: -20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="name" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
                        <YAxis domain={[0, 10]} tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
                        <Tooltip
                          contentStyle={{ backgroundColor: 'hsl(var(--background))', border: '1px solid hsl(var(--border))', borderRadius: 'var(--radius)' }}
                          labelStyle={{ color: 'hsl(var(--foreground))' }}
                          itemStyle={{ color: 'hsl(var(--primary))' }}
                          formatter={(value: number, name: string) => [`${value.toFixed(1)}/10`, name]}
                        />
                        <Bar dataKey="score" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]}>
                          <LabelList dataKey="score" position="top" fill="hsl(var(--foreground))" fontSize={12} formatter={(value: number) => typeof value === 'number' ? value.toFixed(1) : 'N/A'} />
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
                
                {jobOutput.dimension_analysis && jobOutput.dimension_analysis.length > 0 && (
                    <div className="mb-6 p-4 border rounded-lg shadow-sm">
                        <h3 className="text-lg font-semibold mb-2 text-foreground">Dimension Analysis & Observations</h3>
                        {jobOutput.dimension_analysis.map((item, index) => (
                            <Card key={index} className="mb-3 bg-card/50">
                                <CardHeader className="pb-2 pt-3 px-4">
                                    <CardTitle className="text-md">{item.Dimension}</CardTitle>
                                    <CardDescription>Weight: {parseFloat(item["Weight (%)"]).toFixed(1)}% | Score: {parseFloat(item["Score (/10)"]).toFixed(1)}/10</CardDescription>
                                </CardHeader>
                                <CardContent className="px-4 pb-3 text-sm text-muted-foreground">
                                    {item.Observation}
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                )}

                {jobOutput.detailed_rule_results && jobOutput.detailed_rule_results.length > 0 && (
                  <div className="p-4 border rounded-lg shadow-sm">
                    <h3 className="text-lg font-semibold mb-2 text-foreground">Detailed Rule Results</h3>
                    <Table>
                        <TableHeader>
                        <TableRow>
                            <TableHead>Rule Description</TableHead>
                            <TableHead>Column</TableHead>
                            <TableHead>Dimension</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Affected Records</TableHead>
                            <TableHead>Details</TableHead>
                        </TableRow>
                        </TableHeader>
                        <TableBody>
                        {jobOutput.detailed_rule_results.map((result, index) => (
                            <TableRow key={index}>
                            <TableCell>{result["Rule Description"]}</TableCell>
                            <TableCell>{result.Column}</TableCell>
                            <TableCell>{result.Dimension}</TableCell>
                            <TableCell className="flex items-center">{getStatusIcon(result.Status)} <span className="ml-2">{result.Status}</span></TableCell>
                            <TableCell>{result["Affected Records"]}</TableCell>
                            <TableCell>{result.Details}</TableCell>
                            </TableRow>
                        ))}
                        </TableBody>
                    </Table>
                  </div>
                )}
                {(assessmentJobState.status === 'SUCCEEDED' || assessmentJobState.status === 'LOADED_FROM_HISTORY') && jobOutput && (!jobOutput?.detailed_rule_results || jobOutput.detailed_rule_results.length === 0) && (
                    <p className="text-muted-foreground text-center py-4">The assessment job completed but returned no detailed rule results.</p>
                )}
              </>
            )}
          </CardContent>
        </Card>
      )}

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center">
            <History className="mr-2 h-5 w-5 text-primary" /> Previously Saved Assessments
          </CardTitle>
          <CardDescription>
            View details of past Data Nexus assessments. Clicking "View Details" will load the assessment results above.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {allHistoricalNexusAssessments.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data Source / Context</TableHead>
                  <TableHead>Assessment Saved At</TableHead>
                  <TableHead>Overall Score</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {allHistoricalNexusAssessments.map((histItem) => (
                  <TableRow key={`${histItem.dataSourceId}-${histItem.assessmentRunId}`}>
                    <TableCell>{histItem.dataSourceName}</TableCell>
                    <TableCell>
                      <FormattedDateTime 
                        date={new Date(histItem.savedAt)} 
                        formatter={(d) => d.toLocaleString()} 
                        placeholder="..." 
                      />
                    </TableCell>
                    <TableCell>
                      {typeof histItem.output.overall_dq_score === 'number' 
                        ? `${histItem.output.overall_dq_score.toFixed(1)}/10` 
                        : 'N/A'}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleDataSourceSelectionChange(histItem.dataSourceId)}
                      >
                        <Eye className="mr-1 h-4 w-4" /> View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-muted-foreground text-center py-4">No previously saved Data Nexus assessments found.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
