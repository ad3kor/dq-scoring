
"use client";

import React, { useState, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PlusCircle, Trash2, Edit3, Wand2, Save, Info, ListChecks, AlertTriangle, HelpCircle, Loader2, DatabaseZap, Sparkles, Brain } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { suggestDQRulesWithGenkitAIAction, type SuggestDQRulesInput, type SuggestDQRulesOutput } from '@/app/actions';
import { z } from 'zod';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { getCurrentMockUser, getUserSpecificKey, BASE_DS_KEY, BASE_RULES_KEY, addAuditLog } from '@/lib/authUtils';
import { useSearchParams, useRouter } from 'next/navigation';

const DATA_NEXUS_JOB_RESULT_PREFIX = 'dataNexusJobResult_';

const DIMENSIONS_CONFIG = [
  { name: "Accuracy", label: "Accuracy" },
  { name: "Completeness", label: "Completeness" },
  { name: "Consistency", label: "Consistency" },
  { name: "Uniqueness", label: "Uniqueness" },
] as const;

type DimensionName = typeof DIMENSIONS_CONFIG[number]['name'];

const ruleSchema = z.object({
  id: z.string(),
  description: z.string().min(1, "Description is required."),
  column: z.string().min(1, "Column is required."),
  type: z.string().optional(),
  parameters: z.record(z.any()).optional(),
  rationale: z.string().optional(),
  reasonForColumnChoice: z.string().optional(),
  impactOnDimension: z.string().optional(),
  weight: z.number().min(0).max(100).optional(),
  dimension: z.enum([...DIMENSIONS_CONFIG.map(d => d.name), "Other"]),
});

type Rule = z.infer<typeof ruleSchema>;

interface SuggestedRuleFromGenkit {
  description: string;
  column: string;
  rationale?: string;
  reasonForColumnChoice?: string;
  impactOnDimension?: string;
  weight?: number;
  dimension?: DimensionName | "Other";
  type?: string;
  parameters?: Record<string, any>;
}

type DataSourceTypeFromSourcesPage =
  | 'delta-lake'
  | 'csv-json-cloud'
  | 'relational-database'
  | 'csv-file'
  | 'excel-file'
  | 'parquet-file'
  | 'json-file'
  | 'web-api'
  | 'databricks'
  | 'fivetran'
  | 'cassandra'
  | 'mongodb'
  | 'kafka'
  | 'local-file-upload'
  | 'data-nexus-csv'
  | '';

interface DataSourceFromLocalStorage {
  id: string;
  name: string;
  type: DataSourceTypeFromSourcesPage;
  details: string;
}

interface NexusJobDataSample {
    status?: string;
    message?: string;
    data_sample?: Record<string, any>[];
}
interface NexusJobResult {
    dataSourceName: string;
    containerName: string;
    blobName: string;
    dataAgeMonths: string;
    dataSample: NexusJobDataSample | Record<string, any>[];
    type: 'data-nexus-csv';
}

interface StoredRulesConfig {
  rules: Rule[];
  dimensionWeights: Record<DimensionName, number>;
}

// Moved outside component for stable reference
const INITIAL_DIMENSION_WEIGHTS_STATE: Record<DimensionName, number> = {
  Accuracy: 25, Completeness: 25, Consistency: 25, Uniqueness: 25,
};


const generateMockDataSample = (dataSourceType: DataSourceTypeFromSourcesPage, dataSourceName: string): Record<string, any>[] => {
  let sample: Record<string, any>[] = [];
  const baseRecord1: Record<string, any> = {
    id: 1,
    created_at: "2024-01-15T10:30:00Z",
    last_updated: "2024-05-20T14:00:00Z",
    status_code: "ACTIVE",
    notes: "This is the first sample record."
  };
  const baseRecord2: Record<string, any> = {
    id: 2,
    created_at: "2024-02-20T11:00:00Z",
    last_updated: "2024-05-21T16:30:00Z",
    status_code: "INACTIVE",
    notes: "Second record with some nulls."
  };
   const baseRecord3: Record<string, any> = {
    id: 3,
    created_at: "2024-03-10T09:15:00Z",
    last_updated: "2024-05-22T10:00:00Z",
    status_code: "PENDING",
    notes: "A third variant of a sample record."
  };


  switch (dataSourceType) {
    case 'delta-lake':
      sample = [
        { ...baseRecord1, transaction_id: "txn_abc123", user_email: "user1@example.com", product_id: "prod_001", quantity: 5, unit_price: 10.99, total_amount: 54.95, country_code: "US" },
        { ...baseRecord2, transaction_id: "txn_def456", user_email: "user2@example.com", product_id: "prod_002", quantity: 2, unit_price: 25.50, total_amount: 51.00, country_code: "CA" },
        { ...baseRecord3, transaction_id: "txn_ghi789", user_email: "user1@example.com", product_id: "prod_001", quantity: 1, unit_price: 10.99, total_amount: 10.99, country_code: "US", notes: null },
      ];
      break;
    case 'csv-json-cloud':
    case 'csv-file':
    case 'json-file':
    case 'local-file-upload': // Treat local uploads similarly for mock generation
      sample = [
        { ...baseRecord1, col_A_string: "Value Alpha", col_B_numeric: 123, col_C_date: "2024-01-15", col_D_boolean: true, col_E_email: "alpha@example.com" },
        { ...baseRecord2, col_A_string: "Value Beta", col_B_numeric: 456.78, col_C_date: "2024-02-20", col_D_boolean: false, col_E_email: "beta@example.net" },
        { ...baseRecord3, col_A_string: "Value Gamma", col_B_numeric: null, col_C_date: "2024-03-10", col_D_boolean: true, col_E_email: "gamma@example.org" },
      ];
      break;
    case 'relational-database':
      sample = [
        { ...baseRecord1, customer_id: "CUST1001", order_id: "ORD5001", order_date: "2024-01-15T10:30:00Z", product_sku: "SKU-X1", amount_decimal: 120.75, payment_status: "PAID" },
        { ...baseRecord2, customer_id: "CUST1002", order_id: "ORD5002", order_date: "2024-02-20T11:00:00Z", product_sku: "SKU-Y2", amount_decimal: 75.00, payment_status: "PENDING" },
        { ...baseRecord3, customer_id: "CUST1001", order_id: "ORD5003", order_date: "2024-03-10T09:15:00Z", product_sku: "SKU-X1", amount_decimal: 60.30, payment_status: "PAID" },
      ];
      break;
    case 'data-nexus-csv': // If somehow no real sample, but type is known
       sample = [
        { ...baseRecord1, nexus_col_1: "Nexus Field A", nexus_val_num: 99.9, nexus_date_iso: "2023-11-01T00:00:00Z", category_code: "NXC"},
        { ...baseRecord2, nexus_col_1: "Nexus Field B", nexus_val_num: -10.5, nexus_date_iso: "2023-12-15T23:59:59Z", category_code: "NXD", notes: "Special case"},
        { ...baseRecord3, nexus_col_1: "Nexus Field C", nexus_val_num: 0.0, nexus_date_iso: "2024-01-01T12:00:00Z", category_code: "NXC"},
      ];
      break;
    default: // Generic fallback
      sample = [
        { ...baseRecord1, field_1_text: `Generic ${dataSourceName} data point 1`, field_2_number: 1001, field_3_datetime: "2024-04-01T12:00:00Z", field_4_boolean: true },
        { ...baseRecord2, field_1_text: `Another item for ${dataSourceName}`, field_2_number: 2002.5, field_3_datetime: "2024-04-02T15:30:00Z", field_4_boolean: false, notes: null },
        { ...baseRecord3, field_1_text: `Final example entry for ${dataSourceName}`, field_2_number: 3003, field_3_datetime: "2024-04-03T18:45:00Z", field_4_boolean: null },
      ];
  }
  return sample;
};


export default function RulesEditorPage() {
  const { toast } = useToast();
  const router = useRouter();
  const searchParams = useSearchParams();

  const [dataSourcesForSelect, setDataSourcesForSelect] = useState<DataSourceFromLocalStorage[]>([]);
  const [selectedDataSourceId, setSelectedDataSourceId] = useState<string | undefined>(undefined);
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  // Local states for the currently selected data source's config
  const [dimensionWeights, setDimensionWeights] = useState<Record<DimensionName, number>>({ ...INITIAL_DIMENSION_WEIGHTS_STATE });
  const [rules, setRules] = useState<Rule[]>([]);

  // Central store for ALL configurations, this is what gets saved to localStorage
  const [allStoredConfigs, setAllStoredConfigs] = useState<Record<string, StoredRulesConfig>>({});

  const [isSuggesting, setIsSuggesting] = useState(false);
  const [editingRule, setEditingRule] = useState<Rule | null>(null);
  const [nexusJobResultContext, setNexusJobResultContext] = useState<NexusJobResult | null>(null);

  useEffect(() => {
    const user = getCurrentMockUser();
    setCurrentUser(user);
    if (user) {
      try {
        const dsStorageKey = getUserSpecificKey(BASE_DS_KEY, user);
        const dsItem = window.localStorage.getItem(dsStorageKey);
        const loadedDataSources: DataSourceFromLocalStorage[] = dsItem ? JSON.parse(dsItem) : [];
        setDataSourcesForSelect(loadedDataSources);

        const allConfigsStorageKey = getUserSpecificKey(BASE_RULES_KEY, user);
        const allConfigsItem = window.localStorage.getItem(allConfigsStorageKey);
        setAllStoredConfigs(allConfigsItem ? JSON.parse(allConfigsItem) : {});

        const nexusJobId = searchParams.get('nexus_job_id');
        if (nexusJobId) {
          const jobResultKey = DATA_NEXUS_JOB_RESULT_PREFIX + nexusJobId;
          const jobResultJson = window.localStorage.getItem(jobResultKey);
          if (jobResultJson) {
            const jobResult: NexusJobResult = JSON.parse(jobResultJson);
            setNexusJobResultContext(jobResult);
            const associatedDataSourceId = `dn-job-${nexusJobId}`;
            if (loadedDataSources.some(ds => ds.id === associatedDataSourceId)) {
              setSelectedDataSourceId(associatedDataSourceId);
            }
          }
        }
      } catch (error) {
        console.error("Error reading initial data from localStorage for Rules Editor", error);
        toast({ title: "Initialization Error", description: "Could not load initial configurations.", variant: "destructive" });
      }
    }
  }, [currentUser, searchParams, toast]);


  useEffect(() => {
    if (selectedDataSourceId) {
      const configForDS = allStoredConfigs[selectedDataSourceId];
      if (configForDS) {
        setRules(configForDS.rules || []);
        setDimensionWeights(configForDS.dimensionWeights || { ...INITIAL_DIMENSION_WEIGHTS_STATE });
      } else {
        setRules([]);
        setDimensionWeights({ ...INITIAL_DIMENSION_WEIGHTS_STATE });
      }
    } else {
      setRules([]);
      setDimensionWeights({ ...INITIAL_DIMENSION_WEIGHTS_STATE });
    }
  }, [selectedDataSourceId, allStoredConfigs]);

  useEffect(() => {
    if (currentUser && Object.keys(allStoredConfigs).length > 0) {
      try {
        const storageKey = getUserSpecificKey(BASE_RULES_KEY, currentUser);
        window.localStorage.setItem(storageKey, JSON.stringify(allStoredConfigs));
      } catch (error) {
        console.error("Error saving all configs to localStorage", error);
      }
    } else if (currentUser && Object.keys(allStoredConfigs).length === 0) {
        const storageKey = getUserSpecificKey(BASE_RULES_KEY, currentUser);
        const item = window.localStorage.getItem(storageKey);
        if (item) { // Only remove if it exists
            window.localStorage.removeItem(storageKey);
        }
    }
  }, [allStoredConfigs, currentUser]);

  const handleSaveConfiguration = () => {
    if (!selectedDataSourceId || !currentUser) {
      toast({ title: "Error", description: "Cannot save configuration without a selected data source or user.", variant: "destructive" });
      return;
    }
    const configToSave: StoredRulesConfig = { rules, dimensionWeights };
    setAllStoredConfigs(prev => ({
      ...prev,
      [selectedDataSourceId]: configToSave
    }));
    const selectedDSName = dataSourcesForSelect.find(ds => ds.id === selectedDataSourceId)?.name || 'Unknown Data Source';
    addAuditLog('SAVE_RULES_CONFIG_GENKIT_CTX', `User explicitly saved rules and weights for data source '${selectedDSName}' (ID: ${selectedDataSourceId}). Total rules: ${rules.length}.`, 'RulesConfiguration', selectedDataSourceId);
    toast({ title: "Configuration Saved", description: `Rules and weights for ${selectedDSName} saved locally.` });
  };

  const handleSuggestRules = async () => {
    if (!currentUser || !selectedDataSourceId) {
      toast({ title: "Error", description: "Please select a data source first.", variant: "destructive" });
      return;
    }

    const selectedDS = dataSourcesForSelect.find(ds => ds.id === selectedDataSourceId);
    if (!selectedDS) {
      toast({ title: "Error", description: "Selected data source details not found.", variant: "destructive" });
      return;
    }
    const dataSourceNameForLog = selectedDS.name;

    setIsSuggesting(true);
    let dataSampleToUse: Record<string, any>[] | undefined;
    let sampleSourceMessage = "";

    if (nexusJobResultContext && nexusJobResultContext.dataSourceName === selectedDS.name) {
      if (nexusJobResultContext.dataSample && typeof nexusJobResultContext.dataSample === 'object' &&
          !Array.isArray(nexusJobResultContext.dataSample) && 'data_sample' in nexusJobResultContext.dataSample &&
          Array.isArray((nexusJobResultContext.dataSample as NexusJobDataSample).data_sample)) {
        dataSampleToUse = (nexusJobResultContext.dataSample as NexusJobDataSample).data_sample;
      } else if (Array.isArray(nexusJobResultContext.dataSample)) {
        dataSampleToUse = nexusJobResultContext.dataSample;
      }
      if (dataSampleToUse && dataSampleToUse.length > 0) {
        sampleSourceMessage = `Using real data sample from Data Nexus for "${dataSourceNameForLog}" to suggest rules with AI...`;
      } else {
        dataSampleToUse = undefined;
      }
    }
    
    if (!dataSampleToUse || dataSampleToUse.length === 0) {
      dataSampleToUse = generateMockDataSample(selectedDS.type, selectedDS.name);
      sampleSourceMessage = `Using a mock data sample based on type "${selectedDS.type}" for "${dataSourceNameForLog}" to suggest rules with AI...`;
    }
    
    toast({ title: "AI Rule Suggestion", description: `${sampleSourceMessage} This may take a moment.`, duration: 6000 });

    try {
      const dataSampleJsonString = JSON.stringify(dataSampleToUse);
      const genkitInput: SuggestDQRulesInput = {
        dataSample: dataSampleJsonString,
        completenessWeight: dimensionWeights.Completeness, // Use current local state for weights
        accuracyWeight: dimensionWeights.Accuracy,
        consistencyWeight: dimensionWeights.Consistency,
        uniquenessWeight: dimensionWeights.Uniqueness,
      };

      const result: SuggestDQRulesOutput = await suggestDQRulesWithGenkitAIAction(genkitInput);
      let suggestedRulesFromGenkit: SuggestedRuleFromGenkit[] = [];
      if (result.suggestedRules && result.suggestedRules.trim() !== "") {
        try {
          suggestedRulesFromGenkit = JSON.parse(result.suggestedRules);
          if (!Array.isArray(suggestedRulesFromGenkit)) {
            suggestedRulesFromGenkit = [];
          }
        } catch (e) {
          suggestedRulesFromGenkit = [];
          console.error("RulesEditor: Failed to parse AI suggestedRules. Error:", e, "Raw:", result.suggestedRules);
          toast({ title: "AI Parse Error", description: "Could not parse suggestions from AI. Existing rules cleared. Check console.", variant: "destructive", duration: 7000 });
        }
      }

      const newRulesForUI: Rule[] = suggestedRulesFromGenkit.map((r, index) => ({
        id: `genkit-ai-${Date.now()}-${index}`,
        description: r.description,
        column: Array.isArray(r.column) ? r.column.join(', ') : r.column,
        rationale: r.rationale || `Rule suggested by AI for ${dataSourceNameForLog}`,
        reasonForColumnChoice: r.reasonForColumnChoice || "AI did not provide specific reason for column choice.",
        impactOnDimension: r.impactOnDimension || "AI did not specify impact on dimension.",
        weight: typeof r.weight === 'number' ? r.weight : 50,
        dimension: r.dimension || "Other",
        type: r.type,
        parameters: r.parameters,
      }));

      setRules(newRulesForUI); // Update local state, user will click "Save Configuration" to persist

      if (newRulesForUI.length > 0) {
        addAuditLog('SUGGEST_RULES_GENKIT_AI', `Genkit AI generated/replaced ${newRulesForUI.length} rules for data source '${dataSourceNameForLog}'. User needs to save to persist.`, 'RulesSuggestion', selectedDataSourceId);
        toast({ title: "AI Success", description: `${newRulesForUI.length} rules suggested. Review and click "Save Configuration" to persist.` });
      } else {
        addAuditLog('SUGGEST_RULES_GENKIT_AI_EMPTY', `Genkit AI returned no rules for '${dataSourceNameForLog}'. Existing rules (if any) remain until save.`, 'RulesSuggestion', selectedDataSourceId);
        toast({ title: "No New Rules from AI", description: `AI returned 0 new rules for "${dataSourceNameForLog}". Review and save if needed.`, variant: "default", duration: 10000 });
      }
    } catch (error: any) {
      console.error("Error during AI rule suggestion:", error);
      toast({ title: "AI Suggestion Error", description: `Failed to get suggestions: ${error.message}. Check console.`, variant: "destructive", duration: 10000 });
      setRules([]); // Clear local rules if AI fails
    } finally {
      setIsSuggesting(false);
    }
  };

  const handleAddRule = () => {
    if (!selectedDataSourceId) {
      toast({ title: "Error", description: "Please select a data source before adding rules.", variant: "destructive" });
      return;
    }
    setEditingRule({
      id: '', description: '', column: '', rationale: '', reasonForColumnChoice: '', impactOnDimension: '', weight: 50, dimension: "Accuracy"
    });
  };

  const handleEditRule = (rule: Rule) => {
    setEditingRule({ ...rule });
  };

  const handleDeleteRule = (id: string) => {
    if (!selectedDataSourceId || !currentUser) return;
    const updatedRulesForDS = rules.filter(rule => rule.id !== id);
    setRules(updatedRulesForDS); // Update local state
    toast({ title: "Rule Staged for Deletion", description: "Rule removed. Click 'Save Configuration' to persist." });
  };

  const handleSaveRule = (ruleToSave: Rule) => {
    if (!selectedDataSourceId || !currentUser) {
      toast({ title: "Error", description: "Cannot save rule without a selected data source or user session.", variant: "destructive" });
      return;
    }

    const validatedRule = ruleSchema.safeParse(ruleToSave);
    if (!validatedRule.success) {
      const errors = validatedRule.error.flatten().fieldErrors;
      let errorMessages = "";
      if (errors.description) errorMessages += `Description: ${errors.description.join(', ')}\n`;
      if (errors.column) errorMessages += `Column: ${errors.column.join(', ')}\n`;
      if (errors.dimension) errorMessages += `Dimension: ${errors.dimension.join(', ')}\n`;
      if (errors.weight) errorMessages += `Weight: ${errors.weight.join(', ')}\n`;
      toast({ title: "Validation Error", description: errorMessages || "Invalid input for rule.", variant: "destructive", duration: 7000 });
      return;
    }

    let action: 'ADD_RULE' | 'UPDATE_RULE' = 'ADD_RULE';
    let updatedRulesList;

    if (ruleToSave.id && (ruleToSave.id.startsWith('manual-') || ruleToSave.id.startsWith('ai-') || ruleToSave.id.startsWith('genkit-ai-'))) {
      updatedRulesList = rules.map(r => r.id === ruleToSave.id ? validatedRule.data : r);
      action = 'UPDATE_RULE';
    } else {
      const newRuleId = `manual-genkit-${Date.now()}`;
      updatedRulesList = [...rules, { ...validatedRule.data, id: newRuleId }];
    }
    
    setRules(updatedRulesList); // Update local state
    toast({ title: "Rule Staged", description: `Rule ${action === 'ADD_RULE' ? 'added' : 'updated'}. Click 'Save Configuration' to persist.` });
    setEditingRule(null);
  };

  const handleDimensionWeightChange = (dimension: DimensionName, value: number[]) => {
    if (!selectedDataSourceId) return;
    const newWeight = value[0];
    setDimensionWeights(prev => ({ ...prev, [dimension]: newWeight })); // Update local state
  };

  const handleRuleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    if (editingRule) {
      const { name, value } = e.target;
      setEditingRule({ ...editingRule, [name]: value });
    }
  };

  const handleRuleFormSelectChange = (name: string, value: string) => {
    if (editingRule) {
      setEditingRule({ ...editingRule, [name]: value as Rule['dimension'] | Rule['type'] });
    }
  };

  const handleRuleFormWeightChange = (value: number[]) => {
    if (editingRule) {
      setEditingRule({ ...editingRule, weight: value[0] });
    }
  };

  const DimensionInfo = ({ title, weight, onWeightChange, examples }: { title: DimensionName, weight: number, onWeightChange: (val: number[]) => void, examples: string[] }) => (
    <div className="p-4 border rounded-lg bg-card shadow-sm">
      <Label htmlFor={`${title.toLowerCase()}Weight`} className="text-base font-semibold text-card-foreground">{title} ({weight}%)</Label>
      <Slider id={`${title.toLowerCase()}Weight`} value={[weight]} onValueChange={onWeightChange} max={100} step={1} className="my-3" disabled={!selectedDataSourceId}/>
      <div className="mt-2 space-y-1">
        <Label className="text-xs text-muted-foreground flex items-center"><HelpCircle className="w-3 h-3 mr-1" /> Potential Checks (for AI rule suggestion):</Label>
        <ul className="list-disc list-inside pl-2 text-xs text-muted-foreground space-y-0.5">
          {examples.map((ex, i) => <li key={i}>{ex}</li>)}
        </ul>
      </div>
    </div>
  );

  if (!currentUser) {
    return <div className="container mx-auto py-8 text-center">Please log in to manage rules.</div>;
  }

  const suggestButtonText = "Suggest Rules with Genkit AI";
  const dimensionWeightsMap: Record<DimensionName | "Other", number> = {
    ...dimensionWeights,
    Other: 0, // For display consistency, not directly set by user
  };


  return (
    <div className="container mx-auto py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Rules Editor (Genkit AI) for {currentUser}</h1>
        <p className="text-muted-foreground">Define DQ rules. Select a source, then AI can suggest rules using a real sample (from Data Nexus) or a mock sample. Rules and weights are saved per source.</p>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center"><Wand2 className="mr-2 h-5 w-5 text-primary" />AI Rule Suggestion Configuration</CardTitle>
          <CardDescription>Select a data source. AI will use its specific dimension weights and a data sample (real or mock) to suggest rules. Suggested rules will replace existing ones for this source locally until saved.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="dataSourceSelect">Data Source for Rule Management</Label>
            <Select
              onValueChange={(value) => {
                setSelectedDataSourceId(value);
                const selectedDSDetails = dataSourcesForSelect.find(ds => ds.id === value);
                if (selectedDSDetails && selectedDSDetails.type === 'data-nexus-csv' && selectedDSDetails.id.startsWith('dn-job-')) {
                    const jobIdFromDsId = selectedDSDetails.id.substring('dn-job-'.length);
                    const jobResultKey = DATA_NEXUS_JOB_RESULT_PREFIX + jobIdFromDsId;
                    const jobResultJson = window.localStorage.getItem(jobResultKey);
                    if (jobResultJson) {
                        try {
                            const jobResult: NexusJobResult = JSON.parse(jobResultJson);
                            setNexusJobResultContext(jobResult);
                            toast({
                                title: "Data Nexus Context Reloaded",
                                description: `Context for "${jobResult.dataSourceName}" loaded. AI will use this real sample.`,
                                duration: 5000,
                            });
                        } catch (e) { setNexusJobResultContext(null); console.warn("Error parsing reloaded Nexus Job Result for selected DS", e); }
                    } else { setNexusJobResultContext(null); }
                } else {
                    setNexusJobResultContext(null);
                    if (searchParams.get('nexus_job_id')) { router.replace(window.location.pathname, { scroll: false }); }
                }
              }}
              value={selectedDataSourceId}
            >
              <SelectTrigger id="dataSourceSelect" className="mt-1">
                <SelectValue placeholder="Select a data source" />
              </SelectTrigger>
              <SelectContent>
                {dataSourcesForSelect.length > 0 ? (
                  dataSourcesForSelect.map(ds => (
                    <SelectItem key={ds.id} value={ds.id}>{ds.name} ({ds.type?.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) || 'Unknown'})</SelectItem>
                  ))
                ) : ( <SelectItem value="no-sources" disabled>No data sources found. Add sources on the Data Sources page.</SelectItem> )}
              </SelectContent>
            </Select>
            {nexusJobResultContext && selectedDataSourceId && dataSourcesForSelect.find(ds => ds.id === selectedDataSourceId)?.name === nexusJobResultContext.dataSourceName && (
                <p className="text-xs text-accent mt-1 flex items-center">
                    <DatabaseZap className="w-3 h-3 mr-1" />
                    Context active from Data Nexus for: {nexusJobResultContext.dataSourceName}. AI will use this real sample.
                </p>
            )}
            {!nexusJobResultContext && selectedDataSourceId && (
                 <p className="text-xs text-muted-foreground mt-1 flex items-center">
                    <Info className="w-3 h-3 mr-1" />
                    No active Data Nexus sample for this source. AI will use a generated mock sample.
                </p>
            )}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {DIMENSIONS_CONFIG.map(dim => (
              <DimensionInfo
                key={dim.name}
                title={dim.name}
                weight={dimensionWeights[dim.name]}
                onWeightChange={(val) => handleDimensionWeightChange(dim.name, val)}
                examples={
                    dim.name === "Completeness" ? ["Non-null values", "Presence of required fields", "Record count expectations"] :
                    dim.name === "Accuracy" ? ["Format validation (email, date)", "Range checks (age, amount)", "Reference integrity"] :
                    dim.name === "Consistency" ? ["Cross-field validation", "Uniformity of units/formats", "No contradictory info"] :
                    ["Duplicate values in ID columns", "Primary key uniqueness", "Unique email/usernames"]
                }
              />
            ))}
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSuggestRules} disabled={isSuggesting || !selectedDataSourceId}>
            {isSuggesting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            <Wand2 className="mr-2 h-4 w-4" /> {isSuggesting ? "Suggesting with AI..." : suggestButtonText}
          </Button>
        </CardFooter>
      </Card>

      {editingRule && (
        <Card className="shadow-lg">
            <CardHeader>
                <CardTitle>{editingRule.id ? 'Edit Rule' : 'Add New Rule'}</CardTitle>
                <CardDescription>For Data Source: {selectedDataSourceId ? dataSourcesForSelect.find(ds => ds.id === selectedDataSourceId)?.name : 'N/A'}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <div>
                    <Label htmlFor="ruleDimension">Dimension <span className="text-destructive">*</span></Label>
                    <Select name="dimension" value={editingRule.dimension || ''} onValueChange={(value) => handleRuleFormSelectChange('dimension', value as DimensionName | "Other")} required>
                        <SelectTrigger id="ruleDimension"><SelectValue placeholder="Select primary dimension" /></SelectTrigger>
                        <SelectContent>
                            {DIMENSIONS_CONFIG.map(dim => (<SelectItem key={dim.name} value={dim.name}>{dim.label}</SelectItem>))}
                            <SelectItem value="Other">Other / Uncategorized</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div><Label htmlFor="ruleDescription">Description <span className="text-destructive">*</span></Label><Input id="ruleDescription" name="description" value={editingRule.description} onChange={handleRuleFormChange} placeholder="e.g., Email must be valid" required/></div>
                <div><Label htmlFor="ruleColumn">Column <span className="text-destructive">*</span></Label><Input id="ruleColumn" name="column" value={editingRule.column} onChange={handleRuleFormChange} placeholder="e.g., email_address or comma-separated: email,phone" required/></div>
                <div>
                    <Label htmlFor="ruleType">Rule Type (Optional, for execution engine)</Label>
                    <Select name="type" value={editingRule.type || ''} onValueChange={(value) => handleRuleFormSelectChange('type', value)}>
                        <SelectTrigger id="ruleType"><SelectValue placeholder="Select rule type (e.g., not_null, regex, range)" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="not_null">Not Null</SelectItem><SelectItem value="unique">Unique</SelectItem><SelectItem value="regex">Regex Pattern</SelectItem><SelectItem value="range">Numeric Range</SelectItem><SelectItem value="enum">Value in Set</SelectItem><SelectItem value="date_format">Date Format</SelectItem><SelectItem value="custom">Custom (Specify parameters)</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <Label htmlFor="ruleParameters">Parameters (JSON, Optional)</Label>
                    <Textarea id="ruleParameters" name="parameters" value={editingRule.parameters ? JSON.stringify(editingRule.parameters, null, 2) : ''}
                        onChange={(e) => { if (editingRule) { try { const parsed = e.target.value ? JSON.parse(e.target.value) : {}; setEditingRule({...editingRule, parameters: parsed });} catch (err) { /* Allow invalid JSON while typing */ }}}}
                        placeholder='e.g., {"pattern": "^[A-Za-z]+$", "min": 0, "max": 100}' rows={3} />
                </div>
                <div><Label htmlFor="ruleRationale">Rationale (Optional)</Label><Textarea id="ruleRationale" name="rationale" value={editingRule.rationale || ''} onChange={handleRuleFormChange} placeholder="Why this rule is generally important." rows={2}/></div>
                <div><Label htmlFor="ruleReasonForColumnChoice">Reason for Column Choice (AI Suggested - Optional)</Label><Textarea id="ruleReasonForColumnChoice" name="reasonForColumnChoice" value={editingRule.reasonForColumnChoice || ''} onChange={handleRuleFormChange} placeholder="Why AI chose this column for this rule." rows={2}/></div>
                <div><Label htmlFor="ruleImpactOnDimension">Impact on Dimension (AI Suggested - Optional)</Label><Textarea id="ruleImpactOnDimension" name="impactOnDimension" value={editingRule.impactOnDimension || ''} onChange={handleRuleFormChange} placeholder="How this rule improves the dimension." rows={2}/></div>
                <div><Label htmlFor="ruleWeight">Importance Weight ({editingRule.weight || 0}%)</Label><Slider id="ruleWeight" value={[editingRule.weight || 0]} onValueChange={handleRuleFormWeightChange} max={100} step={1} className="mt-2" /></div>
            </CardContent>
            <CardFooter className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setEditingRule(null)}>Cancel</Button>
                <Button onClick={() => handleSaveRule(editingRule)}><Save className="mr-2 h-4 w-4" /> Save Rule Edits</Button>
            </CardFooter>
        </Card>
      )}

      <Card className="shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center"><ListChecks className="mr-2 h-5 w-5" /> Defined Rules For: {selectedDataSourceId ? dataSourcesForSelect.find(ds => ds.id === selectedDataSourceId)?.name : 'No Data Source Selected'}</CardTitle>
            <CardDescription>Manage DQ rules. Rules & weights are specific to the selected source. Edits are staged locally until you click "Save Configuration".</CardDescription>
          </div>
          <Button onClick={handleAddRule} variant="default" disabled={!selectedDataSourceId}><PlusCircle className="mr-2 h-4 w-4" /> Add Rule Manually</Button>
        </CardHeader>
        <CardContent>
          {!selectedDataSourceId ? (
            <div className="text-center py-10"><AlertTriangle className="mx-auto h-12 w-12 text-muted-foreground" /><h3 className="mt-2 text-sm font-medium text-foreground">No Data Source Selected</h3><p className="mt-1 text-sm text-muted-foreground">Please select a data source above to view or add rules.</p></div>
          ) : rules.length > 0 ? (
            <Accordion type="multiple" className="w-full" defaultValue={DIMENSIONS_CONFIG.map(d => d.name).concat("Other")}>
              {[...DIMENSIONS_CONFIG.map(dc => dc.name), "Other"].map(dimensionNameKey => {
                const dimensionName = dimensionNameKey as DimensionName | "Other";
                const dimensionRules = rules.filter(rule => (rule.dimension || "Other") === dimensionName);
                if (dimensionRules.length === 0 && dimensionName !== "Other") return null;
                if (dimensionRules.length === 0 && dimensionName === "Other" && !rules.some(r => !r.dimension || r.dimension === "Other")) return null;
                const dimensionLabel = dimensionName === "Other" ? "Other / Uncategorized" : DIMENSIONS_CONFIG.find(dc => dc.name === dimensionName)?.label;
                const dimensionWeightDisplay = dimensionName === "Other" ? "" : `(current weight ${dimensionWeightsMap[dimensionName as DimensionName] || 0}%)`;

                return (
                  <AccordionItem value={dimensionName} key={dimensionName}>
                    <AccordionTrigger className="text-lg hover:no-underline"><span className="font-semibold">– {dimensionLabel} {dimensionWeightDisplay}: {dimensionRules.length} rule(s)</span></AccordionTrigger>
                    <AccordionContent className="pl-6 pr-2 pt-2 pb-2">
                      <ul className="space-y-3">
                        {dimensionRules.map((rule) => (
                          <li key={rule.id} className="p-3 border rounded-md shadow-sm bg-card/50 hover:shadow-md transition-shadow">
                            <div className="flex justify-between items-start gap-2">
                              <div className="flex-grow space-y-1">
                                <div className="flex items-start"><span className="mr-2 text-lg leading-tight text-primary">•</span><p className="font-medium text-base text-foreground flex-1">{rule.description}</p></div>
                                <div className="pl-5 space-y-0.5">
                                  <p className="text-xs text-muted-foreground"><span className="font-medium">Column(s):</span> {rule.column}</p>
                                  {rule.type && (<p className="text-xs text-muted-foreground"><span className="font-medium">Type:</span> {rule.type}</p>)}
                                  {rule.weight !== undefined && (<p className="text-xs text-muted-foreground"><span className="font-medium">Rule Weight:</span> {rule.weight}%</p>)}
                                  {rule.rationale && (<p className="text-xs text-muted-foreground italic"><Sparkles className="inline h-3 w-3 mr-1 text-accent"/><span className="font-medium">Rationale:</span> {rule.rationale}</p>)}
                                  {rule.reasonForColumnChoice && (<p className="text-xs text-muted-foreground italic"><Brain className="inline h-3 w-3 mr-1 text-accent"/><span className="font-medium">AI Column Choice Reasoning:</span> {rule.reasonForColumnChoice}</p>)}
                                  {rule.impactOnDimension && (<p className="text-xs text-muted-foreground italic"><Sparkles className="inline h-3 w-3 mr-1 text-accent"/><span className="font-medium">AI Impact on Dimension:</span> {rule.impactOnDimension}</p>)}
                                </div>
                              </div>
                              <div className="flex space-x-1 shrink-0 mt-1">
                                <Button variant="ghost" size="icon" onClick={() => handleEditRule(rule)} aria-label="Edit rule"><Edit3 className="h-4 w-4" /></Button>
                                <Button variant="ghost" size="icon" onClick={() => handleDeleteRule(rule.id)} className="text-destructive hover:text-destructive" aria-label="Delete rule"><Trash2 className="h-4 w-4" /></Button>
                              </div>
                            </div>
                          </li>
                        ))}
                         {dimensionRules.length === 0 && dimensionName === "Other" && (
                            <p className="text-sm text-muted-foreground pl-1">No rules categorized as 'Other'.</p>
                        )}
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          ) : (
            <div className="text-center py-10"><ListChecks className="mx-auto h-12 w-12 text-muted-foreground" /><h3 className="mt-2 text-sm font-medium text-foreground">No rules defined for {selectedDataSourceId ? dataSourcesForSelect.find(ds => ds.id === selectedDataSourceId)?.name : 'this data source'}</h3><p className="mt-1 text-sm text-muted-foreground">Suggest rules using AI or add them manually. Edits are staged locally until you click "Save Configuration".</p></div>
          )}
        </CardContent>
         <CardFooter className="flex justify-end">
            <Button onClick={handleSaveConfiguration} size="lg" disabled={!selectedDataSourceId}>
                <Save className="mr-2 h-4 w-4" /> Save Configuration
            </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
