
"use client"; 

import React, { useEffect, useState } from 'react';
import NextTopLoader from 'nextjs-toploader';
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarInset,
  SidebarTrigger,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { navItems } from '@/config/nav';
import { SidebarNav } from '@/components/layout/sidebar-nav';
import { Icons } from '@/components/icons';
import Link from 'next/link';
import { User, LogOut, Settings as SettingsIcon } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AuthProvider } from '@/components/AuthProvider'; 
import { getCurrentMockUser, clearCurrentMockUser } from '@/lib/authUtils';
import { useRouter } from 'next/navigation';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider> 
      <NextTopLoader
        color="hsl(var(--primary))"
        initialPosition={0.08}
        crawlSpeed={200}
        height={3}
        crawl={true}
        showSpinner={true}
        easing="ease"
        speed={200}
        shadow="0 0 10px hsl(var(--primary)),0 0 5px hsl(var(--primary))"
        zIndex={1600} // Ensure it's above other elements like sidebar
      />
      <SidebarProvider defaultOpen>
        <Sidebar variant="sidebar" collapsible="icon" className="border-r">
          <SidebarHeader className="p-4 flex items-center gap-2">
            <Link href="/dashboard" className="flex items-center gap-2">
              <Icons.Logo className="w-8 h-8 text-primary" />
              <h1 className="text-xl font-semibold group-data-[collapsible=icon]:hidden">
                DataQualityLens
              </h1>
            </Link>
            <SidebarTrigger className="ml-auto group-data-[collapsible=icon]:hidden" />
          </SidebarHeader>
          <SidebarContent className="p-2">
            <SidebarNav items={navItems} />
          </SidebarContent>
          <SidebarFooter className="p-2 border-t">
              <UserMenu />
          </SidebarFooter>
        </Sidebar>
        <SidebarInset className="flex flex-col">
          <header className="sticky top-0 z-10 flex h-14 items-center gap-4 border-b bg-background px-4 sm:static sm:h-auto sm:border-0 sm:bg-transparent sm:px-6 py-4">
            <SidebarTrigger className="md:hidden" />
          </header>
          <main className="flex-1 overflow-auto p-4 md:p-6">
            {children}
          </main>
        </SidebarInset>
      </SidebarProvider>
    </AuthProvider>
  );
}

function UserMenu() {
    const router = useRouter();
    const [currentUser, setCurrentUser] = useState<string | null>(null);

    useEffect(() => {
        setCurrentUser(getCurrentMockUser());
    }, []);

    const handleLogout = () => {
        clearCurrentMockUser();
        router.push('/login-mock');
    };

    const userInitial = currentUser ? currentUser.charAt(0).toUpperCase() : 'DQ';

    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="w-full justify-start group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-0">
                    <Avatar className="h-8 w-8 mr-2 group-data-[collapsible=icon]:mr-0">
                        <AvatarImage src={`https://placehold.co/100x100.png?text=${userInitial}`} alt="User Avatar" data-ai-hint="user avatar"/>
                        <AvatarFallback>{userInitial}</AvatarFallback>
                    </Avatar>
                    <span className="group-data-[collapsible=icon]:hidden truncate max-w-[120px]">
                        {currentUser || 'User Name'}
                    </span>
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="right" align="start" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                    <Link href="/settings">
                        <SettingsIcon className="mr-2 h-4 w-4" />
                        <span>Settings</span>
                    </Link>
                </DropdownMenuItem>
                <DropdownMenuItem disabled> 
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile (coming soon)</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}
