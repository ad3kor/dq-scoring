
"use client";

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PlusCircle, Trash2, Edit3, Save, Info, ListChecks, AlertTriangle, HelpCircle, Loader2, DatabaseZap, Sparkles, Brain, CheckCircle2, XCircle, History } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { z } from 'zod';
import { getCurrentMockUser, getUserSpecificKey, BASE_DS_KEY, BASE_DATABRICKS_SUGGESTER_CONFIG_KEY, BASE_DATABRICKS_SUGGESTER_HISTORY_KEY, addAuditLog } from '@/lib/authUtils';
import { useRouter, useSearchParams } from 'next/navigation';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { FormattedDateTime } from '@/components/FormattedDateTime';


const DATA_NEXUS_JOB_RESULT_PREFIX = 'dataNexusJobResult_';
const MAX_SAMPLE_RECORDS_FOR_DATABRICKS_PARAMS = 5;
const MAX_HISTORY_ENTRIES_PER_SOURCE = 5;

const DIMENSIONS_CONFIG = [
  { name: "Accuracy", label: "Accuracy" },
  { name: "Completeness", label: "Completeness" },
  { name: "Consistency", label: "Consistency" },
  { name: "Uniqueness", label: "Uniqueness" },
] as const;

type DimensionName = typeof DIMENSIONS_CONFIG[number]['name'];

const ruleSchema = z.object({
  id: z.string(),
  description: z.string().min(1, "Description is required."),
  column: z.string().min(1, "Column is required."),
  type: z.string().optional(),
  condition: z.string().optional(),
  parameters: z.record(z.any()).optional(),
  weight: z.number().min(0).max(100).optional(),
  dimension: z.enum([...DIMENSIONS_CONFIG.map(d => d.name), "Other"]),
  rationale: z.string().optional(),
  reasonForColumnChoice: z.string().optional(),
  impactOnDimension: z.string().optional(),
});

type Rule = z.infer<typeof ruleSchema>;

interface DataSourceFromLocalStorage {
  id: string;
  name: string;
  type: string;
  details: string;
}

interface DatabricksSuggesterJobOutput {
  status: 'SUCCEEDED' | 'FAILED' | 'PENDING' | 'RUNNING';
  message?: string;
  suggested_rules?: Array<{
    name: string;
    dimension: DimensionName | "Other" | string;
    rule_type: string;
    columns: string[];
    rationale?: string;
    reasonForColumnChoice?: string;
    impactOnDimension?: string;
  }>;
  default_weights?: Record<string, number>;
  error?: string;
}


interface DatabricksJobStatus {
  status: 'IDLE' | 'TRIGGERING' | 'POLLING' | 'SUCCEEDED' | 'FAILED';
  message: string;
  runId?: string;
}

interface NexusJobDataSample {
    status?: string;
    message?: string;
    data_sample?: Record<string, any>[];
}
interface NexusJobResult {
    dataSourceName: string;
    containerName: string;
    blobName: string;
    sourceFilePathsJson: string; 
    dataSample: NexusJobDataSample | Record<string, any>[];
    type: 'data-nexus-csv';
}

interface StoredConfigEntry {
  rules: Rule[];
  dimensionWeights: Record<DimensionName, number>;
  timestamp?: string;
}


const INITIAL_DIMENSION_WEIGHTS_STATE: Record<DimensionName, number> = {
  Accuracy: 25, Completeness: 25, Consistency: 25, Uniqueness: 25,
};

export default function DatabricksRulesSuggesterPage() {
  const { toast } = useToast();
  const router = useRouter();
  const searchParams = useSearchParams();

  const [dataSourcesFromStorage, setDataSourcesFromStorage] = useState<DataSourceFromLocalStorage[]>([]);
  const [nexusContextDataSource, setNexusContextDataSource] = useState<DataSourceFromLocalStorage | null>(null);
  const [selectedDataSourceId, setSelectedDataSourceId] = useState<string | undefined>(undefined);
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  const [dimensionWeights, setDimensionWeights] = useState<Record<DimensionName, number>>({ ...INITIAL_DIMENSION_WEIGHTS_STATE });
  const [rules, setRules] = useState<Rule[]>([]);

  const [allCurrentConfigs, setAllCurrentConfigs] = useState<Record<string, StoredConfigEntry>>({});
  const [suggesterConfigHistory, setSuggesterConfigHistory] = useState<Record<string, StoredConfigEntry[]>>({});
  const [activeHistoryEntryTimestamp, setActiveHistoryEntryTimestamp] = useState<string | null>(null);


  const [databricksJobState, setDatabricksJobState] = useState<DatabricksJobStatus>({ status: 'IDLE', message: 'Ready to start.' });
  const [editingRule, setEditingRule] = useState<Rule | null>(null);
  const [nexusJobResultContext, setNexusJobResultContext] = useState<NexusJobResult | null>(null);

  const displayedDropdownSources = useMemo(() => {
    const options = [...dataSourcesFromStorage];
    if (nexusContextDataSource) {
        if (!options.some(ds => ds.id === nexusContextDataSource.id)) {
            options.unshift(nexusContextDataSource);
        } else { 
            const index = options.findIndex(ds => ds.id === nexusContextDataSource.id);
            if (index !== -1) options[index] = nexusContextDataSource;
        }
    }
    return options;
  }, [dataSourcesFromStorage, nexusContextDataSource]);

  useEffect(() => {
    const user = getCurrentMockUser();
    setCurrentUser(user);
    if (user) {
      try {
        const dsStorageKey = getUserSpecificKey(BASE_DS_KEY, user);
        const dsItem = window.localStorage.getItem(dsStorageKey);
        const loadedDataSources: DataSourceFromLocalStorage[] = dsItem ? JSON.parse(dsItem) : [];
        setDataSourcesFromStorage(loadedDataSources);

        const currentConfigsStorageKey = getUserSpecificKey(BASE_DATABRICKS_SUGGESTER_CONFIG_KEY, user);
        const currentConfigsItem = window.localStorage.getItem(currentConfigsStorageKey);
        setAllCurrentConfigs(currentConfigsItem ? JSON.parse(currentConfigsItem) : {});
        
        const historyStorageKey = getUserSpecificKey(BASE_DATABRICKS_SUGGESTER_HISTORY_KEY, user);
        const historyItem = window.localStorage.getItem(historyStorageKey);
        setSuggesterConfigHistory(historyItem ? JSON.parse(historyItem) : {});

        const nexusJobIdFromQuery = searchParams.get('nexus_job_id');
        if (nexusJobIdFromQuery) {
          const jobResultKey = DATA_NEXUS_JOB_RESULT_PREFIX + nexusJobIdFromQuery;
          const jobResultJson = window.localStorage.getItem(jobResultKey);
          if (jobResultJson) {
            try {
              const jobResult: NexusJobResult = JSON.parse(jobResultJson);
              setNexusJobResultContext(jobResult);
              const nexusDSId = `dn-job-${nexusJobIdFromQuery}`;
              
              const tempNexusDS: DataSourceFromLocalStorage = {
                id: nexusDSId,
                name: jobResult.dataSourceName || `Data Nexus Analysis: ${nexusJobIdFromQuery}`,
                type: jobResult.type || 'data-nexus-csv',
                details: `Context from Data Nexus Job ID: ${nexusJobIdFromQuery}`
              };
              setNexusContextDataSource(tempNexusDS); // Set the context data source
              setSelectedDataSourceId(nexusDSId); // Auto-select it
            } catch (e) { console.error("Error parsing Nexus Job Result from localStorage", e); }
          } else {
             console.warn(`No Nexus Job Result found in localStorage for ID: ${nexusJobIdFromQuery}`);
             toast({title:"Context Not Found", description:`Could not load sample data for Nexus Job ID ${nexusJobIdFromQuery}. It might have expired or was not saved.`, variant:"destructive", duration: 7000});
          }
        }
      } catch (error) { console.error("Error reading data sources from localStorage", error); }
    }
  }, [currentUser, searchParams, toast, router]);

  useEffect(() => {
    if (selectedDataSourceId) {
        const configForDS = allCurrentConfigs[selectedDataSourceId];
        if (configForDS) {
            setRules(configForDS.rules || []);
            setDimensionWeights(configForDS.dimensionWeights || { ...INITIAL_DIMENSION_WEIGHTS_STATE });
        } else {
            setRules([]);
            setDimensionWeights({ ...INITIAL_DIMENSION_WEIGHTS_STATE });
        }
        setActiveHistoryEntryTimestamp(null); 
    } else { 
        setRules([]);
        setDimensionWeights({ ...INITIAL_DIMENSION_WEIGHTS_STATE });
        setActiveHistoryEntryTimestamp(null);
    }
  }, [selectedDataSourceId, allCurrentConfigs]);


  useEffect(() => {
    if (currentUser && Object.keys(allCurrentConfigs).length >= 0) { 
        try {
            const storageKey = getUserSpecificKey(BASE_DATABRICKS_SUGGESTER_CONFIG_KEY, currentUser);
            window.localStorage.setItem(storageKey, JSON.stringify(allCurrentConfigs));
        } catch (error) { console.error("Error saving all current configs to localStorage", error); }
    }
  }, [allCurrentConfigs, currentUser]);
  
  useEffect(() => {
    if (currentUser && Object.keys(suggesterConfigHistory).length >= 0) { 
        try {
            const storageKey = getUserSpecificKey(BASE_DATABRICKS_SUGGESTER_HISTORY_KEY, currentUser);
            window.localStorage.setItem(storageKey, JSON.stringify(suggesterConfigHistory));
        } catch (error) { console.error("Error saving suggester config history to localStorage", error); }
    }
  }, [suggesterConfigHistory, currentUser]);


  const pollJobStatus = useCallback(async (internalRunId: string, dsName: string) => {
    const intervalId = setInterval(async () => {
      try {
        const response = await fetch(`/api/databricks-rule-suggester?run_id=${internalRunId}`);
        const result: DatabricksSuggesterJobOutput = await response.json();

        if (!response.ok && result.status !== 'SUCCEEDED') {
            const errorMsgFromServer = result.error || result.message || response.statusText || "Polling failed";
            clearInterval(intervalId);
            setDatabricksJobState({ status: 'FAILED', message: `Job Run ID ${internalRunId} not found or polling failed: ${errorMsgFromServer}`, runId: internalRunId });
            toast({ title: "Polling Error", description: `Job Run ID ${internalRunId} error: ${errorMsgFromServer}`, variant: "destructive" });
            return;
        }
        
        setDatabricksJobState(prev => ({...prev, message: `Job ${internalRunId.substring(0,8)}... status: ${result.status || 'Polling...'}. Polling...`}));

        if (result.status === 'SUCCEEDED') {
          clearInterval(intervalId);
          const notebookRules = result.suggested_rules || [];
          const fetchedRulesUI: Rule[] = notebookRules.map((r, index) => ({
            id: `db-rule-${internalRunId}-${index}`,
            description: r.name || "No description from Databricks",
            column: Array.isArray(r.columns) ? r.columns.join(', ') : (r.columns || "N/A"),
            type: r.rule_type,
            dimension: DIMENSIONS_CONFIG.find(dc => dc.name.toLowerCase() === (r.dimension || "").toLowerCase())?.name || "Other",
            weight: 50, 
            rationale: r.rationale,
            reasonForColumnChoice: r.reasonForColumnChoice,
            impactOnDimension: r.impactOnDimension,
          }));

          const notebookWeights = result.default_weights || {};
          const newDimWeights: Record<DimensionName, number> = { ...INITIAL_DIMENSION_WEIGHTS_STATE };
          let totalWeightsSumFromNotebook = 0;

          DIMENSIONS_CONFIG.forEach(dimConfig => {
            const key = dimConfig.name;
            if (notebookWeights[key] !== undefined && typeof notebookWeights[key] === 'number') {
              newDimWeights[key] = Math.max(0, Math.min(100, Math.round(notebookWeights[key] * 100)));
              totalWeightsSumFromNotebook += newDimWeights[key];
            }
          });

          if (Object.keys(notebookWeights).length > 0 && totalWeightsSumFromNotebook > 0 && totalWeightsSumFromNotebook !== 100 && totalWeightsSumFromNotebook !== 0) {
            const factor = 100 / totalWeightsSumFromNotebook;
            let adjustedSum = 0;
            DIMENSIONS_CONFIG.forEach(dimConfig => {
                const key = dimConfig.name;
                if (newDimWeights[key] > 0) {
                    newDimWeights[key] = Math.round(newDimWeights[key] * factor);
                    adjustedSum += newDimWeights[key];
                }
            });
            if (adjustedSum !== 100) { 
                const diff = 100 - adjustedSum;
                const firstAdjustableDim = DIMENSIONS_CONFIG.find(dc => newDimWeights[dc.name] > 0)?.name || "Uniqueness";
                newDimWeights[firstAdjustableDim] = (newDimWeights[firstAdjustableDim] || 0) + diff;
            }
          } else if (Object.keys(notebookWeights).length === 0) {
             console.warn("No default_weights received from Databricks, using initial frontend weights.");
          }


          setDimensionWeights(newDimWeights);
          setRules(fetchedRulesUI);
          setDatabricksJobState({ status: 'SUCCEEDED', message: `Job ${internalRunId.substring(0,8)} completed. Rules and weights loaded.`, runId: internalRunId });
          addAuditLog('DATABRICKS_RULES_JOB_SUCCEEDED', `Databricks rules loaded for source '${dsName}'. Run ID: ${internalRunId}. ${fetchedRulesUI.length} rules.`, 'DatabricksJob', internalRunId);
          toast({ title: "Databricks Job Success", description: "Rules and weights have been loaded. Save configuration to persist." });
          setActiveHistoryEntryTimestamp(null);

        } else if (result.status === 'FAILED' || result.status === 'TIMED_OUT' || result.status === 'CANCELED') {
          clearInterval(intervalId);
          const errorMessage = result.error || result.message || `Job ${internalRunId.substring(0,8)} ${result.status || 'failed'}`;
          setDatabricksJobState({ status: 'FAILED', message: errorMessage, runId: internalRunId });
          addAuditLog('DATABRICKS_RULES_JOB_FAILED', `Databricks rules job for source '${dsName}' failed. Run ID: ${internalRunId}. Error: ${errorMessage}`, 'DatabricksJob', internalRunId);
          toast({ title: "Databricks Job Failed", description: errorMessage, variant: "destructive" });
        }
      } catch (error: any) {
        clearInterval(intervalId);
        const errorMessage = error.message || 'An unknown error occurred during polling.';
        console.error("Polling error:", error);
        setDatabricksJobState({ status: 'FAILED', message: `Polling error: ${errorMessage}`, runId: internalRunId });
        toast({ title: "Polling System Error", description: errorMessage, variant: "destructive" });
      }
    }, 7000);

    return () => clearInterval(intervalId);
  }, [toast, addAuditLog, setDatabricksJobState, setRules, setDimensionWeights]);


  const handleTriggerDatabricksJob = async () => {
    if (!selectedDataSourceId || !currentUser) {
      toast({ title: "Error", description: "Please select a data source.", variant: "destructive" });
      return;
    }
    
    const currentSelectedDSForJob = displayedDropdownSources.find(ds => ds.id === selectedDataSourceId);
    if (!currentSelectedDSForJob) {
        toast({ title: "Error", description: "Selected data source context not found for job trigger.", variant: "destructive" });
        return;
    }
    const dsNameForJob = currentSelectedDSForJob.name;


    if (!nexusJobResultContext || !nexusJobResultContext.dataSample) {
        toast({ title: "Data Sample Missing", description: "Data sample from Data Nexus context is required to trigger this Databricks job. Please process via Data Nexus first.", variant: "destructive", duration: 7000 });
        return;
    }

    let actualDataSampleArray: Record<string, any>[] | undefined;
    if (nexusJobResultContext.dataSample &&
        typeof nexusJobResultContext.dataSample === 'object' &&
        !Array.isArray(nexusJobResultContext.dataSample) &&
        'data_sample' in nexusJobResultContext.dataSample &&
        Array.isArray((nexusJobResultContext.dataSample as NexusJobDataSample).data_sample)
       ) {
      actualDataSampleArray = (nexusJobResultContext.dataSample as NexusJobDataSample).data_sample;
    } else if (Array.isArray(nexusJobResultContext.dataSample)) {
      actualDataSampleArray = nexusJobResultContext.dataSample as Record<string, any>[];
    }


    if (!actualDataSampleArray || actualDataSampleArray.length === 0) {
      toast({ title: "Empty Data Sample", description: "The provided data sample from Data Nexus is empty. Cannot suggest rules.", variant: "destructive", duration: 5000 });
      return;
    }

    let sampleToSend = actualDataSampleArray;
    if (actualDataSampleArray.length > MAX_SAMPLE_RECORDS_FOR_DATABRICKS_PARAMS) {
      sampleToSend = actualDataSampleArray.slice(0, MAX_SAMPLE_RECORDS_FOR_DATABRICKS_PARAMS);
      toast({
        title: "Data Sample Truncated",
        description: `The data sample was too large and has been truncated to the first ${MAX_SAMPLE_RECORDS_FOR_DATABRICKS_PARAMS} records for the Databricks job.`,
        variant: "default",
        duration: 7000,
      });
    }
    const dataSampleJsonString = JSON.stringify(sampleToSend);

    setDatabricksJobState({ status: 'TRIGGERING', message: `Triggering Databricks rule suggestion for "${dsNameForJob}"...` });
    toast({title: "Job Triggered", description: "Contacting Databricks to start rule suggestion job."});

    try {
      const response = await fetch('/api/databricks-rule-suggester', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dataSampleJson: dataSampleJsonString, dataSourceName: dsNameForJob }),
      });

      const result = await response.json();

      if (!response.ok) {
        const errorMsgFromServer = result.error || `Failed to trigger Databricks job (HTTP ${response.status})`;
        throw new Error(errorMsgFromServer);
      }

      addAuditLog('DATABRICKS_RULES_JOB_TRIGGERED', `Databricks rule suggestion job triggered for source '${dsNameForJob}'. Internal Run ID: ${result.runId}`, 'DatabricksJob', result.runId);
      setDatabricksJobState({ status: 'POLLING', message: `Job ${result.runId} is running. Polling for status...`, runId: result.runId });
      pollJobStatus(result.runId, dsNameForJob);

    } catch (error: any) {
      const errorMessage = error.message || 'An unknown error occurred during job trigger.';
      console.error("Error triggering Databricks job:", error);
      setDatabricksJobState({ status: 'FAILED', message: `Job Trigger Failed: ${errorMessage}` });
      toast({ title: "Job Trigger Failed", description: errorMessage, variant: "destructive" });
    }
  };


  const handleDimensionWeightChange = (dimension: DimensionName, value: number[]) => {
    setDimensionWeights(prev => ({ ...prev, [dimension]: value[0] }));
  };

  const handleSaveConfiguration = () => {
    if (!selectedDataSourceId || !currentUser) {
      toast({ title: "Error", description: "Cannot save configuration without a selected data source or user.", variant: "destructive" });
      return;
    }
    
    const configToSave: StoredConfigEntry = { rules, dimensionWeights, timestamp: new Date().toISOString() };
    
    setAllCurrentConfigs(prev => ({
      ...prev,
      [selectedDataSourceId]: configToSave 
    }));

    setSuggesterConfigHistory(prevHistory => {
        const currentHistoryForDS = prevHistory[selectedDataSourceId] || [];
        const updatedHistoryForDS = [configToSave, ...currentHistoryForDS].slice(0, MAX_HISTORY_ENTRIES_PER_SOURCE);
        return { ...prevHistory, [selectedDataSourceId]: updatedHistoryForDS };
    });

    const selectedDSName = displayedDropdownSources.find(ds => ds.id === selectedDataSourceId)?.name || 'Unknown Data Source';
    addAuditLog('SAVE_DATABRICKS_RULES_CONFIG', `User saved rules and weights for data source '${selectedDSName}' (ID: ${selectedDataSourceId}). Total rules: ${rules.length}. This creates/updates active config & adds to history.`, 'RulesConfiguration', selectedDataSourceId);
    
    setActiveHistoryEntryTimestamp(null);
    
    toast({ title: "Configuration Saved", description: `Rules and weights for ${selectedDSName} saved locally. Proceeding to Data Nexus Assessment...` });
    router.push(`/data-nexus-assessment?dataSourceId=${selectedDataSourceId}`);
  };


  const handleLoadHistoricalConfig = (config: StoredConfigEntry) => {
    setRules(config.rules || []);
    setDimensionWeights(config.dimensionWeights || { ...INITIAL_DIMENSION_WEIGHTS_STATE });
    setActiveHistoryEntryTimestamp(config.timestamp || null);
    toast({title: "Historical Config Loaded", description: "Configuration from selected timestamp is now in the editor. Saving will make it the new active config."});
  };

  const handleAddRule = () => {
    if (!selectedDataSourceId) return;
    setEditingRule({ id: '', description: '', column: '', dimension: "Accuracy", weight: 50 });
  };

  const handleEditRule = (rule: Rule) => setEditingRule({ ...rule });

  const handleDeleteRule = (id: string) => {
    if (!selectedDataSourceId || !currentUser) return;
    const dsName = displayedDropdownSources.find(ds => ds.id === selectedDataSourceId)?.name || 'Unknown';
    const ruleDesc = rules.find(r => r.id === id)?.description || 'Unknown rule';

    const updatedRules = rules.filter(rule => rule.id !== id);
    setRules(updatedRules);

    addAuditLog('DELETE_RULE_DATABRICKS_CTX_STAGED', `Staged deletion of rule '${ruleDesc}' from data source '${dsName}' (Databricks context).`, 'Rule', id);
    toast({ title: "Rule Deleted (Staged)", description: "Rule removed locally. Save configuration to persist." });
  };

  const handleSaveRule = (ruleToSave: Rule) => {
    if (!selectedDataSourceId || !currentUser) return;
    const validatedRule = ruleSchema.safeParse(ruleToSave);
    if (!validatedRule.success) {
      toast({ title: "Validation Error", description: "Invalid rule input.", variant: "destructive" });
      return;
    }
    const dsName = displayedDropdownSources.find(ds => ds.id === selectedDataSourceId)?.name || 'Unknown';
    let action: 'ADD_RULE' | 'UPDATE_RULE' = 'ADD_RULE';

    let updatedRulesList;
    if (ruleToSave.id && (ruleToSave.id.startsWith('db-rule-') || ruleToSave.id.startsWith('manual-db-'))) {
        updatedRulesList = rules.map(r => r.id === ruleToSave.id ? validatedRule.data : r);
        action = 'UPDATE_RULE';
    } else {
        const newRuleId = `manual-db-${Date.now()}`;
        updatedRulesList = [...rules, { ...validatedRule.data, id: newRuleId }];
    }
    setRules(updatedRulesList);

    toast({ title: "Rule Saved (Staged)", description: `Rule ${action === 'ADD_RULE' ? 'added' : 'updated'} locally. Save configuration to persist.` });
    addAuditLog(`${action}_DATABRICKS_CTX_STAGED`, `${action === 'ADD_RULE' ? 'Added' : 'Updated'} rule '${validatedRule.data.description}' for source '${dsName}' (Databricks context) - STAGED.`, 'Rule', validatedRule.data.id);
    setEditingRule(null);
  };

  const handleRuleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    if (editingRule) setEditingRule({ ...editingRule, [e.target.name]: e.target.value });
  };
  const handleRuleFormSelectChange = (name: string, value: string) => {
    if (editingRule) setEditingRule({ ...editingRule, [name]: value });
  };
  const handleRuleFormWeightChange = (value: number[]) => {
    if (editingRule) setEditingRule({ ...editingRule, weight: value[0] });
  };

   const DimensionInfo = ({ title, weight, onWeightChange, examples }: { title: DimensionName, weight: number, onWeightChange: (val: number[]) => void, examples: string[] }) => (
    <div className="p-4 border rounded-lg bg-card shadow-sm">
      <Label htmlFor={`${title.toLowerCase()}Weight`} className="text-base font-semibold text-card-foreground">{title} ({weight}%)</Label>
      <Slider id={`${title.toLowerCase()}Weight`} value={[weight]} onValueChange={onWeightChange} max={100} step={1} className="my-3" />
      <div className="mt-2 space-y-1">
        <Label className="text-xs text-muted-foreground flex items-center"><HelpCircle className="w-3 h-3 mr-1" /> Potential Checks (for AI rule suggestion):</Label>
        <ul className="list-disc list-inside pl-2 text-xs text-muted-foreground space-y-0.5">
          {examples.map((ex, i) => <li key={i}>{ex}</li>)}
        </ul>
      </div>
    </div>
  );


  if (!currentUser) {
    return <div className="container mx-auto py-8 text-center">Please log in to use this feature.</div>;
  }

  const getJobStatusIcon = () => {
    switch (databricksJobState.status) {
      case 'TRIGGERING':
      case 'POLLING':
        return <Loader2 className="h-4 w-4 animate-spin" />;
      case 'SUCCEEDED':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'FAILED':
        return <XCircle className="h-4 w-4 text-destructive" />;
      default:
        return <Sparkles className="h-4 w-4" />;
    }
  };

  const suggestButtonText = nexusJobResultContext?.dataSample
    ? "Generate Rules via Databricks AI (using Data Nexus Sample)"
    : "Generate Rules via Databricks AI (Data Nexus Sample Required)";

  const dimensionWeightsMap: Record<DimensionName | "Other", number> = {
    ...dimensionWeights,
    Other: 0,
  };

  const currentDSHistory = selectedDataSourceId ? suggesterConfigHistory[selectedDataSourceId] || [] : [];

  return (
    <div className="container mx-auto py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Databricks AI Rule Suggester</h1>
        <p className="text-muted-foreground">
          Select a data source. If a Data Nexus job ID is in the URL, its sample data will be used by the Databricks notebook.
          View history of saved configurations and load them for editing.
        </p>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center"><DatabaseZap className="mr-2 h-5 w-5 text-primary" /> Configure &amp; Trigger Databricks Job</CardTitle>
          <CardDescription>Select the data source context. Triggering the job will pass the sampled data (if available from Data Nexus) to the Databricks notebook for rule suggestion.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="dataSourceSelect">Data Source Context</Label>
            <Select onValueChange={
                (value) => {
                    setSelectedDataSourceId(value);
                    if (value && !value.startsWith('dn-job-')) {
                        setNexusContextDataSource(null);
                        setNexusJobResultContext(null);
                        if (searchParams.get('nexus_job_id')) {
                           router.replace(window.location.pathname, { scroll: false });
                        }
                    } else if (value && value.startsWith('dn-job-')) {
                        const nexusJobIdFromSelected = value.substring('dn-job-'.length);
                        const jobResultKey = DATA_NEXUS_JOB_RESULT_PREFIX + nexusJobIdFromSelected;
                        const jobResultJson = window.localStorage.getItem(jobResultKey);
                        if (jobResultJson) {
                            try {
                                const jobResult: NexusJobResult = JSON.parse(jobResultJson);
                                setNexusJobResultContext(jobResult);
                                const tempNexusDS: DataSourceFromLocalStorage = {
                                    id: value,
                                    name: jobResult.dataSourceName || `Data Nexus Analysis: ${nexusJobIdFromSelected}`,
                                    type: jobResult.type || 'data-nexus-csv',
                                    details: `Context from Data Nexus Job ID: ${nexusJobIdFromSelected}`
                                };
                                setNexusContextDataSource(tempNexusDS);
                            } catch (e) { 
                                console.error("Error parsing Nexus Job Result for selected dropdown item", e);
                                setNexusContextDataSource(null);
                                setNexusJobResultContext(null);
                            }
                        } else {
                            setNexusContextDataSource(null);
                            setNexusJobResultContext(null);
                        }
                    }
                }
            } value={selectedDataSourceId}>
              <SelectTrigger id="dataSourceSelect"><SelectValue placeholder="Select data source" /></SelectTrigger>
              <SelectContent>
                {displayedDropdownSources.length > 0 ? displayedDropdownSources.map(ds => (
                  <SelectItem key={ds.id} value={ds.id}>{ds.name}</SelectItem>
                )) : <SelectItem value="no-ds" disabled>No data sources available</SelectItem>}
              </SelectContent>
            </Select>
            {nexusJobResultContext && selectedDataSourceId && nexusContextDataSource?.id === selectedDataSourceId && (
                <p className="text-xs text-accent mt-1 flex items-center">
                    <DatabaseZap className="w-3 h-3 mr-1" />
                    Context active: {nexusContextDataSource.name}. AI will use this real sample.
                </p>
            )}
             {activeHistoryEntryTimestamp && selectedDataSourceId && (
                <p className="text-xs text-amber-500 mt-1 flex items-center">
                    <History className="w-3 h-3 mr-1" />
                    Editing historical configuration from: <FormattedDateTime date={new Date(activeHistoryEntryTimestamp)} formatter={(d) => d.toLocaleString()} />. Saving will make this the new active config.
                </p>
            )}
          </div>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {DIMENSIONS_CONFIG.map(dim => (
               <DimensionInfo
                key={dim.name}
                title={dim.name}
                weight={dimensionWeights[dim.name]}
                onWeightChange={(val) => handleDimensionWeightChange(dim.name, val)}
                examples={
                    dim.name === "Completeness" ? ["Non-null values", "Presence of required fields", "Record count expectations"] :
                    dim.name === "Accuracy" ? ["Format validation (email, date)", "Range checks (age, amount)", "Reference integrity"] :
                    dim.name === "Consistency" ? ["Cross-field validation", "Uniformity of units/formats", "No contradictory info"] :
                    ["Duplicate values in ID columns", "Primary key uniqueness", "Unique email/usernames"]
                }
                />
            ))}
          </div>

          <Button onClick={handleTriggerDatabricksJob} disabled={!selectedDataSourceId || databricksJobState.status === 'TRIGGERING' || databricksJobState.status === 'POLLING' || !nexusJobResultContext?.dataSample}>
            {databricksJobState.status === 'TRIGGERING' || databricksJobState.status === 'POLLING' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
            {databricksJobState.status === 'TRIGGERING' ? 'Triggering Job...' : databricksJobState.status === 'POLLING' ? `Polling (Run ID: ${databricksJobState.runId?.substring(0,8)}...)` : suggestButtonText}
          </Button>
          {databricksJobState.status !== 'IDLE' && (
            <div className={`flex items-center p-3 rounded-md text-sm ${databricksJobState.status === 'FAILED' ? 'bg-destructive/20 text-destructive-foreground' : 'bg-secondary/70'}`}>
              {getJobStatusIcon()}
              <span className="ml-2">{databricksJobState.message}</span>
            </div>
          )}
        </CardContent>
      </Card>

      {editingRule && (
         <Card className="shadow-lg">
            <CardHeader>
                <CardTitle>{editingRule.id ? 'Edit Rule' : 'Add New Rule'}</CardTitle>
                 <CardDescription>
                   For Data Source: {selectedDataSourceId ? displayedDropdownSources.find(ds => ds.id === selectedDataSourceId)?.name : 'N/A'}
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                 <div>
                    <Label htmlFor="ruleDimension">Dimension <span className="text-destructive">*</span></Label>
                    <Select
                        name="dimension"
                        value={editingRule.dimension || ''}
                        onValueChange={(value) => handleRuleFormSelectChange('dimension', value as DimensionName | "Other")}
                        required
                    >
                        <SelectTrigger id="ruleDimension"><SelectValue placeholder="Select primary dimension" /></SelectTrigger>
                        <SelectContent>
                            {DIMENSIONS_CONFIG.map(dim => (
                                <SelectItem key={dim.name} value={dim.name}>{dim.label}</SelectItem>
                            ))}
                            <SelectItem value="Other">Other / Uncategorized</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <Label htmlFor="ruleDescription">Description <span className="text-destructive">*</span></Label>
                    <Input id="ruleDescription" name="description" value={editingRule.description} onChange={handleRuleFormChange} placeholder="e.g., Email must be valid" required/>
                </div>
                <div>
                    <Label htmlFor="ruleColumn">Column(s) <span className="text-destructive">*</span></Label>
                    <Input id="ruleColumn" name="column" value={editingRule.column} onChange={handleRuleFormChange} placeholder="e.g., email_address or comma-separated: email,phone" required/>
                </div>
                <div>
                    <Label htmlFor="ruleType">Rule Type (Optional, e.g., from Databricks)</Label>
                    <Input id="ruleType" name="type" value={editingRule.type || ''} onChange={handleRuleFormChange} placeholder="e.g., IS_NOT_NULL, SQL_EXPRESSION"/>
                </div>
                <div>
                    <Label htmlFor="ruleCondition">Condition (Optional, e.g., from Databricks)</Label>
                    <Input id="ruleCondition" name="condition" value={editingRule.condition || ''} onChange={handleRuleFormChange} placeholder="e.g., isNotNull, isValidEmail"/>
                </div>
                <div>
                    <Label htmlFor="ruleWeight">Rule Importance Weight ({editingRule.weight || 0}%)</Label>
                    <Slider id="ruleWeight" value={[editingRule.weight || 0]} onValueChange={handleRuleFormWeightChange} max={100} step={1} className="mt-2" />
                </div>
                 <div>
                    <Label htmlFor="ruleRationale">Rationale (Optional)</Label>
                    <Textarea id="ruleRationale" name="rationale" value={editingRule.rationale || ''} onChange={handleRuleFormChange} placeholder="Why this rule is generally important." rows={2}/>
                </div>
                 <div>
                    <Label htmlFor="ruleReasonForColumnChoice">Reason for Column Choice (AI Suggested - Optional)</Label>
                    <Textarea id="ruleReasonForColumnChoice" name="reasonForColumnChoice" value={editingRule.reasonForColumnChoice || ''} onChange={handleRuleFormChange} placeholder="Why AI chose this column for this rule." rows={2}/>
                </div>
                 <div>
                    <Label htmlFor="ruleImpactOnDimension">Impact on Dimension (AI Suggested - Optional)</Label>
                    <Textarea id="ruleImpactOnDimension" name="impactOnDimension" value={editingRule.impactOnDimension || ''} onChange={handleRuleFormChange} placeholder="How this rule improves the dimension." rows={2}/>
                </div>

            </CardContent>
            <CardFooter className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setEditingRule(null)}>Cancel</Button>
                <Button onClick={() => handleSaveRule(editingRule)}><Save className="mr-2 h-4 w-4" /> Save Rule Edits (Staged)</Button>
            </CardFooter>
        </Card>
      )}

      {selectedDataSourceId && (
        <Card className="shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
                <CardTitle className="flex items-center"><ListChecks className="mr-2 h-5 w-5" />Review &amp; Edit Rules/Weights</CardTitle>
                <CardDescription>
                Rules for {displayedDropdownSources.find(ds => ds.id === selectedDataSourceId)?.name || 'selected source'}. Adjust dimension weights and individual rules as needed.
                {activeHistoryEntryTimestamp && " (Editing historical config)"}
                </CardDescription>
            </div>
            <Button onClick={handleAddRule} variant="default" disabled={!selectedDataSourceId}>
                <PlusCircle className="mr-2 h-4 w-4" /> Add Rule Manually
            </Button>
          </CardHeader>
          <CardContent className="space-y-6">
             <Accordion type="multiple" className="w-full" defaultValue={DIMENSIONS_CONFIG.map(d => d.name).concat("Other")}>
              {[...DIMENSIONS_CONFIG.map(dc => dc.name), "Other"].map(dimensionNameKey => {
                const dimensionName = dimensionNameKey as DimensionName | "Other";
                const dimensionRules = rules.filter(rule => (rule.dimension || "Other") === dimensionName);

                if (dimensionRules.length === 0 && dimensionName !== "Other") return null;
                if (dimensionRules.length === 0 && dimensionName === "Other" && !rules.some(r => !r.dimension || r.dimension === "Other")) return null;

                const dimensionLabel = dimensionName === "Other" ? "Other / Uncategorized" : DIMENSIONS_CONFIG.find(dc => dc.name === dimensionName)?.label;
                const dimensionWeightDisplay = dimensionName === "Other" ? "" : `(weight ${dimensionWeightsMap[dimensionName as DimensionName] || 0}%)`;


                return (
                  <AccordionItem value={dimensionName} key={dimensionName}>
                    <AccordionTrigger className="text-lg hover:no-underline">
                      <span className="font-semibold">
                        – {dimensionLabel} {dimensionWeightDisplay}: {dimensionRules.length} rule(s)
                      </span>
                    </AccordionTrigger>
                    <AccordionContent className="pl-6 pr-2 pt-2 pb-2">
                        <ul className="space-y-3">
                          {dimensionRules.map((rule) => (
                            <li key={rule.id} className="p-3 border rounded-md shadow-sm bg-card/50 hover:shadow-md transition-shadow">
                              <div className="flex justify-between items-start gap-2">
                                <div className="flex-grow space-y-1">
                                  <div className="flex items-start">
                                    <span className="mr-2 text-lg leading-tight text-primary">•</span>
                                    <p className="font-medium text-base text-foreground flex-1">{rule.description}</p>
                                  </div>
                                  <div className="pl-5 space-y-0.5">
                                    <p className="text-xs text-muted-foreground">
                                      <span className="font-medium">Column(s):</span> {rule.column}
                                    </p>
                                    {rule.type && (
                                      <p className="text-xs text-muted-foreground">
                                        <span className="font-medium">Type:</span> {rule.type}
                                      </p>
                                    )}
                                    {rule.condition && (
                                      <p className="text-xs text-muted-foreground">
                                        <span className="font-medium">Condition:</span> {rule.condition}
                                      </p>
                                    )}
                                    {rule.weight !== undefined && (
                                      <p className="text-xs text-muted-foreground">
                                        <span className="font-medium">Rule Weight:</span> {rule.weight}%
                                      </p>
                                    )}
                                    {rule.rationale && (
                                      <p className="text-xs text-muted-foreground italic"><Sparkles className="inline h-3 w-3 mr-1 text-accent"/>
                                        <span className="font-medium">Rationale:</span> {rule.rationale}
                                      </p>
                                    )}
                                     {rule.reasonForColumnChoice && (
                                      <p className="text-xs text-muted-foreground italic"><Brain className="inline h-3 w-3 mr-1 text-accent"/>
                                        <span className="font-medium">AI Column Choice Reasoning:</span> {rule.reasonForColumnChoice}
                                      </p>
                                    )}
                                    {rule.impactOnDimension && (
                                      <p className="text-xs text-muted-foreground italic"><Sparkles className="inline h-3 w-3 mr-1 text-accent"/>
                                        <span className="font-medium">AI Impact on Dimension:</span> {rule.impactOnDimension}
                                      </p>
                                    )}
                                  </div>
                                </div>
                                <div className="flex space-x-1 shrink-0 mt-1">
                                  <Button variant="ghost" size="icon" onClick={() => handleEditRule(rule)} aria-label="Edit rule">
                                    <Edit3 className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="icon" onClick={() => handleDeleteRule(rule.id)} className="text-destructive hover:text-destructive" aria-label="Delete rule">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            </li>
                          ))}
                         {dimensionRules.length === 0 && dimensionName === "Other" && (
                            <p className="text-sm text-muted-foreground pl-1">No rules categorized as 'Other'.</p>
                        )}
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={handleSaveConfiguration} size="lg" disabled={!selectedDataSourceId}><Save className="mr-2 h-4 w-4" /> Save Configuration &amp; Proceed to Assessment</Button>
          </CardFooter>
        </Card>
      )}
      
      {selectedDataSourceId && currentDSHistory.length > 0 && (
        <Card className="shadow-lg">
            <CardHeader>
                <CardTitle className="flex items-center"><History className="mr-2 h-5 w-5 text-primary" />Configuration History for {displayedDropdownSources.find(ds => ds.id === selectedDataSourceId)?.name}</CardTitle>
                <CardDescription>Load previously saved configurations for editing. Max {MAX_HISTORY_ENTRIES_PER_SOURCE} entries are kept.</CardDescription>
            </CardHeader>
            <CardContent>
                <ul className="space-y-2">
                    {currentDSHistory.map((histEntry, index) => (
                        <li key={index} className="p-3 border rounded-md flex justify-between items-center bg-card/60">
                            <div>
                                <p className="text-sm font-medium text-foreground">
                                    Saved at: <FormattedDateTime date={new Date(histEntry.timestamp || Date.now())} formatter={(d) => d.toLocaleString()} />
                                </p>
                                <p className="text-xs text-muted-foreground">
                                    {histEntry.rules.length} rules. Weights: Acc({histEntry.dimensionWeights.Accuracy}%) Comp({histEntry.dimensionWeights.Completeness}%) Cons({histEntry.dimensionWeights.Consistency}%) Uniq({histEntry.dimensionWeights.Uniqueness}%)
                                </p>
                            </div>
                            <Button variant="outline" size="sm" onClick={() => handleLoadHistoricalConfig(histEntry)}>
                                <History className="mr-2 h-4 w-4" /> Load for Editing
                            </Button>
                        </li>
                    ))}
                </ul>
            </CardContent>
        </Card>
      )}


      {!selectedDataSourceId && databricksJobState.status === 'IDLE' && (
        <Card>
          <CardHeader><CardTitle>No Data Source Selected</CardTitle></CardHeader>
          <CardContent><p className="text-muted-foreground">Please select a data source to generate or manage rules with Databricks.</p></CardContent>
        </Card>
      )}
      {selectedDataSourceId && rules.length === 0 && databricksJobState.status === 'IDLE' && !activeHistoryEntryTimestamp && (
         <Card>
          <CardHeader><CardTitle>No Rules Loaded or Defined</CardTitle></CardHeader>
          <CardContent><p className="text-muted-foreground">No rules currently loaded for {displayedDropdownSources.find(ds => ds.id === selectedDataSourceId)?.name || 'this data source'}. Trigger the Databricks job to generate/load rules (requires Data Nexus sample), add them manually, or load from history.</p></CardContent>
        </Card>
      )}
       {selectedDataSourceId && rules.length === 0 && databricksJobState.status === 'SUCCEEDED' && !activeHistoryEntryTimestamp && (
         <Card>
          <CardHeader><CardTitle>No Rules Returned by Databricks</CardTitle></CardHeader>
          <CardContent><p className="text-muted-foreground">The Databricks job completed successfully but returned no rules. This could be due to the data sample or the notebook's LLM logic. You can add rules manually.</p></CardContent>
        </Card>
      )}
    </div>
  );
}
