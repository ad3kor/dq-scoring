
"use client";

import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PlusCircle, Trash2, HardDrive, Cloud, DatabaseZap, FileText, FileSpreadsheet, FileCode, Network, GitBranch, Database, Waypoints, FileUp } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { getCurrentMockUser, getUserSpecificKey, BASE_DS_KEY, addAuditLog } from '@/lib/authUtils';

type DataSourceType =
  | 'delta-lake'
  | 'csv-json-cloud'
  | 'relational-database'
  | 'csv-file'
  | 'excel-file'
  | 'parquet-file'
  | 'json-file'
  | 'web-api'
  | 'databricks'
  | 'fivetran'
  | 'cassandra'
  | 'mongodb'
  | 'kafka'
  | 'local-file-upload'
  | 'data-nexus-csv'
  | '';

interface DataSource {
  id: string;
  name: string;
  type: DataSourceType;
  details: string;
}

export default function DataSourcesPage() {
  const { toast } = useToast();
  const [dataSources, setDataSources] = useState<DataSource[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  // Form state
  const [sourceName, setSourceName] = useState('');
  const [sourceType, setSourceType] = useState<DataSourceType>('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [deltaTablePath, setDeltaTablePath] = useState('');
  const [cloudStorageUrl, setCloudStorageUrl] = useState('');
  const [dbConnectionString, setDbConnectionString] = useState('');
  const [filePath, setFilePath] = useState('');
  const [webApiUrl, setWebApiUrl] = useState('');
  const [databricksWorkspaceUrl, setDatabricksWorkspaceUrl] = useState('');
  const [databricksToken, setDatabricksToken] = useState('');
  const [fivetranConnectorId, setFivetranConnectorId] = useState('');
  const [cassandraContactPoints, setCassandraContactPoints] = useState('');
  const [cassandraKeyspace, setCassandraKeyspace] = useState('');
  const [mongodbConnectionString, setMongodbConnectionString] = useState('');
  const [kafkaBootstrapServers, setKafkaBootstrapServers] = useState('');
  const [kafkaTopic, setKafkaTopic] = useState('');

  useEffect(() => {
    const user = getCurrentMockUser();
    setCurrentUser(user);
    if (user) {
      try {
        const storageKey = getUserSpecificKey(BASE_DS_KEY, user);
        const item = window.localStorage.getItem(storageKey);
        setDataSources(item ? JSON.parse(item) : []);
      } catch (error) {
        console.error("Error reading data sources from localStorage", error);
        setDataSources([]);
      }
    } else {
      setDataSources([]); // No user, no data sources to show
    }
  }, []); 

  // Save data sources to localStorage when they change
  useEffect(() => {
    if (currentUser && dataSources.length >= 0) { 
      try {
        const storageKey = getUserSpecificKey(BASE_DS_KEY, currentUser);
        window.localStorage.setItem(storageKey, JSON.stringify(dataSources));
      } catch (error) {
        console.error("Error saving data sources to localStorage", error);
      }
    }
  }, [dataSources, currentUser]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
        toast({ title: "Error", description: "No active user session.", variant: "destructive" });
        return;
    }
    if (!sourceName || !sourceType) {
      toast({ title: "Error", description: "Name and Type are required.", variant: "destructive" });
      return;
    }
    let details = '';
    switch (sourceType) {
      case 'delta-lake': details = deltaTablePath; break;
      case 'csv-json-cloud': details = cloudStorageUrl; break;
      case 'relational-database': details = dbConnectionString; break;
      case 'csv-file': details = `Local Path: ${filePath}`; break;
      case 'excel-file': details = `Local Path: ${filePath}`; break;
      case 'parquet-file': details = `Local Path: ${filePath}`; break;
      case 'json-file': details = `Local Path: ${filePath}`; break;
      case 'web-api': details = `API URL: ${webApiUrl}`; break;
      case 'databricks': details = `Workspace: ${databricksWorkspaceUrl}`; break;
      case 'fivetran': details = `Connector ID: ${fivetranConnectorId}`; break;
      case 'cassandra': details = `Contact Points: ${cassandraContactPoints}, Keyspace: ${cassandraKeyspace}`; break;
      case 'mongodb': details = mongodbConnectionString; break;
      case 'kafka': details = `Bootstrap Servers: ${kafkaBootstrapServers}, Topic: ${kafkaTopic}`; break;
      case 'local-file-upload':
        if (!selectedFile) {
          toast({ title: "Error", description: "Please select a file to upload.", variant: "destructive" });
          return;
        }
        details = `Uploaded File: ${selectedFile.name}`;
        break;
    }

    if (!details && sourceType !== '' && sourceType !== 'local-file-upload') {
        toast({ title: "Error", description: "Connection details are required for the selected type.", variant: "destructive" });
        return;
    }

    const newSourceId = String(Date.now());
    const newSource: DataSource = {
      id: newSourceId,
      name: sourceName,
      type: sourceType as DataSourceType,
      details,
    };
    setDataSources(prevSources => [...prevSources, newSource]);
    
    addAuditLog(
      'ADD_DATASOURCE', 
      `Added data source '${sourceName}' of type '${sourceType}'. Details: ${details.substring(0, 100)}${details.length > 100 ? '...' : ''}`,
      'DataSource',
      newSourceId
    );

    toast({ title: "Success", description: `Data source "${sourceName}" added.` });

    // Reset form
    setSourceName('');
    setSourceType('');
    setSelectedFile(null);
    setDeltaTablePath('');
    setCloudStorageUrl('');
    setDbConnectionString('');
    setFilePath('');
    setWebApiUrl('');
    setDatabricksWorkspaceUrl('');
    setDatabricksToken('');
    setFivetranConnectorId('');
    setCassandraContactPoints('');
    setCassandraKeyspace('');
    setMongodbConnectionString('');
    setKafkaBootstrapServers('');
    setKafkaTopic('');
    setShowForm(false);
  };

  const handleDelete = (id: string) => {
    if (!currentUser) return;
    const sourceToDelete = dataSources.find(ds => ds.id === id);
    if (sourceToDelete) {
        addAuditLog(
            'DELETE_DATASOURCE',
            `Deleted data source '${sourceToDelete.name}' (ID: ${id}).`,
            'DataSource',
            id
        );
    }
    setDataSources(dataSources.filter(ds => ds.id !== id));
    toast({ title: "Success", description: "Data source removed." });
  };

  const getIconForType = (type: DataSource['type']) => {
    switch (type) {
      case 'delta-lake': return <DatabaseZap className="h-5 w-5 text-primary" />;
      case 'csv-json-cloud': return <Cloud className="h-5 w-5 text-primary" />;
      case 'relational-database': return <HardDrive className="h-5 w-5 text-primary" />;
      case 'csv-file': return <FileText className="h-5 w-5 text-primary" />;
      case 'excel-file': return <FileSpreadsheet className="h-5 w-5 text-primary" />;
      case 'parquet-file': return <FileCode className="h-5 w-5 text-primary" />;
      case 'json-file': return <FileCode className="h-5 w-5 text-primary" />;
      case 'web-api': return <Network className="h-5 w-5 text-primary" />;
      case 'databricks': return <DatabaseZap className="h-5 w-5 text-primary" />;
      case 'fivetran': return <GitBranch className="h-5 w-5 text-primary" />;
      case 'cassandra': return <Database className="h-5 w-5 text-primary" />;
      case 'mongodb': return <Database className="h-5 w-5 text-primary" />;
      case 'kafka': return <Waypoints className="h-5 w-5 text-primary" />;
      case 'local-file-upload': return <FileUp className="h-5 w-5 text-primary" />;
      case 'data-nexus-csv': return <Cloud className="h-5 w-5 text-primary" />;
      default: return <DatabaseZap className="h-5 w-5 text-muted-foreground" />;
    }
  };

  if (!currentUser) {
    return <div className="container mx-auto py-8 text-center">Please log in to manage data sources.</div>;
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Data Sources</h1>
            <p className="text-muted-foreground">Manage your connections to various data systems or upload local files for user: {currentUser}.</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} variant="default">
          <PlusCircle className="mr-2 h-4 w-4" /> {showForm ? 'Cancel' : 'Add New Source'}
        </Button>
      </div>

      {showForm && (
        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle>Add New Data Source</CardTitle>
            <CardDescription>Configure a new data source for quality checks.</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="sourceName">Source Name</Label>
                <Input id="sourceName" placeholder="e.g., Customer Transactions" value={sourceName} onChange={(e) => setSourceName(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sourceType">Source Type</Label>
                <Select onValueChange={(value) => setSourceType(value as DataSourceType)} value={sourceType} required>
                  <SelectTrigger id="sourceType">
                    <SelectValue placeholder="Select source type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="local-file-upload">Local File Upload (CSV, Excel, Parquet, JSON)</SelectItem>
                    <SelectItem value="delta-lake">Delta Lake Table (Unity Catalog)</SelectItem>
                    <SelectItem value="csv-json-cloud">CSV/JSON (Cloud Storage S3/GCS)</SelectItem>
                    <SelectItem value="relational-database">Relational Database (JDBC/ODBC)</SelectItem>
                    <SelectItem value="csv-file">CSV File (Server Path)</SelectItem>
                    <SelectItem value="excel-file">Excel File (Server Path)</SelectItem>
                    <SelectItem value="parquet-file">Parquet File (Server Path)</SelectItem>
                    <SelectItem value="json-file">JSON File (Server Path)</SelectItem>
                    <SelectItem value="web-api">Web API / HTTP Endpoint</SelectItem>
                    <SelectItem value="databricks">Databricks Connector</SelectItem>
                    <SelectItem value="fivetran">Fivetran Connector</SelectItem>
                    <SelectItem value="cassandra">Cassandra Connector</SelectItem>
                    <SelectItem value="mongodb">MongoDB Connector</SelectItem>
                    <SelectItem value="kafka">Kafka Connector</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {sourceType === 'local-file-upload' && (
                <div className="space-y-2">
                  <Label htmlFor="localFileUpload">Upload File</Label>
                  <Input
                    id="localFileUpload"
                    type="file"
                    accept=".csv,.xlsx,.xls,.parquet,.json"
                    onChange={(e) => setSelectedFile(e.target.files ? e.target.files[0] : null)}
                    required={sourceType === 'local-file-upload'}
                  />
                  {selectedFile && <p className="text-sm text-muted-foreground">Selected: {selectedFile.name}</p>}
                </div>
              )}

              {sourceType === 'delta-lake' && (
                <div className="space-y-2">
                  <Label htmlFor="deltaTablePath">Delta Table Path (Unity Catalog)</Label>
                  <Input id="deltaTablePath" placeholder="e.g., catalog_name.schema_name.table_name" value={deltaTablePath} onChange={(e) => setDeltaTablePath(e.target.value)} required={sourceType === 'delta-lake'}/>
                </div>
              )}
              {sourceType === 'csv-json-cloud' && (
                <div className="space-y-2">
                  <Label htmlFor="cloudStorageUrl">Cloud Storage URL (S3/GCS for CSV/JSON)</Label>
                  <Input id="cloudStorageUrl" placeholder="e.g., s3://my-bucket/data.csv or gs://my-bucket/data.json" value={cloudStorageUrl} onChange={(e) => setCloudStorageUrl(e.target.value)} required={sourceType === 'csv-json-cloud'}/>
                </div>
              )}
              {sourceType === 'relational-database' && (
                <div className="space-y-2">
                  <Label htmlFor="dbConnectionString">Database Connection String / Details</Label>
                  <Input id="dbConnectionString" placeholder="e.g., jdbc:postgresql://host:port/database" value={dbConnectionString} onChange={(e) => setDbConnectionString(e.target.value)} required={sourceType === 'relational-database'}/>
                </div>
              )}
              {(sourceType === 'csv-file' || sourceType === 'excel-file' || sourceType === 'parquet-file' || sourceType === 'json-file') && (
                <div className="space-y-2">
                  <Label htmlFor="filePath">File Path (Server Accessible)</Label>
                  <Input id="filePath" placeholder="e.g., /mnt/data/my_file.csv" value={filePath} onChange={(e) => setFilePath(e.target.value)} required={['csv-file', 'excel-file', 'parquet-file', 'json-file'].includes(sourceType)}/>
                </div>
              )}
              {sourceType === 'web-api' && (
                <div className="space-y-2">
                  <Label htmlFor="webApiUrl">API Endpoint URL</Label>
                  <Input id="webApiUrl" placeholder="e.g., https://api.example.com/data" value={webApiUrl} onChange={(e) => setWebApiUrl(e.target.value)} required={sourceType === 'web-api'}/>
                </div>
              )}
              {sourceType === 'databricks' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="databricksWorkspaceUrl">Databricks Workspace URL</Label>
                    <Input id="databricksWorkspaceUrl" placeholder="e.g., adb-xxxx.azuredatabricks.net" value={databricksWorkspaceUrl} onChange={(e) => setDatabricksWorkspaceUrl(e.target.value)} required={sourceType === 'databricks'}/>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="databricksToken">Databricks Access Token</Label>
                    <Input id="databricksToken" type="password" placeholder="dapi..." value={databricksToken} onChange={(e) => setDatabricksToken(e.target.value)} required={sourceType === 'databricks'}/>
                  </div>
                </>
              )}
              {sourceType === 'fivetran' && (
                <div className="space-y-2">
                  <Label htmlFor="fivetranConnectorId">Fivetran Connector ID</Label>
                  <Input id="fivetranConnectorId" placeholder="e.g., flimsy_quicksand" value={fivetranConnectorId} onChange={(e) => setFivetranConnectorId(e.target.value)} required={sourceType === 'fivetran'}/>
                </div>
              )}
              {sourceType === 'cassandra' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="cassandraContactPoints">Contact Points (comma-separated)</Label>
                    <Input id="cassandraContactPoints" placeholder="e.g., node1.example.com,node2.example.com" value={cassandraContactPoints} onChange={(e) => setCassandraContactPoints(e.target.value)} required={sourceType === 'cassandra'}/>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cassandraKeyspace">Keyspace</Label>
                    <Input id="cassandraKeyspace" placeholder="e.g., my_keyspace" value={cassandraKeyspace} onChange={(e) => setCassandraKeyspace(e.target.value)} required={sourceType === 'cassandra'}/>
                  </div>
                </>
              )}
              {sourceType === 'mongodb' && (
                <div className="space-y-2">
                  <Label htmlFor="mongodbConnectionString">MongoDB Connection String</Label>
                  <Input id="mongodbConnectionString" placeholder="e.g., mongodb+srv://user:pass@cluster.mongodb.net/mydb" value={mongodbConnectionString} onChange={(e) => setMongodbConnectionString(e.target.value)} required={sourceType === 'mongodb'}/>
                </div>
              )}
              {sourceType === 'kafka' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="kafkaBootstrapServers">Bootstrap Servers (comma-separated)</Label>
                    <Input id="kafkaBootstrapServers" placeholder="e.g., broker1:9092,broker2:9092" value={kafkaBootstrapServers} onChange={(e) => setKafkaBootstrapServers(e.target.value)} required={sourceType === 'kafka'}/>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="kafkaTopic">Topic Name</Label>
                    <Input id="kafkaTopic" placeholder="e.g., my_data_topic" value={kafkaTopic} onChange={(e) => setKafkaTopic(e.target.value)} required={sourceType === 'kafka'}/>
                  </div>
                </>
              )}

            </CardContent>
            <CardFooter>
              <Button type="submit">Save Data Source</Button>
            </CardFooter>
          </form>
        </Card>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {dataSources.map((source) => (
          <Card key={source.id} className="flex flex-col justify-between shadow-md hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{source.name}</CardTitle>
                {getIconForType(source.type)}
              </div>
              <CardDescription className="capitalize">
                {source.type?.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) || 'Unknown Type'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground break-all">
                <span className="font-medium text-foreground">Details: </span>{source.details}
              </p>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button variant="ghost" size="sm" onClick={() => handleDelete(source.id)}>
                <Trash2 className="mr-2 h-4 w-4" /> Delete
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      {dataSources.length === 0 && !showForm && (
        <div className="text-center py-10">
          <HardDrive className="mx-auto h-12 w-12 text-muted-foreground" />
          <h3 className="mt-2 text-sm font-medium text-foreground">No data sources for {currentUser}</h3>
          <p className="mt-1 text-sm text-muted-foreground">Get started by adding a new data source.</p>
        </div>
      )}
    </div>
  );
}

    