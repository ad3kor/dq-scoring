
"use client";

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FolderOpen, FileText, RefreshCcw, CheckCircle2, Loader2, AlertTriangle, Briefcase, Filter, DatabaseZap, Brain, History as HistoryIcon } from 'lucide-react';
import { Progress } from "@/components/ui/progress";
import { useToast } from '@/hooks/use-toast';
import { getCurrentMockUser, getUserSpecificKey, addAuditLog, BASE_DATANEXUS_ANALYSIS_HISTORY_KEY } from '@/lib/authUtils';
import { useRouter } from 'next/navigation';
import { FormattedDateTime } from '@/components/FormattedDateTime';

const AZURE_STORAGE_ACCOUNT_NAME = "fofstrprdeusdata";
const AZURE_CONTAINER_NAME = "genai";
const DATA_NEXUS_JOB_RESULT_PREFIX = 'dataNexusJobResult_';
const MAX_ANALYSIS_HISTORY_ITEMS = 10;


interface ListedFile {
  name: string;
  path: string;
  size: number;
  modificationTime: string;
  type?: 'csv' | 'parquet' | 'xlsx' | 'xls' | 'other';
}

interface FileListerJobState {
  status: 'IDLE' | 'TRIGGERING' | 'POLLING' | 'SUCCEEDED' | 'FAILED';
  message: string;
  runId?: string;
  files: ListedFile[];
  progress?: number;
}

interface FileProcessingJobState {
  status: 'IDLE' | 'SUBMITTING' | 'POLLING' | 'SUCCEEDED' | 'FAILED';
  message: string;
  runId?: string;
  progress?: number;
}

interface DataNexusAnalysisHistoryItem {
  id: string; // This ID must be unique, usually the processing job ID
  dataSourceName: string;
  timestamp: string; // ISO string
  sourceFilePathsJson: string; // JSON string array of original file paths
  status: 'SUCCEEDED';
  firstFileName?: string; // Name of the first file if multiple, or the only file
  fileCount?: number; // Number of files merged
}


const timeFilterOptions = [
  { label: "All files", value: "all_files" },
  { label: "Last 24 hours", value: "1" },
  { label: "Last 7 days", value: "7" },
  { label: "Last 30 days", value: "30" },
  { label: "Last 3 months", value: "90" },
  { label: "Last 6 months", value: "180" },
  { label: "Last 1 year", value: "365" },
  { label: "Last 5 years", value: "1825" },
];

export default function DataNexusStorageBrowserPage() {
  const { toast } = useToast();
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  const [selectedTimeFilter, setSelectedTimeFilter] = useState<string>("all_files");
  const [fileListerJob, setFileListerJob] = useState<FileListerJobState>({ status: 'IDLE', message: 'Select a time filter and fetch files.', files: [] });

  const [selectedFilePaths, setSelectedFilePaths] = useState<string[]>([]);
  const [fileProcessingJob, setFileProcessingJob] = useState<FileProcessingJobState>({ status: 'IDLE', message: '' });
  const [analysisHistory, setAnalysisHistory] = useState<DataNexusAnalysisHistoryItem[]>([]);


  const listerPollingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const processorPollingIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const user = getCurrentMockUser();
    setCurrentUser(user);
    if (user) {
        try {
            const historyStorageKey = getUserSpecificKey(BASE_DATANEXUS_ANALYSIS_HISTORY_KEY, user);
            const historyItem = window.localStorage.getItem(historyStorageKey);
            const loadedHistory: DataNexusAnalysisHistoryItem[] = historyItem ? JSON.parse(historyItem) : [];
            
            // De-duplicate on load to prevent key errors
            const uniqueHistoryMap = new Map<string, DataNexusAnalysisHistoryItem>();
            if (Array.isArray(loadedHistory)) {
                loadedHistory.forEach((item: DataNexusAnalysisHistoryItem) => {
                    // Basic validation of item structure before accessing item.id
                    if (item && typeof item.id === 'string') {
                        if (!uniqueHistoryMap.has(item.id)) { // Keep the first occurrence
                            uniqueHistoryMap.set(item.id, item);
                        }
                    } else {
                        console.warn("Found invalid item in analysis history, skipping:", item);
                    }
                });
            }
            setAnalysisHistory(Array.from(uniqueHistoryMap.values()));

        } catch (error) {
            console.error("Error reading or processing analysis history from localStorage", error);
            setAnalysisHistory([]); // Reset to empty on error
        }
    } else {
        setAnalysisHistory([]);
    }
  }, [currentUser]);


  useEffect(() => {
    if (currentUser && analysisHistory.length >= 0) {
        try {
            const historyStorageKey = getUserSpecificKey(BASE_DATANEXUS_ANALYSIS_HISTORY_KEY, currentUser);
            window.localStorage.setItem(historyStorageKey, JSON.stringify(analysisHistory));
        } catch (error) {
            console.error("Error saving analysis history to localStorage", error);
        }
    }
  }, [analysisHistory, currentUser]);


  useEffect(() => {
    return () => {
      if (listerPollingIntervalRef.current) clearInterval(listerPollingIntervalRef.current);
      if (processorPollingIntervalRef.current) clearInterval(processorPollingIntervalRef.current);
    };
  }, []);

  const determineFileType = (fileName: string): ListedFile['type'] => {
    const lowerName = fileName.toLowerCase();
    if (lowerName.endsWith('.csv')) return 'csv';
    if (lowerName.endsWith('.parquet')) return 'parquet';
    if (lowerName.endsWith('.xlsx')) return 'xlsx';
    if (lowerName.endsWith('.xls')) return 'xls';
    return 'other';
  };


  const pollFileListerJob = useCallback(async (internalRunId: string) => {
    try {
      const response = await fetch(`/api/databricks-file-lister?run_id=${internalRunId}`);
      const result = await response.json();

      if (!response.ok) {
        setFileListerJob(prev => ({ ...prev, status: 'FAILED', message: result.error || `Polling failed (HTTP ${response.status})` }));
        if (listerPollingIntervalRef.current) clearInterval(listerPollingIntervalRef.current);
        return;
      }

      setFileListerJob(prev => ({
        ...prev,
        message: result.message || `Job status: ${result.status || 'Polling...'}. Progress: ${prev.progress || 10}%`,
        progress: Math.min(95, (prev.progress || 0) + 15)
      }));

      if (result.status === 'SUCCEEDED') {
        if (listerPollingIntervalRef.current) clearInterval(listerPollingIntervalRef.current);
        const filesWithTypes = (result.files || []).map((file: Omit<ListedFile, 'type'>) => ({
            ...file,
            type: determineFileType(file.name)
        }));
        setFileListerJob({
          status: 'SUCCEEDED',
          message: result.message || `Successfully fetched ${result.files?.length || 0} files.`,
          files: filesWithTypes,
          runId: internalRunId,
          progress: 100,
        });
        toast({ title: "Files Loaded", description: result.message || "File list updated." });
      } else if (result.status === 'FAILED' || result.status === 'TIMED_OUT' || result.status === 'CANCELED') {
        if (listerPollingIntervalRef.current) clearInterval(listerPollingIntervalRef.current);
        setFileListerJob({ status: 'FAILED', message: result.error || `Job ${result.status || 'failed'}`, files: [], runId: internalRunId, progress: fileListerJob.progress });
        toast({ title: "File Listing Failed", description: result.error || `Job ${result.status}`, variant: "destructive" });
      }
    } catch (error: any) {
      if (listerPollingIntervalRef.current) clearInterval(listerPollingIntervalRef.current);
      setFileListerJob(prev => ({ ...prev, status: 'FAILED', message: `Polling error: ${error.message}` }));
      toast({ title: "Polling Error", description: error.message, variant: "destructive" });
    }
  }, [toast, fileListerJob.progress]);

  const handleFetchFiles = async () => {
    if (!currentUser) {
      toast({ title: "Error", description: "User session not found.", variant: "destructive" });
      return;
    }
    setFileListerJob({ status: 'TRIGGERING', message: 'Requesting file list from Databricks...', files: [], progress: 0 });
    setSelectedFilePaths([]);
    toast({ title: "Fetching Files", description: "Contacting Databricks job..." });

    try {
      const ageParam = selectedTimeFilter === "all_files" ? null : selectedTimeFilter;
      const response = await fetch('/api/databricks-file-lister', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ age_in_days: ageParam }),
      });
      const result = await response.json();

      if (!response.ok) throw new Error(result.error || `Failed to trigger file listing job (HTTP ${response.status})`);

      addAuditLog('DATABRICKS_FILE_LIST_JOB_TRIGGERED', `File listing job triggered. Filter: ${selectedTimeFilter === "all_files" ? 'All' : selectedTimeFilter}. Internal Run ID: ${result.runId}`, 'DatabricksJob', result.runId);
      setFileListerJob(prev => ({ ...prev, status: 'POLLING', message: `Job ${result.runId} submitted. Polling for status...`, runId: result.runId, progress: 10 }));
      if (listerPollingIntervalRef.current) clearInterval(listerPollingIntervalRef.current);
      listerPollingIntervalRef.current = setInterval(() => pollFileListerJob(result.runId), 5000);
    } catch (error: any) {
      setFileListerJob({ status: 'FAILED', message: `Triggering failed: ${error.message}`, files: [] });
      toast({ title: "Trigger Failed", description: error.message, variant: "destructive" });
    }
  };

 const pollFileProcessorJob = useCallback(async (internalProcessingJobId: string, firstSelectedFileName: string, allSelectedFilePathsJson: string) => {
    try {
      const response = await fetch(`/api/job-status/${internalProcessingJobId}`);
      if (!response.ok) throw new Error(`Failed to poll file processing job status (HTTP ${response.status}).`);

      const result = await response.json();
      setFileProcessingJob(prev => ({
          ...prev,
          message: `Processing ${firstSelectedFileName || JSON.parse(allSelectedFilePathsJson)[0] || 'selected files'}: ${result.status}${result.progress > 0 ? ` (${result.progress}%)` : ''}`,
          progress: result.progress || 0
      }));

      if (result.status === 'SUCCEEDED') {
        if (processorPollingIntervalRef.current) clearInterval(processorPollingIntervalRef.current);
        setFileProcessingJob({ status: 'SUCCEEDED', message: `Processing complete for selected file(s)! Preparing for rule suggestion.`, runId: internalProcessingJobId, progress: 100 });

        const jobResultKey = DATA_NEXUS_JOB_RESULT_PREFIX + internalProcessingJobId;
        const dsNameForResult = result.dataSourceName || `Data Nexus: Merged Sample`;
        const jobResultData = {
            dataSourceName: dsNameForResult,
            sourceFilePathsJson: result.sourceFilePathsJson,
            dataSample: result.dataSample,
            type: 'data-nexus-csv'
        };
        window.localStorage.setItem(jobResultKey, JSON.stringify(jobResultData));

        if(currentUser){
            const historyEntry: DataNexusAnalysisHistoryItem = {
              id: internalProcessingJobId, // This is the Databricks or UUID job ID
              dataSourceName: dsNameForResult,
              timestamp: new Date().toISOString(),
              sourceFilePathsJson: allSelectedFilePathsJson,
              status: 'SUCCEEDED',
              firstFileName: firstSelectedFileName || (JSON.parse(allSelectedFilePathsJson)[0] || '').split('/').pop(),
              fileCount: JSON.parse(allSelectedFilePathsJson).length
            };
            setAnalysisHistory(prevHistory => {
              // Ensure no duplicates by ID before adding
              const filteredHistory = prevHistory.filter(entry => entry.id !== internalProcessingJobId);
              const newHistory = [historyEntry, ...filteredHistory];
              return newHistory.slice(0, MAX_ANALYSIS_HISTORY_ITEMS); // Keep only the last N items
            });
        }
        router.push(`/databricks-suggester?nexus_job_id=${internalProcessingJobId}`);

      } else if (result.status === 'FAILED') {
        if (processorPollingIntervalRef.current) clearInterval(processorPollingIntervalRef.current);
        const currentFileReference = result.blobName || firstSelectedFileName || (JSON.parse(allSelectedFilePathsJson)[0] || 'selected files');
        setFileProcessingJob({ status: 'FAILED', message: `Processing Failed for ${currentFileReference}. ${result.error || ''}`, runId: internalProcessingJobId, progress: result.progress });
        toast({ title: "File Processing Failed", description: result.error || `Processing for ${currentFileReference} failed.`, variant: "destructive" });
        addAuditLog('NEXUS_SAMPLING_JOB_FAILED', `Data Nexus sampling job ${internalProcessingJobId} for selected file(s) failed. Reason: ${result.error || 'Unknown'}`, 'DataNexusJob', internalProcessingJobId);
      }
    } catch (error: any) {
      if (processorPollingIntervalRef.current) clearInterval(processorPollingIntervalRef.current);
      setFileProcessingJob(prev => ({ ...prev, status: 'FAILED', message: `Error checking processing job status: ${error.message}` }));
      toast({ title: "Processing Polling Error", description: error.message || "Could not get job status.", variant: "destructive" });
    }
  }, [toast, router, currentUser, setAnalysisHistory]);


  const handleAnalyzeFiles = async () => {
    if (!currentUser || selectedFilePaths.length === 0) {
      toast({ title: "Error", description: "User session or no files selected for analysis.", variant: "destructive" });
      return;
    }

    const firstSelectedFileObject = fileListerJob.files.find(f => f.path === selectedFilePaths[0]);
    const firstSelectedFileNameForDisplay = firstSelectedFileObject?.name || 'selected files';

    const dataSourceDisplayName = selectedFilePaths.length === 1
        ? `Data Nexus: ${firstSelectedFileNameForDisplay}`
        : `Data Nexus: Merged ${selectedFilePaths.length} files (first: ${firstSelectedFileNameForDisplay})`;

    const sourceFilePathsJsonString = JSON.stringify(selectedFilePaths);

    setFileProcessingJob({ status: 'SUBMITTING', message: `Submitting ${selectedFilePaths.length} file(s) for DQ analysis...`, progress: 0 });
    toast({ title: "Submitting for Analysis", description: "Requesting data sample and DQ processing..." });

    try {
      const response = await fetch('/api/data-nexus-proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          source_file_paths_json: sourceFilePathsJsonString,
          user: currentUser,
          dataSourceName: dataSourceDisplayName
        }),
      });
      const result = await response.json();

      if (!response.ok || !result.success || !result.jobId) {
        throw new Error(result.message || result.error || `Failed to submit file(s) for analysis (HTTP ${response.status})`);
      }

      addAuditLog('NEXUS_SAMPLING_JOB_TRIGGERED', `Data Nexus sampling job ${result.jobId} triggered for ${selectedFilePaths.length} file(s). First path: '${selectedFilePaths[0]}'.`, 'DataNexusJob', result.jobId);
      setFileProcessingJob(prev => ({ ...prev, status: 'POLLING', message: `Analysis job ${result.jobId} submitted. Polling...`, runId: result.jobId, progress: 10 }));
      if (processorPollingIntervalRef.current) clearInterval(processorPollingIntervalRef.current);
      processorPollingIntervalRef.current = setInterval(() => pollFileProcessorJob(result.jobId, firstSelectedFileNameForDisplay, sourceFilePathsJsonString), 3000);

    } catch (error: any) {
      setFileProcessingJob({ status: 'FAILED', message: `Analysis submission failed: ${error.message}` });
      toast({ title: "Analysis Submission Error", description: error.message, variant: "destructive" });
    }
  };

  const handleFileSelectionToggle = (filePath: string, checked: boolean) => {
    setSelectedFilePaths(prev => {
      if (checked) {
        return [...prev, filePath];
      } else {
        return prev.filter(path => path !== filePath);
      }
    });
  };

  const handleSendToSuggester = (jobId: string) => {
    router.push(`/databricks-suggester?nexus_job_id=${jobId}`);
  };


  if (!currentUser) {
    return <div className="container mx-auto py-8 text-center">Please log in to access Data Nexus Storage.</div>;
  }

  const isFetchingFiles = fileListerJob.status === 'TRIGGERING' || fileListerJob.status === 'POLLING';
  const isProcessingFile = fileProcessingJob.status === 'SUBMITTING' || fileProcessingJob.status === 'POLLING';

  const getSelectedFilesSummary = () => {
    if (selectedFilePaths.length === 0) return "No files selected.";
    if (selectedFilePaths.length === 1) {
        const file = fileListerJob.files.find(f => f.path === selectedFilePaths[0]);
        return `Selected File: ${file?.name || 'Unknown'}`;
    }
    return `${selectedFilePaths.length} files selected.`;
  };

  return (
    <div className="container mx-auto py-8 space-y-6 h-full flex flex-col">
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-foreground flex items-center">
            <Briefcase className="mr-3 h-6 w-6 text-primary" /> {AZURE_STORAGE_ACCOUNT_NAME} Storage Browser
          </CardTitle>
          <CardDescription>
            Browsing container: <span className="font-medium text-primary">{AZURE_CONTAINER_NAME}</span>.
            Select a time filter and fetch files. Then select one or more files (CSV/Parquet/XLSX/XLS with identical schemas) to analyze.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4 items-end">
                <div className="flex-grow">
                    <Label htmlFor="timeFilterSelect" className="flex items-center"><Filter className="h-4 w-4 mr-2 text-muted-foreground"/>Time Filter</Label>
                    <Select value={selectedTimeFilter} onValueChange={setSelectedTimeFilter} disabled={isFetchingFiles || isProcessingFile}>
                        <SelectTrigger id="timeFilterSelect">
                            <SelectValue placeholder="Select time range" />
                        </SelectTrigger>
                        <SelectContent>
                        {timeFilterOptions.map(option => (
                            <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                        ))}
                        </SelectContent>
                    </Select>
                </div>
                <Button onClick={handleFetchFiles} disabled={isFetchingFiles || isProcessingFile} className="w-full sm:w-auto">
                    {isFetchingFiles && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Fetch Files
                </Button>
            </div>
            {(fileListerJob.status !== 'IDLE') && (
                <div className={`p-3 rounded-md text-sm ${fileListerJob.status === 'FAILED' ? 'bg-destructive/20 text-destructive-foreground' : 'bg-secondary/70'}`}>
                    <div className="flex items-center mb-1">
                        {fileListerJob.status === 'TRIGGERING' || fileListerJob.status === 'POLLING' ? <Loader2 className="inline mr-2 h-4 w-4 animate-spin" /> : fileListerJob.status === 'SUCCEEDED' ? <CheckCircle2 className="inline mr-2 h-4 w-4 text-green-500" /> : fileListerJob.status === 'FAILED' ? <AlertTriangle className="inline mr-2 h-4 w-4" /> : null}
                        <span className="font-medium">{fileListerJob.message}</span>
                    </div>
                    {fileListerJob.runId && fileListerJob.status !== 'SUCCEEDED' && fileListerJob.status !== 'FAILED' && <p className="text-xs text-muted-foreground">File Lister Job ID: {fileListerJob.runId}</p>}
                    {(fileListerJob.status === 'POLLING' || fileListerJob.status === 'TRIGGERING') && typeof fileListerJob.progress === 'number' && fileListerJob.progress < 100 && (
                       <Progress value={fileListerJob.progress} className="w-full h-2 mt-2" />
                    )}
                </div>
            )}
        </CardContent>
      </Card>

      <Card className="flex-1 flex flex-col shadow-md min-h-0">
        <CardHeader>
            <CardTitle className="text-lg flex items-center">
                <FolderOpen className="mr-2 h-5 w-5 text-primary" /> Files in <span className="text-primary mx-1">{AZURE_CONTAINER_NAME}</span>
            </CardTitle>
            <CardDescription>
                Select one or more CSV, Parquet, XLSX, or XLS files (with identical schemas) to enable analysis.
            </CardDescription>
        </CardHeader>
        <CardContent className="flex-1 p-0 overflow-hidden">
          <ScrollArea className="h-full">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12 text-center">Select</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Last Modified</TableHead>
                  <TableHead>Size (Bytes)</TableHead>
                  <TableHead>Type</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fileListerJob.status === 'SUCCEEDED' && fileListerJob.files.length > 0 ? fileListerJob.files.map(file => {
                  const isCompatible = file.type && file.type !== 'other';
                  return (
                  <TableRow
                    key={file.path} // Using file.path as key, assuming paths are unique within a listing
                    className={`
                        ${isCompatible ? 'cursor-pointer hover:bg-muted/50' : 'opacity-50 cursor-not-allowed'}
                        ${selectedFilePaths.includes(file.path) && isCompatible ? 'bg-accent text-accent-foreground hover:bg-accent' : ''}
                        ${isProcessingFile ? 'cursor-wait' : ''}
                    `}
                  >
                    <TableCell className="text-center">
                      <Checkbox
                        checked={selectedFilePaths.includes(file.path)}
                        onCheckedChange={(checked) => handleFileSelectionToggle(file.path, !!checked)}
                        disabled={!isCompatible || isProcessingFile}
                        aria-label={`Select file ${file.name}`}
                      />
                    </TableCell>
                    <TableCell className="font-medium flex items-center">
                        <FileText className="h-4 w-4 mr-2 text-muted-foreground"/>{file.name}
                    </TableCell>
                    <TableCell><FormattedDateTime date={new Date(file.modificationTime)} formatter={(d) => d.toLocaleString()} placeholder="..." /></TableCell>
                    <TableCell>{file.size.toLocaleString()}</TableCell>
                    <TableCell>
                        <span className={`px-2 py-0.5 text-xs rounded-full ${
                            file.type === 'csv' ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300' :
                            file.type === 'parquet' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' :
                            file.type === 'xlsx' || file.type === 'xls' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300' :
                            'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
                        }`}>
                            {file.type?.toUpperCase()}
                        </span>
                    </TableCell>
                  </TableRow>
                )}) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                      {fileListerJob.status === 'IDLE' || fileListerJob.status === 'TRIGGERING' ? 'Use the filter and "Fetch Files" to load the list.' : fileListerJob.status === 'POLLING' ? 'Loading files...' : fileListerJob.status === 'FAILED' ? 'Failed to load files. Check status above.' : 'No files found for the selected filter in this container.'}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
        {selectedFilePaths.length > 0 && (
          <CardFooter className="border-t pt-4 flex-col items-start space-y-3">
             <div className="text-sm font-semibold text-primary">{getSelectedFilesSummary()}</div>
            {(fileProcessingJob.status !== 'IDLE') && (
                <div className={`p-3 rounded-md w-full text-sm ${fileProcessingJob.status === 'FAILED' ? 'bg-destructive/20 text-destructive-foreground' : 'bg-secondary/70'}`}>
                    <div className="flex items-center mb-1">
                        {fileProcessingJob.status === 'SUBMITTING' || fileProcessingJob.status === 'POLLING' ? <Loader2 className="inline mr-2 h-4 w-4 animate-spin" /> : fileProcessingJob.status === 'SUCCEEDED' ? <CheckCircle2 className="inline mr-2 h-4 w-4 text-green-500" /> : fileProcessingJob.status === 'FAILED' ? <AlertTriangle className="inline mr-2 h-4 w-4" /> : null}
                        <span className="font-medium">{fileProcessingJob.message}</span>
                    </div>
                    {fileProcessingJob.runId && fileProcessingJob.status !== 'SUCCEEDED' && fileProcessingJob.status !== 'FAILED' && <p className="text-xs text-muted-foreground">Processing Job ID: {fileProcessingJob.runId}</p>}
                    {(fileProcessingJob.status === 'POLLING' || fileProcessingJob.status === 'SUBMITTING') && typeof fileProcessingJob.progress === 'number' && fileProcessingJob.progress < 100 && (
                       <Progress value={fileProcessingJob.progress} className="w-full h-2 mt-2" />
                    )}
                </div>
            )}
            <Button
                onClick={handleAnalyzeFiles}
                disabled={selectedFilePaths.length === 0 || isProcessingFile || isFetchingFiles}
                className="self-end"
            >
              {isProcessingFile && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isProcessingFile ? 'Analyzing...' : `Analyze Selected Files for DQ`}
              {!isProcessingFile && <DatabaseZap className="ml-2 h-4 w-4" />}
            </Button>
          </CardFooter>
        )}
      </Card>

      {analysisHistory.length > 0 && (
        <Card className="shadow-md">
            <CardHeader>
                <CardTitle className="text-lg flex items-center">
                    <HistoryIcon className="mr-2 h-5 w-5 text-primary" /> Past Data Analyses
                </CardTitle>
                <CardDescription>
                    Successfully completed data sampling jobs. You can re-send any of these for rule suggestion. Max {MAX_ANALYSIS_HISTORY_ITEMS} items are kept.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <ScrollArea className="h-[300px]">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Analysis Name</TableHead>
                                <TableHead>Timestamp</TableHead>
                                <TableHead>Files Analyzed</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {analysisHistory.map(item => (
                                <TableRow key={item.id}>
                                    <TableCell className="font-medium">{item.dataSourceName}</TableCell>
                                    <TableCell>
                                        <FormattedDateTime date={new Date(item.timestamp)} formatter={(d) => d.toLocaleString()} placeholder="..." />
                                    </TableCell>
                                    <TableCell>
                                        {item.fileCount === 1 ? item.firstFileName : `${item.fileCount || 'Multiple'} files`}
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <Button variant="outline" size="sm" onClick={() => handleSendToSuggester(item.id)}>
                                            <Brain className="mr-2 h-4 w-4" /> Send to Suggester
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </ScrollArea>
            </CardContent>
        </Card>
      )}
    </div>
  );
}
    
