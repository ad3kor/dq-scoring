
"use server";

import { 
  analyzeDataQualityIssues, 
  type AnalyzeDataQualityIssuesInput, 
  type AnalyzeDataQualityIssuesOutput 
} from '@/ai/flows/analyze-data-quality-issues';
import { 
  suggestDQRules, 
  type SuggestDQRulesInput, 
  type SuggestDQRulesOutput 
} from '@/ai/flows/suggest-dq-rules';
import { z } from 'zod';

// --- Genkit AI (Gemini-based) Rule Suggestion ---
const analyzeDataQualityIssuesInputSchema = z.object({
  userQuery: z.string(),
  dataQualityReport: z.string(),
});

export async function analyzeDataQualityIssuesAction(
  input: AnalyzeDataQualityIssuesInput
): Promise<AnalyzeDataQualityIssuesOutput> {
  const validatedInput = analyzeDataQualityIssuesInputSchema.safeParse(input);
  if (!validatedInput.success) {
    throw new Error(`Invalid input: ${validatedInput.error.message}`);
  }
  try {
    return await analyzeDataQualityIssues(validatedInput.data);
  } catch (error) {
    console.error("Error in analyzeDataQualityIssuesAction:", error);
    return { answer: "Sorry, I encountered an error trying to process your request." };
  }
}

const suggestDQRulesInputSchema = z.object({
  dataSample: z.string(),
  completenessWeight: z.number().min(0).max(100),
  accuracyWeight: z.number().min(0).max(100),
  consistencyWeight: z.number().min(0).max(100),
  uniquenessWeight: z.number().min(0).max(100),
});

export async function suggestDQRulesWithGenkitAIAction(
  input: SuggestDQRulesInput
): Promise<SuggestDQRulesOutput> {
  const validatedInput = suggestDQRulesInputSchema.safeParse(input);
  if (!validatedInput.success) {
    throw new Error(`Invalid input: ${validatedInput.error.message}`);
  }

  try {
    return await suggestDQRules(validatedInput.data);
  } catch (error) {
    console.error("Error in suggestDQRulesWithGenkitAIAction:", error);
    return { suggestedRules: "[]" }; 
  }
}


// --- Databricks-driven Rule Suggestion ---
interface DatabricksRule {
  description: string;
  column: string; 
  rationale?: string;
  weight?: number;
  dimension?: "Accuracy" | "Completeness" | "Consistency" | "Uniqueness" | "Other";
  type?: string; 
}

export interface FetchRulesFromDatabricksOutput {
  rules: DatabricksRule[];
  error?: string;
}

export async function fetchRulesFromDatabricksAction(): Promise<FetchRulesFromDatabricksOutput> {
  try {
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:9002';
    console.log(`[fetchRulesFromDatabricksAction] Attempting to POST to: ${appUrl}/api/databricks-rule-suggester`);
    
    const response = await fetch(`${appUrl}/api/databricks-rule-suggester`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      let errorData;
      let errorMessage = `API request failed with status ${response.status}.`;
      try {
        errorData = await response.json();
        if (errorData && errorData.error) {
            errorMessage = `Databricks API Error: ${errorData.error}`;
        } else if (errorData && errorData.message) {
            errorMessage = `Databricks API Error: ${errorData.message}`;
        }
      } catch (e) {
        const rawText = await response.text().catch(() => "Could not read error response text.");
        console.error("[fetchRulesFromDatabricksAction] Non-JSON error response from API route:", rawText.substring(0,500), "Status:", response.status);
        errorMessage += ` Response: ${rawText.substring(0,100)}...`;
      }
      
      console.error("[fetchRulesFromDatabricksAction] Error response from /api/databricks-rule-suggester route:", errorMessage, "Full errorData:", errorData, "Status:", response.status);
      return { rules: [], error: errorMessage };
    }

    const result = await response.json();
    if (result.rules && Array.isArray(result.rules)) {
      return { rules: result.rules };
    } else {
      console.error("[fetchRulesFromDatabricksAction] Invalid or missing rules array from /api/databricks-rule-suggester:", result);
      return { rules: [], error: result.error || "Received invalid rule data from Databricks suggester." };
    }
  } catch (error: any) { 
    console.error("[fetchRulesFromDatabricksAction] Network or unexpected error when calling API route. Error Name:", error.name, "Message:", error.message);
    if(error.cause) {
        console.error("Underlying Cause:", error.cause);
    }
    // console.error("Full error object:", JSON.stringify(error, Object.getOwnPropertyNames(error))); // This can be too verbose for client

    let detailedErrorMessage = `Failed to connect to the rule suggester API. Message: ${error.message || 'Unknown fetch error'}`;
    if (error.code) { // e.g., ECONNREFUSED
        detailedErrorMessage += ` (Code: ${error.code})`;
    }
    if (error.cause) {
      const causeString = typeof error.cause === 'string' ? error.cause : 
                          (error.cause.message ? error.cause.message : JSON.stringify(error.cause));
      detailedErrorMessage += `. Cause: ${causeString}`;
    }
    return { rules: [], error: detailedErrorMessage };
  }
}
