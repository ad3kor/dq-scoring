
"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { setCurrentMockUser } from '@/lib/authUtils';
import { Icons } from '@/components/icons';

export default function MockLoginPage() {
  const [username, setUsername] = useState('');
  const router = useRouter();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      setCurrentMockUser(username.trim());
      router.push('/dashboard');
    }
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <Icons.Logo className="w-16 h-16 text-primary" />
          </div>
          <CardTitle className="text-3xl">Welcome to DataQualityLens</CardTitle>
          <CardDescription>Enter a username to simulate a session.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username">Username (e.g., user@example.com)</Label>
              <Input
                id="username"
                type="text"
                placeholder="Enter your desired username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                className="text-base"
              />
            </div>
            <Button type="submit" className="w-full text-lg py-6">
              Access Dashboard
            </Button>
          </form>
        </CardContent>
      </Card>
      <p className="mt-8 text-xs text-muted-foreground">
        This is a mock login for demonstration purposes. No real authentication is performed.
      </p>
    </div>
  );
}
