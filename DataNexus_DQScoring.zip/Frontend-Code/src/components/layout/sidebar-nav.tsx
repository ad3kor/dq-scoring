"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { NavItem } from '@/config/nav';
import { cn } from '@/lib/utils';
import {
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from '@/components/ui/sidebar';
import { Icons } from '@/components/icons'; // Assuming Icons.Logo might be used in header

interface SidebarNavProps {
  items: NavItem[];
}

export function SidebarNav({ items }: SidebarNavProps) {
  const pathname = usePathname();

  if (!items?.length) {
    return null;
  }

  return (
    <SidebarMenu>
      {items.map((item, index) => {
        const IconComponent = item.icon;
        const isActive = pathname === item.href || (pathname.startsWith(item.href) && item.href !== '/');


        return item.href ? (
          <SidebarMenuItem key={index}>
            <Link href={item.href} legacyBehavior passHref>
              <SidebarMenuButton
                variant="default"
                size="default"
                isActive={isActive}
                tooltip={item.title}
                className="justify-start"
                disabled={item.disabled}
              >
                <IconComponent className="h-5 w-5" />
                <span>{item.title}</span>
                {item.label && (
                  <span className="ml-auto rounded-md bg-primary px-1.5 py-0.5 text-xs no-underline group-hover:no-underline text-primary-foreground">
                    {item.label}
                  </span>
                )}
              </SidebarMenuButton>
            </Link>
          </SidebarMenuItem>
        ) : (
          <span
            key={index}
            className={cn(
              "flex w-full cursor-not-allowed items-center rounded-md p-2 text-muted-foreground hover:underline",
              item.disabled && "cursor-not-allowed opacity-60"
            )}
          >
            {item.title}
          </span>
        );
      })}
    </SidebarMenu>
  );
}
