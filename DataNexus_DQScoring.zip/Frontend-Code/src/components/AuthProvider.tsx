
"use client";

import React, { useEffect, useState, ReactNode } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { getCurrentMockUser } from '@/lib/authUtils';
import { Skeleton } from '@/components/ui/skeleton'; // For loading state

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const router = useRouter();
  const pathname = usePathname();
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const user = getCurrentMockUser();
    if (!user && pathname !== '/login-mock') {
      router.replace('/login-mock');
    } else if (user) {
      setCurrentUser(user);
      if (pathname === '/login-mock') {
        router.replace('/dashboard'); // Redirect if user is logged in and on login page
      }
    }
    setIsLoading(false);
  }, [pathname, router]);

  if (isLoading) {
    // Optional: Show a more sophisticated loading screen
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="space-y-4 p-8">
          <Skeleton className="h-12 w-12 rounded-full mx-auto" />
          <Skeleton className="h-6 w-48 mx-auto" />
          <Skeleton className="h-4 w-64 mx-auto" />
        </div>
      </div>
    );
  }

  if (!currentUser && pathname !== '/login-mock') {
    // This case should ideally be handled by the redirect in useEffect,
    // but acts as a fallback or if the effect hasn't run yet on initial bad navigation.
    // For client-side only rendering this might be less critical.
    return null; // Or a loading/redirecting indicator
  }

  return <>{children}</>;
}
