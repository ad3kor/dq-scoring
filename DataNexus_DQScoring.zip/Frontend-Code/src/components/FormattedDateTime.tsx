
"use client";

import { useState, useEffect } from 'react';

interface FormattedDateTimeProps {
  date: Date | undefined | null;
  formatter: (date: Date) => string;
  placeholder?: string;
}

export function FormattedDateTime({ date, formatter, placeholder = "" }: FormattedDateTimeProps) {
  const [formattedString, setFormattedString] = useState<string>(placeholder);

  useEffect(() => {
    if (date) {
      try {
        setFormattedString(formatter(new Date(date))); // Ensure it's a Date object
      } catch (e) {
        console.error("Error formatting date:", e);
        setFormattedString("Invalid Date");
      }
    } else {
      // Handle case where date might initially be undefined or null
      // You might want to keep the placeholder or set to an empty string
      setFormattedString(placeholder);
    }
  }, [date, formatter, placeholder]);

  return <>{formattedString}</>;
}
