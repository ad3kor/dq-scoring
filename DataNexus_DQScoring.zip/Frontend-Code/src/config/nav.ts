
import type { LucideIcon } from 'lucide-react';
import { LayoutDashboard, Database, ListChecks, PlayCircle, FileText, MessageCircle, ShieldCheck, Settings, CloudCog, Sparkles, Route, Briefcase } from 'lucide-react'; // Added Briefcase

export interface NavItem {
  title: string;
  href: string;
  icon: LucideIcon;
  label?: string;
  disabled?: boolean;
  external?: boolean;
}

export const navItems: NavItem[] = [
  {
    title: 'Dashboard',
    href: '/dashboard',
    icon: LayoutDashboard,
  },
  {
    title: 'Data Sources',
    href: '/data-sources',
    icon: Database,
  },
  {
    title: 'Data Nexus Storage', // Updated title
    href: '/data-nexus',       // Points to the overhauled page
    icon: Briefcase,           // Using Briefcase as a generic storage browser icon
  },
  {
    title: 'Rules Editor (Genkit)',
    href: '/rules-editor',
    icon: ListChecks,
  },
  {
    title: 'Databricks Suggester',
    href: '/databricks-suggester',
    icon: Sparkles,
  },
  {
    title: 'Data Nexus Assessment',
    href: '/data-nexus-assessment',
    icon: Route,
  },
  {
    title: 'Old Assessment (Sim)',
    href: '/assessment',
    icon: PlayCircle,
  },
  {
    title: 'Reports',
    href: '/reports',
    icon: FileText,
  },
  {
    title: 'AI Chatbot',
    href: '/chatbot',
    icon: MessageCircle,
  },
  {
    title: 'Auditing',
    href: '/auditing',
    icon: ShieldCheck,
  },
];
    
    