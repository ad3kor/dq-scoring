# **App Name**: DataQualityLens

## Core Features:

- Data Source Selection: Allows users to specify data sources via Streamlit UI: Delta Lake tables, CSV/JSON files from cloud storage.
- LLM Rule Suggestion: LLM-powered suggestion of DQ rules based on data profiling summaries for dimensions like Completeness, Accuracy. LLM acts as a tool suggesting appropriate validation constraints.
- Interactive Rule Editor: Interactive Streamlit-based rule management interface for modifying LLM suggestions or creating custom rules and weighting DQ dimensions.
- DQ Rule Execution: Execution of DQ rules via Spark on the selected data source, leveraging Unity Catalog-governed data.
- Report Generation: Automated generation of PDF reports summarizing DQ metrics per dimension.
- AI Chatbot for Issue Analysis: Natural language querying via a chatbot powered by Databricks Vector Search (primary) or Weaviate (fallback). LLM synthesizes data + context from Vector DB to respond to user queries about anomalies.
- Auditing and Governance: Auditing user actions and configuration changes, data lineage via Unity Catalog

## Style Guidelines:

- Primary color: Deep teal (#008080) to evoke trust, data focus, and enterprise feel. Not overbearing. Can work in dark or light scheme, but better suited to dark.
- Background color: Dark gray (#222831) to ensure excellent readability and visual comfort for long usage.
- Accent color: Soft Yellow (#FFD369) to highlight key interactive elements, action buttons, and important readouts.
- Clean, sans-serif fonts optimized for readability. Consistent font sizes and weights to ensure information hierarchy.
- Simple, consistent icons to represent different data sources, DQ dimensions, and actions.
- Intuitive tab-based navigation. Clearly defined sections for data source selection, rule management, assessment, reporting, and RAG.
- Subtle loading animations and progress indicators for DQ assessment and report generation.
- Streamlit-based User Interface